package com.example.hesabyar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import java.util.Locale;
import java.util.UUID;

public class BankSmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        try {
            if (!android.preference.PreferenceManager.getDefaultSharedPreferences(context).getBoolean("bank_sms_enabled", false)) return;
            SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
            if (messages == null || messages.length == 0) return;
            StringBuilder body = new StringBuilder();
            String sender = "";
            long timestamp = 0;
            for (SmsMessage m : messages) {
                if (m == null) continue;
                if (sender.isEmpty() && m.getOriginatingAddress() != null) sender = m.getOriginatingAddress();
                if (body.length() > 0) body.append("");
                if (m.getMessageBody() != null) body.append(m.getMessageBody());
                timestamp = Math.max(timestamp, m.getTimestampMillis());
            }
            String text = body.toString().trim();
            if (!text.isEmpty() && isCandidate(sender, text))
                save(context, "پیامک", sender, text, timestamp > 0 ? timestamp : System.currentTimeMillis());
        } catch (Exception ignored) { }
    }
    private static boolean isCandidate(String sender, String body) {
        String x = norm((sender == null ? "" : sender) + " " + body);
        boolean action = has(x, "برداشت","واریز","خرید","پرداخت","انتقال","تراکنش","کسر","واریزشد","برداشتشد",
                "مانده","موجودی","کارتبهکارت","پایا","ساتنا","withdraw","deposit","purchase","transaction","transfer","debit","credit");
        boolean money = x.matches("(?s).*[0-9]{1,3}([,٬،.][0-9]{3})+.*")
                || x.matches("(?s).*[0-9]{4,}.*") || has(x,"ریال","تومان","تومن");
        boolean bank = has(x,"بانک","بلو","blubank","ملت","ملی","صادرات","تجارت","سامان","پاسارگاد","رفاه",
                "کشاورزی","بانکینو","bank","shaparak","شتاب","شمارهکارت");
        // Sender IDs are often numeric/short codes; action + money is enough to queue for review.
        return action && money && (bank || sender != null && !sender.trim().isEmpty() || money);
    }
    private static String norm(String s) {
        return s.toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک').replace('‌',' ')
                .replaceAll("[\\s\\p{Punct}]+","");
    }
    private static boolean has(String s, String... terms) { for (String t:terms) if(s.contains(norm(t))) return true; return false; }
    public static void save(Context c,String source,String sender,String raw,long time) {
        if(c==null||raw==null||raw.trim().isEmpty())return;
        String value=(source==null?"بانک":source)+"\n"+time+"\n"+(sender==null?"":sender)+"\n"+raw.trim();
        c.getSharedPreferences("bank_import_candidates",Context.MODE_PRIVATE).edit()
                .putString("candidate_"+UUID.randomUUID(),value).apply();
    }
}
