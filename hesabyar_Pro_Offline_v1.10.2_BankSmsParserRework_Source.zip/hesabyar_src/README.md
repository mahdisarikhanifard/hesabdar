# hesabyar Pro Offline — v1.9.3

سورس نسخه `1.9.3-Pro-UnifiedBankImport` با فضای نام کد اندروید `com.example.hesabyar`.

## شناسه نصب و سازگاری
`applicationId` برابر `com.example.hisabyarpro` حفظ شده تا نصب موجود از نظر شناسه برنامه دچار تغییر نشود. namespace و مسیر Java به `com.example.hesabyar` منتقل شده‌اند.

## اجرای GitHub Actions
1. ZIP را استخراج کنید.
2. محتویات را در ریشه مخزن `mahdisarikhanifard/hesabdar` قرار دهید و commit کنید؛ خود ZIP به‌تنهایی اجرا ایجاد نمی‌کند.
3. فایل `.github/workflows/build-apk.yml` باید در مسیر دقیق ریشه مخزن باشد.
4. از Actions گزینه Run workflow را اجرا کنید.
5. APK پس از build موفق در Artifacts قرار می‌گیرد.

- Version code: 193
- Version name: `1.9.3-Pro-UnifiedBankImport`
