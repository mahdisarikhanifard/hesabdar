package com.example.hesabyar;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import java.util.Locale;
import java.util.UUID;

public class BankNotificationListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getPackageName() == null || sbn.getPackageName().equals(getPackageName())) return;
        try {
            if (!android.preference.PreferenceManager.getDefaultSharedPreferences(this)
                    .getBoolean("bank_notifications_enabled", false)) return;
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;
            Bundle e = n.extras;
            StringBuilder raw = new StringBuilder();
            append(raw, e.getCharSequence(Notification.EXTRA_TITLE));
            append(raw, e.getCharSequence(Notification.EXTRA_TEXT));
            append(raw, e.getCharSequence(Notification.EXTRA_BIG_TEXT));
            CharSequence[] lines = e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
            if (lines != null) for (CharSequence line : lines) append(raw, line);
            if (android.os.Build.VERSION.SDK_INT >= 24) {
                android.os.Parcelable[] messages = e.getParcelableArray(Notification.EXTRA_MESSAGES);
                if (messages != null) for (android.os.Parcelable item : messages) {
                    if (item instanceof Bundle) append(raw, ((Bundle)item).getCharSequence("text"));
                }
            }
            String text = raw.toString().trim();
            if (text.isEmpty() || !isCandidate(sbn.getPackageName(), text)) return;
            String value = "اعلان\n" + sbn.getPostTime() + "\n" + sbn.getPackageName() + "\n" + text;
            getSharedPreferences("bank_import_candidates", MODE_PRIVATE).edit()
                    .putString("candidate_" + UUID.randomUUID(), value).apply();
        } catch (Exception ignored) { }
    }
    private void append(StringBuilder b, CharSequence s) {
        if (s == null || TextUtils.isEmpty(s)) return;
        if (b.length() > 0) b.append('\n');
        b.append(s);
    }
    private boolean isCandidate(String pkg, String raw) {
        String x = norm(pkg + " " + raw);
        boolean action = has(x,"برداشت","واریز","خرید","پرداخت","انتقال","تراکنش","کسر","کارتبهکارت",
                "پایا","ساتنا","withdraw","deposit","purchase","transaction","transfer","debit","credit");
        boolean money = x.matches("(?s).*[0-9]{1,3}([,٬،.][0-9]{3})+.*")
                || x.matches("(?s).*[0-9]{4,}.*") || has(x,"ریال","تومان","تومن");
        boolean knownApp = has(x,"blubank","blu","bankino","mellat","saderat","tejarat","sepah","melli",
                "refah","saman","pasargad","shahr","ayandeh","parsian","resalat","بانک");
        return action && money && (knownApp || has(x,"مانده","موجودی","شمارهکارت") || !pkg.isEmpty());
    }
    private String norm(String s) {
        if (s == null) return "";
        StringBuilder digits = new StringBuilder(s.length());
        for (int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if (c>='۰' && c<='۹') c=(char)('0'+(c-'۰'));
            else if (c>='٠' && c<='٩') c=(char)('0'+(c-'٠'));
            digits.append(c);
        }
        return digits.toString().toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک').replace('‌',' ')
                .replaceAll("[\\s\\p{Punct}]+","");
    }
    private boolean has(String s,String... terms) { for(String t:terms) if(s.contains(norm(t))) return true; return false; }
}
