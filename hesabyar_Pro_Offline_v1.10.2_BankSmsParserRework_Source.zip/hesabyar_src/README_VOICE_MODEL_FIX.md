# Hesabyar Pro Offline — 1.9.6 Voice Model Fix

- Application ID retained: `com.example.hesabyarpro`
- Namespace retained: `com.example.hesabyar`
- Version: `1.9.6-Pro-VoiceModelFix` (versionCode 196)
- Source base: Hesabyar Pro 1.9.5 BankAmountFix.

## Persian offline voice model

The app calls Vosk `StorageService.unpack(this, "model-fa", ...)`. It requires
`app/src/main/assets/model-fa/` with `uuid`, `am/final.mdl`, `conf/model.conf`,
and graph assets. The accompanying GitHub Actions workflow fetches the model on
the build runner, validates these files, and checks they are present inside the
APK. The installed app uses the model offline; it does not fetch the model on
the phone.

Build using `build-apk-hesabyar-v1.9.6.yml` and this source ZIP.
