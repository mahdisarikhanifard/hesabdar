package com.example.hisabyar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(25, 104, 77);
    private static final int DARK = Color.rgb(20, 68, 54);
    private static final int BG = Color.rgb(245, 247, 245);
    private static final int TEXT = Color.rgb(35, 45, 40);
    private DB db;
    private LinearLayout root, body, topbar;
    private String activeBook = "شخصی";
    private String page = "خانه";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        ensureDefaults();
        showShell();
        showHome();
    }

    private void ensureDefaults() {
        SQLiteDatabase w = db.getWritableDatabase();
        if (count("books") == 0) {
            addBookRaw("شخصی");
            addBookRaw("کسب‌وکار");
        }
        if (countForBook("accounts", activeBook) == 0) {
            ContentValues v = new ContentValues();
            v.put("book", activeBook); v.put("name", "پول نقد"); v.put("kind", "نقدی"); v.put("opening", 0L);
            w.insert("accounts", null, v);
        }
        if (count("categories") == 0) {
            String[][] cats = {{"هزینه","خوراک"},{"هزینه","مسکن"},{"هزینه","حمل‌ونقل"},{"هزینه","سلامت"},{"هزینه","خرید شخصی"},{"هزینه","قبوض"},{"هزینه","تفریح"},{"هزینه","سایر"},{"درآمد","حقوق"},{"درآمد","کسب‌وکار"},{"درآمد","سرمایه‌گذاری"},{"درآمد","سایر"}};
            for (String[] c : cats) { ContentValues v = new ContentValues(); v.put("type",c[0]); v.put("name",c[1]); w.insert("categories",null,v); }
        }
    }
    private long count(String table) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private long countForBook(String table, String book) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+" WHERE book=?",new String[]{book});
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private void addBookRaw(String name) {
        ContentValues v=new ContentValues(); v.put("name",name); db.getWritableDatabase().insert("books",null,v);
    }

    private void showShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        topbar = new LinearLayout(this); topbar.setOrientation(LinearLayout.VERTICAL); topbar.setPadding(dp(18),dp(16),dp(18),dp(12)); topbar.setBackgroundColor(DARK);
        TextView title = text("حساب‌یار",24,Color.WHITE,true); topbar.addView(title);
        TextView subtitle = text("حسابداری شخصی و مدیریت دارایی",13,Color.rgb(215,235,225),false); topbar.addView(subtitle);
        root.addView(topbar);
        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(14),dp(12),dp(14),dp(8));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this); nav.setBackgroundColor(Color.WHITE); nav.setElevation(dp(8));
        String[] tabs={"خانه","تراکنش‌ها","ثبت","دارایی‌ها","تنظیمات"};
        for(String t:tabs){ Button b=button(t); b.setTextSize(12); b.setPadding(dp(2),dp(10),dp(2),dp(10)); b.setBackgroundColor(Color.WHITE); b.setTextColor(GREEN); nav.addView(b,new LinearLayout.LayoutParams(0,dp(54),1)); b.setOnClickListener(v->navigate(t)); }
        root.addView(nav); setContentView(root);
    }
    private void navigate(String p) {
        page=p; body.removeAllViews();
        switch(p) {
            case "خانه": showHome(); break;
            case "تراکنش‌ها": showTransactions(); break;
            case "ثبت": showAddMenu(); break;
            case "دارایی‌ها": showAssets(); break;
            default: showSettings(); break;
        }
    }
    private void showHome() {
        body.removeAllViews();
        addHeading("خلاصه وضعیت مالی");
        LinearLayout bookrow=new LinearLayout(this); bookrow.setGravity(Gravity.CENTER_VERTICAL);
        TextView bl=text("دفتر فعال: "+activeBook,15,TEXT,true); bookrow.addView(bl,new LinearLayout.LayoutParams(0,-2,1));
        Button switchB=button("تغییر دفتر"); bookrow.addView(switchB); switchB.setOnClickListener(v->chooseBook()); body.addView(bookrow);
        long income=sum("درآمد"), expense=sum("هزینه"), balance=balance();
        addMetric("موجودی حساب‌های این دفتر", money(balance), GREEN);
        LinearLayout pair=new LinearLayout(this);
        pair.addView(metricBox("درآمد ثبت‌شده",money(income),GREEN),new LinearLayout.LayoutParams(0,-2,1));
        pair.addView(metricBox("هزینه ثبت‌شده",money(expense),Color.rgb(183,74,60)),new LinearLayout.LayoutParams(0,-2,1));
        body.addView(pair);
        addHeading("ثبت سریع");
        LinearLayout row1=new LinearLayout(this);
        row1.addView(actionBox("＋ ثبت هزینه",()->showEntry("هزینه")),new LinearLayout.LayoutParams(0,dp(76),1));
        row1.addView(actionBox("＋ ثبت درآمد",()->showEntry("درآمد")),new LinearLayout.LayoutParams(0,dp(76),1));
        body.addView(row1);
        LinearLayout row2=new LinearLayout(this);
        row2.addView(actionBox("⇄ انتقال پول",()->showTransfer()),new LinearLayout.LayoutParams(0,dp(76),1));
        row2.addView(actionBox("＋ دارایی",()->showAssetDialog()),new LinearLayout.LayoutParams(0,dp(76),1));
        body.addView(row2);
        addHeading("آخرین تراکنش‌ها");
        showRecentIntoBody();
    }
    private View metricBox(String label,String value,int color) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(12),dp(14),dp(12),dp(14)); box.setBackground(roundBg(Color.WHITE));
        TextView a=text(label,13,Color.GRAY,false), b=text(value,17,color,true); box.addView(a); box.addView(b); return box;
    }
    private void addMetric(String label,String value,int color) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(18),dp(16),dp(18)); box.setBackground(roundBg(Color.WHITE));
        TextView a=text(label,14,Color.GRAY,false), b=text(value,25,color,true); box.addView(a); box.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(10),0,dp(10)); body.addView(box,lp);
    }
    private void showAddMenu() {
        body.removeAllViews(); addHeading("ثبت عملیات مالی");
        addWideButton("ثبت هزینه",()->showEntry("هزینه"));
        addWideButton("ثبت درآمد",()->showEntry("درآمد"));
        addWideButton("انتقال بین حساب‌ها",()->showTransfer());
        addWideButton("ثبت دارایی",()->showAssetDialog());
        addWideButton("ثبت بدهی یا طلب",()->showDebtDialog());
    }
    private void showEntry(String type) {
        LinearLayout form=formLayout();
        EditText amount=edit("مبلغ به تومان",InputType.TYPE_CLASS_NUMBER);
        EditText category=edit("دسته‌بندی (مثلاً خوراک)",InputType.TYPE_CLASS_TEXT);
        EditText account=edit("حساب (مثلاً پول نقد)",InputType.TYPE_CLASS_TEXT);
        EditText note=edit("شرح / یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        form.addView(amount); form.addView(category); form.addView(account); form.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت "+type).setView(form)
          .setNegativeButton("انصراف",null).setPositiveButton("ثبت", (d,w)->{
              long a=parseAmount(amount.getText().toString());
              if(a<=0){toast("مبلغ باید بیشتر از صفر باشد");return;}
              String cat=category.getText().toString().trim(); if(cat.isEmpty()) cat=type.equals("هزینه")?"سایر":"سایر";
              String acc=account.getText().toString().trim(); if(acc.isEmpty()) acc="پول نقد";
              ensureAccount(acc);
              ContentValues v=new ContentValues(); v.put("book",activeBook); v.put("type",type); v.put("amount",a); v.put("category",cat); v.put("account",acc); v.put("note",note.getText().toString()); v.put("date",System.currentTimeMillis());
              db.getWritableDatabase().insert("transactions",null,v);
              toast("تراکنش ثبت شد"); navigate("خانه");
          }).show();
    }
    private void showTransfer() {
        LinearLayout f=formLayout();
        EditText from=edit("از حساب",InputType.TYPE_CLASS_TEXT), to=edit("به حساب",InputType.TYPE_CLASS_TEXT), amt=edit("مبلغ به تومان",InputType.TYPE_CLASS_NUMBER), note=edit("شرح (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(from);f.addView(to);f.addView(amt);f.addView(note);
        new AlertDialog.Builder(this).setTitle("انتقال پول").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ثبت انتقال",(d,w)->{
            long a=parseAmount(amt.getText().toString()); String fr=from.getText().toString().trim(),toN=to.getText().toString().trim();
            if(a<=0||fr.isEmpty()||toN.isEmpty()||fr.equals(toN)){toast("حساب‌ها و مبلغ را درست وارد کن");return;}
            ensureAccount(fr);ensureAccount(toN);
            SQLiteDatabase s=db.getWritableDatabase();
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("type","انتقال خروجی");v.put("amount",a);v.put("category","انتقال");v.put("account",fr);v.put("note","به "+toN+"؛ "+note.getText());v.put("date",System.currentTimeMillis());s.insert("transactions",null,v);
            ContentValues x=new ContentValues();x.put("book",activeBook);x.put("type","انتقال ورودی");x.put("amount",a);x.put("category","انتقال");x.put("account",toN);x.put("note","از "+fr+"؛ "+note.getText());x.put("date",System.currentTimeMillis());s.insert("transactions",null,x);
            toast("انتقال ثبت شد");navigate("خانه");
        }).show();
    }
    private void showTransactions() {
        body.removeAllViews(); addHeading("تراکنش‌های دفتر "+activeBook);
        Button add=button("＋ ثبت تراکنش"); body.addView(add); add.setOnClickListener(v->showAddMenu());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT type,amount,category,account,note,date FROM transactions WHERE book=? ORDER BY date DESC LIMIT 200",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز تراکنشی ثبت نشده است.");return;}
        do {
            String type=c.getString(0); long amount=c.getLong(1); String cat=c.getString(2), acc=c.getString(3), note=c.getString(4);
            LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(dp(12),dp(10),dp(12),dp(10)); item.setBackground(roundBg(Color.WHITE));
            TextView line=text(cat+"  •  "+type,15,TEXT,true); item.addView(line);
            item.addView(text(acc+"  |  "+money(amount),14,type.equals("هزینه")||type.equals("انتقال خروجی")?Color.rgb(183,74,60):GREEN,false));
            if(note!=null&&!note.isEmpty()) item.addView(text(note,12,Color.GRAY,false));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        } while(c.moveToNext()); c.close();
    }
    private void showRecentIntoBody() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT type,amount,category,account FROM transactions WHERE book=? ORDER BY date DESC LIMIT 5",new String[]{activeBook});
        if(!c.moveToFirst()){addEmpty("هنوز تراکنشی ثبت نشده است.");c.close();return;}
        do { String t=c.getString(0); long a=c.getLong(1); String cat=c.getString(2),acc=c.getString(3);
            TextView v=text(cat+"  •  "+money(a)+"\n"+t+" | "+acc,14,TEXT,false);v.setPadding(dp(10),dp(10),dp(10),dp(10));v.setBackground(roundBg(Color.WHITE));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);
        }while(c.moveToNext());c.close();
    }
    private void showAssets() {
        body.removeAllViews(); addHeading("دارایی‌ها و ارزش خالص");
        Button add=button("＋ افزودن دارایی");body.addView(add);add.setOnClickListener(v->showAssetDialog());
        long total=0; Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,value,note FROM assets WHERE book=? ORDER BY name",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز دارایی ثبت نشده است.");return;}
        do {String name=c.getString(0),kind=c.getString(1),note=c.getString(3);long val=c.getLong(2);total+=val;
            LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setPadding(dp(12),dp(10),dp(12),dp(10));item.setBackground(roundBg(Color.WHITE));
            item.addView(text(name+" • "+kind,15,TEXT,true));item.addView(text(money(val),16,GREEN,true));if(note!=null&&!note.isEmpty())item.addView(text(note,12,Color.GRAY,false));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        }while(c.moveToNext());c.close();
        addMetric("ارزش دارایی‌های ثبت‌شده",money(total),GREEN);
    }
    private void showAssetDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام دارایی",InputType.TYPE_CLASS_TEXT),kind=edit("نوع (طلا، خودرو، ملک و ...)",InputType.TYPE_CLASS_TEXT),value=edit("ارزش فعلی به تومان",InputType.TYPE_CLASS_NUMBER),note=edit("یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(name);f.addView(kind);f.addView(value);f.addView(note);
        new AlertDialog.Builder(this).setTitle("افزودن دارایی").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long val=parseAmount(value.getText().toString());if(name.getText().toString().trim().isEmpty()||val<0){toast("نام و ارزش دارایی را بررسی کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name.getText().toString().trim());v.put("kind",kind.getText().toString().trim());v.put("value",val);v.put("note",note.getText().toString());db.getWritableDatabase().insert("assets",null,v);navigate("دارایی‌ها");
        }).show();
    }
    private void showDebtDialog() {
        LinearLayout f=formLayout();EditText person=edit("نام شخص",InputType.TYPE_CLASS_TEXT),kind=edit("طلب از شخص یا بدهی به شخص",InputType.TYPE_CLASS_TEXT),amount=edit("مبلغ کل به تومان",InputType.TYPE_CLASS_NUMBER),note=edit("شرح",InputType.TYPE_CLASS_TEXT);
        f.addView(person);f.addView(kind);f.addView(amount);f.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت بدهی یا طلب").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long a=parseAmount(amount.getText().toString());if(a<=0||person.getText().toString().trim().isEmpty()){toast("نام و مبلغ را وارد کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("person",person.getText().toString().trim());v.put("kind",kind.getText().toString().trim().isEmpty()?"طلب از شخص":kind.getText().toString().trim());v.put("amount",a);v.put("paid",0);v.put("note",note.getText().toString());v.put("date",System.currentTimeMillis());db.getWritableDatabase().insert("debts",null,v);toast("ثبت شد؛ مدیریت اقساط در مرحله بعد تکمیل می‌شود");
        }).show();
    }
    private void showSettings() {
        body.removeAllViews();addHeading("تنظیمات");
        addWideButton("مدیریت دفترها",()->manageBooks());
        addWideButton("افزودن حساب بانکی یا کیف پول",()->addAccountDialog());
        addWideButton("درباره برنامه",()->new AlertDialog.Builder(this).setTitle("حساب‌یار ۰.۱").setMessage("نسخه آغازین حسابداری شخصی فارسی؛ اطلاعات به‌صورت محلی روی گوشی ذخیره می‌شوند. پشتیبان‌گیری و امکانات تکمیلی در مراحل بعد اضافه می‌شوند.").setPositiveButton("باشه",null).show());
        addEmpty("واحد نمایش: تومان • زبان: فارسی\nاطلاعات این نسخه فقط روی همین گوشی ذخیره می‌شود.");
    }
    private void chooseBook() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM books ORDER BY id",null);java.util.ArrayList<String> names=new java.util.ArrayList<>();while(c.moveToNext())names.add(c.getString(0));c.close();
        String[] a=names.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("انتخاب دفتر").setItems(a,(d,w)->{activeBook=a[w];ensureBookAccount();navigate("خانه");}).setNegativeButton("انصراف",null).show();
    }
    private void manageBooks() {
        LinearLayout f=formLayout();EditText name=edit("نام دفتر جدید (مثلاً شخصی، گلخانه)",InputType.TYPE_CLASS_TEXT);f.addView(name);
        new AlertDialog.Builder(this).setTitle("افزودن دفتر مالی").setView(f).setNeutralButton("انتخاب دفتر",(d,w)->chooseBook()).setNegativeButton("بستن",null).setPositiveButton("افزودن",(d,w)->{String n=name.getText().toString().trim();if(!n.isEmpty()){addBookRaw(n);activeBook=n;ensureBookAccount();toast("دفتر اضافه شد");navigate("خانه");}}).show();
    }
    private void addAccountDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام حساب",InputType.TYPE_CLASS_TEXT),kind=edit("نوع حساب (بانکی/نقدی/کیف پول)",InputType.TYPE_CLASS_TEXT),opening=edit("موجودی اولیه به تومان",InputType.TYPE_CLASS_NUMBER);f.addView(name);f.addView(kind);f.addView(opening);
        new AlertDialog.Builder(this).setTitle("حساب جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty())return;ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("kind",kind.getText().toString());v.put("opening",parseAmount(opening.getText().toString()));db.getWritableDatabase().insert("accounts",null,v);navigate("خانه");}).show();
    }
    private void ensureAccount(String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{activeBook,name});boolean exists=c.moveToFirst();c.close();
        if(!exists){ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name);v.put("kind","نقدی");v.put("opening",0);db.getWritableDatabase().insert("accounts",null,v);}
    }
    private void ensureBookAccount() { if(countForBook("accounts",activeBook)==0)ensureAccount("پول نقد"); }
    private long sum(String type) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=?",new String[]{activeBook,type});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;
    }
    private long balance() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(opening),0) FROM accounts WHERE book=?",new String[]{activeBook});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();
        Cursor t=db.getReadableDatabase().rawQuery("SELECT type,amount FROM transactions WHERE book=?",new String[]{activeBook});
        while(t.moveToNext()){String type=t.getString(0);long a=t.getLong(1);if(type.equals("درآمد")||type.equals("انتقال ورودی"))n+=a;else if(type.equals("هزینه")||type.equals("انتقال خروجی"))n-=a;}t.close();return n;
    }
    private long parseAmount(String s) { try{return Long.parseLong(s.replace(",","").replace("٬","").trim());}catch(Exception e){return 0;} }
    private String money(long n) { NumberFormat f=NumberFormat.getInstance(new Locale("fa","IR"));return f.format(n)+" تومان"; }
    private void addHeading(String s) {TextView t=text(s,18,TEXT,true);t.setPadding(0,dp(8),0,dp(10));body.addView(t);}
    private void addEmpty(String s) {TextView t=text(s,14,Color.GRAY,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(16),dp(20),dp(16),dp(20));body.addView(t);}
    private void addWideButton(String s,Runnable r) {Button b=button(s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.setMargins(0,dp(5),0,dp(5));body.addView(b,lp);b.setOnClickListener(v->r.run());}
    private View actionBox(String s,Runnable r) {TextView t=text(s,15,GREEN,true);t.setGravity(Gravity.CENTER);t.setBackground(roundBg(Color.WHITE));t.setOnClickListener(v->r.run());return t;}
    private LinearLayout formLayout(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(20),dp(8),dp(20),dp(4));return l;}
    private EditText edit(String hint,int inputType){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine(true);e.setInputType(inputType);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(dp(8),dp(6),dp(8),dp(6));return e;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(0,dp(3),0,dp(3));return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(GREEN);b.setAllCaps(false);return b;}
    private android.graphics.drawable.GradientDrawable roundBg(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private class DB extends SQLiteOpenHelper {
        DB(Activity a){super(a,"hisabyar.db",null,1);}
        @Override public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE)");
            d.execSQL("CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,opening INTEGER NOT NULL DEFAULT 0)");
            d.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,name TEXT NOT NULL)");
            d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,note TEXT,date INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE assets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,value INTEGER NOT NULL,note TEXT)");
            d.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,person TEXT NOT NULL,kind TEXT,amount INTEGER NOT NULL,paid INTEGER NOT NULL DEFAULT 0,note TEXT,date INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE budgets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,category TEXT NOT NULL,month TEXT NOT NULL,limit_amount INTEGER NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int oldVersion,int newVersion){}
    }
}
