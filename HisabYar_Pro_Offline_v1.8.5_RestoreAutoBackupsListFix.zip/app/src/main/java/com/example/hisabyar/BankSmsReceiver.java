package com.example.hisabyar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import java.util.Locale;
import java.util.UUID;

/** Captures likely bank SMS locally for user review; it never posts directly to accounting. */
public class BankSmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        try {
            if (!android.preference.PreferenceManager.getDefaultSharedPreferences(context)
                    .getBoolean("bank_sms_enabled", false)) return;
            for (SmsMessage message : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                if (message == null) continue;
                String body = message.getMessageBody();
                if (body == null || body.trim().isEmpty()) continue;
                String sender = message.getOriginatingAddress() == null ? "" : message.getOriginatingAddress();
                String searchable = (sender + " " + body).toLowerCase(Locale.ROOT);
                if (isLikelyBankMessage(searchable)) {
                    save(context, "پیامک", sender, body, message.getTimestampMillis());
                }
            }
        } catch (Exception ignored) {
            // Do not crash the SMS delivery pipeline; candidate remains local-only.
        }
    }

    private static boolean isLikelyBankMessage(String text) {
        return text.contains("برداشت") || text.contains("واریز") || text.contains("خرید")
                || text.contains("مانده") || text.contains("انتقال") || text.contains("بلو")
                || text.contains("پرداخت") || text.contains("تراکنش")
                || text.contains("transaction") || text.contains("withdrawal")
                || text.contains("deposit");
    }

    /** Stores raw candidate locally. De-duplication and financial registration happen later. */
    public static void save(Context context, String source, String sender, String raw, long timestamp) {
        if (context == null || raw == null || raw.trim().isEmpty()) return;
        String value = (source == null ? "بانک" : source) + "\n"
                + timestamp + "\n" + (sender == null ? "" : sender) + "\n" + raw.trim();
        context.getSharedPreferences("bank_import_candidates", Context.MODE_PRIVATE)
                .edit().putString("candidate_" + UUID.randomUUID(), value).apply();
    }
}
