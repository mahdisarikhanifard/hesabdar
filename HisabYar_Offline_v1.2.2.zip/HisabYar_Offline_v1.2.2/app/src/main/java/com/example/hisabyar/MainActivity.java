package com.example.hisabyar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.os.Build;
import android.widget.*;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;
import java.util.Locale;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(25, 104, 77);
    private static final int DARK = Color.rgb(20, 68, 54);
    private static final int BG = Color.rgb(245, 247, 245);
    private static final int TEXT = Color.rgb(35, 45, 40);
    private DB db;
    private android.speech.SpeechRecognizer speechRecognizer;
    private LinearLayout root, body, topbar, navBar;
    private String activeBook = "شخصی";
    private String page = "خانه";
    private static final int REQ_EXPORT_BACKUP = 701;
    private static final int REQ_IMPORT_BACKUP = 702;
    private static final int REQ_EXPORT_CSV = 703;
    private static final int REQ_AUDIO_PERMISSION = 704;
    private static final int REQ_VOICE_INPUT = 705;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        activeBook = getPreferences(0).getString("active_book", "شخصی");
        ensureDefaults();
        showShell();
        showHome();
        promptUnlockIfNeeded();
    }

    private void ensureDefaults() {
        SQLiteDatabase w = db.getWritableDatabase();
        if (count("books") == 0) {
            addBookRaw("شخصی");
            addBookRaw("کسب‌وکار");
        }
        if (countForBook("accounts", activeBook) == 0) {
            ContentValues v = new ContentValues();
            v.put("book", activeBook); v.put("name", "پول نقد"); v.put("kind", "نقدی"); v.put("opening", 0L);
            w.insert("accounts", null, v);
        }
        if (count("categories") == 0) {
            String[][] cats = {{"هزینه","خوراک"},{"هزینه","مسکن"},{"هزینه","حمل‌ونقل"},{"هزینه","سلامت"},{"هزینه","خرید شخصی"},{"هزینه","قبوض"},{"هزینه","تفریح"},{"هزینه","سایر"},{"درآمد","حقوق"},{"درآمد","کسب‌وکار"},{"درآمد","سرمایه‌گذاری"},{"درآمد","سایر"}};
            for (String[] c : cats) { ContentValues v = new ContentValues(); v.put("type",c[0]); v.put("name",c[1]); w.insert("categories",null,v); }
        }
    }
    private long count(String table) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private long countForBook(String table, String book) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+" WHERE book=?",new String[]{book});
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private void addBookRaw(String name) {
        ContentValues v=new ContentValues(); v.put("name",name); db.getWritableDatabase().insert("books",null,v);
    }

    private void showShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(BG);

        topbar = new LinearLayout(this);
        topbar.setOrientation(LinearLayout.VERTICAL);
        topbar.setPadding(dp(20), dp(18), dp(20), dp(18));
        topbar.setBackground(roundBg(DARK));
        TextView title = text("حساب‌یار", 27, Color.WHITE, true);
        title.setGravity(Gravity.RIGHT);
        topbar.addView(title);
        TextView subtitle = text("مدیریت مالی شخصی و کسب‌وکار", 13, Color.rgb(218, 238, 228), false);
        topbar.addView(subtitle);
        LinearLayout status = new LinearLayout(this);
        status.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        TextView dot = text("●  آفلاین  •  ذخیره‌سازی روی گوشی", 12, Color.rgb(183, 232, 204), true);
        status.addView(dot);
        topbar.addView(status);
        LinearLayout.LayoutParams topLp = new LinearLayout.LayoutParams(-1, -2);
        topLp.setMargins(dp(12), dp(10), dp(12), dp(4));
        root.addView(topbar, topLp);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        body.setPadding(dp(14), dp(10), dp(14), dp(14));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setGravity(Gravity.CENTER);
        navBar.setPadding(dp(5), dp(4), dp(5), dp(4));
        navBar.setClipChildren(false);
        navBar.setClipToPadding(false);
        navBar.setBackgroundColor(Color.WHITE);
        navBar.setElevation(dp(12));
        String[][] tabs = {{"خانه", "⌂"}, {"تراکنش‌ها", "↕"}, {"ثبت", "+"}, {"دارایی‌ها", "◇"}, {"تنظیمات", "☰"}};
        for (String[] tab : tabs) {
            final String target = tab[0];
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            boolean selected = target.equals(page);
            item.setPadding(dp(1), dp(2), dp(1), dp(2));
            item.setClipChildren(false);
            item.setClipToPadding(false);
            item.setBackground(roundBg(selected ? Color.rgb(226, 241, 233) : Color.WHITE));
            TextView icon = text(tab[1], 22, selected ? GREEN : Color.rgb(55, 66, 59), true);
            icon.setGravity(Gravity.CENTER);
            TextView label = text(target, 12, selected ? Color.rgb(15, 75, 53) : Color.rgb(35, 45, 40), true);
            label.setGravity(Gravity.CENTER);
            label.setMinHeight(dp(20));
            label.setMaxLines(1);
            label.setIncludeFontPadding(true);
            item.addView(icon);
            item.addView(label);
            item.setOnClickListener(v -> navigate(target));
            navBar.addView(item, new LinearLayout.LayoutParams(0, dp(68), 1));
        }
        root.addView(navBar);
        // Android 15 enforces edge-to-edge for targetSdk 35. Keep navigation items
        // above the system navigation buttons/gesture area on all supported versions.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottomInset = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                bottomInset = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            navBar.setPadding(dp(5), dp(4), dp(5), dp(4) + bottomInset);
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();
    }

    private void navigate(String p) {
        page = p;
        showShell();
        body.removeAllViews();
        switch(p) {
            case "خانه": showHome(); break;
            case "تراکنش‌ها": showTransactions(); break;
            case "ثبت": showAddMenu(); break;
            case "دارایی‌ها": showAssets(); break;
            default: showSettings(); break;
        }
    }
    private void showHome() {
        body.removeAllViews();
        LinearLayout bookrow = new LinearLayout(this);
        bookrow.setGravity(Gravity.CENTER_VERTICAL);
        TextView greeting = text("نمای کلی امور مالی", 18, TEXT, true);
        bookrow.addView(greeting, new LinearLayout.LayoutParams(0, -2, 1));
        Button switchB = button("دفتر: " + activeBook + " ▾");
        switchB.setTextSize(12);
        switchB.setBackground(roundBg(Color.WHITE));
        bookrow.addView(switchB);
        switchB.setOnClickListener(v -> chooseBook());
        body.addView(bookrow);

        long income = sum("درآمد"), expense = sum("هزینه"), bal = balance();
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(roundBg(GREEN));
        TextView heroLabel = text("موجودی محاسبه‌شده", 14, Color.rgb(220, 242, 230), false);
        TextView heroValue = text(money(bal), 29, Color.WHITE, true);
        hero.addView(heroLabel); hero.addView(heroValue);
        TextView heroFoot = text("مجموع موجودی اولیه + درآمدها − هزینه‌ها", 11, Color.rgb(220, 242, 230), false);
        hero.addView(heroFoot);
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(-1, -2);
        heroLp.setMargins(0, dp(12), 0, dp(8));
        body.addView(hero, heroLp);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.addView(metricBox("درآمد کل", money(income), GREEN), new LinearLayout.LayoutParams(0, -2, 1));
        View spacer = new View(this); metrics.addView(spacer, new LinearLayout.LayoutParams(dp(8), 1));
        metrics.addView(metricBox("هزینه کل", money(expense), Color.rgb(184, 74, 67)), new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(metrics);

        addHeading("دسترسی سریع");
        addWideButton("🎙 دستیار صوتی ثبت تراکنش", this::startVoiceAssistant);
        LinearLayout row1 = new LinearLayout(this);
        row1.addView(actionBox("＋  ثبت هزینه", () -> showEntry("هزینه")), new LinearLayout.LayoutParams(0, dp(68), 1));
        row1.addView(spaceWidth(8));
        row1.addView(actionBox("＋  ثبت درآمد", () -> showEntry("درآمد")), new LinearLayout.LayoutParams(0, dp(68), 1));
        body.addView(row1);
        LinearLayout row2 = new LinearLayout(this);
        row2.addView(actionBox("⇄  انتقال پول", () -> showTransfer()), new LinearLayout.LayoutParams(0, dp(68), 1));
        row2.addView(spaceWidth(8));
        row2.addView(actionBox("◇  ثبت دارایی", () -> showAssetDialog()), new LinearLayout.LayoutParams(0, dp(68), 1));
        body.addView(row2);

        addHeading("موجودی حساب‌ها");
        addAccountBalancesIntoBody();

        addHeading("آخرین تراکنش‌ها");
        showRecentIntoBody();
        addWideButton("مشاهده همه تراکنش‌ها  ←", () -> navigate("تراکنش‌ها"));
    }

    private View spaceWidth(int width) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(width), 1)); return v; }

    private View metricBox(String label,String value,int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(14), dp(12), dp(14));
        box.setBackground(roundBg(Color.WHITE));
        TextView a = text(label, 12, Color.rgb(105, 116, 110), false);
        TextView b = text(value, 15, color, true);
        box.addView(a); box.addView(b);
        return box;
    }

    private void addMetric(String label,String value,int color) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(18),dp(16),dp(18)); box.setBackground(roundBg(Color.WHITE));
        TextView a=text(label,14,Color.rgb(86, 99, 91),false), b=text(value,25,color,true); box.addView(a); box.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(10),0,dp(10)); body.addView(box,lp);
    }
    private void showAddMenu() {
        body.removeAllViews(); addHeading("ثبت عملیات مالی");
        addWideButton("🎙 ثبت با دستیار صوتی", this::startVoiceAssistant);
        addWideButton("ثبت هزینه",()->showEntry("هزینه"));
        addWideButton("ثبت درآمد",()->showEntry("درآمد"));
        addWideButton("انتقال بین حساب‌ها",()->showTransfer());
        addWideButton("ثبت دارایی",()->showAssetDialog());
        addWideButton("ثبت بدهی یا طلب",()->showDebtDialog());
        addWideButton("مشاهده و تسویه بدهی‌ها و طلب‌ها",()->showDebts());
        addWideButton("بودجه‌بندی ماهانه",()->showBudgets());
        addWideButton("پرداخت‌های تکرارشونده و سررسیدها",()->showRecurring());
        addWideButton("هدف‌های پس‌انداز",()->showGoals());
        addWideButton("گزارش‌ها و ارزش خالص",()->showReports());
    }
    private void showEntry(String type) {
        LinearLayout form=formLayout();
        EditText amount=edit("مبلغ به تومان",InputType.TYPE_CLASS_NUMBER);
        AutoCompleteTextView category=categoryInput(type,"دسته‌بندی (مثلاً خوراک)");
        AutoCompleteTextView account=accountInput("حساب (مثلاً پول نقد)");
        EditText note=edit("شرح / یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        Calendar selectedDate=Calendar.getInstance();
        Button dateButton=button("تاریخ تراکنش: "+jalaliDate(selectedDate.getTimeInMillis()));
        dateButton.setOnClickListener(v->{Calendar cur=(Calendar)selectedDate.clone();new DatePickerDialog(this,(view,year,month,day)->{selectedDate.set(Calendar.YEAR,year);selectedDate.set(Calendar.MONTH,month);selectedDate.set(Calendar.DAY_OF_MONTH,day);selectedDate.set(Calendar.HOUR_OF_DAY,12);selectedDate.set(Calendar.MINUTE,0);selectedDate.set(Calendar.SECOND,0);dateButton.setText("تاریخ تراکنش: "+jalaliDate(selectedDate.getTimeInMillis()));},cur.get(Calendar.YEAR),cur.get(Calendar.MONTH),cur.get(Calendar.DAY_OF_MONTH)).show();});
        form.addView(amount); form.addView(category); form.addView(account); form.addView(dateButton); form.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت "+type).setView(form)
          .setNegativeButton("انصراف",null).setPositiveButton("ثبت", (d,w)->{
              long a=parseAmount(amount.getText().toString());
              if(a<=0){toast("مبلغ باید بیشتر از صفر باشد");return;}
              String cat=category.getText().toString().trim(); if(cat.isEmpty()) cat=type.equals("هزینه")?"سایر":"سایر";
              String acc=account.getText().toString().trim(); if(acc.isEmpty()) acc="پول نقد";
              ensureAccount(acc);
              saveCategoryIfMissing(type,cat);
              ContentValues v=new ContentValues(); v.put("book",activeBook); v.put("type",type); v.put("amount",a); v.put("category",cat); v.put("account",acc); v.put("note",note.getText().toString()); v.put("date",selectedDate.getTimeInMillis());
              db.getWritableDatabase().insert("transactions",null,v);
              toast("تراکنش ثبت شد"); navigate("خانه");
          }).show();
    }
    private void startVoiceAssistant() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, REQ_AUDIO_PERMISSION);
            return;
        }
        launchVoiceRecognizer();
    }

    private void launchVoiceRecognizer() {
        if (!android.speech.SpeechRecognizer.isRecognitionAvailable(this)) {
            new AlertDialog.Builder(this).setTitle("تشخیص گفتار در دسترس نیست")
                .setMessage("سرویس تشخیص گفتار اندروید پیدا نشد. با توجه به اینکه جست‌وجوی صوتی گوگل کار می‌کند، بررسی کنید سرویس «Speech Recognition & Synthesis from Google» در تنظیمات برنامه‌ها فعال باشد.")
                .setPositiveButton("متوجه شدم", null).show();
            return;
        }
        releaseVoiceRecognizer();
        try {
            speechRecognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new android.speech.RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { toast("گوش می‌دهم؛ دستور را بیان کن."); }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() { toast("در حال بررسی گفتار…"); }
                @Override public void onError(int error) {
                    String message;
                    switch (error) {
                        case android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                            message = "اجازهٔ میکروفون داده نشده است."; break;
                        case android.speech.SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED:
                            message = "سرویس گفتار از زبان فارسی انتخاب‌شده پشتیبانی نمی‌کند."; break;
                        case android.speech.SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE:
                            message = "بستهٔ زبان فارسی در سرویس گفتار در دسترس نیست؛ اتصال اینترنت و زبان‌های سرویس گفتار را بررسی کن."; break;
                        case android.speech.SpeechRecognizer.ERROR_NETWORK:
                        case android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                            message = "اتصال سرویس تشخیص گفتار برقرار نشد؛ اینترنت را بررسی و دوباره امتحان کن."; break;
                        case android.speech.SpeechRecognizer.ERROR_NO_MATCH:
                        case android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                            message = "گفتاری تشخیص داده نشد؛ دوباره و واضح‌تر صحبت کن."; break;
                        case android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                            message = "سرویس گفتار مشغول است؛ چند لحظه بعد دوباره امتحان کن."; break;
                        default:
                            message = "تشخیص گفتار ناموفق بود (کد " + error + "). سرویس گفتار گوگل و مجوز میکروفون را بررسی کن."; break;
                    }
                    releaseVoiceRecognizer();
                    toast(message);
                }
                @Override public void onResults(Bundle results) {
                    java.util.ArrayList<String> matches = results == null ? null : results.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION);
                    releaseVoiceRecognizer();
                    if (matches != null && !matches.isEmpty()) processVoiceCommand(matches.get(0));
                    else toast("متن گفتار دریافت نشد؛ دوباره امتحان کن.");
                }
                @Override public void onPartialResults(Bundle partialResults) {}
                @Override public void onEvent(int eventType, Bundle params) {}
            });
            Intent intent = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "fa-IR");
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR");
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "مثلاً بگویید: امروز یک دفتر به قیمت ۵۰۰ هزار تومان خریدیم");
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
            speechRecognizer.startListening(intent);
        } catch (RuntimeException e) {
            releaseVoiceRecognizer();
            toast("شروع تشخیص گفتار ممکن نشد. سرویس گفتار گوگل را بررسی و دوباره امتحان کن.");
        }
    }

    private void releaseVoiceRecognizer() {
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); } catch (Exception ignored) {}
            try { speechRecognizer.destroy(); } catch (Exception ignored) {}
            speechRecognizer = null;
        }
    }

    @Override protected void onDestroy() {
        releaseVoiceRecognizer();
        super.onDestroy();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) launchVoiceRecognizer();
            else toast("برای ثبت صوتی، اجازهٔ میکروفون لازم است.");
        }
    }

    private void processVoiceCommand(String spoken) {
        if (spoken == null || spoken.trim().isEmpty()) { toast("گفتار قابل تشخیص نبود؛ دوباره تلاش کن."); return; }
        String normalized = normalizeDigits(spoken).toLowerCase(Locale.ROOT);
        String type = "هزینه";
        boolean income = containsAny(normalized, "درآمد", "حقوق", "دریافت کردم", "گرفتم", "واریز شد", "واریز کردند", "فروختم", "فروش داشتم", "به حسابم آمد");
        boolean expense = containsAny(normalized, "هزینه", "خرج", "خریدم", "خریدیم", "خرید کردم", "پرداخت کردم", "پرداختیم", "دادم", "قبض", "خوردیم", "مصرف کردیم", "خریداری");
        if (income && !expense) type = "درآمد";
        String category = guessVoiceCategory(normalized, type);
        long amountValue = parseVoiceAmount(normalized);
        showVoiceDraft(spoken, type, amountValue, category, normalized.contains("دیروز"));
    }

    private String normalizeDigits(String input) {
        if (input == null) return "";
        StringBuilder b = new StringBuilder(input.length());
        for (int i=0;i<input.length();i++) {
            char ch=input.charAt(i);
            if(ch>='۰'&&ch<='۹') ch=(char)('0'+ch-'۰');
            else if(ch>='٠'&&ch<='٩') ch=(char)('0'+ch-'٠');
            if(ch=='٬'||ch=='،') ch=',';
            b.append(ch);
        }
        return b.toString();
    }

    private boolean containsAny(String value, String... words) {
        for (String word : words) if (value.contains(word)) return true;
        return false;
    }

    private long parseVoiceAmount(String spoken) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("([0-9][0-9,٬.]*)(?:\\s*(میلیون|میلیارد|هزار))?(?:\\s*(?:تومان|تومن|ریال))?").matcher(normalizeDigits(spoken));
        long fallback = 0;
        while (m.find()) {
            String raw = m.group(1).replace(",", "").replace("٬", "").replace(".", "");
            long n; try { n = Long.parseLong(raw); } catch (Exception e) { continue; }
            String unit = m.group(2) == null ? "" : m.group(2);
            if (unit.equals("هزار")) n = safeMultiply(n, 1000L);
            else if (unit.equals("میلیون")) n = safeMultiply(n, 1000000L);
            else if (unit.equals("میلیارد")) n = safeMultiply(n, 1000000000L);
            String after = spoken.substring(Math.min(m.end(), spoken.length()));
            String before = spoken.substring(0, Math.min(m.start(), spoken.length()));
            if (!unit.isEmpty() || after.trim().startsWith("تومان") || after.trim().startsWith("تومن") || after.trim().startsWith("ریال") || before.contains("قیمت") || before.contains("مبلغ") || before.contains("به مبلغ")) return n;
            fallback = n; // if there are several bare numbers, prefer the last one
        }
        long wordsAmount = parsePersianWordsAmount(spoken);
        return wordsAmount > 0 ? wordsAmount : fallback;
    }

    private long parsePersianWordsAmount(String spoken) {
        String[] tokens = normalizeDigits(spoken).toLowerCase(Locale.ROOT).split("\\s+");
        StringBuilder group = new StringBuilder();
        long lastValue = 0;
        for (String raw : tokens) {
            String token = raw.replaceAll("^[^\\p{L}0-9]+|[^\\p{L}0-9]+$", "");
            boolean numericWord = persianNumberTokenValue(token) >= 0 || token.equals("هزار") || token.equals("میلیون") || token.equals("میلیارد");
            if (numericWord) {
                if (group.length() > 0) group.append(' ');
                group.append(token);
            } else if (token.equals("و") && group.length() > 0) {
                group.append(" و");
            } else if (group.length() > 0) {
                long parsed = evaluatePersianNumberGroup(group.toString());
                if (parsed > 0) lastValue = parsed;
                group.setLength(0);
            }
        }
        if (group.length() > 0) {
            long parsed = evaluatePersianNumberGroup(group.toString());
            if (parsed > 0) lastValue = parsed;
        }
        return lastValue;
    }

    private long evaluatePersianNumberGroup(String phrase) {
        long total = 0, current = 0;
        for (String token : phrase.split("\\s+")) {
            if (token.equals("و")) continue;
            if (token.equals("هزار") || token.equals("میلیون") || token.equals("میلیارد")) {
                long factor = token.equals("هزار") ? 1000L : token.equals("میلیون") ? 1000000L : 1000000000L;
                total += safeMultiply(current == 0 ? 1 : current, factor);
                current = 0;
            } else {
                int n = persianNumberTokenValue(token);
                if (n >= 0) current += n;
            }
        }
        return total + current;
    }

    private int persianNumberTokenValue(String token) {
        switch (token) {
            case "یه": case "یک": case "یکی": return 1;
            case "دو": case "دوتا": return 2;
            case "سه": return 3; case "چهار": return 4; case "پنج": return 5;
            case "شش": case "شیش": return 6; case "هفت": return 7; case "هشت": return 8; case "نه": return 9;
            case "ده": return 10; case "یازده": return 11; case "دوازده": return 12; case "سیزده": return 13;
            case "چهارده": return 14; case "پانزده": return 15; case "شانزده": return 16; case "هفده": return 17;
            case "هجده": return 18; case "نوزده": return 19; case "بیست": return 20; case "سی": return 30;
            case "چهل": return 40; case "پنجاه": return 50; case "شصت": return 60; case "هفتاد": return 70;
            case "هشتاد": return 80; case "نود": return 90; case "صد": case "یکصد": return 100;
            case "دویست": return 200; case "سیصد": return 300; case "چهارصد": return 400;
            case "پانصد": case "پونصد": return 500; case "ششصد": case "شیشصد": return 600;
            case "هفتصد": return 700; case "هشتصد": return 800; case "نهصد": return 900;
            default: return -1;
        }
    }

    private long safeMultiply(long value, long factor) {
        if (value > Long.MAX_VALUE / factor) return Long.MAX_VALUE;
        return value * factor;
    }

    private String guessVoiceCategory(String text, String type) {
        if (type.equals("درآمد")) {
            if (containsAny(text, "حقوق", "دستمزد", "حقوق ماهانه")) return "حقوق";
            if (containsAny(text, "فروختم", "فروش", "مشتری")) return "کسب‌وکار";
            if (containsAny(text, "سود", "سرمایه")) return "سرمایه‌گذاری";
            return "سایر";
        }
        if (containsAny(text, "دفتر", "خودکار", "کاغذ", "لوازم التحریر", "لوازم اداری", "پرینتر", "کارتریج")) return "لوازم اداری";
        if (containsAny(text, "غذا", "ناهار", "شام", "صبحانه", "رستوران", "نان", "میوه")) return "خوراک";
        if (containsAny(text, "بنزین", "تاکسی", "اسنپ", "اتوبوس", "کرایه", "سوخت")) return "حمل‌ونقل";
        if (containsAny(text, "دارو", "دکتر", "درمان", "بیمارستان")) return "سلامت";
        if (containsAny(text, "برق", "آب", "گاز", "اینترنت", "قبض")) return "قبوض";
        if (containsAny(text, "اجاره", "خانه", "مسکن")) return "مسکن";
        return "سایر";
    }

    private void showVoiceDraft(String spoken, String guessedType, long guessedAmount, String guessedCategory, boolean yesterday) {
        LinearLayout form = formLayout();
        TextView recognized = text("متن تشخیص‌داده‌شده:\n" + spoken, 14, TEXT, true);
        recognized.setBackground(roundBg(Color.rgb(236, 244, 239)));
        recognized.setPadding(dp(12),dp(10),dp(12),dp(10));
        form.addView(recognized);
        TextView safetyNote = text("برای جلوگیری از ثبت اشتباه، اطلاعات را بررسی کن. تا زدن دکمهٔ «تأیید و ثبت» هیچ تراکنشی ذخیره نمی‌شود.", 13, DARK, true);
        safetyNote.setPadding(dp(4), dp(8), dp(4), dp(8));
        form.addView(safetyNote);
        Spinner typeSpinner = new Spinner(this);
        typeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"هزینه", "درآمد"}));
        typeSpinner.setSelection("درآمد".equals(guessedType) ? 1 : 0);
        form.addView(typeSpinner);
        EditText amount = edit("مبلغ به تومان (اجباری)", InputType.TYPE_CLASS_NUMBER);
        if (guessedAmount > 0) amount.setText(String.valueOf(guessedAmount));
        form.addView(amount);
        EditText category = edit("دسته‌بندی (قابل ویرایش)", InputType.TYPE_CLASS_TEXT);
        category.setText(guessedCategory);
        form.addView(category);
        AutoCompleteTextView account = accountInput("حساب");
        account.setText("پول نقد", false);
        form.addView(account);
        EditText note = edit("شرح تراکنش", InputType.TYPE_CLASS_TEXT);
        note.setText(spoken);
        form.addView(note);
        Calendar selectedDate = Calendar.getInstance();
        if (yesterday) selectedDate.add(Calendar.DAY_OF_MONTH, -1);
        Button dateButton = button("تاریخ تراکنش: " + jalaliDate(selectedDate.getTimeInMillis()));
        dateButton.setOnClickListener(v -> {
            Calendar cur=(Calendar)selectedDate.clone();
            new DatePickerDialog(this,(view,year,month,day)->{
                selectedDate.set(Calendar.YEAR,year); selectedDate.set(Calendar.MONTH,month); selectedDate.set(Calendar.DAY_OF_MONTH,day);
                selectedDate.set(Calendar.HOUR_OF_DAY,12); selectedDate.set(Calendar.MINUTE,0); selectedDate.set(Calendar.SECOND,0);
                dateButton.setText("تاریخ تراکنش: "+jalaliDate(selectedDate.getTimeInMillis()));
            },cur.get(Calendar.YEAR),cur.get(Calendar.MONTH),cur.get(Calendar.DAY_OF_MONTH)).show();
        });
        form.addView(dateButton);
        ScrollView scroll = new ScrollView(this); scroll.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("بررسی و تأیید تراکنش صوتی").setView(scroll)
            .setNegativeButton("لغو", null).setNeutralButton("اصلاح متن", (d,w)->showManualVoiceText(spoken)).setPositiveButton("تأیید و ثبت", null).create();
        dialog.setOnShowListener(dlg -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            long a = parseAmount(amount.getText().toString());
            String ty = String.valueOf(typeSpinner.getSelectedItem());
            String cat = category.getText().toString().trim();
            String acc = account.getText().toString().trim();
            if (a <= 0) { amount.setError("مبلغ معتبر و بیشتر از صفر وارد کن"); amount.requestFocus(); return; }
            if (cat.isEmpty()) { category.setError("دسته‌بندی را وارد کن"); category.requestFocus(); return; }
            if (acc.isEmpty()) { account.setError("حساب را انتخاب یا وارد کن"); account.requestFocus(); return; }
            ensureAccount(acc); saveCategoryIfMissing(ty,cat);
            ContentValues values = new ContentValues(); values.put("book",activeBook); values.put("type",ty); values.put("amount",a); values.put("category",cat); values.put("account",acc); values.put("note",note.getText().toString().trim()); values.put("date",selectedDate.getTimeInMillis());
            long id = db.getWritableDatabase().insert("transactions",null,values);
            if (id == -1) { toast("ثبت تراکنش انجام نشد؛ دوباره بررسی کن."); return; }
            dialog.dismiss(); toast("تراکنش صوتی با تأیید شما ثبت شد."); navigate("خانه");
        }));
        dialog.show();
    }

    private void showManualVoiceText(String initial) {
        EditText input = edit("متن دستور مالی را وارد کن", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setText(initial);
        new AlertDialog.Builder(this).setTitle("اصلاح متن تشخیص‌داده‌شده").setView(input)
            .setNegativeButton("لغو",null).setPositiveButton("تحلیل دوباره",(d,w)->processVoiceCommand(input.getText().toString().trim())).show();
    }

    private void showTransfer() {
        LinearLayout f=formLayout();
        AutoCompleteTextView from=accountInput("از حساب"), to=accountInput("به حساب"); EditText amt=edit("مبلغ به تومان",InputType.TYPE_CLASS_NUMBER), note=edit("شرح (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(from);f.addView(to);f.addView(amt);f.addView(note);
        new AlertDialog.Builder(this).setTitle("انتقال پول").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ثبت انتقال",(d,w)->{
            long a=parseAmount(amt.getText().toString()); String fr=from.getText().toString().trim(),toN=to.getText().toString().trim();
            if(a<=0||fr.isEmpty()||toN.isEmpty()||fr.equals(toN)){toast("حساب‌ها و مبلغ را درست وارد کن");return;}
            ensureAccount(fr);ensureAccount(toN);
            SQLiteDatabase s=db.getWritableDatabase();
            String transferId=java.util.UUID.randomUUID().toString();
            s.beginTransaction();try{
                ContentValues v=new ContentValues();v.put("book",activeBook);v.put("type","انتقال خروجی");v.put("amount",a);v.put("category","انتقال");v.put("account",fr);v.put("note","به "+toN+"؛ "+note.getText());v.put("date",System.currentTimeMillis());v.put("transfer_id",transferId);s.insertOrThrow("transactions",null,v);
                ContentValues x=new ContentValues();x.put("book",activeBook);x.put("type","انتقال ورودی");x.put("amount",a);x.put("category","انتقال");x.put("account",toN);x.put("note","از "+fr+"؛ "+note.getText());x.put("date",System.currentTimeMillis());x.put("transfer_id",transferId);s.insertOrThrow("transactions",null,x);s.setTransactionSuccessful();
            }finally{s.endTransaction();}
            toast("انتقال ثبت شد");navigate("خانه");
        }).show();
    }
    private void showTransactions() {
        body.removeAllViews(); addHeading("سوابق و جست‌وجوی تراکنش‌ها");
        EditText search=edit("جست‌وجو در شرح، دسته‌بندی یا حساب",InputType.TYPE_CLASS_TEXT);
        body.addView(search);
        Spinner filter=new Spinner(this);
        String[] filters={"همه تراکنش‌ها","فقط درآمد","فقط هزینه","انتقال‌ها"};
        filter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,filters));
        body.addView(filter);
        addWideButton("اعمال فیلتر",()->renderTransactions(search.getText().toString().trim(),filter.getSelectedItemPosition()));
        addWideButton("پاک کردن جست‌وجو",()->{search.setText("");filter.setSelection(0);renderTransactions("",0);});
        renderTransactions("",0);
    }

    private void renderTransactions(String query,int filterIndex) {
        // Remove only transaction cards, preserving the search/filter controls and their buttons.
        while(body.getChildCount()>5) body.removeViewAt(5);
        String typeClause="";
        if(filterIndex==1) typeClause=" AND type='درآمد'";
        else if(filterIndex==2) typeClause=" AND type='هزینه'";
        else if(filterIndex==3) typeClause=" AND type LIKE 'انتقال%'";
        String sql="SELECT id,type,amount,category,account,note,date,transfer_id FROM transactions WHERE book=?"+typeClause+" AND (COALESCE(category,'') LIKE ? OR COALESCE(account,'') LIKE ? OR COALESCE(note,'') LIKE ?) ORDER BY date DESC LIMIT 500";
        String q="%"+query+"%";
        Cursor c=db.getReadableDatabase().rawQuery(sql,new String[]{activeBook,q,q,q});
        if(!c.moveToFirst()){c.close();addEmpty("تراکنشی مطابق این فیلتر پیدا نشد.");return;}
        do {
            long txId=c.getLong(0); String type=c.getString(1); long amount=c.getLong(2); String cat=c.getString(3), acc=c.getString(4), note=c.getString(5); long stamp=c.getLong(6);String transferId=c.isNull(7)?null:c.getString(7);
            LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(dp(12),dp(10),dp(12),dp(10)); item.setBackground(roundBg(Color.WHITE));
            TextView line=text((cat==null?"بدون دسته":cat)+"  •  "+type,15,TEXT,true); item.addView(line);
            item.addView(text((acc==null?"":acc)+"  |  "+money(amount),14,type.equals("هزینه")||type.equals("انتقال خروجی")?Color.rgb(183,74,60):GREEN,false));
            item.addView(text(jalaliDate(stamp),12,Color.rgb(86, 99, 91),false));
            if(note!=null&&!note.isEmpty()) item.addView(text(note,12,Color.rgb(86, 99, 91),false));
            item.setOnClickListener(v->transactionActions(txId,type,amount,cat,acc,note,transferId));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        } while(c.moveToNext()); c.close();
    }
    private void transactionActions(long id,String type,long amount,String category,String account,String note,String transferId){
        boolean transfer=type!=null&&type.startsWith("انتقال");
        if(transfer){
            if(transferId==null){new AlertDialog.Builder(this).setTitle("انتقال قدیمی").setMessage("این انتقال در نسخهٔ قدیمی ثبت شده و دو سمت آن به هم متصل نیستند. برای جلوگیری از خراب‌شدن ماندهٔ حساب‌ها، حذف تکی آن از این صفحه غیرفعال است. اگر لازم است اصلاح شود، مبلغ را با یک انتقال معکوس جبران کن.").setPositiveButton("متوجه شدم",null).show();return;}
            new AlertDialog.Builder(this).setTitle("مدیریت انتقال").setMessage("هر دو سمت این انتقال با هم حذف می‌شوند.").setNegativeButton("بازگشت",null).setPositiveButton("حذف انتقال",(d,w)->new AlertDialog.Builder(this).setTitle("تأیید حذف").setMessage("حذف انتقال قابل بازگشت نیست. ادامه می‌دهی؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("transactions","book=? AND transfer_id=?",new String[]{activeBook,transferId});toast("هر دو سمت انتقال حذف شدند");showTransactions();}).show()).show();
            return;
        }
        String[] options={"ویرایش تراکنش","حذف تراکنش"};new AlertDialog.Builder(this).setTitle("مدیریت تراکنش").setItems(options,(d,which)->{if(which==0)editTransaction(id,type,amount,category,account,note);else new AlertDialog.Builder(this).setTitle("حذف تراکنش").setMessage("این تراکنش حذف شود؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("transactions","id=? AND book=?",new String[]{String.valueOf(id),activeBook});toast("تراکنش حذف شد");showTransactions();}).show();}).show();
    }
    private void editTransaction(long id,String type,long amount,String category,String account,String note){
        LinearLayout f=formLayout();EditText a=edit("مبلغ به تومان",InputType.TYPE_CLASS_NUMBER),nt=edit("شرح",InputType.TYPE_CLASS_TEXT);AutoCompleteTextView acc=accountInput("حساب"),cat=categoryInput(type.equals("هزینه")?"هزینه":"درآمد","دسته‌بندی");a.setText(String.valueOf(amount));cat.setText(category);acc.setText(account);nt.setText(note==null?"":note);f.addView(a);f.addView(cat);f.addView(acc);f.addView(nt);
        new AlertDialog.Builder(this).setTitle("ویرایش تراکنش").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{long value=parseAmount(a.getText().toString());String accountName=acc.getText().toString().trim();if(value<=0||accountName.isEmpty()){toast("مبلغ و حساب معتبر وارد کن");return;}ensureAccount(accountName);saveCategoryIfMissing(type,cat.getText().toString().trim());ContentValues v=new ContentValues();v.put("amount",value);v.put("category",cat.getText().toString().trim());v.put("account",accountName);v.put("note",nt.getText().toString());db.getWritableDatabase().update("transactions",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});toast("تراکنش ویرایش شد");showTransactions();}).show();
    }
    private void showRecentIntoBody() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT type,amount,category,account FROM transactions WHERE book=? ORDER BY date DESC LIMIT 5",new String[]{activeBook});
        if(!c.moveToFirst()){addEmpty("هنوز تراکنشی ثبت نشده است.");c.close();return;}
        do { String t=c.getString(0); long a=c.getLong(1); String cat=c.getString(2),acc=c.getString(3);
            TextView v=text(cat+"  •  "+money(a)+"\n"+t+" | "+acc,14,TEXT,false);v.setPadding(dp(10),dp(10),dp(10),dp(10));v.setBackground(roundBg(Color.WHITE));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);
        }while(c.moveToNext());c.close();
    }
    private void addAccountBalancesIntoBody() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,opening FROM accounts WHERE book=? ORDER BY id",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز حسابی تعریف نشده است.");return;}
        do {
            String name=c.getString(0),kind=c.getString(1);long opening=c.getLong(2);
            long bal=opening;
            Cursor t=db.getReadableDatabase().rawQuery("SELECT type,amount FROM transactions WHERE book=? AND account=?",new String[]{activeBook,name});
            while(t.moveToNext()){String type=t.getString(0);long amount=t.getLong(1);if(type.equals("درآمد")||type.equals("انتقال ورودی"))bal+=amount;else if(type.equals("هزینه")||type.equals("انتقال خروجی"))bal-=amount;}
            t.close();
            TextView v=text(name+" • "+(kind==null?"حساب":kind)+"\n"+money(bal),14,bal<0?Color.rgb(183,74,60):GREEN,true);v.setPadding(dp(12),dp(10),dp(12),dp(10));v.setBackground(roundBg(Color.WHITE));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);
        }while(c.moveToNext());c.close();
    }

    private long accountBalance(String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(opening,0) FROM accounts WHERE book=? AND name=?",new String[]{activeBook,name});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();
        Cursor t=db.getReadableDatabase().rawQuery("SELECT type,amount FROM transactions WHERE book=? AND account=?",new String[]{activeBook,name});while(t.moveToNext()){String ty=t.getString(0);long a=t.getLong(1);if(ty.equals("درآمد")||ty.equals("انتقال ورودی"))n+=a;else if(ty.equals("هزینه")||ty.equals("انتقال خروجی"))n-=a;}t.close();return n;
    }

    private void showAccounts() {
        body.removeAllViews();addHeading("حساب‌ها و ماندهٔ هر حساب");addWideButton("＋ حساب جدید",()->addAccountDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,opening FROM accounts WHERE book=? ORDER BY id",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("حسابی ثبت نشده است.");return;}
        do{String name=c.getString(0),kind=c.getString(1);long opening=c.getLong(2);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(roundBg(Color.WHITE));card.addView(text(name+" • "+kind,15,TEXT,true));card.addView(text("موجودی اولیه: "+money(opening),12,Color.rgb(86, 99, 91),false));card.addView(text("مانده فعلی: "+money(accountBalance(name)),18,GREEN,true));body.addView(card,new LinearLayout.LayoutParams(-1,-2));}while(c.moveToNext());c.close();
    }

    private AutoCompleteTextView accountInput(String hint) {
        AutoCompleteTextView input=new AutoCompleteTextView(this);input.setHint(hint);input.setTextSize(15);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT);input.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);input.setPadding(dp(8),dp(6),dp(8),dp(6));
        java.util.ArrayList<String> names=new java.util.ArrayList<>();Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM accounts WHERE book=? ORDER BY id",new String[]{activeBook});while(c.moveToNext())names.add(c.getString(0));c.close();
        input.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,names));input.setThreshold(1);return input;
    }

    private AutoCompleteTextView categoryInput(String type,String hint) {
        AutoCompleteTextView input=new AutoCompleteTextView(this);input.setHint(hint);input.setTextSize(15);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT);input.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);input.setPadding(dp(8),dp(6),dp(8),dp(6));
        java.util.ArrayList<String> names=new java.util.ArrayList<>();Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM categories WHERE type=? ORDER BY name",new String[]{type});while(c.moveToNext())names.add(c.getString(0));c.close();
        Cursor tx=db.getReadableDatabase().rawQuery("SELECT DISTINCT category FROM transactions WHERE book=? AND type=? AND category IS NOT NULL ORDER BY category",new String[]{activeBook,type});while(tx.moveToNext()){String n=tx.getString(0);if(n!=null&&!names.contains(n))names.add(n);}tx.close();
        input.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,names));input.setThreshold(1);return input;
    }

    private void saveCategoryIfMissing(String type,String name) {
        if(name==null||name.trim().isEmpty())return;Cursor c=db.getReadableDatabase().rawQuery("SELECT id FROM categories WHERE type=? AND name=?",new String[]{type,name.trim()});boolean found=c.moveToFirst();c.close();if(!found){ContentValues v=new ContentValues();v.put("type",type);v.put("name",name.trim());db.getWritableDatabase().insert("categories",null,v);}
    }

    private void manageCategories() {
        body.removeAllViews();addHeading("دسته‌بندی‌های درآمد و هزینه");addWideButton("＋ دسته‌بندی درآمد",()->categoryDialog("درآمد"));addWideButton("＋ دسته‌بندی هزینه",()->categoryDialog("هزینه"));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,type,name FROM categories ORDER BY type,name",null);if(!c.moveToFirst()){c.close();addEmpty("دسته‌بندی‌ای وجود ندارد.");return;}
        do{long id=c.getLong(0);String type=c.getString(1),name=c.getString(2);TextView row=text(type+" • "+name+"   (برای حذف لمس کن)",14,TEXT,false);row.setPadding(dp(12),dp(12),dp(12),dp(12));row.setBackground(roundBg(Color.WHITE));body.addView(row,new LinearLayout.LayoutParams(-1,-2));row.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف دسته‌بندی").setMessage("فقط دسته‌بندی حذف می‌شود؛ تراکنش‌های قبلی باقی می‌مانند.").setNegativeButton("انصراف",null).setPositiveButton("حذف",(d,w)->{db.getWritableDatabase().delete("categories","id=?",new String[]{String.valueOf(id)});manageCategories();}).show());}while(c.moveToNext());c.close();
    }

    private void categoryDialog(String type) {
        EditText name=edit("نام دسته‌بندی جدید",InputType.TYPE_CLASS_TEXT);new AlertDialog.Builder(this).setTitle("دسته‌بندی "+type).setView(name).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty()){toast("نام دسته‌بندی را وارد کن");return;}saveCategoryIfMissing(type,n);manageCategories();}).show();
    }

    private void showRecurring() {
        body.removeAllViews();addHeading("پرداخت‌های تکرارشونده و سررسیدها");addEmpty("این بخش برای قبض‌ها، اجاره، اقساط، حقوق و درآمدهای تکراری است. ثبت هر سررسید با تأیید شما انجام می‌شود.");addWideButton("＋ تعریف مورد تکرارشونده",()->recurringDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,type,amount,category,account,frequency,next_due FROM recurring WHERE book=? ORDER BY next_due",new String[]{activeBook});if(!c.moveToFirst()){c.close();addEmpty("مورد تکرارشونده‌ای تعریف نشده است.");return;}
        do{long id=c.getLong(0),amount=c.getLong(3),due=c.getLong(7);String name=c.getString(1),type=c.getString(2),cat=c.getString(4),acc=c.getString(5),freq=c.getString(6);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(name+" • "+type,15,TEXT,true));card.addView(text(money(amount)+" | "+freq+" | سررسید: "+jalaliDate(due),13,Color.rgb(86, 99, 91),false));Button post=button("ثبت این سررسید در حساب‌ها");card.addView(post);post.setOnClickListener(v->postRecurring(id,name,type,amount,cat,acc,freq,due));Button del=button("حذف مورد تکرارشونده");card.addView(del);del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("این مورد از فهرست تکرارشونده حذف شود؟ تراکنش‌های قبلی حذف نمی‌شوند.").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("recurring","id=? AND book=?",new String[]{String.valueOf(id),activeBook});showRecurring();}).show());body.addView(card,new LinearLayout.LayoutParams(-1,-2));}while(c.moveToNext());c.close();
    }

    private void recurringDialog() {
        LinearLayout f=formLayout();EditText name=edit("عنوان (مثلاً اجاره خانه)",InputType.TYPE_CLASS_TEXT);Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"هزینه","درآمد"}));EditText amount=edit("مبلغ به تومان",InputType.TYPE_CLASS_NUMBER);AutoCompleteTextView cat=categoryInput("هزینه","دسته‌بندی");AutoCompleteTextView account=accountInput("حساب (مثلاً پول نقد)");Spinner freq=new Spinner(this);freq.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"ماهانه","هفتگی","سالانه"}));f.addView(name);f.addView(type);f.addView(amount);f.addView(cat);f.addView(account);f.addView(freq);
        new AlertDialog.Builder(this).setTitle("تعریف مورد تکرارشونده").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim(),a=account.getText().toString().trim();long val=parseAmount(amount.getText().toString());if(n.isEmpty()||val<=0){toast("عنوان و مبلغ معتبر وارد کن");return;}if(a.isEmpty())a="پول نقد";ensureAccount(a);String ty=type.getSelectedItem().toString(),category=cat.getText().toString().trim();if(category.isEmpty())category="سایر";saveCategoryIfMissing(ty,category);ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("type",ty);v.put("amount",val);v.put("category",category);v.put("account",a);v.put("frequency",freq.getSelectedItem().toString());v.put("next_due",System.currentTimeMillis());db.getWritableDatabase().insert("recurring",null,v);showRecurring();}).show();
    }

    private void postRecurring(long id,String name,String type,long amount,String category,String account,String frequency,long due) {
        new AlertDialog.Builder(this).setTitle("ثبت سررسید").setMessage("مورد «"+name+"» به‌عنوان تراکنش "+type+" به مبلغ "+money(amount)+" ثبت شود؟").setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{SQLiteDatabase sql=db.getWritableDatabase();sql.beginTransaction();try{ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",type);tx.put("amount",amount);tx.put("category",category);tx.put("account",account);tx.put("note","ثبت از سررسید تکرارشونده: "+name);tx.put("date",System.currentTimeMillis());sql.insertOrThrow("transactions",null,tx);Calendar cal=Calendar.getInstance();cal.setTimeInMillis(Math.max(due,System.currentTimeMillis()));if(frequency.equals("هفتگی"))cal.add(Calendar.DAY_OF_YEAR,7);else if(frequency.equals("سالانه"))cal.add(Calendar.YEAR,1);else cal.add(Calendar.MONTH,1);ContentValues upd=new ContentValues();upd.put("next_due",cal.getTimeInMillis());sql.update("recurring",upd,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});sql.setTransactionSuccessful();toast("سررسید ثبت شد");}catch(Exception e){toast("ثبت سررسید انجام نشد");}finally{sql.endTransaction();}showRecurring();}).show();
    }

    private void showGoals() {
        body.removeAllViews();addHeading("هدف‌های پس‌انداز");addEmpty("هدف‌ها برای پیگیری پیشرفت پس‌انداز هستند؛ واریز به هدف به‌تنهایی موجودی حساب را تغییر نمی‌دهد. برای جابه‌جایی واقعی پول از «انتقال بین حساب‌ها» استفاده کن.");addWideButton("＋ هدف جدید",()->goalDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,target,current_amount,deadline,note FROM goals WHERE book=? ORDER BY id DESC",new String[]{activeBook});if(!c.moveToFirst()){c.close();addEmpty("هنوز هدفی تعریف نشده است.");return;}
        do{long id=c.getLong(0),target=c.getLong(2),current=c.getLong(3),deadline=c.getLong(4);String name=c.getString(1),note=c.getString(5);int pct=target<=0?0:(int)Math.min(100,current*100.0/target);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(name,16,TEXT,true));card.addView(text("پس‌انداز: "+money(current)+" از "+money(target),13,Color.rgb(86, 99, 91),false));ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(pct);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(8)));card.addView(text(pct+"٪ پیشرفت"+(deadline>0?" • موعد: "+jalaliDate(deadline):""),12,GREEN,false));if(note!=null&&!note.isEmpty())card.addView(text(note,12,Color.rgb(86, 99, 91),false));Button add=button("ثبت مبلغ پس‌اندازشده");card.addView(add);add.setOnClickListener(v->contributeGoal(id,name,target,current));body.addView(card,new LinearLayout.LayoutParams(-1,-2));}while(c.moveToNext());c.close();
    }

    private void goalDialog() {
        LinearLayout f=formLayout();EditText name=edit("عنوان هدف (مثلاً خرید خودرو)",InputType.TYPE_CLASS_TEXT),target=edit("مبلغ هدف به تومان",InputType.TYPE_CLASS_NUMBER),note=edit("یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);f.addView(name);f.addView(target);f.addView(note);new AlertDialog.Builder(this).setTitle("هدف پس‌انداز جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();long t=parseAmount(target.getText().toString());if(n.isEmpty()||t<=0){toast("عنوان و مبلغ هدف معتبر وارد کن");return;}ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("target",t);v.put("current_amount",0);v.put("deadline",0);v.put("note",note.getText().toString());db.getWritableDatabase().insert("goals",null,v);showGoals();}).show();
    }

    private void contributeGoal(long id,String name,long target,long current) {
        EditText amount=edit("مبلغ جدید پس‌اندازشده به تومان",InputType.TYPE_CLASS_NUMBER);new AlertDialog.Builder(this).setTitle("به‌روزرسانی هدف «"+name+"»").setView(amount).setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{long a=parseAmount(amount.getText().toString());if(a<=0){toast("مبلغ باید بیشتر از صفر باشد");return;}ContentValues v=new ContentValues();v.put("current_amount",Math.min(target,current+a));db.getWritableDatabase().update("goals",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});showGoals();}).show();
    }

    private void exportTransactionsCsv() {
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"HisabYar-transactions.csv");startActivityForResult(i,703);
    }

    private void showAssets() {
        body.removeAllViews(); addHeading("دارایی‌ها و ارزش خالص");
        Button add=button("＋ افزودن دارایی");body.addView(add);add.setOnClickListener(v->showAssetDialog());
        long total=0; Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,value,note FROM assets WHERE book=? ORDER BY name",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز دارایی ثبت نشده است.");return;}
        do {String name=c.getString(0),kind=c.getString(1),note=c.getString(3);long val=c.getLong(2);total+=val;
            LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setPadding(dp(12),dp(10),dp(12),dp(10));item.setBackground(roundBg(Color.WHITE));
            item.addView(text(name+" • "+kind,15,TEXT,true));item.addView(text(money(val),16,GREEN,true));if(note!=null&&!note.isEmpty())item.addView(text(note,12,Color.rgb(86, 99, 91),false));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        }while(c.moveToNext());c.close();
        addMetric("ارزش دارایی‌های ثبت‌شده",money(total),GREEN);
    }
    private void showAssetDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام دارایی",InputType.TYPE_CLASS_TEXT),kind=edit("نوع (طلا، خودرو، ملک و ...)",InputType.TYPE_CLASS_TEXT),value=edit("ارزش فعلی به تومان",InputType.TYPE_CLASS_NUMBER),note=edit("یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(name);f.addView(kind);f.addView(value);f.addView(note);
        new AlertDialog.Builder(this).setTitle("افزودن دارایی").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long val=parseAmount(value.getText().toString());if(name.getText().toString().trim().isEmpty()||val<0){toast("نام و ارزش دارایی را بررسی کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name.getText().toString().trim());v.put("kind",kind.getText().toString().trim());v.put("value",val);v.put("note",note.getText().toString());db.getWritableDatabase().insert("assets",null,v);navigate("دارایی‌ها");
        }).show();
    }
    private void showDebtDialog() {
        LinearLayout f=formLayout();
        EditText person=edit("نام شخص",InputType.TYPE_CLASS_TEXT);
        Spinner kind=new Spinner(this); String[] kinds={"طلب از شخص","بدهی به شخص"}; kind.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,kinds));
        EditText amount=edit("مبلغ کل به تومان",InputType.TYPE_CLASS_NUMBER),note=edit("شرح (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(person);f.addView(kind);f.addView(amount);f.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت بدهی یا طلب").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long a=parseAmount(amount.getText().toString());String who=person.getText().toString().trim();
            if(a<=0||who.isEmpty()){toast("نام و مبلغ را درست وارد کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("person",who);v.put("kind",kind.getSelectedItem().toString());v.put("amount",a);v.put("paid",0);v.put("note",note.getText().toString());v.put("date",System.currentTimeMillis());
            db.getWritableDatabase().insert("debts",null,v);toast("بدهی/طلب ثبت شد");showDebts();
        }).show();
    }
    private void showDebts() {
        body.removeAllViews();addHeading("بدهی‌ها و طلب‌ها");
        addWideButton("＋ ثبت بدهی یا طلب",()->showDebtDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,person,kind,amount,paid,note,date FROM debts WHERE book=? ORDER BY date DESC",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز بدهی یا طلبی ثبت نشده است.");return;}
        do {
            long id=c.getLong(0), amount=c.getLong(3), paid=c.getLong(4);String person=c.getString(1),kind=c.getString(2),note=c.getString(5);long remaining=Math.max(0,amount-paid);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));
            card.addView(text(person+" • "+kind,15,TEXT,true));card.addView(text("کل: "+money(amount)+" | تسویه: "+money(paid),13,Color.rgb(86, 99, 91),false));
            card.addView(text("مانده: "+money(remaining),16,remaining==0?GREEN:Color.rgb(183,74,60),true));if(note!=null&&!note.isEmpty())card.addView(text(note,12,Color.rgb(86, 99, 91),false));
            Button settle=button(remaining==0?"تسویه کامل شده":"ثبت تسویه / دریافت" );settle.setEnabled(remaining>0);card.addView(settle);settle.setOnClickListener(v->settleDebt(id,person,kind,remaining));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(card,lp);
        }while(c.moveToNext());c.close();
    }
    private void settleDebt(long id,String person,String kind,long remaining) {
        EditText amount=edit("مبلغ این تسویه (مانده: "+remaining+")",InputType.TYPE_CLASS_NUMBER);amount.setText(String.valueOf(remaining));
        new AlertDialog.Builder(this).setTitle("تسویه با "+person).setView(amount).setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{
            long a=parseAmount(amount.getText().toString());if(a<=0||a>remaining){toast("مبلغ باید بین ۱ تا مانده بدهی باشد");return;}
            SQLiteDatabase sql=db.getWritableDatabase();
            sql.execSQL("UPDATE debts SET paid=MIN(amount,paid+?) WHERE id=?",new Object[]{a,id});
            String txType=kind.contains("بدهی")?"هزینه":"درآمد";String cat=kind.contains("بدهی")?"تسویه بدهی":"دریافت طلب";ensureAccount("پول نقد");
            ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",txType);tx.put("amount",a);tx.put("category",cat);tx.put("account","پول نقد");tx.put("note","تسویه با "+person);tx.put("date",System.currentTimeMillis());sql.insert("transactions",null,tx);
            toast("تسویه ثبت شد");showDebts();
        }).show();
    }
    private void showSettings() {
        body.removeAllViews();addHeading("تنظیمات");
        addWideButton("مدیریت دفترها",()->manageBooks());
        addWideButton("مدیریت حساب‌ها و موجودی",()->showAccounts());
        addWideButton("افزودن حساب بانکی یا کیف پول",()->addAccountDialog());
        addWideButton("مدیریت دسته‌بندی‌ها",()->manageCategories());
        addWideButton("بودجه‌بندی ماهانه و هشدار هزینه",()->showBudgets());
        addWideButton("پرداخت‌های تکرارشونده و سررسیدها",()->showRecurring());
        addWideButton("هدف‌های پس‌انداز",()->showGoals());
        addWideButton("خروجی گزارش تراکنش‌ها (CSV)",()->exportTransactionsCsv());
        addWideButton("گزارش مالی و ارزش خالص دارایی",()->showReports());
        addWideButton("بدهی‌ها، طلب‌ها و تسویه",()->showDebts());
        addWideButton("قفل برنامه با رمز عددی",()->setPinDialog());
        addWideButton("پشتیبان‌گیری از اطلاعات",()->exportBackup());
        addWideButton("بازیابی پشتیبان",()->importBackup());
        addWideButton("درباره برنامه",()->new AlertDialog.Builder(this).setTitle("حساب‌یار ۱.۱.۰").setMessage("حسابداری شخصی فارسی؛ ذخیره‌سازی محلی روی گوشی، دفترهای جداگانه، حساب‌ها، جست‌وجوی تراکنش، پرداخت‌های تکرارشونده، هدف پس‌انداز، دارایی‌ها، بدهی و طلب، بودجه، گزارش و پشتیبان‌گیری. قفل عددی برنامه جایگزین رمزنگاری فایل پایگاه داده نیست.").setPositiveButton("باشه",null).show());
        addEmpty("واحد: تومان • تاریخ نمایشی: شمسی • داده‌ها روی همین گوشی ذخیره می‌شوند.");
    }
    private void showBudgets() {
        body.removeAllViews();addHeading("بودجه‌بندی ماهانه");
        addWideButton("＋ تعریف سقف هزینه برای دسته‌بندی",()->budgetDialog());
        String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT category,limit_amount FROM budgets WHERE book=? AND month=? ORDER BY category",new String[]{activeBook,month});
        if(!c.moveToFirst()){c.close();addEmpty("برای این ماه بودجه‌ای تعریف نشده است.");return;}
        do {String cat=c.getString(0);long limit=c.getLong(1),spent=categoryExpenseThisMonth(cat);int pct=limit<=0?0:(int)Math.min(100,spent*100.0/limit);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(cat,15,TEXT,true));card.addView(text("هزینه: "+money(spent)+" / بودجه: "+money(limit),13,TEXT,false));
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(pct);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(8)));
            card.addView(text(pct>=100?"هشدار: بودجه مصرف شده است":"مصرف بودجه: "+pct+"٪",12,pct>=100?Color.rgb(183,74,60):GREEN,false));body.addView(card,new LinearLayout.LayoutParams(-1,-2));
        }while(c.moveToNext());c.close();
    }
    private void budgetDialog() {
        LinearLayout f=formLayout();EditText cat=edit("دسته‌بندی هزینه (مثلاً خوراک)",InputType.TYPE_CLASS_TEXT),limit=edit("سقف بودجه ماهانه به تومان",InputType.TYPE_CLASS_NUMBER);f.addView(cat);f.addView(limit);
        new AlertDialog.Builder(this).setTitle("تعریف بودجه ماه جاری").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String name=cat.getText().toString().trim();long amount=parseAmount(limit.getText().toString());if(name.isEmpty()||amount<=0){toast("دسته‌بندی و سقف معتبر وارد کن");return;}String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());SQLiteDatabase sql=db.getWritableDatabase();sql.delete("budgets","book=? AND category=? AND month=?",new String[]{activeBook,name,month});ContentValues v=new ContentValues();v.put("book",activeBook);v.put("category",name);v.put("month",month);v.put("limit_amount",amount);sql.insert("budgets",null,v);showBudgets();}).show();
    }
    private long categoryExpenseThisMonth(String cat) {
        Calendar cal=Calendar.getInstance();cal.set(Calendar.DAY_OF_MONTH,1);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);long start=cal.getTimeInMillis();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type='هزینه' AND category=? AND date>=?",new String[]{activeBook,cat,String.valueOf(start)});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;
    }
    private void showReports() {
        body.removeAllViews();addHeading("گزارش مالی و ارزش خالص");long income=sum("درآمد"),expense=sum("هزینه"),assets=scalar("SELECT COALESCE(SUM(value),0) FROM assets WHERE book=?",activeBook),receivable=scalar("SELECT COALESCE(SUM(amount-paid),0) FROM debts WHERE book=? AND kind LIKE '%طلب%'",activeBook),payable=scalar("SELECT COALESCE(SUM(amount-paid),0) FROM debts WHERE book=? AND kind LIKE '%بدهی%'",activeBook);
        addMetric("موجودی نقدی محاسبه‌شده",money(balance()),GREEN);addMetric("درآمد ثبت‌شده",money(income),GREEN);addMetric("هزینه ثبت‌شده",money(expense),Color.rgb(183,74,60));addMetric("خالص درآمد منهای هزینه",money(income-expense),income>=expense?GREEN:Color.rgb(183,74,60));addMetric("ارزش دارایی‌های غیرنقدی",money(assets),GREEN);addMetric("طلب‌های باز",money(receivable),GREEN);addMetric("بدهی‌های باز",money(payable),Color.rgb(183,74,60));addMetric("ارزش خالص تقریبی",money(balance()+assets+receivable-payable),GREEN);
        addHeading("هزینه بر اساس دسته‌بندی");Cursor c=db.getReadableDatabase().rawQuery("SELECT category,SUM(amount) total FROM transactions WHERE book=? AND type='هزینه' GROUP BY category ORDER BY total DESC",new String[]{activeBook});if(!c.moveToFirst())addEmpty("هنوز هزینه‌ای ثبت نشده است.");else do{addEmpty(c.getString(0)+"  •  "+money(c.getLong(1)));}while(c.moveToNext());c.close();
        addHeading("خلاصه ۳۰ روز اخیر");long since=System.currentTimeMillis()-30L*24*60*60*1000;addEmpty("درآمد: "+money(sumSince("درآمد",since))+"\nهزینه: "+money(sumSince("هزینه",since)));
    }
    private long scalar(String query,String book){Cursor c=db.getReadableDatabase().rawQuery(query,new String[]{book});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    private long sumSince(String type,long since){Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=? AND date>=?",new String[]{activeBook,type,String.valueOf(since)});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    private void exportBackup() {
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"HisabYar-backup.db");startActivityForResult(i,REQ_EXPORT_BACKUP);
    }
    private void importBackup() {
        new AlertDialog.Builder(this).setTitle("بازیابی پشتیبان").setMessage("ابتدا فایل بررسی می‌شود. فقط اگر پایگاه داده سالم باشد، اطلاعات فعلی جایگزین می‌شود. بهتر است پیش از ادامه یک پشتیبان از اطلاعات فعلی بگیری.").setNegativeButton("انصراف",null).setPositiveButton("انتخاب فایل",(d,w)->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");startActivityForResult(i,REQ_IMPORT_BACKUP);}).show();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == REQ_VOICE_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                java.util.ArrayList<String> results = data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) processVoiceCommand(results.get(0));
                else toast("متن گفتار دریافت نشد؛ زبان فارسی و سرویس گفتار را بررسی کن.");
            } else {
                toast("تشخیص گفتار انجام نشد؛ اینترنت، مجوز میکروفون و سرویس گفتار گوگل را بررسی کن.");
            }
            return;
        }
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try {
            if(requestCode==REQ_EXPORT_BACKUP) {
                db.close();
                try(InputStream in=new FileInputStream(getDatabasePath("hisabyar.db"));OutputStream out=getContentResolver().openOutputStream(uri)){copy(in,out);}
                db=new DB(this);db.getWritableDatabase();toast("پشتیبان ذخیره شد");
            } else if(requestCode==REQ_IMPORT_BACKUP) {
                File temp=new File(getCacheDir(),"hisabyar_restore.tmp");
                try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(temp)){copy(in,out);}
                SQLiteDatabase check=null;
                try {
                    check=SQLiteDatabase.openDatabase(temp.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
                    Cursor integrity=check.rawQuery("PRAGMA integrity_check",null);boolean healthy=integrity.moveToFirst()&&"ok".equalsIgnoreCase(integrity.getString(0));integrity.close();
                    Cursor tables=check.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('books','accounts','transactions','debts','assets','budgets')",null);boolean valid=tables.moveToFirst()&&tables.getInt(0)>=6;tables.close();
                    if(!healthy||!valid)throw new IOException("فایل انتخاب‌شده پشتیبان معتبر حساب‌یار نیست.");
                } finally {if(check!=null)check.close();}
                db.close();File dest=getDatabasePath("hisabyar.db");File wal=new File(dest.getPath()+"-wal"),shm=new File(dest.getPath()+"-shm");if(wal.exists())wal.delete();if(shm.exists())shm.delete();
                if(dest.exists()&&!dest.delete())throw new IOException("جایگزینی پایگاه داده انجام نشد.");
                if(!temp.renameTo(dest)){try(InputStream in=new FileInputStream(temp);OutputStream out=new FileOutputStream(dest)){copy(in,out);}temp.delete();}
                db=new DB(this);db.getWritableDatabase();toast("پشتیبان سالم بازیابی شد");navigate("خانه");
            } else if(requestCode==703) {
                try(OutputStream out=getContentResolver().openOutputStream(uri);BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(out,StandardCharsets.UTF_8))) {
                    writer.write("\uFEFFتاریخ,نوع,مبلغ تومان,دسته‌بندی,حساب,شرح\n");
                    Cursor c=db.getReadableDatabase().rawQuery("SELECT type,amount,category,account,note,date FROM transactions WHERE book=? ORDER BY date DESC",new String[]{activeBook});
                    while(c.moveToNext())writer.write(csv(jalaliDate(c.getLong(5))+"")+","+csv(c.getString(0))+","+c.getLong(1)+","+csv(c.getString(2))+","+csv(c.getString(3))+","+csv(c.getString(4))+"\n");
                    c.close();writer.flush();toast("گزارش CSV ذخیره شد");
                }
            }
        } catch(Exception e) {
            if(db==null)db=new DB(this);
            try{db.getWritableDatabase();}catch(Exception ignored){}
            toast("عملیات انجام نشد: "+e.getMessage());
        }
    }
    private void copy(InputStream in,OutputStream out)throws IOException {if(in==null||out==null)throw new IOException("فایل باز نشد");byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);out.flush();}
    private String csv(String s){if(s==null)return "\"\"";return "\""+s.replace("\"","\"\"").replace("\r"," ").replace("\n"," ")+"\"";}
    private String hashPin(String salt,String pin) {
        try {byte[] bytes=MessageDigest.getInstance("SHA-256").digest((salt+":"+pin).getBytes(StandardCharsets.UTF_8));StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format(Locale.US,"%02x",b&0xff));return out.toString();}
        catch(Exception e){return "";}
    }
    private void setPinDialog() {
        String old=getPreferences(0).getString("app_pin_hash",getPreferences(0).getString("app_pin",""));
        LinearLayout f=formLayout();EditText pin=edit("رمز عددی ۴ تا ۸ رقمی (خالی = حذف رمز)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);f.addView(pin);
        new AlertDialog.Builder(this).setTitle(old.isEmpty()?"تنظیم قفل برنامه":"تغییر یا حذف قفل").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            String p=pin.getText().toString().trim();if(!p.isEmpty()&&(p.length()<4||p.length()>8)){toast("رمز باید ۴ تا ۸ رقم باشد");return;}
            android.content.SharedPreferences.Editor editor=getPreferences(0).edit();
            if(p.isEmpty())editor.remove("app_pin").remove("app_pin_hash").remove("app_pin_salt");
            else {String salt=java.util.UUID.randomUUID().toString();String hash=hashPin(salt,p);if(hash.isEmpty()){toast("تنظیم قفل ناموفق بود");return;}editor.putString("app_pin_salt",salt).putString("app_pin_hash",hash).remove("app_pin");}
            editor.apply();toast(p.isEmpty()?"قفل حذف شد":"قفل برنامه فعال شد");
        }).show();
    }
    private void promptUnlockIfNeeded() {
        String storedHash=getPreferences(0).getString("app_pin_hash","");String legacy=getPreferences(0).getString("app_pin","");
        if(storedHash.isEmpty()&&legacy.isEmpty())return;
        EditText input=edit("رمز عددی برنامه",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("حساب‌یار قفل است").setView(input).setCancelable(false).setPositiveButton("باز کردن",null).create();
        dlg.setOnShowListener(x->dlg.getButton(-1).setOnClickListener(v->{String entered=input.getText().toString();boolean ok;
            if(!storedHash.isEmpty())ok=storedHash.equals(hashPin(getPreferences(0).getString("app_pin_salt",""),entered));else ok=legacy.equals(entered);
            if(ok){if(storedHash.isEmpty()){String salt=java.util.UUID.randomUUID().toString();getPreferences(0).edit().putString("app_pin_salt",salt).putString("app_pin_hash",hashPin(salt,legacy)).remove("app_pin").apply();}dlg.dismiss();}
            else{input.setText("");input.setError("رمز اشتباه است");}
        }));dlg.show();
    }
    private String jalaliDate(long millis){Calendar c=Calendar.getInstance();c.setTimeInMillis(millis);int gy=c.get(Calendar.YEAR),gm=c.get(Calendar.MONTH)+1,gd=c.get(Calendar.DAY_OF_MONTH);int[] j=gregorianToJalali(gy,gm,gd);return String.format(new Locale("fa","IR"),"%04d/%02d/%02d",j[0],j[1],j[2]);}
    private int[] gregorianToJalali(int gy,int gm,int gd){int[] gdm={0,31,59,90,120,151,181,212,243,273,304,334};int gy2=gm>2?gy+1:gy;int days=355666+365*gy+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400+gd+gdm[gm-1];int jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365;}int jm,jd;if(days<186){jm=1+days/31;jd=1+days%31;}else{jm=7+(days-186)/30;jd=1+(days-186)%30;}return new int[]{jy,jm,jd};}
    private void chooseBook() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM books ORDER BY id",null);java.util.ArrayList<String> names=new java.util.ArrayList<>();while(c.moveToNext())names.add(c.getString(0));c.close();
        String[] a=names.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("انتخاب دفتر").setItems(a,(d,w)->{activeBook=a[w];getPreferences(0).edit().putString("active_book",activeBook).apply();ensureBookAccount();navigate("خانه");}).setNegativeButton("انصراف",null).show();
    }
    private void manageBooks() {
        LinearLayout f=formLayout();EditText name=edit("نام دفتر جدید (مثلاً شخصی، گلخانه)",InputType.TYPE_CLASS_TEXT);f.addView(name);
        new AlertDialog.Builder(this).setTitle("افزودن دفتر مالی").setView(f).setNeutralButton("انتخاب دفتر",(d,w)->chooseBook()).setNegativeButton("بستن",null).setPositiveButton("افزودن",(d,w)->{String n=name.getText().toString().trim();if(!n.isEmpty()){Cursor ex=db.getReadableDatabase().rawQuery("SELECT id FROM books WHERE name=?",new String[]{n});boolean dup=ex.moveToFirst();ex.close();if(dup){toast("این دفتر از قبل وجود دارد");return;}addBookRaw(n);activeBook=n;getPreferences(0).edit().putString("active_book",activeBook).apply();ensureBookAccount();toast("دفتر اضافه شد");navigate("خانه");}}).show();
    }
    private void addAccountDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام حساب",InputType.TYPE_CLASS_TEXT),kind=edit("نوع حساب (بانکی/نقدی/کیف پول)",InputType.TYPE_CLASS_TEXT),opening=edit("موجودی اولیه به تومان",InputType.TYPE_CLASS_NUMBER);f.addView(name);f.addView(kind);f.addView(opening);
        new AlertDialog.Builder(this).setTitle("حساب جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty())return;long initial=parseAmount(opening.getText().toString());if(initial<0){toast("موجودی اولیه نمی‌تواند منفی باشد");return;}ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("kind",kind.getText().toString().trim().isEmpty()?"نقدی":kind.getText().toString().trim());v.put("opening",initial);Cursor exists=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{activeBook,n});boolean duplicate=exists.moveToFirst();exists.close();if(duplicate){toast("این نام حساب از قبل وجود دارد");return;}db.getWritableDatabase().insert("accounts",null,v);navigate("خانه");}).show();
    }
    private void ensureAccount(String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{activeBook,name});boolean exists=c.moveToFirst();c.close();
        if(!exists){ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name);v.put("kind","نقدی");v.put("opening",0);db.getWritableDatabase().insert("accounts",null,v);}
    }
    private void ensureBookAccount() { if(countForBook("accounts",activeBook)==0)ensureAccount("پول نقد"); }
    private long sum(String type) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=?",new String[]{activeBook,type});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;
    }
    private long balance() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(opening),0) FROM accounts WHERE book=?",new String[]{activeBook});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();
        Cursor t=db.getReadableDatabase().rawQuery("SELECT type,amount FROM transactions WHERE book=?",new String[]{activeBook});
        while(t.moveToNext()){String type=t.getString(0);long a=t.getLong(1);if(type.equals("درآمد")||type.equals("انتقال ورودی"))n+=a;else if(type.equals("هزینه")||type.equals("انتقال خروجی"))n-=a;}t.close();return n;
    }
    private long parseAmount(String s) {
        if(s==null)return 0;
        String v=s.trim().replace(",","").replace("٬","").replace("،","").replace(" ","");
        StringBuilder out=new StringBuilder();
        for(int i=0;i<v.length();i++){
            char ch=v.charAt(i);
            if(ch>='۰'&&ch<='۹') ch=(char)('0'+(ch-'۰'));
            else if(ch>='٠'&&ch<='٩') ch=(char)('0'+(ch-'٠'));
            if(ch>='0'&&ch<='9')out.append(ch);
        }
        try{return Long.parseLong(out.toString());}catch(Exception e){return 0;}
    }
    private String money(long n) { NumberFormat f=NumberFormat.getInstance(new Locale("fa","IR"));return f.format(n)+" تومان"; }
    private void addHeading(String s) {
        TextView t = text(s, 17, TEXT, true);
        t.setPadding(dp(2), dp(16), dp(2), dp(9));
        body.addView(t);
    }

    private void addEmpty(String s) {TextView t=text(s,14,Color.rgb(86, 99, 91),false);t.setGravity(Gravity.CENTER);t.setPadding(dp(16),dp(20),dp(16),dp(20));body.addView(t);}
    private void addWideButton(String s,Runnable r) {
        TextView b = text(s + "   ›", 15, GREEN, true);
        b.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        b.setPadding(dp(16), dp(13), dp(16), dp(13));
        b.setBackground(roundBg(Color.WHITE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.setMargins(0, dp(4), 0, dp(4));
        body.addView(b, lp);
        b.setOnClickListener(v -> r.run());
    }

    private View actionBox(String s,Runnable r) {
        TextView t = text(s, 14, GREEN, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundBg(Color.WHITE));
        t.setElevation(dp(1));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private LinearLayout formLayout(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(20),dp(8),dp(20),dp(4));return l;}
    private EditText edit(String hint,int inputType){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine(true);e.setInputType(inputType);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(dp(8),dp(6),dp(8),dp(6));return e;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT);t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));t.setIncludeFontPadding(true);t.setLineSpacing(dp(1),1.0f);t.setPadding(0,dp(3),0,dp(3));return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(GREEN);b.setAllCaps(false);return b;}
    private android.graphics.drawable.GradientDrawable roundBg(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private class DB extends SQLiteOpenHelper {
        DB(Activity a){super(a,"hisabyar.db",null,6);}
        @Override public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE)");
            d.execSQL("CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,opening INTEGER NOT NULL DEFAULT 0)");
            d.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,name TEXT NOT NULL)");
            d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,note TEXT,date INTEGER NOT NULL,transfer_id TEXT)");
            d.execSQL("CREATE TABLE assets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,value INTEGER NOT NULL,note TEXT)");
            d.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,person TEXT NOT NULL,kind TEXT,amount INTEGER NOT NULL,paid INTEGER NOT NULL DEFAULT 0,note TEXT,date INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE budgets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,category TEXT NOT NULL,month TEXT NOT NULL,limit_amount INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE recurring(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,frequency TEXT NOT NULL,next_due INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,target INTEGER NOT NULL,current_amount INTEGER NOT NULL DEFAULT 0,deadline INTEGER NOT NULL DEFAULT 0,note TEXT)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_book_date ON transactions(book,date)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_debts_book ON debts(book)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_budgets_book_month ON budgets(book,month)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int oldVersion,int newVersion){
            if(oldVersion<2){d.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_book_date ON transactions(book,date)");d.execSQL("CREATE INDEX IF NOT EXISTS idx_debts_book ON debts(book)");d.execSQL("CREATE INDEX IF NOT EXISTS idx_budgets_book_month ON budgets(book,month)");}
            if(oldVersion<4){d.execSQL("CREATE TABLE IF NOT EXISTS recurring(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,frequency TEXT NOT NULL,next_due INTEGER NOT NULL)");}
            if(oldVersion<5){d.execSQL("CREATE TABLE IF NOT EXISTS goals(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,target INTEGER NOT NULL,current_amount INTEGER NOT NULL DEFAULT 0,deadline INTEGER NOT NULL DEFAULT 0,note TEXT)");}
            if(oldVersion<6){d.execSQL("ALTER TABLE transactions ADD COLUMN transfer_id TEXT");}
        }
    }
}
