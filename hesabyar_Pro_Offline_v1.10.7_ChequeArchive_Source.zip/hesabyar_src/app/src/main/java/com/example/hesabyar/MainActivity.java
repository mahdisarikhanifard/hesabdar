package com.example.hesabyar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.WindowInsets;
import android.os.Build;
import android.widget.*;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.PrintWriter;
import android.content.ClipboardManager;
import android.content.ClipData;
import java.io.File;
import java.util.Locale;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private static final String VOICE_TAG = "HisabYarProVoice";
    // HisabYar Pro uses an embedded Persian Vosk model. Audio recognition is fully local.
    private org.vosk.Model offlineVoiceModel;
    private org.vosk.Recognizer offlineVoiceRecognizer;
    private org.vosk.android.SpeechService offlineSpeechService;
    private boolean offlineVoiceReady = false;
    private boolean offlineVoiceLoading = false;
    private boolean voiceButtonHeld = false;
    private boolean voiceStopRequested = false;
    private boolean voiceResultHandled = false;
    private boolean widgetVoiceLaunchPending = false;
    private boolean widgetVoiceMode = false;
    private boolean widgetVoiceUnlockPending = false;
    public static final String ACTION_WIDGET_VOICE = "com.example.hesabyar.ACTION_WIDGET_VOICE";
    public static final String ACTION_REVIEW_BANK_CANDIDATE = "com.example.hesabyar.ACTION_REVIEW_BANK_CANDIDATE";
    public static final String EXTRA_BANK_CANDIDATE_KEY = "bank_candidate_key";
    private String pendingBankCandidateKey = "";
    private boolean appUnlocked = true;
    private boolean pendingOpenBankNotificationSettings = false;
    private static final int GREEN = Color.rgb(226, 78, 116);
    private static final int DARK = Color.rgb(142, 35, 67);
    private static final int BG = Color.rgb(255, 245, 247);
    private static final int TEXT = Color.rgb(35, 45, 40);
    private DB db;
    private static final int[] THEME_COLORS = new int[]{Color.rgb(226,78,116), Color.rgb(33,150,243), Color.rgb(76,175,80), Color.rgb(103,58,183), Color.rgb(255,152,0), Color.rgb(0,150,136), Color.rgb(55,71,79), Color.rgb(233,30,99)};
    private static final String[] THEME_NAMES = new String[]{"صورتی", "آبی", "سبز", "بنفش", "نارنجی", "فیروزه‌ای", "ذغالی", "سرخابی"};
    private int selectedThemeColor() { return getPreferences(0).getInt("theme_color", THEME_COLORS[0]); }
    private int darken(int color) { return Color.rgb((int)(Color.red(color)*0.65f),(int)(Color.green(color)*0.65f),(int)(Color.blue(color)*0.65f)); }
    private int lighten(int color, float amount) { return Color.rgb((int)(Color.red(color)+(255-Color.red(color))*amount),(int)(Color.green(color)+(255-Color.green(color))*amount),(int)(Color.blue(color)+(255-Color.blue(color))*amount)); }
    private void applyThemeToShell() {
        int c=selectedThemeColor();
        if(root!=null) root.setBackgroundColor(lighten(c,0.93f));
        if(topbar!=null) topbar.setBackground(gradientBg(new int[]{darken(c),c,darken(c)},dp(20)));
        if(navBar!=null) navBar.setBackground(gradientBg(new int[]{lighten(c,0.82f),lighten(c,0.48f),c,lighten(c,0.48f),lighten(c,0.82f)},dp(22)));
        if(Build.VERSION.SDK_INT>=21) {
            getWindow().setStatusBarColor(lighten(c,0.82f));
            getWindow().setNavigationBarColor(darken(c));
        }
    }
    private void showThemePalette(LinearLayout target) {
        target.addView(text("رنگ تم برنامه",16,TEXT,true));
        target.addView(text("رنگ دلخواه را انتخاب کنید؛ انتخاب شما ذخیره می‌شود.",12,TEXT,false));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,dp(8),0,dp(8));
        for(int i=0;i<THEME_COLORS.length;i++) { final int color=THEME_COLORS[i]; final String name=THEME_NAMES[i];
            TextView swatch=new TextView(this); swatch.setText("●"); swatch.setTextSize(29); swatch.setGravity(Gravity.CENTER); swatch.setTextColor(color); swatch.setContentDescription(name);
            android.graphics.drawable.GradientDrawable bg=ovalBg(lighten(color,0.8f)); bg.setStroke(dp(selectedThemeColor()==color?4:1),selectedThemeColor()==color?darken(color):Color.LTGRAY); swatch.setBackground(bg);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1); lp.setMargins(dp(2),0,dp(2),0); row.addView(swatch,lp);
            swatch.setOnClickListener(v->{getPreferences(0).edit().putInt("theme_color",color).apply(); applyThemeToShell(); showThemePaletteRefresh(); toast("تم برنامه: "+name);});
        }
        target.addView(row);
    }
    private void showThemePaletteRefresh() {
        applyThemeToShell();
        if ("تنظیمات".equals(page)) showSettings();
        else { showShell(); if ("خانه".equals(page)) showHome(); else showSettings(); }
    }

    private android.speech.SpeechRecognizer speechRecognizer;
    private LinearLayout root, body, topbar, navBar;
    private TextView headerTitle, headerHint, headerDateTime;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable clockTicker = new Runnable() { @Override public void run() { updateHeaderClock(); uiHandler.postDelayed(this, 60_000); } };
    private String activeBook = "شخصی";
    private String page = "خانه";
    private static final int REQ_EXPORT_BACKUP = 701;
    private static final int REQ_IMPORT_BACKUP = 702;
    private static final int REQ_EXPORT_CSV = 703;
    private static final int REQ_AUDIO_PERMISSION = 704;
    private static final int REQ_VOICE_INPUT = 705;
    private static final int REQ_CHEQUE_EXPORT = 707;
    private String pendingChequeCsv = "";
    private EditText chequeNumberField, chequeBankField, chequePartyField, chequeAmountField, chequeDueField, chequeAccountField, chequeNoteField;
    private Spinner chequeDirectionSpinner, chequeStatusSpinner;
    private String pendingChequeImagePath = "";

    @Override public void onCreate(Bundle b) {
        widgetVoiceMode = getIntent() != null && ACTION_WIDGET_VOICE.equals(getIntent().getAction());
        if (widgetVoiceMode) setTheme(R.style.WidgetVoicePopupTheme);
        super.onCreate(b);
        widgetVoiceLaunchPending = widgetVoiceMode;
        db = new DB(this);
        activeBook = getPreferences(0).getString("active_book", "شخصی");
        ensureDefaults();
        widgetVoiceUnlockPending = widgetVoiceMode && (!getPreferences(0).getString("app_pin_hash", "").isEmpty() || !getPreferences(0).getString("app_pin", "").isEmpty());
        showShell();
        if (widgetVoiceMode) { showWidgetVoiceShell(); applyWidgetPopupWindow(); } else showHome();
        promptUnlockIfNeeded();
        consumeBankCandidateIntent(getIntent());
        prepareOfflineVoiceModel();
        if (widgetVoiceLaunchPending && !widgetVoiceUnlockPending && offlineVoiceReady) {
            uiHandler.postDelayed(() -> startWidgetVoiceCapture(), 450);
        }
        // Safe daily snapshot: never create a new snapshot from an unexpectedly empty database.
        uiHandler.postDelayed(() -> {
            try {
                long last = getPreferences(0).getLong("last_auto_backup_at", 0L);
                if (System.currentTimeMillis() - last >= 24L * 60L * 60L * 1000L) createAutomaticBackup();
            } catch (Exception e) { Log.e("HisabYarBackup", "Daily automatic backup failed", e); }
            if (getPreferences(0).getBoolean("confirm_bank_messages_on_start", false) && pendingBankCandidateKey.isEmpty()) reviewNextBankCandidate();
            android.content.SharedPreferences bankPrefs=android.preference.PreferenceManager.getDefaultSharedPreferences(this);
            if((getIntent()==null||!ACTION_REVIEW_BANK_CANDIDATE.equals(getIntent().getAction()))&&(bankPrefs.getBoolean("bank_sms_enabled",false)||bankPrefs.getBoolean("bank_notifications_enabled",false))&&Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestBankNotificationPermission();
        }, 1200);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && ACTION_REVIEW_BANK_CANDIDATE.equals(intent.getAction())) {
            consumeBankCandidateIntent(intent);
            return;
        }
        if (intent != null && ACTION_WIDGET_VOICE.equals(intent.getAction())) {
            widgetVoiceMode = true;
            showWidgetVoiceShell();
            applyWidgetPopupWindow();
            widgetVoiceLaunchPending = true;
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, REQ_AUDIO_PERMISSION);
            } else if (offlineVoiceReady) {
                uiHandler.postDelayed(() -> startWidgetVoiceCapture(), 250);
            } else if (!offlineVoiceLoading) {
                prepareOfflineVoiceModel();
            }
        }
    }

    private void applyWidgetPopupWindow() {
        if (getWindow() == null) return;
        android.view.WindowManager.LayoutParams params = getWindow().getAttributes();
        params.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.86f);
        params.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
        params.gravity = Gravity.CENTER;
        params.dimAmount = 0.35f;
        params.flags |= android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        getWindow().setAttributes(params);
        getWindow().setBackgroundDrawableResource(R.drawable.widget_voice_popup_background);
    }

    private void showWidgetVoiceShell() {
        root.removeAllViews();
        root.setPadding(dp(20), dp(18), dp(20), dp(18));
        root.setGravity(Gravity.CENTER);
        root.setBackground(roundBg(Color.rgb(255, 245, 247)));
        TextView heading = text("دستیار صوتی حساب‌یار", 19, DARK, true);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading, new LinearLayout.LayoutParams(-1, -2));
        TextView hint = text("فرمان مالی خود را بیان کنید. پیش از ثبت، مبلغ و دسته‌بندی را تأیید خواهید کرد.", 13, TEXT, false);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(10), 0, dp(12));
        root.addView(hint, new LinearLayout.LayoutParams(-1, -2));
        Button listen = button("شروع / تکرار ضبط صوتی");
        listen.setOnClickListener(v -> { widgetVoiceLaunchPending = false; startVoiceAssistant(); });
        root.addView(listen, new LinearLayout.LayoutParams(-1, dp(48)));
        Button close = button("بستن");
        close.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, dp(42));
        closeLp.topMargin = dp(8);
        root.addView(close, closeLp);
        HesabyarVoiceWidgetProvider.updateStatus(this, "دستیار باز است");
    }

    private void ensureDefaults() {
        SQLiteDatabase w = db.getWritableDatabase();
        if (count("books") == 0) {
            addBookRaw("شخصی");
            addBookRaw("کسب‌وکار");
        }
        if (countForBook("accounts", activeBook) == 0) {
            ContentValues v = new ContentValues();
            v.put("book", activeBook); v.put("name", "پول نقد"); v.put("kind", "نقدی"); v.put("opening", 0L); v.put("account_uid", java.util.UUID.randomUUID().toString()); v.put("enabled",1);
            w.insert("accounts", null, v);
        }
        if (count("categories") == 0) {
            String[][] cats = {{"هزینه","خوراک"},{"هزینه","مسکن"},{"هزینه","حمل‌ونقل"},{"هزینه","سلامت"},{"هزینه","خرید شخصی"},{"هزینه","قبوض"},{"هزینه","تفریح"},{"هزینه","سایر"},{"درآمد","حقوق"},{"درآمد","کسب‌وکار"},{"درآمد","سرمایه‌گذاری"},{"درآمد","سایر"}};
            for (String[] c : cats) { ContentValues v = new ContentValues(); v.put("type",c[0]); v.put("name",c[1]); w.insert("categories",null,v); }
        }
    }
    private long count(String table) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private long countForBook(String table, String book) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+" WHERE book=?",new String[]{book});
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private void addBookRaw(String name) {
        ContentValues v=new ContentValues(); v.put("name",name); db.getWritableDatabase().insert("books",null,v);
    }

    private void showShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(lighten(selectedThemeColor(),0.93f));

        topbar = new LinearLayout(this);
        topbar.setOrientation(LinearLayout.VERTICAL);
        topbar.setPadding(dp(18), dp(10), dp(18), dp(10));
        topbar.setElevation(dp(5));
        topbar.setBackground(gradientBg(new int[]{darken(selectedThemeColor()), selectedThemeColor(), darken(selectedThemeColor())}, dp(20)));
        headerTitle = text(headerTitleForPage(), 23, Color.WHITE, true);
        headerTitle.setGravity(Gravity.RIGHT);
        topbar.addView(headerTitle);
        headerHint = text(headerHintForPage(), 12, Color.rgb(255, 235, 241), false);
        headerHint.setPadding(0, dp(3), 0, dp(5));
        topbar.addView(headerHint);
        LinearLayout infoRow = new LinearLayout(this);
        infoRow.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        headerDateTime = text("", 12, Color.rgb(255, 219, 230), true);
        infoRow.addView(headerDateTime);
        topbar.addView(infoRow);
        updateHeaderClock();
        uiHandler.removeCallbacks(clockTicker);
        uiHandler.postDelayed(clockTicker, 60_000);
        LinearLayout.LayoutParams topLp = new LinearLayout.LayoutParams(-1, -2);
        topLp.setMargins(dp(12), dp(8), dp(12), dp(4));
        root.addView(topbar, topLp);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        body.setPadding(dp(14), dp(10), dp(14), dp(14));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setGravity(Gravity.CENTER);
        navBar.setPadding(dp(5), dp(6), dp(5), dp(6));
        navBar.setClipChildren(false);
        navBar.setClipToPadding(false);
        // The palette becomes deeper toward the center to draw attention to voice entry.
        navBar.setBackground(gradientBg(new int[]{lighten(selectedThemeColor(),0.82f), lighten(selectedThemeColor(),0.48f), selectedThemeColor(), lighten(selectedThemeColor(),0.48f), lighten(selectedThemeColor(),0.82f)}, dp(22)));
        navBar.setElevation(dp(12));
        String[][] tabs = {{"خانه", "⌂"}, {"تراکنش‌ها", "↕"}, {"دستیار صوتی", ""}, {"ثبت", "＋"}, {"تنظیمات", "☰"}};
        for (int i = 0; i < tabs.length; i++) {
            final String target = tabs[i][0];
            final boolean voice = "دستیار صوتی".equals(target);
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setClipChildren(false);
            item.setClipToPadding(false);
            if (voice) {
                item.setGravity(Gravity.CENTER);
                item.setBackground(ovalBg(Color.rgb(255, 224, 234)));
                item.setElevation(dp(8));
                ImageView mic = new ImageView(this);
                mic.setImageResource(android.R.drawable.ic_btn_speak_now);
                mic.setColorFilter(Color.rgb(142, 35, 67));
                mic.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                item.addView(mic, new LinearLayout.LayoutParams(dp(31), dp(31)));
                item.setContentDescription("دستیار صوتی؛ شروع ثبت تراکنش با گفتار");
            } else {
                item.setPadding(dp(2), dp(3), dp(2), dp(3));
                boolean selected = target.equals(page);
                item.setBackground(roundBg(selected ? Color.rgb(255, 232, 239) : Color.TRANSPARENT));
                TextView icon = text(tabs[i][1], 21, target.equals(page) ? Color.rgb(125, 43, 73) : Color.rgb(91, 48, 63), true);
                icon.setGravity(Gravity.CENTER);
                TextView label = text(target, 11, target.equals(page) ? Color.rgb(125, 43, 73) : Color.rgb(91, 48, 63), true);
                label.setGravity(Gravity.CENTER);
                label.setMinHeight(dp(18));
                label.setMaxLines(1);
                label.setIncludeFontPadding(true);
                item.addView(icon);
                item.addView(label);
                item.setContentDescription(target);
            }
            if (voice) {
                item.setContentDescription("برای ضبط فرمان صوتی نگه دارید؛ با رها کردن، گفتار بررسی می‌شود");
                item.setOnTouchListener((v, event) -> {
                    switch (event.getAction()) {
                        case android.view.MotionEvent.ACTION_DOWN:
                            v.setPressed(true);
                            startVoiceAssistant();
                            return true;
                        case android.view.MotionEvent.ACTION_UP:
                        case android.view.MotionEvent.ACTION_CANCEL:
                            v.setPressed(false);
                            stopVoiceListening();
                            return true;
                        default:
                            return true;
                    }
                });
            } else {
                item.setOnClickListener(v -> navigate(target));
            }
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(0, voice ? dp(64) : dp(60), voice ? 1.08f : 1f);
            itemLp.setMargins(dp(2), 0, dp(2), 0);
            navBar.addView(item, itemLp);
        }
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(-1, -2);
        navLp.setMargins(dp(8), dp(4), dp(8), dp(3));
        root.addView(navBar, navLp);
        // Android 15 enforces edge-to-edge for targetSdk 35. Keep navigation items
        // above the system navigation buttons/gesture area on all supported versions.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int topInset;
            int bottomInset;
            if (Build.VERSION.SDK_INT >= 30) {
                topInset = insets.getInsets(WindowInsets.Type.statusBars()).top;
                bottomInset = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            // Keep the header pinned below the phone status bar on every page.
            root.setPadding(0, topInset, 0, 0);
            navBar.setPadding(dp(5), dp(6), dp(5), dp(6) + bottomInset);
            return insets;
        });
        if (Build.VERSION.SDK_INT >= 21) {
            // System bars follow the user's selected theme color.
            getWindow().setStatusBarColor(lighten(selectedThemeColor(),0.82f));
            getWindow().setNavigationBarColor(darken(selectedThemeColor()));
        }
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        setContentView(root);
        root.requestApplyInsets();
    }

    private String headerTitleForPage() {
        switch (page) {
            case "خانه": return "خانه";
            case "تراکنش‌ها": return "تراکنش‌ها";
            case "ثبت": return "ثبت عملیات مالی";
            case "دارایی‌ها": return "دارایی‌ها";
            case "تنظیمات": return "تنظیمات";
            default: return "حساب‌یار";
        }
    }

    private String headerHintForPage() {
        switch (page) {
            case "خانه": return "خلاصه موجودی، درآمد و هزینه‌های دفتر انتخاب‌شده";
            case "تراکنش‌ها": return "تراکنش‌ها را جست‌وجو و جزئیاتشان را بررسی کنید";
            case "ثبت": return "نوع عملیات را انتخاب کنید و پیش از ثبت، مبلغ را بررسی کنید";
            case "دارایی‌ها": return "ارزش دارایی‌ها و موارد ثبت‌شده را مدیریت کنید";
            case "تنظیمات": return "دفتر، پشتیبان‌گیری و تنظیمات برنامه";
            default: return "اطلاعات مالی شما روی همین گوشی ذخیره می‌شود";
        }
    }

    private void setHeaderInfo(String title, String hint) {
        if (headerTitle != null) headerTitle.setText(title);
        if (headerHint != null) headerHint.setText(hint);
    }

    private void updateHeaderClock() {
        if (headerDateTime != null) {
            String time = new SimpleDateFormat("HH:mm", new Locale("fa", "IR")).format(new Date());
            headerDateTime.setText(jalaliDate(System.currentTimeMillis()) + "  •  " + time);
        }
    }

    @Override protected void onStop() {
        // Do not snapshot on every background/foreground transition: an empty or newly
        // recreated database must never overwrite/prune the user's recoverable history.
        super.onStop();
    }

    private long tableCount(SQLiteDatabase sql, String table) {
        Cursor c = null;
        try { c = sql.rawQuery("SELECT COUNT(*) FROM " + table, null); return c.moveToFirst() ? c.getLong(0) : 0L; }
        catch (Exception e) { return 0L; }
        finally { if (c != null) c.close(); }
    }

    private boolean hasMeaningfulUserData(SQLiteDatabase sql) {
        return tableCount(sql,"transactions") > 0 || tableCount(sql,"cheques") > 0 ||
               tableCount(sql,"debts") > 0 || tableCount(sql,"assets") > 0 ||
               tableCount(sql,"recurring") > 0 || tableCount(sql,"budgets") > 0 ||
               tableCount(sql,"goals") > 0 || tableCount(sql,"closed_months") > 0 ||
               tableCount(sql,"bank_inbox") > 0;
    }

    private void verifyDatabaseFile(File file, boolean requireUserData) throws IOException {
        if (file == null || !file.isFile() || file.length() < 1024) throw new IOException("فایل پایگاه داده ناقص یا خالی است.");
        SQLiteDatabase check = null;
        try {
            check = SQLiteDatabase.openDatabase(file.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            Cursor integrity = check.rawQuery("PRAGMA integrity_check", null);
            boolean healthy = integrity.moveToFirst() && "ok".equalsIgnoreCase(integrity.getString(0));
            integrity.close();
            if (!healthy) throw new IOException("آزمون سلامت SQLite ناموفق بود.");
            Cursor tables = check.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('books','accounts','transactions','cheques')", null);
            boolean schemaOk = tables.moveToFirst() && tables.getInt(0) == 4; tables.close();
            if (!schemaOk) throw new IOException("این فایل ساختار پایگاه داده حساب‌یار را ندارد.");
            if (requireUserData && !hasMeaningfulUserData(check)) throw new IOException("برای جلوگیری از جایگزینی نسخه‌های قابل‌بازیابی، از پایگاه داده بدون رکورد مالی پشتیبان ساخته نشد.");
        } catch (SQLiteException e) { throw new IOException("فایل انتخاب‌شده پایگاه داده سالم حساب‌یار نیست.", e); }
        finally { if (check != null) check.close(); }
    }

    private void createAutomaticBackup() throws IOException {
        if (db == null) return;
        SQLiteDatabase sql = db.getWritableDatabase();
        try (Cursor checkpoint = sql.rawQuery("PRAGMA wal_checkpoint(FULL)", null)) {
            if (checkpoint.moveToFirst() && checkpoint.getInt(0) != 0)
                throw new IOException("پایگاه داده در حال استفاده است؛ چند لحظه بعد دوباره تلاش کنید.");
        }
        File source = getDatabasePath("hisabyar.db");
        verifyDatabaseFile(source, true);
        File dir = new File(getFilesDir(), "auto_backups");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("ساخت پوشهٔ پشتیبان خودکار ممکن نشد.");
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        File target = new File(dir, "HisabYar_auto_" + stamp + ".db");
        File temp = new File(dir, target.getName() + ".tmp");
        try {
            try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(temp)) { copy(in, out); out.flush(); }
            verifyDatabaseFile(temp, true);
            if (!temp.renameTo(target)) throw new IOException("ثبت نهایی فایل پشتیبان انجام نشد.");
            getPreferences(0).edit().putLong("last_auto_backup_at", System.currentTimeMillis()).apply();
            // Intentionally do not auto-delete old backups. Storage is preferable to data loss.
        } finally { if (temp.exists()) temp.delete(); }
    }

    @Override protected void onDestroy() {
        uiHandler.removeCallbacks(clockTicker);
        releaseVoiceRecognizer();
        super.onDestroy();
    }

    private void navigate(String p) {
        page = p;
        showShell();
        body.removeAllViews();
        switch(p) {
            case "خانه": showHome(); break;
            case "تراکنش‌ها": showTransactions(); break;
            case "ثبت": showAddMenu(); break;
            case "دارایی‌ها": showAssets(); break;
            default: showSettings(); break;
        }
    }
    private void showHome() {
        setHeaderInfo("خانه", "موجودی، درآمد و هزینه‌های دفتر «" + activeBook + "»");
        body.removeAllViews();
        LinearLayout bookrow = new LinearLayout(this);
        bookrow.setGravity(Gravity.CENTER_VERTICAL);
        View bookSpacer = new View(this);
        bookrow.addView(bookSpacer, new LinearLayout.LayoutParams(0, 1, 1));
        Button switchB = button("دفتر: " + activeBook + " ▾");
        switchB.setTextSize(12);
        switchB.setBackground(roundBg(Color.WHITE));
        bookrow.addView(switchB);
        switchB.setOnClickListener(v -> chooseBook());
        body.addView(bookrow);

        long income = sum("درآمد"), expense = sum("هزینه"), bal = balance();
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(roundBg(selectedThemeColor()));
        TextView heroLabel = text("موجودی محاسبه‌شده", 14, Color.rgb(255, 226, 235), false);
        TextView heroValue = text(money(bal), 29, Color.WHITE, true);
        hero.addView(heroLabel); hero.addView(heroValue);
        TextView heroFoot = text("مجموع موجودی اولیه + درآمدها − هزینه‌ها", 11, Color.rgb(255, 226, 235), false);
        hero.addView(heroFoot);
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(-1, -2);
        heroLp.setMargins(0, dp(12), 0, dp(8));
        body.addView(hero, heroLp);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.addView(metricBox("درآمد کل", money(income), GREEN), new LinearLayout.LayoutParams(0, -2, 1));
        View spacer = new View(this); metrics.addView(spacer, new LinearLayout.LayoutParams(dp(8), 1));
        metrics.addView(metricBox("هزینه کل", money(expense), Color.rgb(204, 103, 112)), new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(metrics);
        TextView bankTotal=text("جمع موجودی حساب‌های بانکی: "+money(bankBalance()),14,GREEN,true);
        bankTotal.setPadding(dp(12),dp(8),dp(12),dp(8));
        body.addView(bankTotal);
        addUpcomingRecurringReminder();

        java.util.ArrayList<String> quickActions = getQuickActions();
        if (!quickActions.isEmpty()) {
            addHeading("دسترسی سریع");
            for (String action : quickActions) addWideButton(quickActionLabel(action), () -> runQuickAction(action));
        }

        addHeading("موجودی حساب‌ها");
        addAccountBalancesIntoBody();

        addHeading("آخرین تراکنش‌ها");
        showRecentIntoBody();
        addWideButton("مشاهده همه تراکنش‌ها  ←", () -> navigate("تراکنش‌ها"));
    }

    private void addUpcomingRecurringReminder() {
        long now=System.currentTimeMillis(),week=now+7L*24*60*60*1000;
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,type,amount,next_due FROM recurring WHERE book=? AND next_due<=? ORDER BY next_due LIMIT 3",new String[]{activeBook,String.valueOf(week)});
        if(c.moveToFirst()) {
            addHeading("یادآوری پرداخت‌ها و درآمدهای نزدیک");
            do {String name=c.getString(0),type=c.getString(1);long amount=c.getLong(2),due=c.getLong(3);String status=due<now?"سررسید گذشته":"سررسید نزدیک";addEmpty(status+" • "+name+"\n"+type+" • "+money(amount)+" • "+jalaliDate(due));}while(c.moveToNext());
            addWideButton("مشاهده و مدیریت همه سررسیدها",()->showRecurring());
        }
        c.close();
    }

    private View spaceWidth(int width) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(width), 1)); return v; }

    private View metricBox(String label,String value,int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(14), dp(12), dp(14));
        box.setBackground(roundBg(Color.WHITE));
        TextView a = text(label, 12, Color.rgb(105, 116, 110), false);
        TextView b = text(value, 15, color, true);
        box.addView(a); box.addView(b);
        return box;
    }

    private void addMetric(String label,String value,int color) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(18),dp(16),dp(18)); box.setBackground(roundBg(Color.WHITE));
        TextView a=text(label,14,Color.rgb(86, 99, 91),false), b=text(value,25,color,true); box.addView(a); box.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(10),0,dp(10)); body.addView(box,lp);
    }
    private void showAddMenu() {
        setHeaderInfo("ثبت عملیات مالی", "نوع عملیات را انتخاب کنید و پیش از ثبت، مبلغ را بررسی کنید");
        body.removeAllViews(); addHeading("ثبت عملیات مالی");
        addWideButton("🎙 برای صحبت، دکمهٔ دستیار صوتی پایین صفحه را نگه دارید", () -> toast("برای ضبط فرمان، دکمهٔ میکروفون پایین صفحه را نگه دارید و پس از پایان صحبت رها کنید."));
        addWideButton("ثبت هزینه",()->showEntry("هزینه"));
        addWideButton("ثبت درآمد",()->showEntry("درآمد"));
        addWideButton("انتقال بین حساب‌ها",()->showTransfer());
        addWideButton("ثبت دارایی",()->showAssetDialog());
        addWideButton("ثبت بدهی یا طلب",()->showDebtDialog());
        addWideButton("🧾 دریافت و پرداخت چک (ثبت و فهرست چک‌ها)",()->showCheques());
        addWideButton("مشاهده و تسویه بدهی‌ها و طلب‌ها",()->showDebts());
        addWideButton("بودجه‌بندی ماهانه",()->showBudgets());
        addWideButton("پرداخت‌های تکرارشونده و سررسیدها",()->showRecurring());
        addWideButton("هدف‌های پس‌انداز",()->showGoals());
        addWideButton("گزارش‌ها و ارزش خالص",()->showReports());
    }
    private void showEntry(String type) {
        LinearLayout form=formLayout();
        EditText amount=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER);
        AutoCompleteTextView category=categoryInput(type,"دسته‌بندی (مثلاً خوراک)");
        AutoCompleteTextView account=accountInput("حساب (مثلاً پول نقد)");
        Spinner paymentMethod=styledSpinner();paymentMethod.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"نقدی","کارت بانکی","انتقال بانکی","کارت‌خوان","اعتباری","متفرقه"}));paymentMethod.setSelection(5);
        EditText note=edit("شرح / یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        Calendar selectedDate=Calendar.getInstance();
        Button dateButton=button("تاریخ تراکنش: "+jalaliDate(selectedDate.getTimeInMillis()));
        dateButton.setOnClickListener(v->{Calendar cur=(Calendar)selectedDate.clone();new DatePickerDialog(this,(view,year,month,day)->{selectedDate.set(Calendar.YEAR,year);selectedDate.set(Calendar.MONTH,month);selectedDate.set(Calendar.DAY_OF_MONTH,day);selectedDate.set(Calendar.HOUR_OF_DAY,12);selectedDate.set(Calendar.MINUTE,0);selectedDate.set(Calendar.SECOND,0);dateButton.setText("تاریخ تراکنش: "+jalaliDate(selectedDate.getTimeInMillis()));},cur.get(Calendar.YEAR),cur.get(Calendar.MONTH),cur.get(Calendar.DAY_OF_MONTH)).show();});
        form.addView(amount); form.addView(category); form.addView(account); form.addView(text("نوع پرداخت",13,TEXT,true)); form.addView(paymentMethod); form.addView(dateButton); form.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت "+type).setView(form)
          .setNegativeButton("انصراف",null).setPositiveButton("ثبت", (d,w)->{
              long a=parseAmount(amount.getText().toString());
              if(a<=0){toast("مبلغ باید بیشتر از صفر باشد");return;}
              String cat=category.getText().toString().trim(); if(cat.isEmpty()) cat=type.equals("هزینه")?"سایر":"سایر";
              String acc=account.getText().toString().trim(); if(acc.isEmpty()) acc="پول نقد";
              ensureAccount(acc);
              saveCategoryIfMissing(type,cat);
              ContentValues v=new ContentValues(); v.put("book",activeBook); v.put("type",type); v.put("amount",a); v.put("category",cat); v.put("account",acc); v.put("payment_method",String.valueOf(paymentMethod.getSelectedItem())); v.put("note",note.getText().toString()); v.put("date",selectedDate.getTimeInMillis()); setMonthKey(v,selectedDate.getTimeInMillis());
              if(isMonthClosed(monthKey(selectedDate.getTimeInMillis()))){toast("این ماه بسته شده است؛ برای ثبت در ماه جدید تاریخ را تغییر بده.");return;}
              saveTransactionWithDuplicateWarning(v,type,a,cat,acc,selectedDate.getTimeInMillis(),()->{toast("تراکنش ثبت شد");navigate("خانه");});
          }).show();
    }
    private void saveVoiceErrorReport(String report) {
        try (OutputStreamWriter writer = new OutputStreamWriter(
                new FileOutputStream(new File(getFilesDir(), "voice_error_report.txt"), false),
                StandardCharsets.UTF_8)) {
            writer.write(report);
        } catch (Exception saveError) {
            Log.e(VOICE_TAG, "Could not save voice error report", saveError);
        }
    }

    private String makeVoiceErrorReport(String stage, Throwable error, File external, long freeExternal, long freeInternal) {
        StringBuilder report = new StringBuilder();
        report.append("HisabYar Pro offline voice diagnostic\n")
              .append("App version: 1.4.9-Pro\n")
              .append("Stage: ").append(stage).append('\n')
              .append("Android SDK: ").append(Build.VERSION.SDK_INT).append('\n')
              .append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
              .append("External files dir: ").append(external == null ? "null" : external.getAbsolutePath()).append('\n')
              .append("Internal files dir: ").append(getFilesDir().getAbsolutePath()).append('\n')
              .append("Free external bytes: ").append(freeExternal).append('\n')
              .append("Free internal bytes: ").append(freeInternal).append('\n')
              .append("Assets model-fa entries: ");
        try {
            String[] entries = getAssets().list("model-fa");
            report.append(entries == null ? "null" : java.util.Arrays.toString(entries));
        } catch (Exception e) { report.append("ASSET_LIST_ERROR: ").append(e); }
        report.append("\n\nERROR / STACK TRACE:\n");
        if (error == null) report.append("No exception object supplied.\n");
        else {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            error.printStackTrace(pw);
            pw.flush();
            report.append(sw);
            Throwable cause = error.getCause();
            int depth = 0;
            while (cause != null && cause != error && depth++ < 10) {
                report.append("\nCAUSE ").append(depth).append(": ");
                cause.printStackTrace(pw = new PrintWriter(sw = new StringWriter()));
                pw.flush(); report.append(sw);
                cause = cause.getCause();
            }
        }
        return report.toString();
    }

    private void showVoiceErrorReport(String title, String stage, Throwable error, File external, long freeExternal, long freeInternal) {
        String report = makeVoiceErrorReport(stage, error, external, freeExternal, freeInternal);
        saveVoiceErrorReport(report);
        Log.e(VOICE_TAG, report, error);
        TextView details = new TextView(this);
        details.setText(report);
        details.setTextIsSelectable(true);
        details.setTextSize(12);
        details.setTextColor(Color.rgb(35, 35, 35));
        details.setPadding(dp(12), dp(12), dp(12), dp(12));
        details.setTypeface(Typeface.MONOSPACE);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(details);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage("گزارش کامل خطا آماده است. متن زیر را می‌توانی انتخاب و کپی کنی یا با دکمهٔ «کپی گزارش» یکجا کپی کنی.")
                .setView(scroll)
                .setPositiveButton("کپی گزارش", (dialog, which) -> {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(ClipData.newPlainText("HisabYar Pro voice error", report));
                        toast("گزارش کامل کپی شد؛ آن را اینجا ارسال کن.");
                    }
                })
                .setNeutralButton("بستن", null)
                .show();
    }

    private void prepareOfflineVoiceModel() {
        if (offlineVoiceReady || offlineVoiceLoading) return;
        offlineVoiceLoading = true;
        toast("در حال آماده‌سازی دستیار صوتی فارسی؛ بار اول ممکن است کمی طول بکشد.");
        File external = getExternalFilesDir(null);
        File internal = getFilesDir();
        long freeInternal = internal != null ? internal.getUsableSpace() : -1L;
        long freeExternal = external != null ? external.getUsableSpace() : -1L;
        Log.i(VOICE_TAG, "Model prepare started; external=" + (external == null ? "null" : external.getAbsolutePath())
                + ", freeExternal=" + freeExternal + ", freeInternal=" + freeInternal);
        try {
            org.vosk.android.StorageService.unpack(this, "model-fa", "model-fa",
                model -> runOnUiThread(() -> {
                    offlineVoiceModel = model;
                    offlineVoiceLoading = false;
                    offlineVoiceReady = true;
                    Log.i(VOICE_TAG, "Persian Vosk model loaded successfully.");
                    toast("دستیار صوتی فارسی آفلاین آماده است.");
                    if (widgetVoiceLaunchPending && !widgetVoiceUnlockPending) uiHandler.postDelayed(() -> startWidgetVoiceCapture(), 350);
                }),
                exception -> runOnUiThread(() -> {
                    offlineVoiceLoading = false;
                    offlineVoiceReady = false;
                    showVoiceErrorReport("خطای آماده‌سازی دستیار صوتی", "StorageService.unpack callback", exception, external, freeExternal, freeInternal);
                }));
        } catch (Exception exception) {
            offlineVoiceLoading = false;
            offlineVoiceReady = false;
            showVoiceErrorReport("خطای آماده‌سازی دستیار صوتی", "prepareOfflineVoiceModel catch", exception, external, freeExternal, freeInternal);
        }
    }

    private void startWidgetVoiceCapture() {
        if (!widgetVoiceLaunchPending) return;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            startVoiceAssistant();
            return;
        }
        widgetVoiceLaunchPending = false;
        startVoiceAssistant();
    }

    private void startVoiceAssistant() {
        voiceButtonHeld = true;
        voiceStopRequested = false;
        voiceResultHandled = false;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            voiceButtonHeld = false;
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, REQ_AUDIO_PERMISSION);
            return;
        }
        if (!offlineVoiceReady || offlineVoiceModel == null) {
            if (!offlineVoiceLoading) prepareOfflineVoiceModel();
            toast("دستیار آفلاین در حال آماده‌سازی است؛ چند ثانیه صبر کن و دوباره نگه دار.");
            return;
        }
        HesabyarVoiceWidgetProvider.updateStatus(this, "در حال گوش‌دادن…");
        releaseVoiceRecognizer();
        try {
            offlineVoiceRecognizer = new org.vosk.Recognizer(offlineVoiceModel, 16000.0f);
            try { offlineVoiceRecognizer.setMaxAlternatives(5); } catch (Exception ignored) { }
            offlineSpeechService = new org.vosk.android.SpeechService(offlineVoiceRecognizer, 16000.0f);
            offlineSpeechService.startListening(new org.vosk.android.RecognitionListener() {
                @Override public void onPartialResult(String hypothesis) { }
                @Override public void onResult(String hypothesis) { }
                @Override public void onFinalResult(String hypothesis) {
                    handleOfflineVoiceResult(hypothesis);
                }
                @Override public void onError(Exception exception) {
                    runOnUiThread(() -> {
                        releaseVoiceRecognizer();
                        if (voiceButtonHeld) toast("خطا در تشخیص گفتار آفلاین؛ مجوز میکروفون و فضای آزاد گوشی را بررسی کن.");
                    });
                }
                @Override public void onTimeout() {
                    runOnUiThread(() -> {
                        releaseVoiceRecognizer();
                        if (!voiceResultHandled) toast("گفتاری تشخیص داده نشد؛ دوباره و واضح‌تر صحبت کن.");
                    });
                }
            });
            toast("دستیار آفلاین گوش می‌دهد؛ برای پایان، دکمه را رها کن.");
        } catch (Exception e) {
            releaseVoiceRecognizer();
            toast("شروع دستیار آفلاین ناموفق بود. یک‌بار برنامه را ببند و دوباره باز کن.");
        }
    }

    private void handleOfflineVoiceResult(String hypothesis) {
        final String text = extractVoskText(hypothesis);
        runOnUiThread(() -> {
            if (voiceResultHandled) return;
            voiceResultHandled = true;
            releaseVoiceRecognizer();
            if (!text.trim().isEmpty()) { HesabyarVoiceWidgetProvider.updateStatus(this, "در حال بررسی دستور"); processVoiceCommand(text); }
            else { HesabyarVoiceWidgetProvider.updateStatus(this, "آماده دریافت دستور"); toast("متن گفتار دریافت نشد؛ دوباره امتحان کن."); }
        });
    }

    private String extractVoskText(String hypothesis) {
        if (hypothesis == null || hypothesis.trim().isEmpty()) return "";
        try {
            org.json.JSONObject json = new org.json.JSONObject(hypothesis);
            java.util.ArrayList<String> candidates = new java.util.ArrayList<>();
            org.json.JSONArray alternatives = json.optJSONArray("alternatives");
            if (alternatives != null) {
                for (int i=0;i<alternatives.length();i++) {
                    String candidate=alternatives.optJSONObject(i)==null?"":alternatives.optJSONObject(i).optString("text","").trim();
                    if (!candidate.isEmpty() && !candidates.contains(candidate)) candidates.add(candidate);
                }
            }
            String primary=json.optString("text","").trim();
            if (!primary.isEmpty() && !candidates.contains(primary)) candidates.add(0,primary);
            if (!candidates.isEmpty()) return selectBestVoiceTranscript(candidates).trim();
            return primary;
        } catch (Exception ignored) { return hypothesis.trim(); }
    }

    private void stopVoiceListening() {
        voiceButtonHeld = false;
        if (offlineSpeechService != null) {
            try {
                toast("ضبط متوقف شد؛ در حال تحلیل گفتار آفلاین…");
                offlineSpeechService.stop();
            } catch (Exception ignored) { releaseVoiceRecognizer(); }
        }
    }

    private void releaseVoiceRecognizer() {
        if (offlineSpeechService != null) {
            try { offlineSpeechService.stop(); } catch (Exception ignored) { }
            try { offlineSpeechService.shutdown(); } catch (Exception ignored) { }
            offlineSpeechService = null;
        }
        if (offlineVoiceRecognizer != null) {
            try { offlineVoiceRecognizer.close(); } catch (Exception ignored) { }
            offlineVoiceRecognizer = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==731){boolean ok=grantResults.length>0&&grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED;android.preference.PreferenceManager.getDefaultSharedPreferences(this).edit().putBoolean("bank_sms_enabled",ok).apply();toast(ok?"دریافت پیامک فعال شد.":"مجوز پیامک داده نشد.");if(ok)requestBankNotificationPermission();showSmartBankImport();return;}
        if(requestCode==733){boolean ok=grantResults.length>0&&grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED;toast(ok?"اعلان درخواست ثبت تراکنش فعال شد.":"اجازه اعلان داده نشد؛ پیام‌ها همچنان در صف بررسی ذخیره می‌شوند.");if(pendingOpenBankNotificationSettings){pendingOpenBankNotificationSettings=false;openBankNotificationListenerSettings();}return;}
        if (requestCode == REQ_AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                if (widgetVoiceLaunchPending) startWidgetVoiceCapture();
                else toast("اجازهٔ میکروفون داده شد؛ دوباره دکمهٔ دستیار صوتی را نگه دار.");
            } else { widgetVoiceLaunchPending = false; HesabyarVoiceWidgetProvider.updateStatus(this, "مجوز میکروفون لازم است"); toast("برای ثبت صوتی، اجازهٔ میکروفون لازم است."); }
        }
    }

    private String selectBestVoiceTranscript(java.util.ArrayList<String> candidates) {
        // Pick the hypothesis that best fits a complete accounting command, not merely the longest text.
        String best = candidates.get(0);
        int bestScore = Integer.MIN_VALUE;
        for (String candidate : candidates) {
            if (candidate == null || candidate.trim().isEmpty()) continue;
            String n = normalizeVoiceText(candidate);
            int score = Math.min(n.length(), 120) / 12;
            if (containsKnownBank(n)) score += 5;
            if (parseVoiceAmount(n) > 0) score += 7;
            if (hasIncomeCue(n)) score += 4;
            if (hasExpenseCue(n)) score += 4;
            if (hasQueryCue(n) || hasNavigationCue(n)) score += 5;
            if (containsAny(n, "امروز", "دیروز", "پریروز", "ماه قبل", "هفته قبل")) score += 1;
            // Penalize isolated fragments which are unlikely to be a complete instruction.
            if (n.split("\\s+").length < 2) score -= 3;
            if (score > bestScore) { bestScore = score; best = candidate; }
        }
        return best;
    }

    private String monthKey(long millis) { String d=jalaliDate(millis); return d.length()>=7?d.substring(0,7):""; }
    private String currentMonthKey() { return monthKey(System.currentTimeMillis()); }
    private boolean isMonthClosed(String key) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT 1 FROM closed_months WHERE book=? AND month_key=?",new String[]{activeBook,key});
        boolean closed=c.moveToFirst(); c.close(); return closed;
    }
    private void setMonthKey(ContentValues values,long millis) { values.put("month_key",monthKey(millis)); }
    private void showMonthClosing() {
        setHeaderInfo("بستن ماه", "ماه‌های مالی بسته‌شده بایگانی می‌شوند و جداگانه قابل مشاهده‌اند"); body.removeAllViews();
        addHeading("مدیریت ماه مالی");
        String current=currentMonthKey();
        addEmpty("ماه جاری: "+current+"\nبا بستن ماه، تراکنش‌های همان ماه حذف نمی‌شوند؛ فقط بایگانی و از فهرست ماه جاری جدا می‌شوند.");
        addWideButton("بستن ماه جاری ("+current+")",()->new AlertDialog.Builder(this).setTitle("بستن ماه مالی")
            .setMessage("ماه "+current+" بسته و بایگانی شود؟ تراکنش‌ها محفوظ می‌مانند و از فهرست ماه جاری جدا می‌شوند. پس از بستن، ثبت تراکنش با تاریخ این ماه مسدود خواهد شد.")
            .setNegativeButton("انصراف",null).setPositiveButton("بستن و بایگانی",(d,w)->{
                ContentValues v=new ContentValues();v.put("book",activeBook);v.put("month_key",current);v.put("closed_at",System.currentTimeMillis());
                db.getWritableDatabase().insertWithOnConflict("closed_months",null,v,SQLiteDatabase.CONFLICT_REPLACE);
                toast("ماه "+current+" بایگانی شد");showMonthClosing();
            }).show());
        addHeading("ماه‌های بایگانی‌شده");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT month_key,closed_at FROM closed_months WHERE book=? ORDER BY month_key DESC",new String[]{activeBook});
        if(!c.moveToFirst()) addEmpty("هنوز ماهی بسته نشده است.");
        else do {String key=c.getString(0);long closedAt=c.getLong(1);addWideButton(key+" • بسته‌شده در "+jalaliDate(closedAt)+" • مشاهده تراکنش‌ها",()->showTransactionsForMonth(key));} while(c.moveToNext()); c.close();
    }
    private void showTransactionsForMonth(String key) {
        navigate("تراکنش‌ها");
        // The transaction page initializes its month selector to this archive month.
        getPreferences(0).edit().putString("transactions_month_override",key).apply();
        showTransactions();
    }

    private void processVoiceCommand(String spoken) {
        if (spoken == null || spoken.trim().isEmpty()) { toast("گفتار قابل تشخیص نبود؛ دوباره تلاش کن."); return; }
        String normalized = normalizeVoiceText(spoken);
        if (containsAny(normalized, "راهنمای دستیار صوتی", "راهنمای صوتی", "چه فرمان هایی", "چه فرمان‌هایی", "فرمان های صوتی", "فرمان‌های صوتی", "دستیار چه کارهایی می کند", "دستیار چه کارهایی می‌کند")) { showVoiceCommandHelp(); return; }

        // Office/book switching must run before generic navigation and transaction parsing.
        // A named book can be selected directly; ambiguous names always require a choice.
        if (handleVoiceBookSwitch(spoken, normalized)) return;
        // 1) Route natural-language commands centrally across every major app area.
        // This runs before transaction classification so navigation is not mistaken for money entry.
        if (routeVoiceCommandAcrossApp(spoken, normalized)) return;
        if (handleVoiceThemeCommand(normalized)) return;
        if (containsAny(normalized,"بستن ماه","پایان ماه","بایگانی ماه")) { showMonthClosing(); return; }
        if (containsAny(normalized,"صفحه قبل","صفحه قبلی","برگرد عقب","بازگشت")) { if (!"خانه".equals(page)) navigate("خانه"); else toast("در صفحهٔ اصلی هستی."); return; }
        if (containsAny(normalized,"صفحه اصلی","صفحهٔ اصلی","برو خانه","برو به خانه","خانه را باز کن","صفحه خانه","صفحه خانه را باز کن","برگرد صفحه اصلی")) { navigate("خانه"); return; }
        if (containsAny(normalized,"تنظیمات","تنظیمات برنامه","تنظیمات را باز کن","مدیریت تنظیمات","بخش تنظیمات")) { navigate("تنظیمات"); return; }
        if (containsAny(normalized,"ثبت عملیات","ثبت تراکنش","ثبت جدید","منوی ثبت","ثبت را باز کن")) { navigate("ثبت"); return; }
        if (containsAny(normalized,"فهرست تراکنش","تراکنش های اخیر","تراکنش‌های اخیر","همه تراکنش ها","همه تراکنش‌ها","جستجوی تراکنش","تراکنش ها را باز کن")) { navigate("تراکنش‌ها"); return; }
        if (containsAny(normalized,"هدف پس انداز","هدف‌های پس‌انداز","هدف های پس انداز","اهداف پس انداز")) { showGoals(); return; }
        if (containsAny(normalized,"پرداخت تکراری","پرداخت های تکراری","پرداخت‌های تکراری","سررسید","اقساط تکراری")) { showRecurring(); return; }
        if (containsAny(normalized,"مدیریت دفتر","دفترها","تعویض دفتر","تغییر دفتر")) { manageBooks(); return; }
        // Flexible navigation: tolerate colloquial phrasing, missing ezafe, and common ASR variants.
        if (isQuickIconManagementCommand(normalized)) { manageQuickActions(); return; }
        if (containsAny(normalized,"دسته بندی","دسته‌بندی","مدیریت دسته ها","مدیریت دسته‌بندی‌ها","دسته‌ها را باز کن","دسته بندی ها را باز کن")) { manageCategories(); return; }
        if (containsAny(normalized,"خروجی csv","خروجی سی اس وی","فایل اکسل تراکنش","خروجی تراکنش ها")) { exportTransactionsCsv(); return; }
        if (containsAny(normalized,"پشتیبان گیری","پشتیبان‌گیری","بکاپ بگیر","خروجی پشتیبان")) { exportBackup(); return; }
        if (containsAny(normalized,"بازیابی پشتیبان","بازیابی بکاپ","وارد کردن پشتیبان")) { importBackup(); return; }
        if (containsAny(normalized,"رمز برنامه","قفل برنامه","تنظیم رمز","تغییر رمز")) { setPinDialog(); return; }
        if (containsAny(normalized,"درباره برنامه","اطلاعات برنامه","نسخه برنامه")) { showAboutDialog(); return; }
        if (containsAny(normalized,"افزودن دارایی","ثبت دارایی جدید")) { showAssetDialog(); return; }
        if (containsAny(normalized,"ثبت چک با عکس","ثبت چک از عکس","خواندن عکس چک","اسکن چک")) { toast("ثبت از روی عکس حذف شده است؛ لطفاً اطلاعات چک را دستی وارد کن."); showChequeDialog("دریافتی"); return; }
        if (containsAny(normalized,"ثبت چک دریافتی","دریافت چک جدید","چک دریافتی جدید")) { showChequeDialog("دریافتی"); return; }
        if (containsAny(normalized,"ثبت چک پرداختی","پرداخت چک جدید","چک پرداختی جدید")) { showChequeDialog("پرداختی"); return; }
        if (containsAny(normalized,"چک ها","چک‌ها","فهرست چک","مدیریت چک","دریافت و پرداخت چک","وضعیت چک","سررسید چک")) { showCheques(); return; }
        if (containsAny(normalized,"ثبت بدهی","ثبت طلب","افزودن بدهی","افزودن طلب")) { showDebtDialog(); return; }
        if (containsAny(normalized,"گردش حساب","گردش بانکی","تراکنش های بانک","تراکنش‌های بانک","تراکنش های حساب","تراکنش‌های حساب")) {
            String account=findVoiceAccount(spoken);
            if(account!=null){showAccountTransactions(account);return;}
            if (showVoiceAccountPicker(spoken, false)) return;
            toast("بانک یا حساب مشخصی پیدا نشد؛ نام حساب یا چهار رقم آخر کارت را بگو."); showAccounts(); return;
        }
        if (containsAny(normalized,"مانده حساب","موجودی حساب","موجودی بانک","مانده بانک","چقدر پول دارم","چقدر موجودی دارم","موجودی من")) {
            String account=findVoiceAccount(spoken);
            if(account!=null){new AlertDialog.Builder(this).setTitle("مانده حساب").setMessage(account+"\nمانده: "+money(accountBalance(account))).setPositiveButton("مشاهده گردش همین حساب",(d,w)->showAccountTransactions(account)).setNegativeButton("بستن",null).show();return;}
            if (showVoiceAccountPicker(spoken, true)) return;
            showAccounts(); toast("حساب مشخص نشد؛ نام حساب یا چهار رقم آخر کارت را بگو."); return;
        }
        if (containsAny(normalized,"گزارش","خلاصه مالی","درآمد و هزینه","وضعیت مالی","جمع هزینه","جمع درآمد","چقدر خرج کردم","چقدر درآمد داشتم")) { showReports(); return; }
        if (containsAny(normalized,"همه تراکنش ها","همه تراکنش‌ها","فهرست تراکنش","جستجوی تراکنش","تراکنش های اخیر","تراکنش‌های اخیر")) { navigate("تراکنش‌ها"); return; }
        if (containsAny(normalized,"حساب های بانکی","حساب‌های بانکی","فهرست حساب","حساب ها","حساب‌ها","حساب بانکی")) { showAccounts(); return; }
        if (containsAny(normalized,"دارایی","اموال")) { showAssets(); return; }
        if (containsAny(normalized,"بدهی","طلب","قرض")) { showDebts(); return; }
        if (containsAny(normalized,"بودجه")) { showBudgets(); return; }
        if (isTransferIntent(normalized)) { showTransfer(); return; }
        if (containsAny(normalized,"ثبت حساب بانکی","حساب جدید","افزودن حساب")) { addAccountDialog(); return; }

        // 2) Transaction intent uses positive and negative cues. Generic verbs such as "گرفتم"
        // or "دادم" alone are not enough to silently decide income vs expense.
        String type = detectVoiceTransactionType(normalized);
        long amountValue = parseVoiceAmount(normalized);
        if ("نامشخص".equals(type)) {
            showVoiceIntentChoice(spoken);
            return;
        }
        String category = matchExistingVoiceCategory(guessVoiceCategory(normalized, type), normalized, type);
        boolean yesterday = containsAny(normalized,"دیروز","روز گذشته");
        showVoiceDraft(spoken, type, amountValue, category, yesterday);
    }


    /** Central intent router for natural Persian phrases across all app pages and workflows. */
    private void showVoiceCommandHelp() {
        String help = "دفترها\n• «برو به دفتر شخصی»\n• «دفتر گلخانه را انتخاب کن»\n• «دفتر بعدی» / «دفتر قبلی»\n\n"+
            "ثبت مالی (همیشه پیش‌نویس را بررسی کن)\n• «هزینه ۵۰۰ هزار تومان برای خرید از کارت ملت»\n• «حقوق ۳۰ میلیون تومان به حساب ملی واریز شد»\n• «انتقال ۲ میلیون تومان از کارت ملت به پول نقد»\n\n"+
            "حساب و گزارش\n• «مانده بانک ملت کارت ۱۲۳۴»\n• «گردش حساب کارت اصلی»\n• «گزارش مالی این ماه»\n• «تراکنش‌های اخیر را باز کن»\n\n"+
            "بخش‌های برنامه\n• «حساب‌های بانکی را باز کن» / «حساب جدید»\n• «بودجه‌بندی را باز کن» / «هدف پس‌انداز»\n• «بدهی و طلب» / «دارایی‌ها» / «پرداخت‌های تکراری»\n• «مدیریت دسته‌بندی‌ها» / «بستن ماه»\n• «پشتیبان‌گیری» / «بازیابی پشتیبان» / «خروجی CSV»\n• «تنظیمات را باز کن» / «آبی کن» / «راهنمای دستیار صوتی»\n\n"+
            "اگر چند حساب از یک بانک وجود داشته باشد، نام حساب یا چهار رقم آخر کارت را هم بگو. اگر تطبیق مبهم باشد، برنامه از تو انتخاب می‌خواهد. هیچ تراکنشی بدون بررسی و تأیید نهایی ثبت نمی‌شود.";
        new AlertDialog.Builder(this).setTitle("راهنمای فرمان‌های صوتی آفلاین").setMessage(help).setPositiveButton("متوجه شدم",null).show();
    }

    private boolean handleVoiceBookSwitch(String spoken, String normalized) {
        String x = normalizeVoiceText(normalized);
        boolean bookIntent = containsAny(x, "دفتر", "دفترها", "دفتر ها", "دفتر مالی", "دفتر حسابداری");
        boolean switchIntent = containsAny(x, "تعویض", "تغییر", "انتخاب", "برو", "رفتن", "باز کن", "فعال کن", "سوئیچ", "سوییچ", "عوض کن", "جابه جا", "جابجا", "دفتر بعدی", "دفتر قبلی");
        if (!bookIntent && !containsAny(x, "دفتر بعدی", "دفتر قبلی")) return false;
        if (!switchIntent && !containsAny(x, "دفتر بعدی", "دفتر قبلی")) return false;
        Cursor c = db.getReadableDatabase().rawQuery("SELECT name FROM books ORDER BY id", null);
        java.util.ArrayList<String> books = new java.util.ArrayList<>();
        while (c.moveToNext()) books.add(c.getString(0));
        c.close();
        if (books.isEmpty()) { toast("هیچ دفتری برای انتخاب وجود ندارد."); return true; }
        if (containsAny(x, "دفتر بعدی", "دفتر قبلی")) {
            int current = books.indexOf(activeBook);
            if (current < 0) current = 0;
            int next = containsAny(x, "دفتر بعدی") ? (current + 1) % books.size() : (current - 1 + books.size()) % books.size();
            activateVoiceBook(books.get(next));
            return true;
        }
        String candidate = x;
        String[] phrases = {"دفتر حسابداری", "دفتر مالی", "انتخاب کن", "تغییر بده", "عوض کن", "فعال کن", "باز کن", "برو به", "می خواهم", "میخوام", "لطفاً", "لطفا", "سوئیچ", "سوییچ"};
        for (String phrase : phrases) candidate = candidate.replace(phrase, " ");
        candidate = candidate.replaceAll("(^|\\s)(دفتر|مالی|حسابداری|را|رو|به|برو|انتخاب|تغییر|تعویض|من|کن|کنید)(?=\\s|$)", " ");
        candidate = candidate.replaceAll("\\s+", " ").trim();
        java.util.ArrayList<String> matches = new java.util.ArrayList<>();
        String normCandidate = normalizeBankText(candidate);
        if (!normCandidate.isEmpty()) {
            for (String b : books) {
                String nb = normalizeBankText(b);
                if (normCandidate.equals(nb) || normCandidate.contains(nb) || nb.contains(normCandidate)) matches.add(b);
            }
        }
        if (matches.size() == 1) { activateVoiceBook(matches.get(0)); return true; }
        if (matches.size() > 1) {
            String[] opts = matches.toArray(new String[0]);
            new AlertDialog.Builder(this).setTitle("کدام دفتر را فعال کنم؟").setItems(opts, (d,w) -> activateVoiceBook(opts[w])).setNegativeButton("لغو", null).show();
            return true;
        }
        String[] opts = books.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("دفتر موردنظر را انتخاب کن").setMessage("نام دفتر در گفتار واضح تشخیص داده نشد؛ برای جلوگیری از ثبت در دفتر اشتباه، انتخاب را تأیید کن.").setItems(opts, (d,w) -> activateVoiceBook(opts[w])).setNegativeButton("لغو", null).show();
        return true;
    }

    private void activateVoiceBook(String book) {
        if (book == null || book.trim().isEmpty()) return;
        activeBook = book;
        getPreferences(0).edit().putString("active_book", activeBook).apply();
        ensureBookAccount();
        navigate("خانه");
        toast("دفتر فعال تغییر کرد: " + activeBook);
    }

    private boolean routeVoiceCommandAcrossApp(String spoken, String n) {
        String x = normalizeVoiceText(n)
            .replace("آیکون", "آیکن").replace("ایکون", "آیکن").replace("ایکن", "آیکن")
            .replace("های", " ها").replace("سی اس وی", "csv")
            .replace("پس انداز", "پس انداز");
        boolean actionVerb = containsAny(x,"باز کن","بیار","برو","برو به","برو تو","نشون بده","نمایش بده","ببر به","می خوام","میخوام","برو داخل","وارد شو","مدیریت","فهرست","صفحه");
        boolean moneyIntent = containsAny(x,"ثبت هزینه","ثبت درآمد","خرج کردم","هزینه کردم","خریدم","پرداخت کردم","حقوق گرفتم","درآمد داشتم","دریافت کردم","انتقال وجه","انتقال پول","کارت به کارت","واریز کردم","پول دادم","مبلغ","ریال","تومان","تومن");
        // Keep full financial utterances for the transaction parser instead of treating them as navigation.
        if (moneyIntent && (containsAny(x,"ریال","تومان","تومن","هزار","میلیون","میلیارد") || parseVoiceAmount(x)>0)
                && containsAny(x,"ثبت","خرج","هزینه","خرید","پرداخت","درآمد","حقوق","دریافت","انتقال","واریز","دادم","گرفتم")) return false;

        if (isQuickIconManagementCommand(x)) { manageQuickActions(); return true; }
        if (containsAny(x,"تغییر رنگ","رنگ برنامه","رنگ رابط","تم برنامه","ظاهر برنامه","رنگش رو عوض","رنگش را عوض") && !containsAny(x,"تیره","روشن")) {
            if (handleVoiceThemeCommand(x)) return true;
        }
        if (containsAny(x,"صفحه قبل","صفحه قبلی","برگرد عقب","بازگشت","برگرد عقب")) {
            if (!"خانه".equals(page)) navigate("خانه"); else toast("در صفحهٔ اصلی هستی."); return true;
        }
        if (containsAny(x,"خانه","صفحه اصلی","صفحهٔ اصلی","صفحه خانه","داشبورد","صفحه اول","برگرد خانه") && actionVerb) { navigate("خانه"); return true; }
        if (containsAny(x,"تنظیمات","تنظیمات برنامه","تنظیمات عمومی") && actionVerb) { navigate("تنظیمات"); return true; }
        if (containsAny(x,"ثبت عملیات","منوی ثبت","صفحه ثبت","ثبت جدید","بخش ثبت","ثبت تراکنش") && !containsAny(x,"هزینه","درآمد","مبلغ") ) { navigate("ثبت"); return true; }
        if (containsAny(x,"تراکنش","تراکنش ها","تراکنش‌های","تاریخچه مالی","سوابق مالی","ریز پرداخت ها","فهرست پرداخت ها") && actionVerb && !containsAny(x,"گردش حساب بانک","گردش بانکی")) { navigate("تراکنش‌ها"); return true; }
        if (containsAny(x,"گزارش","خلاصه مالی","تحلیل مالی","وضعیت مالی","ارزش خالص","جمع درآمد","جمع هزینه") && actionVerb) { showReports(); return true; }
        if (containsAny(x,"حساب بانکی","حساب های بانکی","حساب‌ها","حساب ها","کیف پول","مدیریت حساب","فهرست حساب") && actionVerb) { showAccounts(); return true; }
        if (containsAny(x,"افزودن حساب","حساب جدید","ثبت حساب بانکی","کیف پول جدید","حساب تازه")) { addAccountDialog(); return true; }
        if (containsAny(x,"مدیریت حساب","ویرایش حساب","اتصال حساب","حساب ها را مدیریت")) { manageAccountLinks(); return true; }
        if (containsAny(x,"دسته بندی","دسته‌بندی","دسته ها","مدیریت دسته","دسته های هزینه","دسته های درآمد") && actionVerb) { manageCategories(); return true; }
        if (containsAny(x,"بودجه","سقف هزینه","بودجه بندی","بودجه‌بندی") && actionVerb) { showBudgets(); return true; }
        if (containsAny(x,"هدف پس انداز","هدف‌های پس انداز","اهداف پس انداز","پس اندازها","پس انداز ماهانه") && actionVerb) { showGoals(); return true; }
        if (containsAny(x,"پرداخت تکراری","تراکنش تکراری","پرداخت های تکراری","سررسید","اقساط","قبض های دوره ای") && actionVerb) { showRecurring(); return true; }
        if (containsAny(x,"بدهی","طلب","قرض","تسویه","بدهکار","طلبکار") && actionVerb && !moneyIntent) { showDebts(); return true; }
        if (containsAny(x,"دارایی","اموال","سرمایه غیرنقدی") && actionVerb && !moneyIntent) { showAssets(); return true; }
        if (containsAny(x,"ثبت دارایی","افزودن دارایی","دارایی جدید","مال جدید")) { showAssetDialog(); return true; }
        if (containsAny(x,"ثبت بدهی","ثبت طلب","افزودن بدهی","افزودن طلب","قرض جدید")) { showDebtDialog(); return true; }
        if (containsAny(x,"انتقال وجه","انتقال پول","انتقال بین حساب","جابجایی پول","جابه جایی پول","کارت به کارت","کارت‌به‌کارت") && !containsAny(x,"تراکنش های انتقال","گزارش انتقال")) { showTransfer(); return true; }
        if (containsAny(x,"مدیریت دفتر","دفترها","دفتر ها","تعویض دفتر","تغییر دفتر","دفتر حسابداری") && actionVerb) { manageBooks(); return true; }
        if (containsAny(x,"بستن ماه","پایان ماه","بایگانی ماه","ماه های بسته شده","ماه‌های بایگانی") && actionVerb) { showMonthClosing(); return true; }
        if (containsAny(x,"خروجی csv","خروجی اکسل","فایل اکسل","خروجی تراکنش","گزارش اکسل","ذخیره تراکنش ها در فایل")) { exportTransactionsCsv(); return true; }
        if (containsAny(x,"پشتیبان گیری","پشتیبان‌گیری","بکاپ بگیر","خروجی پشتیبان","نسخه پشتیبان")) { exportBackup(); return true; }
        if (containsAny(x,"بازیابی پشتیبان","بازیابی بکاپ","وارد کردن پشتیبان","برگرداندن بکاپ")) { importBackup(); return true; }
        if (containsAny(x,"رمز برنامه","قفل برنامه","تنظیم رمز","تغییر رمز","رمز عبور")) { setPinDialog(); return true; }
        if (containsAny(x,"درباره برنامه","اطلاعات برنامه","نسخه برنامه","سازنده برنامه")) { showAboutDialog(); return true; }
        if (containsAny(x,"مانده حساب","موجودی حساب","موجودی بانک","مانده بانک","گردش حساب","گردش بانکی","تراکنش های بانک","تراکنش‌های بانک")) return false; // handled by account-aware logic below
        // If user asks to open a feature but the exact intent was not understood, don't create a transaction.
        if (actionVerb && containsAny(x,"صفحه","بخش","منوی","مدیریت","فهرست")) {
            new AlertDialog.Builder(this).setTitle("منظورت کدام بخش است؟")
                .setItems(new String[]{"خانه","ثبت عملیات","تراکنش‌ها","حساب‌های بانکی","گزارش مالی","دسته‌بندی‌ها","بودجه‌بندی","هدف‌های پس‌انداز","پرداخت‌های تکراری","بدهی و طلب","دارایی‌ها","تنظیمات"}, (d,w)->{
                    switch(w){case 0:navigate("خانه");break;case 1:navigate("ثبت");break;case 2:navigate("تراکنش‌ها");break;case 3:showAccounts();break;case 4:showReports();break;case 5:manageCategories();break;case 6:showBudgets();break;case 7:showGoals();break;case 8:showRecurring();break;case 9:showDebts();break;case 10:showAssets();break;case 11:navigate("تنظیمات");break;}
                }).setNegativeButton("لغو",null).show();
            return true;
        }
        return false;
    }

    private boolean isQuickIconManagementCommand(String input) {
        String n = normalizeVoiceText(input)
            .replace("های", " ها").replace("آیکون", "آیکن")
            .replace("ایکون", "آیکن").replace("ایکن", "آیکن")
            .replace("خانه گی", "خانه").replace("صفحه خانه", "خانه");
        boolean iconWord = containsAny(n, "آیکن", "آیکون", "میانبر", "دسترسی سریع", "دکمه های خانه", "دکمه های صفحه اصلی");
        boolean manageWord = containsAny(n, "مدیریت", "تنظیم", "ویرایش", "مرتب", "انتخاب", "تغییر", "باز کن", "برو به", "برو");
        if (iconWord && manageWord) return true;
        return containsAny(n, "مدیریت آیکن ها", "مدیریت آیکن های خانه", "مدیریت آیکن های صفحه اصلی",
            "مدیریت آیکن های دسترسی سریع", "صفحه مدیریت آیکن ها", "صفحه مدیریت آیکن های خانه",
            "مدیریت میانبرها", "تنظیم آیکن های خانه", "ویرایش آیکن های خانه", "آیکن های خانه را باز کن");
    }

    private boolean handleVoiceThemeCommand(String normalized) {
        boolean themeContext = containsAny(normalized,"تم","رنگ برنامه","رنگ برنامه رو","رنگ برنامه را","تغییر رنگ","رنگش","ظاهر برنامه","رنگ رابط") || (normalized.endsWith("کن") && containsAny(normalized,"صورتی","آبی","سبز","بنفش","نارنجی","فیروزه","ذغالی","زغالی","سرخابی"));
        if (containsAny(normalized,"تم تیره","حالت تیره","دارک مود","dark mode")) {
            toast("حالت تیره هنوز در این نسخه پیاده‌سازی نشده است؛ می‌توانی رنگ اصلی برنامه را تغییر بدهی.");
            navigate("تنظیمات");
            return true;
        }
        if (containsAny(normalized,"تم روشن","حالت روشن","لایت مود","light mode")) {
            toast("برنامه در حالت روشن است؛ برای تغییر ظاهر، رنگ موردنظر را بگو.");
            return true;
        }
        if (!themeContext) return false;
        int chosen = -1;
        String[] aliases = {"صورتی","صورتی کن","آبی","آبی کن","سبز","سبز کن","بنفش","بنفش کن","نارنجی","نارنجی کن","فیروزه ای","فیروزه‌ای","ذغالی","زغالی","سرخابی"};
        int[] map = {0,0,1,1,2,2,3,3,4,4,5,5,6,6,7};
        for (int i=0;i<aliases.length;i++) if (normalized.contains(aliases[i])) { chosen=map[i]; break; }
        if (containsAny(normalized,"رنگ قبلی","برگرد به رنگ قبلی","رنگ پیش فرض","رنگ پیش‌فرض","صورتی پیش فرض")) chosen=0;
        if (chosen >= 0) {
            int color=THEME_COLORS[chosen];
            getPreferences(0).edit().putInt("theme_color",color).apply();
            applyThemeToShell();
            showShell();
            switch(page) {
                case "خانه": showHome(); break;
                case "تراکنش‌ها": showTransactions(); break;
                case "ثبت": showAddMenu(); break;
                case "دارایی‌ها": showAssets(); break;
                default: showSettings(); break;
            }
            toast("رنگ برنامه به "+THEME_NAMES[chosen]+" تغییر کرد.");
            return true;
        }
        if (containsAny(normalized,"تم","رنگ برنامه","ظاهر برنامه")) {
            navigate("تنظیمات");
            new AlertDialog.Builder(this).setTitle("تغییر رنگ برنامه")
                .setMessage("رنگی را انتخاب کن یا بگو: آبی کن، سبز کن، بنفش کن، نارنجی کن، فیروزه‌ای کن، ذغالی کن یا صورتی کن.")
                .setPositiveButton("انتخاب رنگ",(d,w)->showAboutDialog()).setNegativeButton("بستن",null).show();
            return true;
        }
        return false;
    }

    private boolean hasQueryCue(String text) {
        return containsAny(text,"موجودی","مانده","گردش حساب","گزارش","چقدر خرج","چقدر درآمد","فهرست تراکنش","حساب های بانکی","حساب‌های بانکی");
    }

    private boolean hasNavigationCue(String text) {
        return containsAny(text,"بستن ماه","بایگانی ماه","حساب جدید","تنظیمات","صفحه اصلی","دارایی","بدهی","بودجه");
    }

    private boolean hasIncomeCue(String text) {
        return containsAny(text,"درآمد","حقوق گرفتم","حقوق واریز شد","دریافت کردم","دریافت شد","وصول کردم","وصول شد","به حسابم واریز شد","به حسابم آمد","فروختم","فروش داشتم","فروش کردم","مشتری پرداخت کرد","به من پرداخت کرد","سود گرفتم","اجاره گرفتم","پول گرفتم","وجه دریافت کردم");
    }

    private boolean hasExpenseCue(String text) {
        return containsAny(text,"هزینه","خرج","خریدم","خریدیم","خرید کردم","پرداخت کردم","پرداختیم","پرداختم","قبض پرداخت کردم","پول دادم","پول پرداخت کردم","هزینه کردم","خریداری کردم","برداشت کردم","کرایه دادم","کارت کشیدم","خرج کردم","پرداخت شد از حسابم");
    }

    private boolean isTransferIntent(String text) {
        boolean transferWord = containsAny(text,"انتقال پول","انتقال وجه","انتقال بین حساب","جابجایی پول","جابه جایی پول","از حساب","به حساب دیگر","کارت به کارت","کارت‌به‌کارت");
        boolean fromTo = (text.contains("از ") && text.contains(" به ")) && containsAny(text,"واریز","انتقال","جابجا","جابه جا","فرستادم","منتقل کردم");
        return transferWord || fromTo;
    }

    private String normalizeVoiceText(String input) {
        String value = normalizeDigits(input==null?"":input).toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک')
            .replace('ۀ','ه').replace('ة','ه').replaceAll("[\u064B-\u065F]","");
        value = value.replaceAll("(^|\\s)رو(?=\\s|$)", "$1را").replace("میخوام","می خواهم").replace("می خوام","می خواهم")
            .replace("واسه","برای").replace("تو صفحه","در صفحه").replace("برو تو","برو به")
            .replaceAll("\\s+"," ").trim();
        return value;
    }
    private void showVoiceIntentChoice(String spoken) {
        String[] choices={"ثبت هزینه","ثبت درآمد","انتقال بین حساب‌ها","مشاهده تراکنش‌ها","مشاهده حساب‌ها","گزارش مالی","بدهی و طلب","دارایی‌ها","بستن ماه"};
        new AlertDialog.Builder(this).setTitle("نوع درخواست را مشخص کن")
            .setMessage("از گفتار نتوانستم با اطمینان تشخیص بدهم چه کاری می‌خواهی. یکی از بخش‌ها را انتخاب کن.")
            .setItems(choices,(d,w)->{switch(w){case 0:showVoiceDraft(spoken,"هزینه",parseVoiceAmount(spoken),"سایر",spoken.contains("دیروز"));break;case 1:showVoiceDraft(spoken,"درآمد",parseVoiceAmount(spoken),"سایر",spoken.contains("دیروز"));break;case 2:showTransfer();break;case 3:navigate("تراکنش‌ها");break;case 4:showAccounts();break;case 5:showReports();break;case 6:showDebts();break;case 7:showAssets();break;case 8:showMonthClosing();break;}}).setNegativeButton("لغو",null).show();
    }

    /** Returns the start position of the last matching voice-intent cue, or -1. */
    private int lastCuePosition(String text, String[] cues) {
        if (text == null || cues == null || cues.length == 0) return -1;
        int lastPosition = -1;
        for (String cue : cues) {
            if (cue == null || cue.isEmpty()) continue;
            int position = text.lastIndexOf(cue);
            if (position > lastPosition) lastPosition = position;
        }
        return lastPosition;
    }

    private String detectVoiceTransactionType(String spoken) {
        String text = normalizeVoiceText(spoken);
        // Explicit phrases have priority over generic verbs.
        String[] incomeStrong = {"حقوق گرفتم", "حقوق واریز شد", "دریافت کردم", "دریافت شد", "وصول کردم", "وصول شد", "به حسابم واریز شد", "به حسابم آمد", "فروختم", "فروش داشتم", "فروش کردم", "مشتری پرداخت کرد", "به من پرداخت کرد", "سود گرفتم", "اجاره گرفتم", "پول گرفتم", "وجه دریافت کردم"};
        String[] expenseStrong = {"خرید کردم", "خریدم", "خریدیم", "پرداخت کردم", "پرداختم", "پرداختیم", "هزینه کردم", "خرج کردم", "پول دادم", "پول پرداخت کردم", "قبض پرداخت کردم", "برداشت کردم", "کرایه دادم", "کارت کشیدم", "خریداری کردم"};
        int incomeAt = lastCuePosition(text, incomeStrong);
        int expenseAt = lastCuePosition(text, expenseStrong);

        // Negated statements must not be interpreted as completed transactions.
        if (containsAny(text,"پرداخت نکردم","نخریدم","خرج نکردم","دریافت نکردم","واریز نشد","پرداخت نشده","هنوز پرداخت نکردم")) return "نامشخص";
        if (incomeAt >= 0 && expenseAt >= 0) {
            // A sentence can mention both sides (e.g. received money, then paid a bill).
            // Choose the last explicit completed action; user still reviews the draft.
            return incomeAt > expenseAt ? "درآمد" : "هزینه";
        }
        if (incomeAt >= 0) return "درآمد";
        if (expenseAt >= 0) return "هزینه";

        // Weak words are not sufficient on their own: "گرفتم" and "دادم" are ambiguous.
        boolean income = containsAny(text,"درآمد","حقوق","فروش","فروشم","وصول","اجاره گرفتم","واریز شد به حسابم");
        boolean expense = containsAny(text,"هزینه","خرج","خرید","قبض","کرایه","بنزین","پرداخت","برداشت","مصرف کردم");
        if (income && !expense) return "درآمد";
        if (expense && !income) return "هزینه";
        return "نامشخص";
    }

    private String normalizeDigits(String input) {
        if (input == null) return "";
        StringBuilder b = new StringBuilder(input.length());
        for (int i=0;i<input.length();i++) {
            char ch=input.charAt(i);
            if(ch>='۰'&&ch<='۹') ch=(char)('0'+ch-'۰');
            else if(ch>='٠'&&ch<='٩') ch=(char)('0'+ch-'٠');
            if(ch=='٬'||ch=='،') ch=',';
            b.append(ch);
        }
        return b.toString();
    }

    private boolean containsAny(String value, String... words) {
        for (String word : words) if (value.contains(word)) return true;
        return false;
    }

    private long parseVoiceAmount(String spoken) {
        String normalized = normalizeDigits(spoken).toLowerCase(Locale.ROOT).replace('‌', ' ').replace('ي','ی').replace('ك','ک');
        // اول عددی را پیدا می‌کنیم که مستقیماً به واحد پول وصل است؛ عدد تعداد کالا مثل «یه دفتر» نادیده گرفته می‌شود.
        java.util.regex.Matcher numericMoney = java.util.regex.Pattern.compile("([0-9][0-9,٬.]*)(?:\\s*(میلیارد|میلیون|هزار))?\\s*(ریال|تومان|تومن)").matcher(normalized);
        long explicitNumeric = 0;
        while (numericMoney.find()) {
            String raw = numericMoney.group(1).replace(",", "").replace("٬", "").replace(".", "");
            long n; try { n = Long.parseLong(raw); } catch (Exception e) { continue; }
            String scale = numericMoney.group(2) == null ? "" : numericMoney.group(2);
            if (scale.equals("هزار")) n = safeMultiply(n, 1000L);
            else if (scale.equals("میلیون")) n = safeMultiply(n, 1000000L);
            else if (scale.equals("میلیارد")) n = safeMultiply(n, 1000000000L);
            String currency = numericMoney.group(3);
            if (currency.equals("تومان") || currency.equals("تومن")) n = safeMultiply(n, 10L); // همهٔ مبالغ داخلی ریال‌اند.
            explicitNumeric = n;
        }
        if (explicitNumeric > 0) return explicitNumeric;

        long wordsWithCurrency = parseLastWordsAmountBeforeCurrency(normalized);
        if (wordsWithCurrency > 0) return wordsWithCurrency; // تابع بالا واحد همان عبارت را به ریال تبدیل می‌کند.

        // اگر واحد پول گفته نشد، عبارت عددیِ پس از واژه‌هایی مثل «قیمت» یا «مبلغ» اولویت دارد.
        long anchored = parseAmountAfterAnchor(normalized);
        if (anchored > 0) return anchored;
        long words = parsePersianWordsAmount(normalized);
        if (words > 0) return words;
        // ASR گاهی مبلغ را فقط به رقم می‌دهد و واحد پول را حذف می‌کند. فقط اعداد بزرگ را
        // در جمله‌های دارای نیت مالی می‌پذیریم تا شماره کارت/تاریخ به‌اشتباه مبلغ نشود.
        if (containsAny(normalized,"هزینه","خرج","پرداخت","واریز","دریافت","درآمد","فروختم","خریدم","مبلغ","قیمت","تراکنش","ریال","تومان","تومن")) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?<![0-9])([0-9][0-9,٬.]{4,})(?![0-9])").matcher(normalized);
            long candidate = 0; int count = 0;
            while (m.find()) { try { long v = Long.parseLong(m.group(1).replace(",","").replace("٬","").replace(".","")); if (v >= 10000) { candidate=v; count++; } } catch(Exception ignored) {} }
            if (count == 1) return candidate;
        }
        return 0;
    }

    private long parseLastWordsAmountBeforeCurrency(String text) {
        String[] tokens = text.replace('‌', ' ').split("\\s+");
        StringBuilder group = new StringBuilder();
        long lastAmount = 0;
        for (String raw : tokens) {
            String token = raw.replaceAll("^[^\\p{L}0-9]+|[^\\p{L}0-9]+$", "").replace('ي','ی').replace('ك','ک');
            if (token.equals("ریال") || token.equals("تومان") || token.equals("تومن")) {
                long amount = evaluatePersianNumberGroup(group.toString());
                if (amount > 0) lastAmount = (token.equals("تومان") || token.equals("تومن")) ? safeMultiply(amount, 10L) : amount;
                group.setLength(0);
                continue;
            }
            boolean numericWord = persianNumberTokenValue(token) >= 0 || token.matches("[0-9][0-9,٬.]*") || token.equals("هزار") || token.equals("میلیون") || token.equals("میلیارد") || token.equals("و");
            if (numericWord) {
                if (group.length() > 0) group.append(' ');
                group.append(token);
            } else {
                group.setLength(0);
            }
        }
        return lastAmount;
    }

    private long parseAmountAfterAnchor(String text) {
        int anchor = Math.max(Math.max(text.lastIndexOf("قیمت"), text.lastIndexOf("مبلغ")), Math.max(text.lastIndexOf("به مبلغ"), text.lastIndexOf("هزینه")));
        if (anchor < 0) return 0;
        String tail = text.substring(anchor);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("([0-9][0-9,٬.]*)(?:\\s*(میلیارد|میلیون|هزار))?").matcher(tail);
        long value = 0;
        while (m.find()) {
            try {
                long n = Long.parseLong(m.group(1).replace(",", "").replace("٬", "").replace(".", ""));
                String unit = m.group(2) == null ? "" : m.group(2);
                if (unit.equals("هزار")) n = safeMultiply(n, 1000L);
                else if (unit.equals("میلیون")) n = safeMultiply(n, 1000000L);
                else if (unit.equals("میلیارد")) n = safeMultiply(n, 1000000000L);
                value = n;
            } catch (Exception ignored) {}
        }
        long words = parsePersianWordsAmount(tail);
        return words > 0 ? words : value;
    }

    private long parsePersianWordsAmount(String spoken) {
        String[] tokens = normalizeDigits(spoken).toLowerCase(Locale.ROOT).split("\\s+");
        StringBuilder group = new StringBuilder();
        long lastValue = 0;
        for (String raw : tokens) {
            String token = raw.replaceAll("^[^\\p{L}0-9]+|[^\\p{L}0-9]+$", "");
            boolean numericWord = persianNumberTokenValue(token) >= 0 || token.equals("هزار") || token.equals("میلیون") || token.equals("میلیارد");
            if (numericWord) {
                if (group.length() > 0) group.append(' ');
                group.append(token);
            } else if (token.equals("و") && group.length() > 0) {
                group.append(" و");
            } else if (group.length() > 0) {
                long parsed = evaluatePersianNumberGroup(group.toString());
                if (parsed > 0) lastValue = parsed;
                group.setLength(0);
            }
        }
        if (group.length() > 0) {
            long parsed = evaluatePersianNumberGroup(group.toString());
            if (parsed > 0) lastValue = parsed;
        }
        return lastValue;
    }

    private long evaluatePersianNumberGroup(String phrase) {
        long total = 0, current = 0;
        for (String token : phrase.split("\\s+")) {
            if (token.equals("و")) continue;
            if (token.equals("هزار") || token.equals("میلیون") || token.equals("میلیارد")) {
                long factor = token.equals("هزار") ? 1000L : token.equals("میلیون") ? 1000000L : 1000000000L;
                total += safeMultiply(current == 0 ? 1 : current, factor);
                current = 0;
            } else {
                int n = persianNumberTokenValue(token);
                if (n >= 0) current += n;
                else if (token.matches("[0-9][0-9,٬.]*")) {
                    try { current += Long.parseLong(token.replace(",", "").replace("٬", "").replace(".", "")); }
                    catch (Exception ignored) {}
                }
            }
        }
        return total + current;
    }

    private int persianNumberTokenValue(String token) {
        switch (token) {
            case "یه": case "یک": case "یکی": return 1;
            case "دو": case "دوتا": return 2;
            case "سه": return 3; case "چهار": return 4; case "پنج": return 5;
            case "شش": case "شیش": return 6; case "هفت": return 7; case "هشت": return 8; case "نه": return 9;
            case "ده": return 10; case "یازده": return 11; case "دوازده": return 12; case "سیزده": return 13;
            case "چهارده": return 14; case "پانزده": return 15; case "شانزده": return 16; case "هفده": return 17;
            case "هجده": return 18; case "نوزده": return 19; case "بیست": return 20; case "سی": return 30;
            case "چهل": return 40; case "پنجاه": return 50; case "شصت": return 60; case "هفتاد": return 70;
            case "هشتاد": return 80; case "نود": return 90; case "صد": case "یکصد": return 100;
            case "دویست": return 200; case "سیصد": return 300; case "چهارصد": return 400;
            case "پانصد": case "پونصد": return 500; case "ششصد": case "شیشصد": return 600;
            case "هفتصد": return 700; case "هشتصد": return 800; case "نهصد": return 900;
            default: return -1;
        }
    }

    private long safeMultiply(long value, long factor) {
        if (value > Long.MAX_VALUE / factor) return Long.MAX_VALUE;
        return value * factor;
    }

    private String guessVoiceCategory(String text, String type) {
        if (type.equals("درآمد")) {
            if (containsAny(text, "حقوق", "دستمزد", "حقوق ماهانه")) return "حقوق";
            if (containsAny(text, "فروختم", "فروش", "مشتری", "وصول", "فاکتور صادر")) return "کسب‌وکار";
            if (containsAny(text, "سود", "سرمایه")) return "سرمایه‌گذاری";
            return "سایر";
        }
        if (containsAny(text, "دفتر", "خودکار", "کاغذ", "لوازم التحریر", "لوازم اداری", "پرینتر", "کارتریج")) return "لوازم اداری";
        if (containsAny(text, "غذا", "ناهار", "شام", "صبحانه", "رستوران", "نان", "میوه")) return "خوراک";
        if (containsAny(text, "بنزین", "تاکسی", "اسنپ", "اتوبوس", "کرایه", "سوخت")) return "حمل‌ونقل";
        if (containsAny(text, "دارو", "دکتر", "درمان", "بیمارستان")) return "سلامت";
        if (containsAny(text, "برق", "آب", "گاز", "اینترنت", "قبض")) return "قبوض";
        if (containsAny(text, "اجاره", "خانه", "مسکن")) return "مسکن";
        return "سایر";
    }

    private String matchExistingVoiceCategory(String guessed, String spoken, String type) {
        java.util.ArrayList<String> options = getCategoryOptions(type);
        String normalizedSpeech = normalizeDigits(spoken == null ? "" : spoken).toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک');
        String best = null;
        int bestScore = 0;
        for (String option : options) {
            String normOption = option.toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک');
            int score = 0;
            if (guessed != null && normOption.equals(guessed.toLowerCase(Locale.ROOT))) score += 8;
            String compact = normOption.replace("‌", " ").trim();
            if (!compact.isEmpty() && normalizedSpeech.contains(compact)) score += 12;
            String[] words = compact.split("\\s+");
            for (String word : words) if (word.length() >= 3 && normalizedSpeech.contains(word)) score += 2;
            // Common spoken variants map to likely user-defined category names.
            if (containsAny(normalizedSpeech, "بنزین", "تاکسی", "اسنپ", "اتوبوس", "کرایه", "سوخت") && containsAny(normOption,"حمل و نقل","حمل‌ونقل","رفت و آمد","رفت‌وآمد","سوخت")) score += 10;
            if (containsAny(normalizedSpeech, "اینترنت", "قبض برق", "قبض آب", "قبض گاز") && containsAny(normOption,"قبوض","آب و برق","خدمات","اینترنت")) score += 10;
            if (containsAny(normalizedSpeech, "حقوق", "دستمزد") && containsAny(normOption,"حقوق","دستمزد","درآمد شغلی")) score += 10;
            if (containsAny(normalizedSpeech, "نان", "غذا", "ناهار", "شام", "رستوران", "میوه") && containsAny(normOption,"خوراک","غذا","مواد غذایی")) score += 10;
            if (score > bestScore) { bestScore = score; best = option; }
        }
        if (best != null && bestScore >= 4) return best;
        if (guessed != null && options.contains(guessed)) return guessed;
        return options.contains("متفرقه") ? "متفرقه" : (options.isEmpty() ? "متفرقه" : options.get(0));
    }

    private void showVoiceDraft(String spoken, String guessedType, long guessedAmount, String guessedCategory, boolean yesterday) {
        LinearLayout form = formLayout();
        TextView recognized = text("متن تشخیص‌داده‌شده:\n" + spoken, 14, TEXT, true);
        recognized.setBackground(roundBg(Color.rgb(255, 235, 241)));
        recognized.setPadding(dp(12),dp(10),dp(12),dp(10));
        form.addView(recognized);
        TextView safetyNote = text("نوع عملیات، مبلغ، واحد پول، حساب، دسته‌بندی و شرح را بررسی کن. اگر دستیار منظور را اشتباه فهمیده، همین‌جا اصلاح کن؛ تا تأیید تو هیچ تراکنشی ذخیره نمی‌شود.", 13, DARK, true);
        safetyNote.setPadding(dp(4), dp(8), dp(4), dp(8));
        form.addView(safetyNote);
        Spinner typeSpinner = styledSpinner();
        typeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"هزینه", "درآمد"}));
        typeSpinner.setSelection("درآمد".equals(guessedType) ? 1 : 0);
        form.addView(typeSpinner);
        EditText amount = edit("مبلغ نهایی به ریال (اجباری)", InputType.TYPE_CLASS_NUMBER);
        if (guessedAmount > 0) amount.setText(String.valueOf(guessedAmount));
        form.addView(amount);
        form.addView(text("تبدیل واحد: هر ۱ تومان = ۱۰ ریال. اگر واحد در گفتار گفته نشود، مبلغ ریال فرض می‌شود. مبلغ تبدیل‌شده را قبل از ثبت بررسی کن.", 12, DARK, false));
        TextView categoryLabel = text("نوع هزینه / درآمد", 13, TEXT, true); form.addView(categoryLabel);
        Spinner category = styledSpinner();
        java.util.ArrayList<String> categoryOptions = getCategoryOptions(guessedType);
        if (guessedCategory != null && !guessedCategory.trim().isEmpty() && !categoryOptions.contains(guessedCategory)) categoryOptions.add(guessedCategory);
        category.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categoryOptions));
        int categoryIndex = categoryOptions.indexOf(guessedCategory);
        category.setSelection(categoryIndex >= 0 ? categoryIndex : categoryOptions.indexOf("متفرقه"));
        form.addView(category);
        final boolean[] categoryInit = {false};
        typeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!categoryInit[0]) { categoryInit[0] = true; return; }
                String selectedType = String.valueOf(typeSpinner.getSelectedItem());
                java.util.ArrayList<String> refreshed = getCategoryOptions(selectedType);
                String best = matchExistingVoiceCategory(guessVoiceCategory(normalizeDigits(spoken).toLowerCase(Locale.ROOT), selectedType), normalizeDigits(spoken).toLowerCase(Locale.ROOT), selectedType);
                category.setAdapter(new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, refreshed));
                int match = refreshed.indexOf(best);
                category.setSelection(match >= 0 ? match : Math.max(0, refreshed.indexOf("متفرقه")));
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        TextView paymentLabel = text("نوع پرداخت", 13, TEXT, true); form.addView(paymentLabel);
        Spinner paymentMethod = styledSpinner();
        String[] paymentOptions = {"نقدی", "کارت بانکی", "انتقال بانکی", "کارت‌خوان", "اعتباری", "متفرقه"};
        paymentMethod.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, paymentOptions));
        paymentMethod.setSelection(5);
        if (containsAny(normalizeDigits(spoken), "کارتخوان", "کارت‌خوان", "پوز")) paymentMethod.setSelection(3);
        else if (containsAny(normalizeDigits(spoken), "انتقال بانکی", "حواله", "واریز به")) paymentMethod.setSelection(2);
        else if (containsAny(normalizeDigits(spoken), "کارت", "کارت بانکی", "شماره کارت")) paymentMethod.setSelection(1);
        else if (containsAny(normalizeDigits(spoken), "نقدی", "پول نقد")) paymentMethod.setSelection(0);
        form.addView(paymentMethod);
        TextView accountLabel = text("حساب / بانک", 13, TEXT, true); form.addView(accountLabel);
        Spinner account = styledSpinner();
        java.util.ArrayList<String> accountOptions = getAccountOptions();
        account.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, accountOptions));
        String matchedAccount = findVoiceAccount(normalizeDigits(spoken));
        int accountIndex = -1;
        boolean bankMentioned = containsKnownBank(normalizeDigits(spoken));
        if (matchedAccount != null) {
            for (int i = 0; i < accountOptions.size(); i++) {
                if (accountNameFromOption(accountOptions.get(i)).equals(matchedAccount)) { accountIndex = i; break; }
            }
        }
        if (accountIndex < 0 && bankMentioned) { accountIndex = accountOptions.indexOf("متفرقه"); toast("نام بانک تشخیص داده شد اما حساب ثبت‌شدهٔ منطبق پیدا نشد؛ حساب را پیش از ثبت بررسی کن."); }
        if (accountIndex < 0) accountIndex = accountOptions.indexOf("پول نقد");
        if (accountIndex < 0) accountIndex = accountOptions.indexOf("متفرقه");
        account.setSelection(Math.max(0, accountIndex));
        form.addView(account);
        EditText note = edit("شرح تراکنش", InputType.TYPE_CLASS_TEXT);
        note.setText(spoken);
        form.addView(note);
        Calendar selectedDate = Calendar.getInstance();
        if (yesterday) selectedDate.add(Calendar.DAY_OF_MONTH, -1);
        Button dateButton = button("تاریخ تراکنش: " + jalaliDate(selectedDate.getTimeInMillis()));
        dateButton.setOnClickListener(v -> {
            Calendar cur=(Calendar)selectedDate.clone();
            new DatePickerDialog(this,(view,year,month,day)->{
                selectedDate.set(Calendar.YEAR,year); selectedDate.set(Calendar.MONTH,month); selectedDate.set(Calendar.DAY_OF_MONTH,day);
                selectedDate.set(Calendar.HOUR_OF_DAY,12); selectedDate.set(Calendar.MINUTE,0); selectedDate.set(Calendar.SECOND,0);
                dateButton.setText("تاریخ تراکنش: "+jalaliDate(selectedDate.getTimeInMillis()));
            },cur.get(Calendar.YEAR),cur.get(Calendar.MONTH),cur.get(Calendar.DAY_OF_MONTH)).show();
        });
        form.addView(dateButton);
        ScrollView scroll = new ScrollView(this); scroll.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("بررسی و تأیید تراکنش صوتی").setView(scroll)
            .setNegativeButton("لغو", null).setNeutralButton("اصلاح متن", (d,w)->showManualVoiceText(spoken)).setPositiveButton("تأیید و ثبت", null).create();
        dialog.setOnShowListener(dlg -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            long a = parseAmount(amount.getText().toString());
            String ty = String.valueOf(typeSpinner.getSelectedItem());
            String cat = String.valueOf(category.getSelectedItem());
            String acc = accountNameFromOption(String.valueOf(account.getSelectedItem()));
            String payment = String.valueOf(paymentMethod.getSelectedItem());
            if (a <= 0) { amount.setError("مبلغ معتبر به ریال و بیشتر از صفر وارد کن"); amount.requestFocus(); return; }
            if (cat.isEmpty()) cat = "متفرقه";
            if (acc.isEmpty()) acc = "متفرقه";
            if(isMonthClosed(monthKey(selectedDate.getTimeInMillis()))){toast("این ماه بایگانی و بسته شده است؛ تاریخ تراکنش را به ماه باز تغییر بده.");return;}
            ensureAccount(acc); saveCategoryIfMissing(ty,cat);
            ContentValues values = new ContentValues(); values.put("book",activeBook); values.put("type",ty); values.put("amount",a); values.put("category",cat); values.put("account",acc); values.put("payment_method",payment); values.put("note",note.getText().toString().trim()); values.put("date",selectedDate.getTimeInMillis()); setMonthKey(values,selectedDate.getTimeInMillis());
            saveTransactionWithDuplicateWarning(values,ty,a,cat,acc,selectedDate.getTimeInMillis(),()->{dialog.dismiss();HesabyarVoiceWidgetProvider.updateStatus(this, "آخرین ثبت: موفق");toast("تراکنش صوتی با تأیید شما ثبت شد.");if(widgetVoiceMode) finish(); else navigate("خانه");});
        }));
        dialog.show();
    }

    private java.util.ArrayList<String> getCategoryOptions(String type) {
        java.util.ArrayList<String> options = new java.util.ArrayList<>();
        Cursor c = db.getReadableDatabase().rawQuery("SELECT name FROM categories WHERE type=? ORDER BY name", new String[]{type});
        while (c.moveToNext()) { String n = c.getString(0); if (n != null && !n.trim().isEmpty() && !options.contains(n)) options.add(n); }
        c.close();
        Cursor tx = db.getReadableDatabase().rawQuery("SELECT DISTINCT category FROM transactions WHERE book=? AND type=? AND category IS NOT NULL ORDER BY category", new String[]{activeBook,type});
        while (tx.moveToNext()) { String n = tx.getString(0); if (n != null && !n.trim().isEmpty() && !options.contains(n)) options.add(n); }
        tx.close();
        if (!options.contains("متفرقه")) options.add("متفرقه");
        return options;
    }

    private java.util.ArrayList<String> getAccountOptions() {
        java.util.ArrayList<String> options = new java.util.ArrayList<>();
        Cursor c = db.getReadableDatabase().rawQuery("SELECT name,bank_name,card_last4 FROM accounts WHERE book=? ORDER BY id", new String[]{activeBook});
        while (c.moveToNext()) {
            String name = c.getString(0), bank = c.getString(1), last4 = c.getString(2);
            String label = name;
            if (bank != null && !bank.trim().isEmpty()) label += " • بانک " + bank;
            if (last4 != null && !last4.trim().isEmpty()) label += " • " + last4;
            if (!options.contains(label)) options.add(label);
        }
        c.close();
        if (!options.contains("پول نقد")) options.add("پول نقد");
        if (!options.contains("متفرقه")) options.add("متفرقه");
        return options;
    }

    private boolean showVoiceAccountPicker(String spoken, boolean showBalance) {
        String bank = detectBankFromSpeech(spoken);
        String last4 = null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?<![0-9])([0-9]{4})(?![0-9])").matcher(normalizeDigits(spoken));
        while (m.find()) last4 = m.group(1);
        java.util.ArrayList<String> names = new java.util.ArrayList<>();
        Cursor c = db.getReadableDatabase().rawQuery("SELECT name,COALESCE(bank_name,''),COALESCE(card_last4,'') FROM accounts WHERE book=? AND enabled=1 ORDER BY id", new String[]{activeBook});
        while (c.moveToNext()) {
            String name=c.getString(0), bankName=c.getString(1), card=c.getString(2);
            boolean bankMatch = bank != null && normalizeBankText(bankName).equals(normalizeBankText(bank));
            boolean cardMatch = last4 != null && last4.equals(normalizeDigits(card));
            // If both clues were spoken, require both to match. If only one was spoken, use it.
            if (bank != null && last4 != null) { if (bankMatch && cardMatch) names.add(name); }
            else if (last4 != null) { if (cardMatch) names.add(name); }
            else if (bank != null) { if (bankMatch) names.add(name); }
        }
        c.close();
        if (names.isEmpty()) return false;
        if (names.size() == 1) return false; // Caller will resolve the unique account via findVoiceAccount.
        java.util.ArrayList<String> labels = new java.util.ArrayList<>();
        for (String name : names) {
            Cursor meta = db.getReadableDatabase().rawQuery("SELECT COALESCE(bank_name,''),COALESCE(card_last4,'') FROM accounts WHERE book=? AND name=? LIMIT 1", new String[]{activeBook,name});
            String bankName="", card=""; if(meta.moveToFirst()){bankName=meta.getString(0);card=meta.getString(1);}meta.close();
            labels.add(name + (bankName.isEmpty()?"":" • بانک "+bankName) + (card.isEmpty()?"":" • کارت "+card));
        }
        String[] options = labels.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("کدام حساب را می‌خواهی؟")
            .setMessage("چند حساب با اطلاعات گفته‌شده تطبیق دارد. حساب درست را انتخاب کن؛ هیچ تراکنشی بدون تأیید ثبت نمی‌شود.")
            .setItems(options, (dialog, which) -> {
                String selected=names.get(which);
                if (showBalance) new AlertDialog.Builder(this).setTitle("مانده حساب")
                    .setMessage(selected+"\nمانده: "+money(accountBalance(selected)))
                    .setPositiveButton("مشاهده گردش حساب",(d,w)->showAccountTransactions(selected))
                    .setNegativeButton("بستن",null).show();
                else showAccountTransactions(selected);
            }).setNegativeButton("لغو",null).show();
        return true;
    }

    private String accountNameFromOption(String option) {
        if (option == null) return "متفرقه";
        int p = option.indexOf(" • بانک ");
        if (p >= 0) return option.substring(0, p).trim();
        return option.trim();
    }

    private int editDistance(String a, String b) {
        if (a == null || b == null) return 99;
        int[] prev = new int[b.length()+1], cur = new int[b.length()+1];
        for (int j=0;j<=b.length();j++) prev[j]=j;
        for (int i=1;i<=a.length();i++) {
            cur[0]=i;
            for (int j=1;j<=b.length();j++) cur[j]=Math.min(Math.min(cur[j-1]+1,prev[j]+1),prev[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));
            int[] tmp=prev;prev=cur;cur=tmp;
        }
        return prev[b.length()];
    }

    private String detectBankFromSpeech(String spoken) {
        String normalized=normalizeBankText(spoken);
        String[][] aliases=bankAliases();
        // First pass: exact/contained aliases are safest.
        for (String[] group:aliases) for (String alias:group) {
            String key=normalizeBankText(alias);
            if (key.length()>=3 && normalized.contains(key)) return group[0];
        }
        // Second pass: allow a one/two-character recognition error in a bank phrase.
        // Compare short token windows, not the whole sentence, to avoid accidental matches.
        String[] words=normalizeVoiceText(spoken).split("\\s+");
        String best=null; int bestDistance=99;
        for (int i=0;i<words.length;i++) for (int count=1;count<=3 && i+count<=words.length;count++) {
            StringBuilder phrase=new StringBuilder();
            for(int j=i;j<i+count;j++) { if(phrase.length()>0) phrase.append(' '); phrase.append(words[j]); }
            String candidate=normalizeBankText(phrase.toString());
            if(candidate.length()<4) continue;
            for(String[] group:aliases) for(String alias:group) {
                String key=normalizeBankText(alias);
                if(key.length()<4) continue;
                int limit=key.length()>=8?2:1;
                if(Math.abs(candidate.length()-key.length())>limit) continue;
                int distance=editDistance(candidate,key);
                if(distance<=limit && distance<bestDistance) { bestDistance=distance; best=group[0]; }
            }
        }
        return bestDistance<=2?best:null;
    }

    private String findVoiceAccount(String spoken) {
        String raw=normalizeVoiceText(spoken); String normalized=normalizeBankText(raw);
        String detectedBank=detectBankFromSpeech(spoken);
        java.util.regex.Matcher dm=java.util.regex.Pattern.compile("(?<![0-9])([0-9]{4})(?![0-9])").matcher(normalizeDigits(spoken));
        String last4=null;while(dm.find())last4=dm.group(1);
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,COALESCE(bank_name,''),COALESCE(card_last4,'') FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});
        java.util.ArrayList<String> bestNames = new java.util.ArrayList<>();
        int bestScore=0;
        while(c.moveToNext()) {
            String name=c.getString(0),bank=c.getString(1),card=c.getString(2);
            String nn=normalizeBankText(name), nb=normalizeBankText(bank);
            boolean bankMatch=detectedBank!=null && !nb.isEmpty() && (nb.equals(normalizeBankText(detectedBank)) || nn.contains(normalizeBankText(detectedBank)));
            boolean cardMatch=last4!=null && last4.equals(normalizeDigits(card));
            boolean nameMatch=!nn.isEmpty() && nn.length()>=3 && normalized.contains(nn);
            // When the user says both a bank and last four digits, both must match.
            if (detectedBank != null && last4 != null && !(bankMatch && cardMatch)) continue;
            int score=0;
            if(cardMatch) score+=1000;
            if(nameMatch) score+=300;
            if(bankMatch) score+=100;
            if(score>bestScore){bestScore=score;bestNames.clear();bestNames.add(name);}
            else if(score==bestScore && score>0 && !bestNames.contains(name)) bestNames.add(name);
        }
        c.close();
        // A bank name alone is not enough when multiple cards/accounts belong to that bank.
        // Return a result only when the match is unique; never silently choose the first row.
        return bestScore>0 && bestNames.size()==1 ? bestNames.get(0) : null;
    }
    private String[][] bankAliases() {
        return new String[][]{
          {"ملی","بانک ملی","ملی ایران","ملیی","مِلی","meli","bank melli","melli","melli iran"},
          {"ملت","بانک ملت","ملات","ملط","مملت","mellat","mellat bank","ملت ایران"},
          {"صادرات","بانک صادرات","صادرات ایران","صادارات","سادرات","saderat","bank saderat"},
          {"تجارت","بانک تجارت","تجارات","تجرت","tejarat","bank tejarat"},
          {"رفاه","بانک رفاه","رفاه کارگران","refah"},
          {"کشاورزی","بانک کشاورزی","کشاورزی ایران","keshavarzi"},
          {"مسکن","بانک مسکن","maskan"}, {"سپه","بانک سپه","sepah"},
          {"پارسیان","بانک پارسیان","parsian"}, {"پاسارگاد","بانک پاسارگاد","pasargad"},
          {"سامان","بانک سامان","saman"}, {"شهر","بانک شهر","shahr"},
          {"آینده","بانک آینده","ayandeh"}, {"اقتصاد نوین","بانک اقتصاد نوین","اقتصادنوین","eghtesad novin"},
          {"دی","بانک دی","day bank"}, {"کارآفرین","بانک کارآفرین","karafarin"},
          {"گردشگری","بانک گردشگری","tourism bank"}, {"ایران زمین","بانک ایران زمین","ایران‌زمین","iran zamin"},
          {"رسالت","بانک رسالت","قرض الحسنه رسالت","resalat"}, {"مهر ایران","بانک مهر ایران","قرض الحسنه مهر ایران","مهرایران","مهر","mehr iran","mehriran"},
          {"پست بانک","پست‌بانک","پست بانک ایران","post bank"}, {"توسعه تعاون","بانک توسعه تعاون","tosee taavon"},
          {"سینا","بانک سینا","sina"}, {"سرمایه","بانک سرمایه","sarmayeh"},
          {"خاورمیانه","بانک خاورمیانه","middle east bank"}, {"بلوبانک","بلو بانک","بلو","بلو بانک سامان","blu bank","blubank"},
          {"بانکینو","بانک اینو","bankino"}, {"ملل","موسسه اعتباری ملل","مؤسسه اعتباری ملل","melal"},
          {"نور","موسسه اعتباری نور","مؤسسه اعتباری نور"}, {"کوثر","موسسه اعتباری کوثر","مؤسسه اعتباری کوثر"},
          {"قوامین","بانک قوامین"}, {"انصار","بانک انصار"}, {"حکمت ایرانیان","بانک حکمت ایرانیان"},
          {"توسعه صادرات","بانک توسعه صادرات","توسعه صادرات ایران"}, {"صنعت و معدن","بانک صنعت و معدن"},
          {"ایران ونزوئلا","بانک مشترک ایران و ونزوئلا"}, {"کارآفرین","بانک کارآفرین"}
        };
    }
    private boolean containsKnownBank(String spoken) {
        String normalized = normalizeBankText(spoken);
        for(String[] group:bankAliases()) for(String bank:group){String key=normalizeBankText(bank);if(!key.isEmpty()&&normalized.contains(key))return true;}
        return false;
    }

    private String normalizeBankText(String input) {
        if (input == null) return "";
        String value = normalizeDigits(input).toLowerCase(Locale.ROOT)
            .replace('ي','ی').replace('ك','ک').replace('ۀ','ه').replace('ة','ه')
            .replace("بانک", "").replace("کارت", "").replace("حساب", "")
            .replace("شماره", "").replace("مالی", "");
        return value.replaceAll("[\\s\\p{Punct}‌ـ]+", "").trim();
    }

    private String[] bankNames() {
        return new String[]{"ملی","ملت","صادرات","تجارت","رفاه","کشاورزی","مسکن","سپه","پارسیان","پاسارگاد","سامان","شهر","آینده","اقتصاد نوین","دی","کارآفرین","گردشگری","قوامین","انصار","حکمت ایرانیان","ایران زمین","رسالت","خاورمیانه","سینا","سرمایه","توسعه تعاون","پست بانک","صنعت و معدن","توسعه صادرات","مهر ایران","قرض الحسنه مهر ایران","مهر اقتصاد","بانک مرکزی","بلوبانک","بانکینو","ایران ونزوئلا","توسعه صادرات ایران","موسسه اعتباری ملل","ملل","موسسه اعتباری نور","نور","موسسه اعتباری کوثر","کوثر","موسسه اعتباری ثامن","ثامن","بانک مشترک ایران و ونزوئلا","ایران ونزوئلا","بانک خاورمیانه","بانک قرض الحسنه رسالت","بانک قرض الحسنه مهر ایران"};
    }

    private void attachMoneyFormatting(EditText field) {
        final boolean[] changing = {false};
        field.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable editable) {
                if (changing[0]) return;
                String original = editable.toString();
                int cursor = Math.max(0, field.getSelectionStart());
                int digitsBefore = 0;
                for (int i=0; i<Math.min(cursor, original.length()); i++) if (Character.isDigit(original.charAt(i))) digitsBefore++;
                StringBuilder digits = new StringBuilder();
                for (int i=0; i<original.length(); i++) { char ch=original.charAt(i); if(ch>='۰'&&ch<='۹') digits.append((char)('0'+ch-'۰')); else if(ch>='٠'&&ch<='٩') digits.append((char)('0'+ch-'٠')); else if(ch>='0'&&ch<='9') digits.append(ch); }
                if (digits.length()==0) return;
                String formatted;
                try { formatted = NumberFormat.getIntegerInstance(new Locale("fa","IR")).format(Long.parseLong(digits.toString())); }
                catch (Exception e) { return; }
                if (formatted.equals(original)) return;
                changing[0]=true; field.setText(formatted);
                int target=0, seen=0;
                while(target<formatted.length() && seen<digitsBefore){ if(Character.isDigit(formatted.charAt(target))) seen++; target++; }
                field.setSelection(Math.min(target, formatted.length())); changing[0]=false;
            }
        });
    }

    private void showManualVoiceText(String initial) {
        EditText input = edit("متن دستور مالی را وارد کن", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setText(initial);
        new AlertDialog.Builder(this).setTitle("اصلاح متن تشخیص‌داده‌شده").setView(input)
            .setNegativeButton("لغو",null).setPositiveButton("تحلیل دوباره",(d,w)->processVoiceCommand(input.getText().toString().trim())).show();
    }

    private void showTransfer() {
        LinearLayout f=formLayout();
        AutoCompleteTextView from=accountInput("از حساب"), to=accountInput("به حساب"); EditText amt=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER), note=edit("شرح (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(from);f.addView(to);f.addView(amt);f.addView(note);
        new AlertDialog.Builder(this).setTitle("انتقال پول").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ثبت انتقال",(d,w)->{
            long a=parseAmount(amt.getText().toString()); String fr=from.getText().toString().trim(),toN=to.getText().toString().trim();
            if(a<=0||fr.isEmpty()||toN.isEmpty()||fr.equals(toN)){toast("حساب‌ها و مبلغ را درست وارد کن");return;}
            if(isMonthClosed(currentMonthKey())){toast("ماه جاری بسته شده است؛ انتقال جدید در این ماه مجاز نیست.");return;}
            ensureAccount(fr);ensureAccount(toN);
            SQLiteDatabase s=db.getWritableDatabase();
            String transferId=java.util.UUID.randomUUID().toString();
            s.beginTransaction();try{
                ContentValues v=new ContentValues();v.put("book",activeBook);v.put("type","انتقال خروجی");v.put("amount",a);v.put("category","انتقال");v.put("account",fr);v.put("note","به "+toN+"؛ "+note.getText());v.put("date",System.currentTimeMillis());setMonthKey(v,System.currentTimeMillis());v.put("transfer_id",transferId);s.insertOrThrow("transactions",null,v);
                ContentValues x=new ContentValues();x.put("book",activeBook);x.put("type","انتقال ورودی");x.put("amount",a);x.put("category","انتقال");x.put("account",toN);x.put("note","از "+fr+"؛ "+note.getText());x.put("date",System.currentTimeMillis());setMonthKey(x,System.currentTimeMillis());x.put("transfer_id",transferId);s.insertOrThrow("transactions",null,x);s.setTransactionSuccessful();
            }finally{s.endTransaction();}
            toast("انتقال ثبت شد");navigate("خانه");
        }).show();
    }
    private void showTransactions() {
        setHeaderInfo("تراکنش‌ها", "تراکنش‌ها را جست‌وجو و جزئیاتشان را بررسی کنید");
        body.removeAllViews(); addHeading("سوابق و جست‌وجوی تراکنش‌ها");
        EditText search=edit("جست‌وجو در شرح، دسته‌بندی یا حساب",InputType.TYPE_CLASS_TEXT);
        body.addView(search);
        Spinner filter=styledSpinner(); String[] filters={"همه تراکنش‌ها","فقط درآمد","فقط هزینه","انتقال‌ها"};
        filter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,filters)); body.addView(filter);
        Spinner accountFilter=styledSpinner(); java.util.ArrayList<String> accounts=new java.util.ArrayList<>();accounts.add("همه حساب‌ها");Cursor ac=db.getReadableDatabase().rawQuery("SELECT name FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});while(ac.moveToNext())accounts.add(ac.getString(0));ac.close();accountFilter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,accounts));body.addView(accountFilter);
        Spinner monthFilter=styledSpinner();java.util.ArrayList<String> months=new java.util.ArrayList<>();months.add("همه ماه‌ها");Cursor mc=db.getReadableDatabase().rawQuery("SELECT DISTINCT t.month_key FROM transactions t WHERE t.book=? AND t.month_key IS NOT NULL ORDER BY t.month_key DESC",new String[]{activeBook});while(mc.moveToNext())if(!months.contains(mc.getString(0)))months.add(mc.getString(0));mc.close();Cursor closed=db.getReadableDatabase().rawQuery("SELECT month_key FROM closed_months WHERE book=? ORDER BY month_key DESC",new String[]{activeBook});while(closed.moveToNext())if(!months.contains(closed.getString(0)))months.add(closed.getString(0));closed.close();String currentMonth=currentMonthKey();if(!months.contains(currentMonth))months.add(1,currentMonth);monthFilter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months));
        int defaultMonth=months.indexOf(currentMonth);if(defaultMonth>=0)monthFilter.setSelection(defaultMonth);
        String override=getPreferences(0).getString("transactions_month_override","");if(!override.isEmpty()){int ix=months.indexOf(override);if(ix>=0)monthFilter.setSelection(ix);getPreferences(0).edit().remove("transactions_month_override").apply();} body.addView(monthFilter);
        addWideButton("اعمال فیلتر",()->renderTransactions(search.getText().toString().trim(),filter.getSelectedItemPosition(),String.valueOf(accountFilter.getSelectedItem()),String.valueOf(monthFilter.getSelectedItem())));
        addWideButton("پاک کردن جست‌وجو",()->{search.setText("");filter.setSelection(0);accountFilter.setSelection(0);monthFilter.setSelection(Math.max(0,months.indexOf(currentMonth)));renderTransactions("",0,"همه حساب‌ها",currentMonth);});
        renderTransactions("",0,"همه حساب‌ها",currentMonth);
    }

    private void renderTransactions(String query,int filterIndex) { renderTransactions(query,filterIndex,"همه حساب‌ها","همه ماه‌ها"); }
    private void renderTransactions(String query,int filterIndex,String accountName,String monthKey) {
        while(body.getChildCount()>7) body.removeViewAt(7);
        String typeClause="";
        if(filterIndex==1) typeClause=" AND t.type='درآمد'";
        else if(filterIndex==2) typeClause=" AND t.type='هزینه'";
        else if(filterIndex==3) typeClause=" AND t.type LIKE 'انتقال%'";
        String visible="t.book=?";
        String sql="SELECT t.id,t.type,t.amount,t.category,t.account,t.note,t.date,t.transfer_id,t.payment_method,t.book FROM transactions t WHERE "+visible+typeClause+" AND (?='همه حساب‌ها' OR t.account=?) AND (?='همه ماه‌ها' OR t.month_key=?) AND (COALESCE(t.category,'') LIKE ? OR COALESCE(t.account,'') LIKE ? OR COALESCE(t.note,'') LIKE ?) ORDER BY t.date DESC LIMIT 1000";
        String q="%"+query+"%"; Cursor c=db.getReadableDatabase().rawQuery(sql,new String[]{activeBook,accountName,accountName,monthKey,monthKey,q,q,q});
        String totalSql="SELECT t.type,COALESCE(SUM(t.amount),0) FROM transactions t WHERE "+visible+" AND (?='همه حساب‌ها' OR t.account=?) AND (?='همه ماه‌ها' OR t.month_key=?) GROUP BY t.type";
        Cursor totals=db.getReadableDatabase().rawQuery(totalSql,new String[]{activeBook,accountName,accountName,monthKey,monthKey});long income=0,expense=0;while(totals.moveToNext()){if("درآمد".equals(totals.getString(0)))income=totals.getLong(1);if("هزینه".equals(totals.getString(0)))expense=totals.getLong(1);}totals.close();addMetric("جمع درآمد در فهرست",money(income),GREEN);addMetric("جمع هزینه در فهرست",money(expense),Color.rgb(204,103,112));addMetric("خالص",money(income-expense),TEXT);
        if(!c.moveToFirst()){c.close();addEmpty("تراکنشی مطابق این فیلتر پیدا نشد.");return;}
        do {
            long txId=c.getLong(0); String type=c.getString(1); long amount=c.getLong(2); String cat=c.getString(3), acc=c.getString(4), note=c.getString(5); long stamp=c.getLong(6);String transferId=c.isNull(7)?null:c.getString(7); String payment=c.isNull(8)?"متفرقه":c.getString(8);String sourceBook=c.getString(9);
            LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(dp(12),dp(10),dp(12),dp(10)); item.setBackground(roundBg(Color.WHITE));
            TextView line=text((cat==null?"بدون دسته":cat)+"  •  "+type,15,TEXT,true); item.addView(line);
            item.addView(text((acc==null?"":acc)+"  |  "+money(amount),14,type.equals("هزینه")||type.equals("انتقال خروجی")?Color.rgb(204,103,112):GREEN,false));
            item.addView(text("دفتر ثبت‌کننده: "+sourceBook+(sourceBook.equals(activeBook)?"":" • تراکنش مشترک حساب"),12,sourceBook.equals(activeBook)?Color.rgb(86,99,91):Color.rgb(90,100,170),true));
            item.addView(text("روش پرداخت: "+(payment==null?"متفرقه":payment),12,Color.rgb(86,99,91),false));
            item.addView(text(jalaliDate(stamp),12,Color.rgb(86, 99, 91),false));
            if(note!=null&&!note.isEmpty()) item.addView(text(note,12,Color.rgb(86, 99, 91),false));
            if(sourceBook.equals(activeBook)) item.setOnClickListener(v->transactionActions(txId,type,amount,cat,acc,note,transferId));
            else item.setOnClickListener(v->toast("این تراکنش در دفتر «"+sourceBook+"» ثبت شده است؛ برای جلوگیری از تغییر ناخواسته، از همان دفتر آن را ویرایش کن."));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        } while(c.moveToNext()); c.close();
    }
    private void transactionActions(long id,String type,long amount,String category,String account,String note,String transferId){
        boolean transfer=type!=null&&type.startsWith("انتقال");
        if(transfer){
            if(transferId==null){new AlertDialog.Builder(this).setTitle("انتقال قدیمی").setMessage("این انتقال در نسخهٔ قدیمی ثبت شده و دو سمت آن به هم متصل نیستند. برای جلوگیری از خراب‌شدن ماندهٔ حساب‌ها، حذف تکی آن از این صفحه غیرفعال است. اگر لازم است اصلاح شود، مبلغ را با یک انتقال معکوس جبران کن.").setPositiveButton("متوجه شدم",null).show();return;}
            new AlertDialog.Builder(this).setTitle("مدیریت انتقال").setMessage("هر دو سمت این انتقال با هم حذف می‌شوند.").setNegativeButton("بازگشت",null).setPositiveButton("حذف انتقال",(d,w)->new AlertDialog.Builder(this).setTitle("تأیید حذف").setMessage("حذف انتقال قابل بازگشت نیست. ادامه می‌دهی؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("transactions","book=? AND transfer_id=?",new String[]{activeBook,transferId});toast("هر دو سمت انتقال حذف شدند");showTransactions();}).show()).show();
            return;
        }
        String[] options={"ویرایش تراکنش","حذف تراکنش"};new AlertDialog.Builder(this).setTitle("مدیریت تراکنش").setItems(options,(d,which)->{if(which==0)editTransaction(id,type,amount,category,account,note);else new AlertDialog.Builder(this).setTitle("حذف تراکنش").setMessage("این تراکنش حذف شود؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("transactions","id=? AND book=?",new String[]{String.valueOf(id),activeBook});toast("تراکنش حذف شد");showTransactions();}).show();}).show();
    }
    private void editTransaction(long id,String type,long amount,String category,String account,String note){
        LinearLayout f=formLayout();EditText a=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER),nt=edit("شرح",InputType.TYPE_CLASS_TEXT);AutoCompleteTextView acc=accountInput("حساب"),cat=categoryInput(type.equals("هزینه")?"هزینه":"درآمد","دسته‌بندی");a.setText(String.valueOf(amount));cat.setText(category);acc.setText(account);nt.setText(note==null?"":note);f.addView(a);f.addView(cat);f.addView(acc);f.addView(nt);
        new AlertDialog.Builder(this).setTitle("ویرایش تراکنش").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{long value=parseAmount(a.getText().toString());String accountName=acc.getText().toString().trim();if(value<=0||accountName.isEmpty()){toast("مبلغ و حساب معتبر وارد کن");return;}ensureAccount(accountName);saveCategoryIfMissing(type,cat.getText().toString().trim());ContentValues v=new ContentValues();v.put("amount",value);v.put("category",cat.getText().toString().trim());v.put("account",accountName);v.put("note",nt.getText().toString());db.getWritableDatabase().update("transactions",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});toast("تراکنش ویرایش شد");showTransactions();}).show();
    }
    private void showRecentIntoBody() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT t.type,t.amount,t.category,t.account,t.payment_method,t.book FROM transactions t WHERE t.book=? ORDER BY t.date DESC LIMIT 5",new String[]{activeBook});
        if(!c.moveToFirst()){addEmpty("هنوز تراکنشی ثبت نشده است.");c.close();return;}
        do { String t=c.getString(0); long a=c.getLong(1); String cat=c.getString(2),acc=c.getString(3),payment=c.isNull(4)?"متفرقه":c.getString(4),sourceBook=c.getString(5);
            TextView v=text(cat+"  •  "+money(a)+"\n"+t+" | "+acc+"\nدفتر ثبت‌کننده: "+sourceBook+"\nروش پرداخت: "+payment,14,TEXT,false);v.setPadding(dp(10),dp(10),dp(10),dp(10));v.setBackground(roundBg(Color.WHITE));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);
        }while(c.moveToNext());c.close();
    }
    private void addAccountBalancesIntoBody() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,opening,bank_name,card_last4 FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز حسابی تعریف نشده است.");return;}
        do {
            String name=c.getString(0),kind=c.getString(1);long opening=c.getLong(2);
            long bal=accountBalance(name);
            TextView v=text(name+" • "+(kind==null?"حساب":kind)+"\n"+money(bal),14,bal<0?Color.rgb(204,103,112):GREEN,true);v.setPadding(dp(12),dp(10),dp(12),dp(10));v.setBackground(roundBg(Color.WHITE));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);
        }while(c.moveToNext());c.close();
    }

    private String accountUid(String book,String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT account_uid FROM accounts WHERE book=? AND name=?",new String[]{book,name});String uid=null;if(c.moveToFirst())uid=c.getString(0);c.close();return uid;
    }

    private long accountBalance(String name) {
        // فقط account_uid که کاربر صریحاً بین دفترها به اشتراک گذاشته، هویت مشترک حساب است.
        // بانک + چهار رقم آخر کارت شناسه یکتا نیست و نباید باعث ادغام دو حساب شود.
        String uid=accountUid(activeBook,name);
        if(uid==null||uid.trim().isEmpty())return accountBalanceForBook(activeBook,name);
        long total=0;
        Cursor opening=db.getReadableDatabase().rawQuery(
            "SELECT COALESCE(MAX(opening),0) FROM accounts WHERE account_uid=?",new String[]{uid});
        if(opening.moveToFirst())total=opening.getLong(0);opening.close();
        Cursor tx=db.getReadableDatabase().rawQuery(
            "SELECT t.type,t.amount FROM transactions t WHERE EXISTS (SELECT 1 FROM accounts a WHERE a.book=t.book AND a.name=t.account AND a.account_uid=?)",
            new String[]{uid});
        while(tx.moveToNext()){
            String type=tx.getString(0);long amount=tx.getLong(1);
            if("درآمد".equals(type)||"انتقال ورودی".equals(type))total+=amount;
            else if("هزینه".equals(type)||"انتقال خروجی".equals(type))total-=amount;
        }
        tx.close();return total;
    }
    private long accountBalanceForBook(String book,String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(opening,0) FROM accounts WHERE book=? AND name=?",new String[]{book,name});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();
        Cursor t=db.getReadableDatabase().rawQuery("SELECT type,amount FROM transactions WHERE book=? AND account=?",new String[]{book,name});while(t.moveToNext()){String ty=t.getString(0);long a=t.getLong(1);if(ty.equals("درآمد")||ty.equals("انتقال ورودی"))n+=a;else if(ty.equals("هزینه")||ty.equals("انتقال خروجی"))n-=a;}t.close();return n;
    }

    private void manageAccountLinks(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,enabled FROM accounts WHERE book=? ORDER BY id",new String[]{activeBook});java.util.ArrayList<String> labels=new java.util.ArrayList<>();java.util.ArrayList<String> names=new java.util.ArrayList<>();java.util.ArrayList<Integer> enabled=new java.util.ArrayList<>();while(c.moveToNext()){names.add(c.getString(0));enabled.add(c.getInt(1));labels.add(c.getString(0)+(c.getInt(1)==1?" • فعال":" • غیرفعال"));}c.close();
        labels.add("＋ افزودن حساب بانکی موجود از دفتر دیگر");String[] opts=labels.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("مدیریت حساب‌ها در دفتر «"+activeBook+"»").setItems(opts,(d,w)->{if(w==opts.length-1){shareExistingAccountToThisBook();return;}String n=names.get(w);if(enabled.get(w)==1){new AlertDialog.Builder(this).setTitle("غیرفعال‌سازی حساب").setMessage("حساب از فهرست عادی این دفتر پنهان شود؟ سوابق و گردش حساب حفظ می‌شود.").setNegativeButton("لغو",null).setPositiveButton("غیرفعال کن",(x,y)->{ContentValues v=new ContentValues();v.put("enabled",0);db.getWritableDatabase().update("accounts",v,"book=? AND name=?",new String[]{activeBook,n});showAccounts();}).show();}else{ContentValues v=new ContentValues();v.put("enabled",1);db.getWritableDatabase().update("accounts",v,"book=? AND name=?",new String[]{activeBook,n});showAccounts();}}).setNegativeButton("بستن",null).show();
    }
    private void manageSpecificAccount(String name){
        String uid=accountUid(activeBook,name);int linkedCount=0;
        if(uid!=null){Cursor linked=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM accounts WHERE account_uid=?",new String[]{uid});if(linked.moveToFirst())linkedCount=linked.getInt(0);linked.close();}
        java.util.ArrayList<String> opts=new java.util.ArrayList<>();opts.add("غیرفعال کردن در این دفتر");opts.add("فعال کردن در این دفتر");opts.add("افزودن همین حساب به دفتر دیگر");if(linkedCount>1)opts.add("جدا کردن این حساب از حساب‌های مشترک");
        String[] items=opts.toArray(new String[0]);new AlertDialog.Builder(this).setTitle(name).setItems(items,(d,w)->{
            if(w==0||w==1){ContentValues v=new ContentValues();v.put("enabled",w==1?1:0);db.getWritableDatabase().update("accounts",v,"book=? AND name=?",new String[]{activeBook,name});showAccounts();}
            else if(w==2)shareSpecificAccount(name);else separateAccountFromSharedGroup(name);
        }).show();
    }
    private void separateAccountFromSharedGroup(String name){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,COALESCE(account_uid,''),COALESCE(opening,0) FROM accounts WHERE book=? AND name=? LIMIT 1",new String[]{activeBook,name});
        if(!c.moveToFirst()){c.close();toast("حساب پیدا نشد");return;}
        long id=c.getLong(0),openingValue=c.getLong(2);String uid=c.getString(1);c.close();
        if(uid.isEmpty()){toast("این حساب از قبل مستقل است.");return;}
        Cursor group=db.getReadableDatabase().rawQuery("SELECT COUNT(*),COALESCE(MAX(opening),0) FROM accounts WHERE account_uid=?",new String[]{uid});int count=0;long maxOpening=0;if(group.moveToFirst()){count=group.getInt(0);maxOpening=group.getLong(1);}group.close();
        if(count<2){toast("این حساب پیوند مشترک دیگری ندارد.");return;}
        if(maxOpening>0&&openingValue>=maxOpening){new AlertDialog.Builder(this).setTitle("جدا کردن حساب اصلی").setMessage("این ردیف موجودی اولیه اصلی گروه مشترک را در خود دارد. برای جلوگیری از صفر شدن اشتباه موجودی حساب‌های باقی‌مانده، ابتدا یکی از حساب‌های متصل با موجودی اولیه صفر را از دفتر خودش جدا کن.").setPositiveButton("متوجه شدم",null).show();return;}
        LinearLayout form=formLayout();EditText opening=edit("موجودی اولیه این حساب پس از جداسازی (ریال)",InputType.TYPE_CLASS_NUMBER);opening.setText(String.valueOf(openingValue));form.addView(text("پس از جداسازی، فقط تراکنش‌های همین حساب در دفتر فعلی در مانده آن محاسبه می‌شود. حساب‌های دیگر و گردش آن‌ها دست‌نخورده می‌مانند.",13,TEXT,false));form.addView(opening);
        new AlertDialog.Builder(this).setTitle("جدا کردن حساب مشترک").setView(form).setNegativeButton("انصراف",null).setPositiveButton("جدا کن",(d,w)->{
            long newOpening=parseAmount(opening.getText().toString());if(newOpening<0){toast("موجودی اولیه معتبر نیست");return;}
            ContentValues v=new ContentValues();v.put("account_uid",java.util.UUID.randomUUID().toString());v.put("opening",newOpening);
            int updated=db.getWritableDatabase().update("accounts",v,"id=? AND book=? AND account_uid=?",new String[]{String.valueOf(id),activeBook,uid});
            if(updated==1){toast("حساب از اشتراک جدا شد؛ مانده آن اکنون مستقل محاسبه می‌شود.");showAccounts();}else toast("جداسازی انجام نشد؛ اطلاعات حساب تغییر کرده است.");
        }).show();
    }
    private void shareSpecificAccount(String name){
        String uid=accountUid(activeBook,name);if(uid==null){toast("شناسه حساب پیدا نشد");return;}Cursor b=db.getReadableDatabase().rawQuery("SELECT name FROM books WHERE name<>? ORDER BY id",new String[]{activeBook});java.util.ArrayList<String> books=new java.util.ArrayList<>();while(b.moveToNext())books.add(b.getString(0));b.close();if(books.isEmpty()){toast("ابتدا یک دفتر دیگر ایجاد کن");return;}String[] arr=books.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("افزودن حساب به کدام دفتر؟").setItems(arr,(d,w)->linkAccountToBook(uid,name,arr[w])).setNegativeButton("لغو",null).show();
    }
    private void shareExistingAccountToThisBook(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT a.name,a.account_uid,b.name FROM accounts a JOIN books b ON b.name=a.book WHERE a.book<>? AND a.enabled=1 ORDER BY b.name,a.name",new String[]{activeBook});java.util.ArrayList<String> labels=new java.util.ArrayList<>(),uids=new java.util.ArrayList<>(),names=new java.util.ArrayList<>();while(c.moveToNext()){String n=c.getString(0),u=c.getString(1),b=c.getString(2);if(u!=null){labels.add(n+" • دفتر "+b);uids.add(u);names.add(n);}}c.close();if(labels.isEmpty()){toast("حساب فعالی در دفترهای دیگر پیدا نشد");return;}new AlertDialog.Builder(this).setTitle("انتخاب حساب موجود").setItems(labels.toArray(new String[0]),(d,w)->linkAccountToBook(uids.get(w),names.get(w),activeBook)).setNegativeButton("لغو",null).show();
    }
    private void linkAccountToBook(String uid,String name,String targetBook){
        Cursor src=db.getReadableDatabase().rawQuery("SELECT kind,bank_name,card_last4 FROM accounts WHERE account_uid=? ORDER BY id LIMIT 1",new String[]{uid});if(!src.moveToFirst()){src.close();toast("حساب پیدا نشد");return;}String kind=src.getString(0),bank=src.getString(1),last4=src.getString(2);src.close();Cursor ex=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND account_uid=?",new String[]{targetBook,uid});boolean exists=ex.moveToFirst();ex.close();if(exists){toast("این حساب از قبل در آن دفتر وجود دارد");return;}Cursor same=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{targetBook,name});boolean nameExists=same.moveToFirst();same.close();if(nameExists){toast("در دفتر مقصد حسابی با همین نام وجود دارد؛ ابتدا نام آن را تغییر بده");return;}ContentValues v=new ContentValues();v.put("book",targetBook);v.put("name",name);v.put("kind",kind);v.put("opening",0);v.put("bank_name",bank);v.put("card_last4",last4);v.put("account_uid",uid);v.put("enabled",1);v.put("created_at",System.currentTimeMillis());db.getWritableDatabase().insertOrThrow("accounts",null,v);toast("حساب در دفتر «"+targetBook+"» فعال شد؛ موجودی اولیه دوباره ثبت نشد");if(targetBook.equals(activeBook))showAccounts();
    }

    private void showAccountTransactions(String accountName) {
        setHeaderInfo("گردش حساب", "فقط تراکنش‌های دفتر «"+activeBook+"»؛ ماندهٔ حساب مشترک است"); body.removeAllViews(); addHeading("گردش حساب: "+accountName+" • دفتر "+activeBook); addEmpty("فقط تراکنش‌های همین دفتر نمایش داده می‌شود. ماندهٔ حساب مشترک، تغییرات همهٔ دفترهای متصل را در نظر می‌گیرد.");
        String uid=accountUid(activeBook,accountName);
        Cursor c;
        if(uid==null)c=db.getReadableDatabase().rawQuery("SELECT type,amount,category,note,date,book FROM transactions WHERE book=? AND account=? ORDER BY date DESC",new String[]{activeBook,accountName});
        else c=db.getReadableDatabase().rawQuery("SELECT t.type,t.amount,t.category,t.note,t.date,t.book FROM transactions t JOIN accounts a ON a.book=t.book AND a.name=t.account WHERE a.account_uid=? AND t.book=? ORDER BY t.date DESC",new String[]{uid,activeBook});
        long income=0,expense=0,transferIn=0,transferOut=0; java.util.ArrayList<String> rows=new java.util.ArrayList<>();
        while(c.moveToNext()){String type=c.getString(0),cat=c.getString(2),note=c.getString(3),txBook=c.getString(5);long amount=c.getLong(1),date=c.getLong(4);
            if("درآمد".equals(type))income+=amount;else if("هزینه".equals(type))expense+=amount;else if("انتقال ورودی".equals(type))transferIn+=amount;else if("انتقال خروجی".equals(type))transferOut+=amount;
            rows.add(jalaliDate(date)+" • دفتر: "+txBook+" • "+type+" • "+(cat==null?"":cat)+" • "+money(amount)+(note==null||note.isEmpty()?"":"\n"+note));
        } c.close();
        addMetric("جمع درآمد",money(income),GREEN);addMetric("جمع هزینه",money(expense),Color.rgb(204,103,112));addMetric("انتقال ورودی",money(transferIn),GREEN);addMetric("انتقال خروجی",money(transferOut),Color.rgb(204,103,112));addMetric("جمع خالص گردش (بدون موجودی اولیه)",money(income-expense+transferIn-transferOut),TEXT);
        addHeading("ریز تراکنش‌ها");if(rows.isEmpty())addEmpty("برای این حساب تراکنشی ثبت نشده است.");else for(String row:rows){TextView v=text(row,14,TEXT,false);v.setPadding(dp(10),dp(9),dp(10),dp(9));v.setBackground(roundBg(Color.WHITE));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);}
        addWideButton("بازگشت به حساب‌ها",()->showAccounts());
    }

    private void showAccounts() {
        setHeaderInfo("حساب‌ها و موجودی", "موجودی اولیه و ماندهٔ فعلی هر حساب را بررسی کنید");
        body.removeAllViews();addHeading("حساب‌ها و ماندهٔ هر حساب");addEmpty("جمع کل موجودی بانک‌ها: "+money(bankBalance()));addWideButton("＋ حساب جدید",()->addAccountDialog());addWideButton("مدیریت حساب‌های غیرفعال و اشتراک حساب بین دفترها",()->manageAccountLinks());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,opening,bank_name,card_last4 FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("حسابی ثبت نشده است.");return;}
        do{String name=c.getString(0),kind=c.getString(1),bank=c.getString(3),last4=c.getString(4);long opening=c.getLong(2);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(roundBg(Color.WHITE));card.addView(text(name+" • "+kind+(bank!=null&&!bank.isEmpty()?" • بانک "+bank:"")+(last4!=null&&!last4.isEmpty()?" • "+last4:""),15,TEXT,true));card.addView(text("موجودی اولیه: "+money(opening),12,Color.rgb(86, 99, 91),false));card.addView(text("مانده فعلی: "+money(accountBalance(name)),18,GREEN,true));card.addView(text("برای مشاهده گردش حساب لمس کنید",12,DARK,false));card.setOnClickListener(v->showAccountTransactions(name));Button edit=button("ویرایش حساب");edit.setOnClickListener(v->editAccountDialog(name));card.addView(edit);Button manage=button("مدیریت این حساب در دفترها");manage.setOnClickListener(v->manageSpecificAccount(name));card.addView(manage);body.addView(card,new LinearLayout.LayoutParams(-1,-2));}while(c.moveToNext());c.close();
    }

    private AutoCompleteTextView accountInput(String hint) {
        AutoCompleteTextView input=new AutoCompleteTextView(this);input.setHint(hint);input.setHintTextColor(Color.rgb(120,130,140));input.setTextColor(TEXT);input.setTextSize(15);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT);input.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);input.setPadding(dp(14),dp(10),dp(14),dp(10));input.setMinHeight(dp(52));input.setBackground(inputFieldBg());input.setDropDownBackgroundDrawable(roundBg(Color.WHITE));input.setDropDownVerticalOffset(dp(4));input.setOnClickListener(v->{if(input.getAdapter()!=null&&input.getAdapter().getCount()>0)input.showDropDown();});input.setOnFocusChangeListener((v,hasFocus)->{if(hasFocus&&input.getAdapter()!=null&&input.getAdapter().getCount()>0)input.post(input::showDropDown);});
        java.util.ArrayList<String> names=new java.util.ArrayList<>();Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});while(c.moveToNext())names.add(c.getString(0));c.close();
        input.setAdapter(dropdownAdapter(names));input.setThreshold(0);return input;
    }

    private AutoCompleteTextView categoryInput(String type,String hint) {
        AutoCompleteTextView input=new AutoCompleteTextView(this);input.setHint(hint);input.setHintTextColor(Color.rgb(120,130,140));input.setTextColor(TEXT);input.setTextSize(15);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT);input.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);input.setPadding(dp(14),dp(10),dp(14),dp(10));input.setMinHeight(dp(52));input.setBackground(inputFieldBg());input.setDropDownBackgroundDrawable(roundBg(Color.WHITE));input.setDropDownVerticalOffset(dp(4));input.setOnClickListener(v->{if(input.getAdapter()!=null&&input.getAdapter().getCount()>0)input.showDropDown();});input.setOnFocusChangeListener((v,hasFocus)->{if(hasFocus&&input.getAdapter()!=null&&input.getAdapter().getCount()>0)input.post(input::showDropDown);});
        java.util.ArrayList<String> names=new java.util.ArrayList<>();Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM categories WHERE type=? ORDER BY name",new String[]{type});while(c.moveToNext())names.add(c.getString(0));c.close();
        Cursor tx=db.getReadableDatabase().rawQuery("SELECT DISTINCT category FROM transactions WHERE book=? AND type=? AND category IS NOT NULL ORDER BY category",new String[]{activeBook,type});while(tx.moveToNext()){String n=tx.getString(0);if(n!=null&&!names.contains(n))names.add(n);}tx.close();
        input.setAdapter(dropdownAdapter(names));input.setThreshold(0);return input;
    }

    private void saveCategoryIfMissing(String type,String name) {
        if(name==null||name.trim().isEmpty())return;Cursor c=db.getReadableDatabase().rawQuery("SELECT id FROM categories WHERE type=? AND name=?",new String[]{type,name.trim()});boolean found=c.moveToFirst();c.close();if(!found){ContentValues v=new ContentValues();v.put("type",type);v.put("name",name.trim());db.getWritableDatabase().insert("categories",null,v);}
    }

    private void manageCategories() {
        setHeaderInfo("دسته‌بندی‌ها", "دسته‌بندی‌های درآمد و هزینه را مدیریت کنید");
        body.removeAllViews();addHeading("دسته‌بندی‌های درآمد و هزینه");addWideButton("＋ دسته‌بندی درآمد",()->categoryDialog("درآمد"));addWideButton("＋ دسته‌بندی هزینه",()->categoryDialog("هزینه"));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,type,name FROM categories ORDER BY type,name",null);if(!c.moveToFirst()){c.close();addEmpty("دسته‌بندی‌ای وجود ندارد.");return;}
        do{long id=c.getLong(0);String type=c.getString(1),name=c.getString(2);TextView row=text(type+" • "+name+"   (برای حذف لمس کن)",14,TEXT,false);row.setPadding(dp(12),dp(12),dp(12),dp(12));row.setBackground(roundBg(Color.WHITE));body.addView(row,new LinearLayout.LayoutParams(-1,-2));row.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف دسته‌بندی").setMessage("فقط دسته‌بندی حذف می‌شود؛ تراکنش‌های قبلی باقی می‌مانند.").setNegativeButton("انصراف",null).setPositiveButton("حذف",(d,w)->{db.getWritableDatabase().delete("categories","id=?",new String[]{String.valueOf(id)});manageCategories();}).show());}while(c.moveToNext());c.close();
    }

    private void categoryDialog(String type) {
        EditText name=edit("نام دسته‌بندی جدید",InputType.TYPE_CLASS_TEXT);new AlertDialog.Builder(this).setTitle("دسته‌بندی "+type).setView(name).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty()){toast("نام دسته‌بندی را وارد کن");return;}saveCategoryIfMissing(type,n);manageCategories();}).show();
    }

    private void showRecurring() {
        setHeaderInfo("پرداخت‌های تکرارشونده", "سررسیدها را بررسی و مورد لازم را ثبت کنید");
        body.removeAllViews();addHeading("پرداخت‌های تکرارشونده و سررسیدها");addEmpty("این بخش برای قبض‌ها، اجاره، اقساط، حقوق و درآمدهای تکراری است. ثبت هر سررسید با تأیید شما انجام می‌شود.");addWideButton("＋ تعریف مورد تکرارشونده",()->recurringDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,type,amount,category,account,frequency,next_due FROM recurring WHERE book=? ORDER BY next_due",new String[]{activeBook});if(!c.moveToFirst()){c.close();addEmpty("مورد تکرارشونده‌ای تعریف نشده است.");return;}
        do{long id=c.getLong(0),amount=c.getLong(3),due=c.getLong(7);String name=c.getString(1),type=c.getString(2),cat=c.getString(4),acc=c.getString(5),freq=c.getString(6);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(name+" • "+type,15,TEXT,true));card.addView(text(money(amount)+" | "+freq+" | سررسید: "+jalaliDate(due),13,Color.rgb(86, 99, 91),false));Button post=button("ثبت این سررسید در حساب‌ها");card.addView(post);post.setOnClickListener(v->postRecurring(id,name,type,amount,cat,acc,freq,due));Button del=button("حذف مورد تکرارشونده");card.addView(del);del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("این مورد از فهرست تکرارشونده حذف شود؟ تراکنش‌های قبلی حذف نمی‌شوند.").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("recurring","id=? AND book=?",new String[]{String.valueOf(id),activeBook});showRecurring();}).show());body.addView(card,new LinearLayout.LayoutParams(-1,-2));}while(c.moveToNext());c.close();
    }

    private void recurringDialog() {
        LinearLayout f=formLayout();EditText name=edit("عنوان (مثلاً اجاره خانه)",InputType.TYPE_CLASS_TEXT);Spinner type=styledSpinner();type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"هزینه","درآمد"}));EditText amount=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER);AutoCompleteTextView cat=categoryInput("هزینه","دسته‌بندی");AutoCompleteTextView account=accountInput("حساب (مثلاً پول نقد)");Spinner freq=styledSpinner();freq.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"ماهانه","هفتگی","سالانه"}));Calendar firstDue=Calendar.getInstance();Button dueButton=button("اولین سررسید: "+jalaliDate(firstDue.getTimeInMillis()));dueButton.setOnClickListener(v->{Calendar cur=(Calendar)firstDue.clone();new DatePickerDialog(this,(view,year,month,day)->{firstDue.set(Calendar.YEAR,year);firstDue.set(Calendar.MONTH,month);firstDue.set(Calendar.DAY_OF_MONTH,day);firstDue.set(Calendar.HOUR_OF_DAY,12);firstDue.set(Calendar.MINUTE,0);firstDue.set(Calendar.SECOND,0);dueButton.setText("اولین سررسید: "+jalaliDate(firstDue.getTimeInMillis()));},cur.get(Calendar.YEAR),cur.get(Calendar.MONTH),cur.get(Calendar.DAY_OF_MONTH)).show();});f.addView(name);f.addView(type);f.addView(amount);f.addView(cat);f.addView(account);f.addView(freq);f.addView(dueButton);
        new AlertDialog.Builder(this).setTitle("تعریف مورد تکرارشونده").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim(),a=account.getText().toString().trim();long val=parseAmount(amount.getText().toString());if(n.isEmpty()||val<=0){toast("عنوان و مبلغ معتبر وارد کن");return;}if(a.isEmpty())a="پول نقد";ensureAccount(a);String ty=type.getSelectedItem().toString(),category=cat.getText().toString().trim();if(category.isEmpty())category="سایر";saveCategoryIfMissing(ty,category);ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("type",ty);v.put("amount",val);v.put("category",category);v.put("account",a);v.put("frequency",freq.getSelectedItem().toString());v.put("next_due",firstDue.getTimeInMillis());db.getWritableDatabase().insert("recurring",null,v);showRecurring();}).show();
    }

    private void postRecurring(long id,String name,String type,long amount,String category,String account,String frequency,long due) {
        new AlertDialog.Builder(this).setTitle("ثبت سررسید").setMessage("مورد «"+name+"» به‌عنوان تراکنش "+type+" به مبلغ "+money(amount)+" ثبت شود؟").setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{SQLiteDatabase sql=db.getWritableDatabase();sql.beginTransaction();try{ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",type);tx.put("amount",amount);tx.put("category",category);tx.put("account",account);tx.put("note","ثبت از سررسید تکرارشونده: "+name);tx.put("date",System.currentTimeMillis());setMonthKey(tx,System.currentTimeMillis());sql.insertOrThrow("transactions",null,tx);Calendar cal=Calendar.getInstance();cal.setTimeInMillis(Math.max(due,System.currentTimeMillis()));if(frequency.equals("هفتگی"))cal.add(Calendar.DAY_OF_YEAR,7);else if(frequency.equals("سالانه"))cal.add(Calendar.YEAR,1);else cal.add(Calendar.MONTH,1);ContentValues upd=new ContentValues();upd.put("next_due",cal.getTimeInMillis());sql.update("recurring",upd,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});sql.setTransactionSuccessful();toast("سررسید ثبت شد");}catch(Exception e){toast("ثبت سررسید انجام نشد");}finally{sql.endTransaction();}showRecurring();}).show();
    }

    private void showGoals() {
        setHeaderInfo("هدف‌های پس‌انداز", "میزان پیشرفت هر هدف را پیگیری کنید");
        body.removeAllViews();addHeading("هدف‌های پس‌انداز");addEmpty("هدف‌ها برای پیگیری پیشرفت پس‌انداز هستند؛ واریز به هدف به‌تنهایی موجودی حساب را تغییر نمی‌دهد. برای جابه‌جایی واقعی پول از «انتقال بین حساب‌ها» استفاده کن.");addWideButton("＋ هدف جدید",()->goalDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,target,current_amount,deadline,note FROM goals WHERE book=? ORDER BY id DESC",new String[]{activeBook});if(!c.moveToFirst()){c.close();addEmpty("هنوز هدفی تعریف نشده است.");return;}
        do{long id=c.getLong(0),target=c.getLong(2),current=c.getLong(3),deadline=c.getLong(4);String name=c.getString(1),note=c.getString(5);int pct=target<=0?0:(int)Math.min(100,current*100.0/target);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(name,16,TEXT,true));card.addView(text("پس‌انداز: "+money(current)+" از "+money(target),13,Color.rgb(86, 99, 91),false));ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(pct);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(8)));card.addView(text(pct+"٪ پیشرفت"+(deadline>0?" • موعد: "+jalaliDate(deadline):""),12,GREEN,false));if(note!=null&&!note.isEmpty())card.addView(text(note,12,Color.rgb(86, 99, 91),false));Button add=button("ثبت مبلغ پس‌اندازشده");card.addView(add);add.setOnClickListener(v->contributeGoal(id,name,target,current));body.addView(card,new LinearLayout.LayoutParams(-1,-2));}while(c.moveToNext());c.close();
    }

    private void goalDialog() {
        LinearLayout f=formLayout();EditText name=edit("عنوان هدف (مثلاً خرید خودرو)",InputType.TYPE_CLASS_TEXT),target=edit("مبلغ هدف به ریال",InputType.TYPE_CLASS_NUMBER),note=edit("یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);f.addView(name);f.addView(target);f.addView(note);new AlertDialog.Builder(this).setTitle("هدف پس‌انداز جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();long t=parseAmount(target.getText().toString());if(n.isEmpty()||t<=0){toast("عنوان و مبلغ هدف معتبر وارد کن");return;}ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("target",t);v.put("current_amount",0);v.put("deadline",0);v.put("note",note.getText().toString());db.getWritableDatabase().insert("goals",null,v);showGoals();}).show();
    }

    private void contributeGoal(long id,String name,long target,long current) {
        EditText amount=edit("مبلغ جدید پس‌اندازشده به ریال",InputType.TYPE_CLASS_NUMBER);new AlertDialog.Builder(this).setTitle("به‌روزرسانی هدف «"+name+"»").setView(amount).setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{long a=parseAmount(amount.getText().toString());if(a<=0){toast("مبلغ باید بیشتر از صفر باشد");return;}ContentValues v=new ContentValues();v.put("current_amount",Math.min(target,current+a));db.getWritableDatabase().update("goals",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});showGoals();}).show();
    }

    private void exportTransactionsCsv() {
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"HisabYar-transactions.csv");startActivityForResult(i,703);
    }

    private void showAssets() {
        setHeaderInfo("دارایی‌ها", "ارزش دارایی‌ها و موارد ثبت‌شده را مدیریت کنید");
        body.removeAllViews(); addHeading("دارایی‌ها و ارزش خالص");
        Button add=button("＋ افزودن دارایی");body.addView(add);add.setOnClickListener(v->showAssetDialog());
        long total=0; Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,value,note FROM assets WHERE book=? ORDER BY name",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز دارایی ثبت نشده است.");return;}
        do {String name=c.getString(0),kind=c.getString(1),note=c.getString(3);long val=c.getLong(2);total+=val;
            LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setPadding(dp(12),dp(10),dp(12),dp(10));item.setBackground(roundBg(Color.WHITE));
            item.addView(text(name+" • "+kind,15,TEXT,true));item.addView(text(money(val),16,GREEN,true));if(note!=null&&!note.isEmpty())item.addView(text(note,12,Color.rgb(86, 99, 91),false));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        }while(c.moveToNext());c.close();
        addMetric("ارزش دارایی‌های ثبت‌شده",money(total),GREEN);
    }
    private void showAssetDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام دارایی",InputType.TYPE_CLASS_TEXT),kind=edit("نوع (طلا، خودرو، ملک و ...)",InputType.TYPE_CLASS_TEXT),value=edit("ارزش فعلی به ریال",InputType.TYPE_CLASS_NUMBER),note=edit("یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(name);f.addView(kind);f.addView(value);f.addView(note);
        new AlertDialog.Builder(this).setTitle("افزودن دارایی").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long val=parseAmount(value.getText().toString());if(name.getText().toString().trim().isEmpty()||val<0){toast("نام و ارزش دارایی را بررسی کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name.getText().toString().trim());v.put("kind",kind.getText().toString().trim());v.put("value",val);v.put("note",note.getText().toString());db.getWritableDatabase().insert("assets",null,v);navigate("دارایی‌ها");
        }).show();
    }
    private String sqlAsciiDigits(String column) {
        String x=column;
        String[] fa={"۰","۱","۲","۳","۴","۵","۶","۷","۸","۹","٠","١","٢","٣","٤","٥","٦","٧","٨","٩"};
        for(int i=0;i<10;i++){x="REPLACE("+x+",'"+fa[i]+"','"+i+"')";x="REPLACE("+x+",'"+fa[i+10]+"','"+i+"')";}
        return x;
    }
    private String normalizeChequeQuery(String q) {
        String x=normalizeDigits(q==null?"":q).trim();
        return x.replace(",","").replace("٬","").replace(" ","");
    }

    private void showCheques() {
        setHeaderInfo("دریافت و پرداخت چک", "جست‌وجو، فیلتر تاریخ، مرتب‌سازی و خروجی CSV؛ داده‌ها محلی هستند");
        body.removeAllViews(); addHeading("مدیریت چک‌ها");
        addWideButton("＋ ثبت چک دریافتی", () -> showChequeDialog("دریافتی"));
        addWideButton("＋ ثبت چک پرداختی", () -> showChequeDialog("پرداختی"));
        addWideButton("📦 بایگانی چک‌های پاس‌شده، واریزشده و برگشتی", () -> showChequeArchive());
        EditText query=edit("جست‌وجو: شماره، پرداخت‌کننده، بانک، مبلغ، توضیحات…",InputType.TYPE_CLASS_TEXT);
        EditText dateFrom=edit("از تاریخ (اختیاری؛ مثلاً ۱۴۰۵/۰۷/۰۱)",InputType.TYPE_CLASS_TEXT);
        EditText dateTo=edit("تا تاریخ (اختیاری؛ مثلاً ۱۴۰۵/۰۸/۳۰)",InputType.TYPE_CLASS_TEXT);
        body.addView(query);body.addView(dateFrom);body.addView(dateTo);
        Spinner filter=styledSpinner(); filter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"همه چک‌های فعال","دریافتی","پرداختی","باز / در انتظار","خروج‌شده","لغوشده"})); body.addView(filter);
        Spinner sort=styledSpinner();sort.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"تاریخ: قدیمی به جدید","تاریخ: جدید به قدیمی","مبلغ: کم به زیاد","مبلغ: زیاد به کم"}));body.addView(sort);
        Button export=button("خروجی جدول CSV برای Excel");body.addView(export);
        TextView totalSummary=text("تعداد چک‌ها: ۰  •  جمع مبلغ: ۰ ریال",16,DARK,true); totalSummary.setPadding(dp(12),dp(12),dp(12),dp(12)); totalSummary.setBackground(roundBg(Color.rgb(237,247,241))); body.addView(totalSummary);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); body.addView(list);
        Runnable refresh=()->{
            list.removeAllViews(); String f=String.valueOf(filter.getSelectedItem());
            String where="book=? AND NOT ("+archivedChequeSql()+")"; java.util.ArrayList<String> args=new java.util.ArrayList<>(); args.add(activeBook);
            if("دریافتی".equals(f)||"پرداختی".equals(f)){where+=" AND direction=?";args.add(f);}
            else if("باز / در انتظار".equals(f)){where+=" AND status IN ('در انتظار وصول','در انتظار پرداخت','در جریان وصول','در جریان پرداخت')";}
            else if("خروج‌شده".equals(f)){where+=" AND status='خروج شد'";}
            else if("لغوشده".equals(f)){where+=" AND status='لغو شد'";}
            String q=query.getText().toString().trim(); if(!q.isEmpty()){String like="%"+q+"%";String nq=normalizeChequeQuery(q);String nlike="%"+nq+"%";where+=" AND (cheque_no LIKE ? OR bank LIKE ? OR party LIKE ? OR "+sqlAsciiDigits("CAST(amount AS TEXT)")+" LIKE ? OR "+sqlAsciiDigits("due_date").replace("/","/")+" LIKE ? OR account LIKE ? OR note LIKE ? OR status LIKE ? OR "+sqlAsciiDigits("cheque_no").replace("/","/")+" LIKE ?)";args.add(like);args.add(like);args.add(like);args.add(nlike);args.add(like);args.add(like);args.add(like);args.add(like);args.add(nlike);}
            String from=normalizeDigits(dateFrom.getText().toString().trim()),to=normalizeDigits(dateTo.getText().toString().trim());
            if(!from.isEmpty()){where+=" AND REPLACE(REPLACE("+sqlAsciiDigits("due_date")+",'/',''),'-','') >= REPLACE(REPLACE("+"?"+",'/',''),'-','')";args.add(from);}
            if(!to.isEmpty()){where+=" AND REPLACE(REPLACE("+sqlAsciiDigits("due_date")+",'/',''),'-','') <= REPLACE(REPLACE(?,'/',''),'-','')";args.add(to);}
            String order="due_date ASC,id DESC";int sp=sort.getSelectedItemPosition();if(sp==1)order="due_date DESC,id DESC";else if(sp==2)order="amount ASC,due_date ASC";else if(sp==3)order="amount DESC,due_date ASC";
            Cursor c=db.getReadableDatabase().rawQuery("SELECT id,direction,cheque_no,bank,party,amount,due_date,account,status,note,image_path,exit_recipient,exit_description FROM cheques WHERE "+where+" ORDER BY "+order,args.toArray(new String[0]));
            long resultCount=0,totalAmount=0; if(c.moveToFirst()){do{resultCount++;totalAmount+=c.getLong(5);}while(c.moveToNext());} totalSummary.setText("تعداد چک‌های منطبق: "+String.format(Locale.US,"%,d",resultCount)+"  •  جمع مبلغ: "+money(totalAmount)+" ریال"); if(resultCount==0){c.close();list.addView(text("چکی با این شرایط پیدا نشد.",14,TEXT,false));return;} c.moveToPosition(-1);
            while(c.moveToNext()){ long id=c.getLong(0),amount=c.getLong(5);String direction=c.getString(1),no=c.getString(2),bank=c.getString(3),party=c.getString(4),due=c.getString(6),account=c.getString(7),status=c.getString(8),note=c.getString(9),imagePath=c.getString(10),exitRecipient=c.getString(11),exitDescription=c.getString(12);
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));
                card.addView(text((direction.equals("دریافتی")?"⬇ چک دریافتی":"⬆ چک پرداختی")+" • "+(no==null||no.isEmpty()?"بدون شماره":"شماره "+no),16,TEXT,true));
                card.addView(text("بانک: "+safeCheque(bank)+" | طرف حساب: "+safeCheque(party),13,TEXT,false));
                card.addView(text("مبلغ: "+money(amount)+" ریال | سررسید: "+safeCheque(due),14,DARK,true));
                card.addView(text("وضعیت: "+status+" | حساب مرتبط: "+safeCheque(account),13,Color.rgb(86,99,91),false));
                if(note!=null&&!note.isEmpty())card.addView(text("شرح: "+note,12,TEXT,false));
                if("خروج شد".equals(status)){card.addView(text("تحویل‌گیرنده: "+safeCheque(exitRecipient),13,TEXT,false));if(exitDescription!=null&&!exitDescription.trim().isEmpty())card.addView(text("توضیحات خروج: "+exitDescription,13,TEXT,false));}
                if(imagePath!=null&&!imagePath.isEmpty()) {Button photo=button("مشاهده عکس چک");card.addView(photo);photo.setOnClickListener(v->{File fimg=new File(imagePath);if(!fimg.exists()){toast("فایل عکس پیدا نشد؛ ممکن است از حافظه حذف شده باشد.");return;}Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(Uri.fromFile(fimg),"image/*");view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(view);}catch(Exception ex){toast("برنامه‌ای برای نمایش عکس پیدا نشد.");}});}
                Button change=button("تغییر وضعیت / ثبت وصول یا پرداخت");card.addView(change);change.setOnClickListener(v->changeChequeStatus(id,direction,status,amount,account,party));
                Button edit=button("ویرایش مشخصات چک");card.addView(edit);edit.setOnClickListener(v->editCheque(id));
                Button del=button("حذف چک");card.addView(del);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف چک").setMessage("این چک از دفتر فعلی حذف شود؟ تراکنش مالی احتمالی که جداگانه ثبت شده حذف نمی‌شود.").setNegativeButton("انصراف",null).setPositiveButton("حذف",(d,w)->{db.getWritableDatabase().delete("cheques","id=? AND book=?",new String[]{String.valueOf(id),activeBook});showCheques();}).show());
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));list.addView(card,lp);
            }c.close();
        };
        android.text.TextWatcher watcher=new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(android.text.Editable e){}};
        query.addTextChangedListener(watcher);dateFrom.addTextChangedListener(watcher);dateTo.addTextChangedListener(watcher);
        filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){refresh.run();}public void onNothingSelected(android.widget.AdapterView<?> a){}});
        sort.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){refresh.run();}public void onNothingSelected(android.widget.AdapterView<?> a){}});
        export.setOnClickListener(v->{pendingChequeCsv=buildChequeCsv(String.valueOf(filter.getSelectedItem()),query.getText().toString().trim(),normalizeDigits(dateFrom.getText().toString().trim()),normalizeDigits(dateTo.getText().toString().trim()),sort.getSelectedItemPosition());Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"HisabYar_Cheques.csv");startActivityForResult(i,REQ_CHEQUE_EXPORT);});
        refresh.run();
    }
    private boolean isArchivedChequeStatus(String status) {
        if(status==null)return false;
        String x=status.trim().replace("ي","ی").replace("ك","ک");
        return x.equals("پاس شد")||x.equals("واریز به حساب")||x.equals("برگشت")||x.equals("برگشتی")||x.equals("برگشت خورد")||x.equals("برگشت شد")||x.equals("وصول شد")||x.equals("پرداخت شد");
    }
    private String archivedChequeSql() {
        return "status IN ('پاس شد','واریز به حساب','برگشت','برگشتی','برگشت خورد','برگشت شد','وصول شد','پرداخت شد')";
    }
    private void showChequeArchive() {
        setHeaderInfo("بایگانی چک‌ها", "چک‌های پاس‌شده، واریزشده و برگشتی؛ اطلاعات بدون حذف نگهداری می‌شوند");
        body.removeAllViews();addHeading("بایگانی چک‌ها");
        addWideButton("← بازگشت به فهرست چک‌های فعال",()->showCheques());
        EditText query=edit("جست‌وجوی شماره چک، بانک، طرف حساب یا مبلغ",InputType.TYPE_CLASS_TEXT);body.addView(query);
        Spinner filter=styledSpinner();filter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"همه موارد بایگانی","پاس‌شده / وصول‌شده","واریز به حساب","برگشتی"}));body.addView(filter);
        TextView summary=text("تعداد: ۰  •  جمع مبلغ: ۰ ریال",15,DARK,true);summary.setPadding(dp(12),dp(10),dp(12),dp(10));body.addView(summary);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{
            list.removeAllViews();String where="book=? AND ("+archivedChequeSql()+")";java.util.ArrayList<String> args=new java.util.ArrayList<>();args.add(activeBook);
            String f=String.valueOf(filter.getSelectedItem());
            if("پاس‌شده / وصول‌شده".equals(f))where+=" AND status IN ('پاس شد','وصول شد','پرداخت شد')";
            else if("واریز به حساب".equals(f))where+=" AND status='واریز به حساب'";
            else if("برگشتی".equals(f))where+=" AND status IN ('برگشت','برگشتی','برگشت خورد','برگشت شد')";
            String q=query.getText().toString().trim();if(!q.isEmpty()){String like="%"+q+"%";String nq=normalizeChequeQuery(q),nlike="%"+nq+"%";where+=" AND (cheque_no LIKE ? OR bank LIKE ? OR party LIKE ? OR "+sqlAsciiDigits("CAST(amount AS TEXT)")+" LIKE ? OR due_date LIKE ? OR account LIKE ? OR note LIKE ? OR status LIKE ? OR "+sqlAsciiDigits("cheque_no")+" LIKE ?)";args.add(like);args.add(like);args.add(like);args.add(nlike);args.add(like);args.add(like);args.add(like);args.add(like);args.add(nlike);}
            Cursor c=db.getReadableDatabase().rawQuery("SELECT id,direction,cheque_no,bank,party,amount,due_date,account,status,note,image_path,exit_recipient,exit_description FROM cheques WHERE "+where+" ORDER BY updated_at DESC,id DESC",args.toArray(new String[0]));
            long count=0,total=0;if(c.moveToFirst()){do{count++;total+=c.getLong(5);}while(c.moveToNext());}summary.setText("تعداد چک‌های بایگانی: "+String.format(Locale.US,"%,d",count)+"  •  جمع مبلغ: "+money(total)+" ریال");
            if(count==0){c.close();list.addView(text("موردی در بایگانی پیدا نشد.",14,TEXT,false));return;}c.moveToPosition(-1);
            while(c.moveToNext()){
                long id=c.getLong(0),amount=c.getLong(5);String direction=c.getString(1),no=c.getString(2),bank=c.getString(3),party=c.getString(4),due=c.getString(6),account=c.getString(7),status=c.getString(8),note=c.getString(9),imagePath=c.getString(10),exitRecipient=c.getString(11),exitDescription=c.getString(12);
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));
                card.addView(text(("دریافتی".equals(direction)?"⬇ چک دریافتی":"⬆ چک پرداختی")+" • "+(no==null||no.isEmpty()?"بدون شماره":"شماره "+no),16,TEXT,true));
                card.addView(text("بانک: "+safeCheque(bank)+" | طرف حساب: "+safeCheque(party),13,TEXT,false));
                card.addView(text("مبلغ: "+money(amount)+" ریال | سررسید: "+safeCheque(due),14,DARK,true));
                card.addView(text("وضعیت بایگانی: "+status+" | حساب: "+safeCheque(account),13,Color.rgb(86,99,91),false));
                if(note!=null&&!note.isEmpty())card.addView(text("شرح: "+note,12,TEXT,false));
                if("خروج شد".equals(status)){card.addView(text("تحویل‌گیرنده: "+safeCheque(exitRecipient),13,TEXT,false));if(exitDescription!=null&&!exitDescription.trim().isEmpty())card.addView(text("توضیحات خروج: "+exitDescription,13,TEXT,false));}
                if(imagePath!=null&&!imagePath.isEmpty()){Button photo=button("مشاهده عکس چک");card.addView(photo);photo.setOnClickListener(v->{File fimg=new File(imagePath);if(!fimg.exists()){toast("فایل عکس پیدا نشد.");return;}Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(Uri.fromFile(fimg),"image/*");view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(view);}catch(Exception ex){toast("برنامه‌ای برای نمایش عکس پیدا نشد.");}});}
                Button edit=button("مشاهده / ویرایش مشخصات چک");card.addView(edit);edit.setOnClickListener(v->editCheque(id));
                Button restore=button("بازگرداندن به فهرست فعال");card.addView(restore);restore.setOnClickListener(v->{String target="دریافتی".equals(direction)?"در انتظار وصول":"در انتظار پرداخت";new AlertDialog.Builder(this).setTitle("بازگرداندن چک").setMessage("وضعیت چک به «"+target+"» تغییر کند و به فهرست فعال برگردد؟ هیچ تراکنش مالی حذف یا ثبت نمی‌شود.").setNegativeButton("انصراف",null).setPositiveButton("بازگرداندن",(d,w)->{ContentValues cv=new ContentValues();cv.put("status",target);cv.put("updated_at",System.currentTimeMillis());db.getWritableDatabase().update("cheques",cv,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});showChequeArchive();}).show();});
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));list.addView(card,lp);
            }c.close();
        };
        query.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(android.text.Editable e){}});
        filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){refresh.run();}public void onNothingSelected(android.widget.AdapterView<?> a){}});
        refresh.run();
    }
    private String csvCell(String s){if(s==null)s="";return "\""+s.replace("\"","\"\"")+"\"";}
    private String buildChequeCsv(String f,String q,String from,String to,int sortPos){
        String where="book=? AND NOT ("+archivedChequeSql()+")";java.util.ArrayList<String> args=new java.util.ArrayList<>();args.add(activeBook);
        if("دریافتی".equals(f)||"پرداختی".equals(f)){where+=" AND direction=?";args.add(f);}else if("باز / در انتظار".equals(f))where+=" AND status IN ('در انتظار وصول','در انتظار پرداخت','در جریان وصول','در جریان پرداخت')";else if("لغوشده".equals(f))where+=" AND status='لغو شد'";
        if(!q.isEmpty()){String like="%"+q+"%";String nq=normalizeChequeQuery(q),nlike="%"+nq+"%";where+=" AND (cheque_no LIKE ? OR bank LIKE ? OR party LIKE ? OR "+sqlAsciiDigits("CAST(amount AS TEXT)")+" LIKE ? OR due_date LIKE ? OR account LIKE ? OR note LIKE ? OR status LIKE ? OR "+sqlAsciiDigits("cheque_no")+" LIKE ?)";args.add(like);args.add(like);args.add(like);args.add(nlike);args.add(like);args.add(like);args.add(like);args.add(like);args.add(nlike);}
        if(!from.isEmpty()){where+=" AND REPLACE(REPLACE(due_date,'/',''),'-','') >= REPLACE(REPLACE(?,'/',''),'-','')";args.add(from);}if(!to.isEmpty()){where+=" AND REPLACE(REPLACE(due_date,'/',''),'-','') <= REPLACE(REPLACE(?,'/',''),'-','')";args.add(to);}
        String order=sortPos==1?"due_date DESC,id DESC":sortPos==2?"amount ASC,due_date ASC":sortPos==3?"amount DESC,due_date ASC":"due_date ASC,id DESC";
        StringBuilder out=new StringBuilder("نوع چک,شماره چک,بانک,پرداخت‌کننده یا طرف حساب,مبلغ (ریال),تاریخ سررسید,حساب,وضعیت,توضیحات,تحویل‌گیرنده خروج,توضیحات خروج\r\n");Cursor c=db.getReadableDatabase().rawQuery("SELECT direction,cheque_no,bank,party,amount,due_date,account,status,note,exit_recipient,exit_description FROM cheques WHERE "+where+" ORDER BY "+order,args.toArray(new String[0]));while(c.moveToNext()){out.append(csvCell(c.getString(0))).append(',').append(csvCell(c.getString(1))).append(',').append(csvCell(c.getString(2))).append(',').append(csvCell(c.getString(3))).append(',').append(c.getLong(4)).append(',').append(csvCell(c.getString(5))).append(',').append(csvCell(c.getString(6))).append(',').append(csvCell(c.getString(7))).append(',').append(csvCell(c.getString(8))).append(',').append(csvCell(c.getString(9))).append(',').append(csvCell(c.getString(10))).append("\r\n");}c.close();return "\uFEFF"+out.toString();
    }
    private String safeCheque(String s){return s==null||s.trim().isEmpty()?"—":s;}
    private void showChequeDialog(String initialDirection){
        pendingChequeImagePath="";
        LinearLayout f=formLayout();
        chequeDirectionSpinner=styledSpinner();chequeDirectionSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"دریافتی","پرداختی"}));chequeDirectionSpinner.setSelection("پرداختی".equals(initialDirection)?1:0);
        chequeNumberField=edit("شماره چک",InputType.TYPE_CLASS_TEXT);chequeBankField=edit("نام بانک",InputType.TYPE_CLASS_TEXT);chequePartyField=edit("نام صادرکننده / دریافت‌کننده",InputType.TYPE_CLASS_TEXT);chequeAmountField=edit("مبلغ چک به ریال",InputType.TYPE_CLASS_NUMBER);chequeDueField=edit("تاریخ سررسید (مثلاً ۱۴۰۵/۰۸/۱۵)",InputType.TYPE_CLASS_TEXT);chequeAccountField=edit("حساب بانکی مرتبط (اختیاری)",InputType.TYPE_CLASS_TEXT);chequeNoteField=edit("شرح / توضیحات (اختیاری)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        chequeStatusSpinner=styledSpinner();
        f.addView(text("نوع چک",13,TEXT,true));f.addView(chequeDirectionSpinner);f.addView(chequeNumberField);f.addView(chequeBankField);f.addView(chequePartyField);f.addView(chequeAmountField);f.addView(chequeDueField);f.addView(chequeAccountField);f.addView(text("وضعیت اولیه",13,TEXT,true));f.addView(chequeStatusSpinner);f.addView(chequeNoteField);
        chequeDirectionSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){String[] opts=pos==0?new String[]{"در انتظار وصول","در جریان وصول","وصول شد","برگشتی","لغو شد"}:new String[]{"در انتظار پرداخت","در جریان پرداخت","پرداخت شد","خروج شد","برگشتی","لغو شد"};String old=chequeStatusSpinner.getSelectedItem()==null?"":chequeStatusSpinner.getSelectedItem().toString();chequeStatusSpinner.setAdapter(new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,opts));for(int i=0;i<opts.length;i++)if(opts[i].equals(old))chequeStatusSpinner.setSelection(i);}public void onNothingSelected(android.widget.AdapterView<?> a){}});
        new AlertDialog.Builder(this).setTitle("ثبت چک").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره چک",(d,w)->{
            String direction=chequeDirectionSpinner.getSelectedItem().toString(),no=chequeNumberField.getText().toString().trim(),bank=chequeBankField.getText().toString().trim(),party=chequePartyField.getText().toString().trim(),due=chequeDueField.getText().toString().trim(),account=chequeAccountField.getText().toString().trim(),note=chequeNoteField.getText().toString().trim();long amount=parseAmount(chequeAmountField.getText().toString());
            if(amount<=0){toast("مبلغ چک باید بیشتر از صفر باشد.");return;}if(no.isEmpty()&&bank.isEmpty()&&party.isEmpty()){toast("حداقل شماره چک، بانک یا نام طرف حساب را وارد کن.");return;}
            long now=System.currentTimeMillis();ContentValues cv=new ContentValues();cv.put("book",activeBook);cv.put("direction",direction);cv.put("cheque_no",no);cv.put("bank",bank);cv.put("party",party);cv.put("amount",amount);cv.put("due_date",due);cv.put("account",account);cv.put("status",chequeStatusSpinner.getSelectedItem().toString());cv.put("note",note);cv.put("image_path",pendingChequeImagePath);cv.put("created_at",now);cv.put("updated_at",now);db.getWritableDatabase().insert("cheques",null,cv);toast("چک در دفتر «"+activeBook+"» ثبت شد؛ هنوز به‌عنوان تراکنش نقدی ثبت نشده است.");showCheques();
        }).show();
    }
    private void changeChequeStatus(long id,String direction,String current,long amount,String account,String party){
        String[] opts=direction.equals("دریافتی")?new String[]{"در انتظار وصول","در جریان وصول","پاس شد","وصول شد","واریز به حساب","خرج شد","برگشت","برگشتی","لغو شد"}:new String[]{"در انتظار پرداخت","در جریان پرداخت","پاس شد","پرداخت شد","واریز به حساب","خروج شد","خرج شد","برگشت","برگشتی","لغو شد"};
        new AlertDialog.Builder(this).setTitle("وضعیت چک").setSingleChoiceItems(opts,Math.max(0,java.util.Arrays.asList(opts).indexOf(current)),(d,w)->{
            String selected=opts[w];d.dismiss();
            if("خروج شد".equals(selected)||"خرج شد".equals(selected)){
                Cursor old=db.getReadableDatabase().rawQuery("SELECT exit_recipient,exit_description FROM cheques WHERE id=? AND book=?",new String[]{String.valueOf(id),activeBook});
                String oldRecipient="",oldDescription="";if(old.moveToFirst()){oldRecipient=old.getString(0)==null?"":old.getString(0);oldDescription=old.getString(1)==null?"":old.getString(1);}old.close();
                LinearLayout form=formLayout();EditText recipient=edit("نام شخص تحویل‌گیرنده",InputType.TYPE_CLASS_TEXT),description=edit("توضیحات خروج چک (اختیاری)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);recipient.setText(oldRecipient);description.setText(oldDescription);form.addView(recipient);form.addView(description);
                new AlertDialog.Builder(this).setTitle("ثبت خرج / خروج چک").setMessage("نام گیرنده را وارد کن؛ توضیحات خروج نیز برای ثبت دلیل یا جزئیات قابل درج است.").setView(form).setNegativeButton("انصراف",null).setPositiveButton("ثبت خروج",(x,y)->{
                    String name=recipient.getText().toString().trim(),desc=description.getText().toString().trim();if(name.isEmpty()){toast("نام شخص تحویل‌گیرنده را وارد کن.");return;}
                    ContentValues values=new ContentValues();values.put("status",selected);values.put("exit_recipient",name);values.put("exit_description",desc);values.put("updated_at",System.currentTimeMillis());db.getWritableDatabase().update("cheques",values,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});toast("وضعیت چک به «"+selected+"» تغییر کرد.");showCheques();
                }).show();return;
            }
            new AlertDialog.Builder(this).setTitle("تأیید وضعیت").setMessage("وضعیت چک به «"+selected+"» تغییر کند؟ تغییر وضعیت به‌تنهایی مانده حساب را تغییر نمی‌دهد.").setNegativeButton("انصراف",null).setPositiveButton("تأیید",(x,y)->{
                ContentValues v=new ContentValues();v.put("status",selected);v.put("updated_at",System.currentTimeMillis());db.getWritableDatabase().update("cheques",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});
                if(selected.equals("وصول شد")||selected.equals("پرداخت شد")||selected.equals("پاس شد")||selected.equals("واریز به حساب")){
                    new AlertDialog.Builder(this).setTitle("ثبت اثر مالی").setMessage("آیا می‌خواهی اثر وصول/پرداخت این چک هم به‌عنوان تراکنش مالی در دفتر ثبت شود؟ فقط در صورتی تأیید کن که قبلاً ثبت نشده باشد.").setNegativeButton("فقط تغییر وضعیت",(dd,ww)->showCheques()).setPositiveButton("ثبت تراکنش مالی",(dd,ww)->{
                        String acc=account==null?"":account.trim();if(acc.isEmpty()){toast("حساب مرتبط مشخص نیست؛ چک را ویرایش کن و حساب را وارد کن، سپس اثر مالی را جداگانه ثبت کن.");showCheques();return;}
                        Cursor posted=db.getReadableDatabase().rawQuery("SELECT financial_posted FROM cheques WHERE id=? AND book=?",new String[]{String.valueOf(id),activeBook});boolean alreadyPosted=posted.moveToFirst()&&posted.getInt(0)==1;posted.close();if(alreadyPosted){toast("اثر مالی این چک قبلاً ثبت شده است؛ از ثبت تکراری جلوگیری شد.");showCheques();return;}
                        long now=System.currentTimeMillis();ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",direction.equals("دریافتی")?"درآمد":"هزینه");tx.put("amount",amount);tx.put("category",direction.equals("دریافتی")?"وصول چک":"پرداخت چک");tx.put("account",acc);tx.put("note","اثر مالی چک "+(party==null?"":party)+" (شماره "+id+")");tx.put("date",now);setMonthKey(tx,now);
                        db.getWritableDatabase().beginTransaction();try{db.getWritableDatabase().insert("transactions",null,tx);ContentValues mark=new ContentValues();mark.put("financial_posted",1);mark.put("updated_at",now);db.getWritableDatabase().update("cheques",mark,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});db.getWritableDatabase().setTransactionSuccessful();}finally{db.getWritableDatabase().endTransaction();}toast("تراکنش مالی ثبت شد");showCheques();
                    }).show();
                }else showCheques();
            }).show();
        }).setNegativeButton("بستن",null).show();
    }
    private void editCheque(long id){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT direction,cheque_no,bank,party,amount,due_date,account,status,note,image_path,exit_recipient,exit_description FROM cheques WHERE id=? AND book=?",new String[]{String.valueOf(id),activeBook});if(!c.moveToFirst()){c.close();return;}String direction=c.getString(0),no=c.getString(1),bank=c.getString(2),party=c.getString(3),amount=String.valueOf(c.getLong(4)),due=c.getString(5),account=c.getString(6),status=c.getString(7),note=c.getString(8),img=c.getString(9),exitRecipient=c.getString(10)==null?"":c.getString(10),exitDescription=c.getString(11)==null?"":c.getString(11);c.close();
        LinearLayout f=formLayout();EditText n=edit("شماره چک",InputType.TYPE_CLASS_TEXT),b=edit("بانک",InputType.TYPE_CLASS_TEXT),p=edit("طرف حساب",InputType.TYPE_CLASS_TEXT),a=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER),dt=edit("سررسید",InputType.TYPE_CLASS_TEXT),ac=edit("حساب مرتبط",InputType.TYPE_CLASS_TEXT),nt=edit("شرح",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);n.setText(no);b.setText(bank);p.setText(party);a.setText(amount);dt.setText(due);ac.setText(account);nt.setText(note);EditText er=edit("نام شخص تحویل‌گیرنده (در صورت خروج)",InputType.TYPE_CLASS_TEXT),ed=edit("توضیحات خروج چک",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);er.setText(exitRecipient);ed.setText(exitDescription);f.addView(n);f.addView(b);f.addView(p);f.addView(a);f.addView(dt);f.addView(ac);f.addView(nt);f.addView(er);f.addView(ed);
        new AlertDialog.Builder(this).setTitle("ویرایش چک").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{long amt=parseAmount(a.getText().toString());if(amt<=0){toast("مبلغ نامعتبر است");return;}ContentValues v=new ContentValues();v.put("cheque_no",n.getText().toString().trim());v.put("bank",b.getText().toString().trim());v.put("party",p.getText().toString().trim());v.put("amount",amt);v.put("due_date",dt.getText().toString().trim());v.put("account",ac.getText().toString().trim());v.put("note",nt.getText().toString().trim());v.put("exit_recipient",er.getText().toString().trim());v.put("exit_description",ed.getText().toString().trim());v.put("updated_at",System.currentTimeMillis());db.getWritableDatabase().update("cheques",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});showCheques();}).show();
    }

    private void showDebtDialog() {
        LinearLayout f=formLayout();
        EditText person=edit("نام شخص",InputType.TYPE_CLASS_TEXT);
        Spinner kind=styledSpinner(); String[] kinds={"طلب از شخص","بدهی به شخص"}; kind.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,kinds));
        EditText amount=edit("مبلغ کل به ریال",InputType.TYPE_CLASS_NUMBER),note=edit("شرح (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(person);f.addView(kind);f.addView(amount);f.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت بدهی یا طلب").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long a=parseAmount(amount.getText().toString());String who=person.getText().toString().trim();
            if(a<=0||who.isEmpty()){toast("نام و مبلغ را درست وارد کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("person",who);v.put("kind",kind.getSelectedItem().toString());v.put("amount",a);v.put("paid",0);v.put("note",note.getText().toString());v.put("date",System.currentTimeMillis());
            db.getWritableDatabase().insert("debts",null,v);toast("بدهی/طلب ثبت شد");showDebts();
        }).show();
    }
    private void showDebts() {
        setHeaderInfo("بدهی‌ها و طلب‌ها", "مانده و تسویه بدهی‌ها و طلب‌ها را بررسی کنید");
        body.removeAllViews();addHeading("بدهی‌ها و طلب‌ها");
        addWideButton("＋ ثبت بدهی یا طلب",()->showDebtDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,person,kind,amount,paid,note,date FROM debts WHERE book=? ORDER BY date DESC",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز بدهی یا طلبی ثبت نشده است.");return;}
        do {
            long id=c.getLong(0), amount=c.getLong(3), paid=c.getLong(4);String person=c.getString(1),kind=c.getString(2),note=c.getString(5);long remaining=Math.max(0,amount-paid);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));
            card.addView(text(person+" • "+kind,15,TEXT,true));card.addView(text("کل: "+money(amount)+" | تسویه: "+money(paid),13,Color.rgb(86, 99, 91),false));
            card.addView(text("مانده: "+money(remaining),16,remaining==0?GREEN:Color.rgb(204,103,112),true));if(note!=null&&!note.isEmpty())card.addView(text(note,12,Color.rgb(86, 99, 91),false));
            Button settle=button(remaining==0?"تسویه کامل شده":"ثبت تسویه / دریافت" );settle.setEnabled(remaining>0);card.addView(settle);settle.setOnClickListener(v->settleDebt(id,person,kind,remaining));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(card,lp);
        }while(c.moveToNext());c.close();
    }
    private void settleDebt(long id,String person,String kind,long remaining) {
        EditText amount=edit("مبلغ این تسویه (مانده: "+remaining+")",InputType.TYPE_CLASS_NUMBER);amount.setText(String.valueOf(remaining));
        new AlertDialog.Builder(this).setTitle("تسویه با "+person).setView(amount).setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{
            long a=parseAmount(amount.getText().toString());if(a<=0||a>remaining){toast("مبلغ باید بین ۱ تا مانده بدهی باشد");return;}
            SQLiteDatabase sql=db.getWritableDatabase();
            sql.execSQL("UPDATE debts SET paid=MIN(amount,paid+?) WHERE id=?",new Object[]{a,id});
            String txType=kind.contains("بدهی")?"هزینه":"درآمد";String cat=kind.contains("بدهی")?"تسویه بدهی":"دریافت طلب";ensureAccount("پول نقد");
            ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",txType);tx.put("amount",a);tx.put("category",cat);tx.put("account","پول نقد");tx.put("note","تسویه با "+person);tx.put("date",System.currentTimeMillis());setMonthKey(tx,System.currentTimeMillis());sql.insert("transactions",null,tx);
            toast("تسویه ثبت شد");showDebts();
        }).show();
    }
    private static final String QUICK_ACTIONS_PREF = "home_quick_actions_v1";
    private String[] quickActionOptions() {
        return new String[]{"ثبت هزینه", "ثبت درآمد", "انتقال بین حساب‌ها", "ثبت دارایی", "ثبت بدهی یا طلب", "گزارش مالی", "تراکنش‌ها", "هدف‌های پس‌انداز", "بودجه‌بندی"};
    }
    private java.util.ArrayList<String> getQuickActions() {
        String stored = getPreferences(0).getString(QUICK_ACTIONS_PREF, "");
        java.util.ArrayList<String> result = new java.util.ArrayList<>();
        if (!stored.trim().isEmpty()) for (String item : stored.split("\\|")) if (!item.trim().isEmpty()) result.add(item);
        return result;
    }
    private String quickActionLabel(String action) {
        switch (action) {
            case "ثبت هزینه": return "🧾 ثبت هزینه";
            case "ثبت درآمد": return "💰 ثبت درآمد";
            case "انتقال بین حساب‌ها": return "⇄ انتقال بین حساب‌ها";
            case "ثبت دارایی": return "◇ ثبت دارایی";
            case "ثبت بدهی یا طلب": return "↔ بدهی یا طلب";
            case "گزارش مالی": return "▤ گزارش مالی";
            case "تراکنش‌ها": return "↕ تراکنش‌ها";
            case "هدف‌های پس‌انداز": return "◎ هدف‌های پس‌انداز";
            case "بودجه‌بندی": return "▦ بودجه‌بندی";
            default: return action;
        }
    }
    private void runQuickAction(String action) {
        switch (action) {
            case "ثبت هزینه": showEntry("هزینه"); break;
            case "ثبت درآمد": showEntry("درآمد"); break;
            case "انتقال بین حساب‌ها": showTransfer(); break;
            case "ثبت دارایی": showAssetDialog(); break;
            case "ثبت بدهی یا طلب": showDebtDialog(); break;
            case "گزارش مالی": showReports(); break;
            case "تراکنش‌ها": navigate("تراکنش‌ها"); break;
            case "هدف‌های پس‌انداز": showGoals(); break;
            case "بودجه‌بندی": showBudgets(); break;
        }
    }
    private void manageQuickActions() {
        final String[] options = quickActionOptions();
        final java.util.ArrayList<String> current = getQuickActions();
        final boolean[] checked = new boolean[options.length];
        final CheckBox[] boxes = new CheckBox[options.length];
        for (int i = 0; i < options.length; i++) checked[i] = current.contains(options[i]);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        panel.setPadding(dp(14), dp(8), dp(14), dp(8));
        TextView instruction = text("برای نمایش هر گزینه در صفحه خانه، مربع کنار آن را فعال کن.", 14, TEXT, false);
        instruction.setPadding(dp(2), dp(4), dp(2), dp(12));
        panel.addView(instruction);

        ScrollView listScroll = new ScrollView(this);
        listScroll.setFillViewport(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for (int i = 0; i < options.length; i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            row.setPadding(dp(10), dp(5), dp(10), dp(5));
            row.setBackground(roundBg(Color.rgb(255, 247, 249)));
            CheckBox cb = new CheckBox(this);
            cb.setText(options[i]);
            cb.setTextColor(TEXT);
            cb.setTextSize(15);
            cb.setGravity(Gravity.CENTER_VERTICAL);
            cb.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            cb.setButtonTintList(android.content.res.ColorStateList.valueOf(GREEN));
            cb.setChecked(checked[i]);
            cb.setPadding(dp(4), dp(4), dp(4), dp(4));
            boxes[i] = cb;
            row.addView(cb, new LinearLayout.LayoutParams(-1, -2));
            row.setOnClickListener(v -> cb.setChecked(!cb.isChecked()));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
            rowLp.setMargins(0, dp(3), 0, dp(3));
            list.addView(row, rowLp);
        }
        listScroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        panel.addView(listScroll, new LinearLayout.LayoutParams(-1, dp(350)));

        new AlertDialog.Builder(this)
            .setTitle("مدیریت آیکن‌های دسترسی سریع")
            .setView(panel)
            .setNegativeButton("انصراف", null)
            .setNeutralButton("حذف همه", (dialog, which) -> {
                getPreferences(0).edit().putString(QUICK_ACTIONS_PREF, "").apply();
                toast("همه دسترسی‌های سریع حذف شدند");
                showSettings();
            })
            .setPositiveButton("ذخیره", (dialog, which) -> {
                StringBuilder saved = new StringBuilder();
                for (int i = 0; i < options.length; i++) {
                    if (boxes[i].isChecked()) {
                        if (saved.length() > 0) saved.append('|');
                        saved.append(options[i]);
                    }
                }
                getPreferences(0).edit().putString(QUICK_ACTIONS_PREF, saved.toString()).apply();
                toast(saved.length() == 0 ? "دسترسی سریع غیرفعال شد" : "دسترسی‌های سریع ذخیره شدند");
                showSettings();
            }).show();
    }

    private void showSmartBankImport(){
        setHeaderInfo("مدیریت ورود هوشمند بانکی","دریافت خودکار، ورود گردش حساب و بررسی امن");
        body.removeAllViews();
        addHeading("مدیریت ورود هوشمند بانکی");
        android.content.SharedPreferences prefs=android.preference.PreferenceManager.getDefaultSharedPreferences(this);
        boolean sms=prefs.getBoolean("bank_sms_enabled",false);
        boolean notifications=prefs.getBoolean("bank_notifications_enabled",false);
        android.content.SharedPreferences candidates=getSharedPreferences("bank_import_candidates",MODE_PRIVATE);
        int candidateCount=0; for(String key:candidates.getAll().keySet()) if(key.startsWith("candidate_")) candidateCount++;
        Cursor pendingCursor=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM bank_inbox WHERE status='pending'",null);
        int pendingCount=0;if(pendingCursor.moveToFirst())pendingCount=pendingCursor.getInt(0);pendingCursor.close();
        addEmpty("با دریافت هر پیامک یا اعلان بانکی، حساب‌یار یک اعلان فوری برای بررسی همان پیام نشان می‌دهد. با لمس اعلان، فقط همان تراکنش باز می‌شود. مبلغ، حساب و شرح را بررسی و ویرایش کن؛ ثبت نهایی فقط با تأیید تو انجام می‌شود. پیام‌ها تا زمان تصمیم تو در صف باقی می‌مانند.");
        addHeading("۱) دریافت خودکار پیامک و اعلان");
        addWideButton((sms?"✓ ":"")+"دریافت پیامک بانکی: "+(sms?"فعال":"غیرفعال"),()->{boolean next=!prefs.getBoolean("bank_sms_enabled",false);if(next&&Build.VERSION.SDK_INT>=23&&checkSelfPermission("android.permission.RECEIVE_SMS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.RECEIVE_SMS"},731);return;}prefs.edit().putBoolean("bank_sms_enabled",next).apply();if(next)requestBankNotificationPermission();showSmartBankImport();});
        addWideButton((notifications?"✓ ":"")+"دریافت اعلان بانکی: "+(notifications?"فعال":"غیرفعال"),()->{boolean next=!prefs.getBoolean("bank_notifications_enabled",false);prefs.edit().putBoolean("bank_notifications_enabled",next).apply();if(next){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){pendingOpenBankNotificationSettings=true;requestBankNotificationPermission();}else openBankNotificationListenerSettings();}else toast("دریافت اعلان بانکی غیرفعال شد.");showSmartBankImport();});
        boolean confirm=getPreferences(0).getBoolean("confirm_bank_messages_on_start",false);
        addWideButton("تأیید پیامک‌های بانکی هنگام شروع: "+(confirm?"روشن":"خاموش"),()->{boolean next=!getPreferences(0).getBoolean("confirm_bank_messages_on_start",false);getPreferences(0).edit().putBoolean("confirm_bank_messages_on_start",next).apply();toast(next?"از اجرای بعدی پیام‌های جدید برای تأیید اولیه نمایش داده می‌شوند.":"تأیید اولیه هنگام شروع خاموش شد.");showSmartBankImport();});
        addHeading("۲) ورود دستی و گردش حساب");
        addWideButton("ورود متن پیامک یا ردیف‌های گزارش",()->showUnifiedBankTextEntry());
        addWideButton("انتخاب بانک و ورود فایل گردش حساب",()->chooseBankForStatement());
        addHeading("۳) صف‌ها و بررسی تراکنش‌ها");
        addWideButton("صندوق بررسی مالی • "+pendingCount+" مورد",()->showBankInbox());
        addWideButton("بررسی پیامک‌ها و اعلان‌ها • "+candidateCount+" مورد",()->showBankCandidateQueue());
        addEmpty("فرمت‌های فایل: CSV، TXT، Excel با پسوند XLSX و PDF متنی. فایل PDF اسکن‌شده و Excel قدیمی XLS باید ابتدا به قالب پشتیبانی‌شده تبدیل شوند. موارد تکراری، تاریخ‌های خارج از محدوده و حساب‌های مبهم برای جلوگیری از ثبت اشتباه کنترل می‌شوند.");
    }
    private void requestBankNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},733);
        }
    }
    private void openBankNotificationListenerSettings(){
        try{startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));}
        catch(Exception e){toast("تنظیمات دسترسی اعلان‌ها در دسترس نیست.");}
    }
    private void consumeBankCandidateIntent(Intent intent){
        if(intent==null||!ACTION_REVIEW_BANK_CANDIDATE.equals(intent.getAction()))return;
        String key=intent.getStringExtra(EXTRA_BANK_CANDIDATE_KEY);
        if(key==null||!key.startsWith("candidate_"))return;
        pendingBankCandidateKey=key;
        if(appUnlocked)uiHandler.postDelayed(()->openPendingBankCandidate(),350);
    }
    private void openPendingBankCandidate(){
        if(!appUnlocked||pendingBankCandidateKey.isEmpty())return;
        String key=pendingBankCandidateKey;pendingBankCandidateKey="";
        android.content.SharedPreferences p=getSharedPreferences("bank_import_candidates",MODE_PRIVATE);
        String value=p.getString(key,null);
        if(value==null){toast("این پیام قبلاً بررسی یا ثبت شده است.");return;}
        String[] parts=value.split("\\n",4);
        if(parts.length<4){toast("اطلاعات پیام بانکی ناقص است؛ در صف بررسی باقی ماند.");return;}
        String source=parts[0],sender=parts[2],raw=parts[3];long timestamp=parseBankTime(parts[1]);
        new AlertDialog.Builder(this).setTitle("درخواست ثبت تراکنش بانکی")
                .setMessage("پیام دریافت‌شده:\n\n"+raw+"\n\nاین پیام جداگانه بررسی می‌شود. مبلغ را انتخاب کن و شرح، حساب و نوع تراکنش را پیش از ثبت کنترل کن.")
                .setNegativeButton("بعداً",(d,w)->{})
                .setNeutralButton("نادیده گرفتن",(d,w)->{p.edit().remove(key).apply();toast("این پیام از صف بررسی حذف شد.");})
                .setPositiveButton("بررسی و انتخاب مبلغ",(d,w)->chooseBankCandidateAmount(key,raw,source,sender,timestamp,p)).show();
    }

    private void showUnifiedBankTextEntry(){
        EditText e=edit("متن کامل پیامک بانکی یا ردیف‌های گزارش را وارد کنید",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);e.setMinLines(5);
        new AlertDialog.Builder(this).setTitle("افزودن متن به صف بررسی بانکی").setView(e).setNegativeButton("لغو",null).setPositiveButton("افزودن به بررسی",(d,w)->{String raw=e.getText().toString().trim();if(raw.isEmpty()){toast("متنی وارد نشده است.");return;}BankSmsReceiver.save(this,"MANUAL","",raw,System.currentTimeMillis());toast("متن به صف پیام‌ها اضافه شد؛ حالا مبلغ را از عددهای متن انتخاب کن.");showBankCandidateQueue();}).show();
    }
    private void chooseBankForStatement(){
        String[] banks=bankNames();
        String saved=getPreferences(0).getString("statement_import_bank","");
        int selected=0;for(int i=0;i<banks.length;i++)if(banks[i].equals(saved)){selected=i;break;}
        Spinner spinner=styledSpinner();spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,banks));spinner.setSelection(selected);
        LinearLayout box=formLayout();box.addView(text("ابتدا بانک صادرکننده را انتخاب کنید؛ سپس فایل CSV، TXT، Excel (.xlsx) یا PDF متنی را برگزینید. فقط تراکنش‌های هم‌تاریخ یا جدیدتر از تاریخ شروع مجاز وارد می‌شوند.",14,TEXT,false));
        TextView cutoffButton=text("تنظیم تاریخ شروع مجاز برای این بانک",14,GREEN,true);cutoffButton.setPadding(0,dp(10),0,dp(10));box.addView(cutoffButton);
        Runnable updateCutoffLabel=()->{String b=String.valueOf(spinner.getSelectedItem());String k=bankImportCutoff(b);cutoffButton.setText(k.isEmpty()?"⚠ تاریخ شروع مشخص نیست؛ برای تعیین آن لمس کن":"تاریخ شروع مجاز تراکنش‌ها: "+k.substring(0,4)+"/"+k.substring(4,6)+"/"+k.substring(6,8)+"  (برای تغییر لمس کن)");};
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){@Override public void onItemSelected(AdapterView<?> parent,View view,int position,long itemId){updateCutoffLabel.run();}@Override public void onNothingSelected(AdapterView<?> parent){}});
        cutoffButton.setOnClickListener(v->{String b=String.valueOf(spinner.getSelectedItem());String k=bankImportCutoff(b);Calendar initial=Calendar.getInstance();if(k.matches("\\d{8}")){try{initial.setTimeInMillis(statementDateMillis(k.substring(0,4)+"/"+k.substring(4,6)+"/"+k.substring(6,8)));}catch(Exception ignored){}}new DatePickerDialog(this,(picker,year,month,day)->{Calendar picked=Calendar.getInstance();picked.set(year,month,day,12,0,0);String cutoffSaved=statementDateKey(jalaliDate(picked.getTimeInMillis()));if(cutoffSaved.isEmpty()){toast("تاریخ انتخاب‌شده معتبر نیست.");return;}getPreferences(0).edit().putString("bank_import_cutoff_"+activeBook+"_"+b,cutoffSaved).apply();updateCutoffLabel.run();toast("تاریخ شروع بانک «"+b+"» ذخیره شد.");},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show();});box.addView(spinner);
        new AlertDialog.Builder(this).setTitle("انتخاب بانک").setView(box).setNegativeButton("لغو",null).setPositiveButton("انتخاب فایل",(d,w)->{String bank=String.valueOf(spinner.getSelectedItem());getPreferences(0).edit().putString("statement_import_bank",bank).apply();Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/comma-separated-values","text/plain","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/pdf","application/octet-stream"});try{startActivityForResult(i,732);}catch(Exception e){toast("انتخاب فایل ممکن نشد.");}}).show();
    }
    private java.util.List<String> parseCsvLine(String line){java.util.ArrayList<String> out=new java.util.ArrayList<>();StringBuilder cell=new StringBuilder();boolean quoted=false;for(int i=0;i<line.length();i++){char ch=line.charAt(i);if(ch=='"'){if(quoted&&i+1<line.length()&&line.charAt(i+1)=='"'){cell.append('"');i++;}else quoted=!quoted;}else if((ch==','||ch==';'||ch=='\t')&&!quoted){out.add(cell.toString().trim());cell.setLength(0);}else cell.append(ch);}out.add(cell.toString().trim());return out;}
    private String classifyBankExpense(String description){String x=normalizeBankText(description);
        if(containsAny(x,"سوپرمارکت","فروشگاه","افق کوروش","رفاه","جانبو","هایپر","مواد غذایی"))return "خرید روزانه و مواد غذایی";
        if(containsAny(x,"بنزین","جایگاه","پمپ بنزین","سوخت","تاکسی","اسنپ","تپسی","عوارض آزادراه","پارکینگ"))return "حمل‌ونقل و سوخت";
        if(containsAny(x,"قبض برق","شرکت برق","قبض آب","آبفا","گازبها","شرکت گاز","مخابرات","اینترنت","همراه اول","ایرانسل"))return "قبوض و ارتباطات";
        if(containsAny(x,"داروخانه","بیمارستان","درمانگاه","آزمایشگاه","پزشک","درمانی"))return "سلامت و درمان";
        if(containsAny(x,"اجاره","رهن","شارژ ساختمان","تعمیرات","لوازم منزل","ابزار"))return "مسکن و تعمیرات";
        if(containsAny(x,"کارمزد","هزینه پیامک","هزینه خدمات","کارمزد انتقال","سود تسهیلات","قسط وام"))return "کارمزد و خدمات بانکی";
        if(containsAny(x,"حقوق","دستمزد","بیمه تامین اجتماعی","بیمه تأمین اجتماعی"))return "حقوق و بیمه";
        if(containsAny(x,"خرید اینترنتی","دیجی کالا","دیجی‌کالا","درگاه پرداخت","پرداخت اینترنتی"))return "خرید اینترنتی";
        return "نیازمند تعیین دسته‌بندی";
    }
    private String classifyBankDirection(String description, long debit, long credit){String x=normalizeBankText(description);if(debit>0&&credit==0)return "هزینه";if(credit>0&&debit==0)return "درآمد";if(containsAny(x,"برداشت","خرید","پرداخت","کسر","انتقال به","پایا به","ساتنا به","کارمزد"))return "هزینه";if(containsAny(x,"واریز","دریافت","حقوق","سود سپرده","انتقال از","پایا از","ساتنا از"))return "درآمد";return "نیازمند بررسی";}
    private long parseBankNumber(String value){try{String n=normalizeDigits(value==null?"":value).replaceAll("[^0-9]","");return n.isEmpty()?0:Long.parseLong(n);}catch(Exception e){return 0;}}
    private int findColumn(java.util.List<String> headers,String... words){for(int i=0;i<headers.size();i++){String h=normalizeBankText(headers.get(i));for(String w:words)if(h.contains(normalizeBankText(w)))return i;}return -1;}
    private int safeColumn(java.util.List<String> row,int index){return index>=0&&index<row.size()?index:-1;}
    private boolean stageStatementCsvRow(String bank,java.util.List<String> headers,java.util.List<String> row,long time){
        int dateCol=findColumn(headers,"تاریخ","date","زمان");int descCol=findColumn(headers,"شرح سند","شرح","توضیحات","شرح تراکنش","description","شرح عملیات","طرف حساب");int debitCol=findColumn(headers,"برداشت","بدهکار","مبلغ برداشت","debit");int creditCol=findColumn(headers,"واریز","بستانکار","مبلغ واریز","credit");int amountCol=findColumn(headers,"مبلغ","amount","مبلغ تراکنش");int balanceCol=findColumn(headers,"مانده","balance","موجودی");int typeCol=findColumn(headers,"نوع تراکنش","نوع عملیات","transaction type","type");
        String desc=descCol>=0&&descCol<row.size()?row.get(descCol):"";if(desc.isEmpty()){StringBuilder b=new StringBuilder();for(int i=0;i<row.size();i++)if(i!=dateCol&&i!=balanceCol&&i!=debitCol&&i!=creditCol&&i!=amountCol&&row.get(i).length()>2)b.append(row.get(i)).append(" | ");desc=b.toString().trim();}
        long debit=debitCol>=0&&debitCol<row.size()?parseBankNumber(row.get(debitCol)):0;long credit=creditCol>=0&&creditCol<row.size()?parseBankNumber(row.get(creditCol)):0;long amount=debit>0?debit:credit>0?credit:(amountCol>=0&&amountCol<row.size()?parseBankNumber(row.get(amountCol)):0);
        // Do not guess from arbitrary numeric cells: they may be balance, account number or reference.
        if(amount<=0||desc.isEmpty())return false;
        String direction=classifyBankDirection(desc,debit,credit);
        if(debitCol<0&&creditCol<0&&amountCol>=0&&amountCol<row.size()){
            String amountCell=normalizeDigits(row.get(amountCol)).trim();
            if(amountCell.startsWith("-")||amountCell.startsWith("−"))direction="هزینه";
            else if(containsAny(normalizeBankText(row.get(amountCol)),"واریز","بستانکار","credit"))direction="درآمد";
        }
        if(!"هزینه".equals(direction)&&!"درآمد".equals(direction)&&typeCol>=0&&typeCol<row.size()){
            String txType=normalizeBankText(row.get(typeCol));
            if(containsAny(txType,"برداشت","خرید","پرداخت","بدهکار","کسر","کارمزد","خروجی"))direction="هزینه";
            else if(containsAny(txType,"واریز","دریافت","بستانکار","تسهیلات","ورودی","شارژ"))direction="درآمد";
        }
        String category="متفرقه";
        if("هزینه".equals(direction)){String suggested=classifyBankExpense(desc);if(!"نیازمند تعیین دسته‌بندی".equals(suggested)&&getCategoryOptions("هزینه").contains(suggested))category=suggested;}
        else if("درآمد".equals(direction))category="درآمد / واریز";
        else category="نیازمند بررسی";
        String date=dateCol>=0&&dateCol<row.size()?row.get(dateCol):"تاریخ نامشخص";String normalizedDate=normalizeStatementDate(date);if(!normalizedDate.isEmpty())date=normalizedDate;
        String raw="بانک: "+bank+"\nتاریخ: "+date+"\nشرح: "+desc+"\nمبلغ: "+amount+" ریال\nنوع پیشنهادی: "+direction+"\nدسته‌بندی پیشنهادی: "+category+"\nردیف اصلی: "+row.toString();
        String key;try{key=android.util.Base64.encodeToString(java.security.MessageDigest.getInstance("SHA-256").digest((bank+"|"+date+"|"+desc+"|"+amount+"|"+direction+"|"+row.toString()).getBytes(java.nio.charset.StandardCharsets.UTF_8)),android.util.Base64.NO_WRAP);}catch(Exception e){key=String.valueOf(raw.hashCode());}
        ContentValues v=new ContentValues();v.put("source","گزارش گردش حساب • "+bank);v.put("source_key",key);v.put("raw_text",raw);v.put("amount",amount);v.put("kind",direction);v.put("bank",bank);v.put("received_at",time);v.put("status","pending");v.put("note",("متفرقه".equals(category)?"دسته‌بندی خودکار: متفرقه":"دسته‌بندی پیشنهادی: "+category)+"؛ تاریخ: "+date);
        try{return db.getWritableDatabase().insertOrThrow("bank_inbox",null,v)>0;}catch(Exception e){return false;}
    }
    private long extractBankAmount(String text,String normalized) {
        if(text==null||text.trim().isEmpty())return 0L;
        // Parse each line independently first. These bank SMS formats put the transaction
        // amount on a line explicitly labelled (e.g. "برداشت:" or "پایانه فروش:").
        // Do not use normalizeBankText for label matching: it intentionally removes
        // words such as "حساب", which are important to distinguish account IDs.
        java.util.regex.Pattern numberPattern=java.util.regex.Pattern.compile("(?<![0-9])([0-9](?:[0-9 ,٬،.]{0,18}[0-9])?)(?![0-9])");
        String[] lines=text.split("\\r?\\n");
        long lineBest=0L; int lineBestScore=Integer.MIN_VALUE; boolean lineTie=false;
        int globalOffset=0;
        for(String line:lines){
            String label=line.replace('ي','ی').replace('ك','ک').replace('ۀ','ه').replace('ة','ه')
                .replaceAll("[\\s\\p{Punct}‌ـ]+", "").toLowerCase(Locale.ROOT);
            java.util.regex.Matcher m=numberPattern.matcher(line);
            while(m.find()){
                String token=m.group(1).trim();
                String digits=token.replaceAll("[^0-9]","");
                if(digits.length()<4||digits.length()>15)continue;
                long value;try{value=Long.parseLong(digits);}catch(Exception ex){continue;}
                if(value<1000L)continue;
                int a=m.start(),b=m.end();
                String left=line.substring(0,a).replace('ي','ی').replace('ك','ک').replace('ۀ','ه').replace('ة','ه')
                    .replaceAll("[\\s\\p{Punct}‌ـ]+", "").toLowerCase(Locale.ROOT);
                String right=line.substring(b).replace('ي','ی').replace('ك','ک').replace('ۀ','ه').replace('ة','ه')
                    .replaceAll("[\\s\\p{Punct}‌ـ]+", "").toLowerCase(Locale.ROOT);
                boolean accountLine=containsAny(label,"حساب","شمارهحساب","شمارهکارت","شناسه","پیگیری","مرجع","کدرهگیری","شبا","reference","trace");
                boolean balanceLine=containsAny(label,"مانده","موجودی","balance","availablebalance");
                boolean transactionLabel=containsAny(label,"برداشت","واریز","پایانهفروش","پایانه","خریدکارت","خریدکارتخوان","پرداخت","انتقال","کسر","دریافت","مبلغتراکنش","مبلغبرداشت","مبلغواریز","مبلغخرید","amount","debit","credit","purchase","withdrawal","deposit");
                boolean amountAtLabelStart=containsAny(left,"برداشت","واریز","پایانهفروش","پایانه","خریدکارت","خریدکارتخوان","پرداخت","انتقال","کسر","دریافت","مبلغتراکنش","مبلغبرداشت","مبلغواریز","مبلغخرید","amount","debit","credit","purchase","withdrawal","deposit");
                if(accountLine||balanceLine)continue;
                // A transaction label on the same line has precedence over every other
                // numeric value in the SMS (account, balance, date and clock are separate).
                if(transactionLabel&&amountAtLabelStart){
                    int score=100;
                    if(token.matches("[0-9]{1,3}[,٬،.][0-9]{3}(?:[,٬،.][0-9]{3})*"))score+=4;
                    if(b<line.length()&&containsAny(line.substring(b,Math.min(line.length(),b+4)),"-","−","–"))score+=2;
                    if(score>lineBestScore){lineBest=value;lineBestScore=score;lineTie=false;}
                    else if(score==lineBestScore&&value!=lineBest)lineTie=true;
                }
            }
            globalOffset+=line.length()+1;
        }
        if(lineBestScore>=100)return lineTie?0L:lineBest;

        // Conservative fallback for other bank templates: rank numeric candidates using
        // surrounding transaction wording, while explicitly excluding account/balance fields.
        java.util.regex.Matcher m=numberPattern.matcher(text);
        long best=0L;int bestScore=Integer.MIN_VALUE;boolean tied=false;
        while(m.find()){
            String token=m.group(1).trim();String digits=token.replaceAll("[^0-9]","");
            if(digits.length()<4||digits.length()>15)continue;
            long value;try{value=Long.parseLong(digits);}catch(Exception ex){continue;}
            int a=m.start(),b=m.end();
            String before=normalizeBankText(text.substring(Math.max(0,a-75),a));
            String after=normalizeBankText(text.substring(b,Math.min(text.length(),b+55)));
            if(containsAny(before,"مانده","موجودی","balance","شمارهکارت","شمارهحساب","کدرهگیری","شمارهمرجع","شمارهشبا","پیگیری","reference","trace"))continue;
            if(containsAny(before,"حساب:","حساب ","شماره حساب","شماره کارت"))continue;
            if(token.matches("[0-9]{3,4}")&&containsAny(before+after,"ساعت","time","تاریخ","مورخ"))continue;
            int score=0;
            if(containsAny(before,"برداشت","واریز","خرید","پرداخت","انتقال","کسر","دریافت","تراکنش","پایانهفروش","پایانه","مبلغ","deposit","withdraw","purchase","transaction","transfer","debit","credit"))score+=10;
            if(containsAny(after,"برداشت","واریز","خرید","پرداخت","انتقال","کسر","دریافت","تراکنش","مبلغ","deposit","withdraw","purchase","transaction","transfer","debit","credit"))score+=4;
            if(containsAny(before+after,"ریال","تومان","تومن","rial","toman"))score+=2;
            if(token.matches("[0-9]{1,3}[,٬،.][0-9]{3}(?:[,٬،.][0-9]{3})*"))score+=2;
            if(score>bestScore){best=value;bestScore=score;tied=false;}else if(score==bestScore&&value!=best)tied=true;
        }
        return bestScore>=6&&!tied?best:0L;
    }

    private boolean isSelectedBankAmountInToman(String raw,long amount){
        if(raw==null||amount<=0)return false;
        java.util.regex.Pattern p=java.util.regex.Pattern.compile("(?<![0-9])([0-9](?:[0-9 ,٬،.]{0,18}[0-9])?)(?![0-9])");
        String normalized=normalizeDigits(raw);
        java.util.regex.Matcher m=p.matcher(normalized);
        while(m.find()){
            String digits=m.group(1).replaceAll("[^0-9]","");
            long value;try{value=Long.parseLong(digits);}catch(Exception ignored){continue;}
            if(value!=amount)continue;
            int start=Math.max(0,m.start()-24),end=Math.min(normalized.length(),m.end()+24);
            String context=normalized.substring(start,end);
            if(containsAny(context,"تومان","تومن","toman"))return true;
        }
        return false;
    }

    private boolean isSaderatPosDebit(String text){
        if(text==null)return false;
        String n=normalizeDigits(text).replace('ي','ی').replace('ك','ک').replace('ۀ','ه').replace('ة','ه');
        java.util.regex.Pattern p=java.util.regex.Pattern.compile("(?im)^\\s*(?:پایانه\\s*فروش|پایانه|خرید\\s*کارت(?:خوان)?|POS|پوز)\\s*[:：]?\\s*[0-9][0-9 ,٬،.]{2,18}[0-9]\\s*[-−–]\\s*$");
        return p.matcher(n).find();
    }

    private String bankInboxSourceKey(String source,String raw){
        String n=normalizeDigits(raw==null?"":raw).replace('٬',',').replace('،',',');
        try{return android.util.Base64.encodeToString(java.security.MessageDigest.getInstance("SHA-256").digest(((source==null?"":source)+"|"+n.replaceAll("\\s+"," ").trim()).getBytes(java.nio.charset.StandardCharsets.UTF_8)),android.util.Base64.NO_WRAP);}
        catch(Exception e){return String.valueOf((String.valueOf(source)+n).hashCode());}
    }

    private boolean stageBankText(String source,String raw,long time){
        return stageBankText(source,raw,time,0L);
    }
    // A user-selected number overrides heuristic extraction; zero keeps automatic parsing.
    private boolean stageBankText(String source,String raw,long time,long userSelectedAmount){
        String original=raw==null?"":raw.trim();
        String n=normalizeDigits(original).replace('٬',',').replace('،',',');
        String lower=normalizeBankText((source==null?"":source)+" "+n);
        // Manual selection wins; otherwise use the local heuristic parser.
        long amount=userSelectedAmount>0?userSelectedAmount:extractBankAmount(n, lower);
        // The app stores money in rial. Convert only when the message explicitly labels the amount as toman.
        if(amount>0&&isSelectedBankAmountInToman(n,amount)&&amount<=Long.MAX_VALUE/10)amount*=10;
        String kind="نامشخص";
        boolean debit=containsAny(lower,"برداشت","خرید","پرداخت","کسر","انتقال به","کارت به کارت به","پایا به","ساتنا به","کارمزد") || isSaderatPosDebit(n);
        boolean credit=containsAny(lower,"واریز","دریافت","حقوق","انتقال از","کارت به کارت از","پایا از","ساتنا از","سود سپرده");
        if(debit&&!credit)kind="هزینه";else if(credit&&!debit)kind="درآمد";
        String bank="نامشخص";
        String[][] aliases=bankAliases();
        outer: for(String[] group:aliases){for(String b:group){String key=normalizeBankText(b);if(!key.isEmpty()&&lower.contains(key)){bank=group[0];break outer;}}}
        if("نامشخص".equals(bank)){
            String[] known={"صادرات","بلو","ملت","ملی","تجارت","سامان","پاسارگاد","رسالت","رفاه","سپه","شهر","کشاورزی","مسکن","آینده","اقتصاد نوین","پارسیان","دی","گردشگری","قوامین","مهر ایران","پست بانک"};
            for(String b:known)if(lower.contains(normalizeBankText(b))){bank=b;break;}
        }
        String card="";
        java.util.regex.Matcher cm=java.util.regex.Pattern.compile("(?i)(?:کارت(?: شماره)?|شماره کارت|حساب(?: شماره)?|شماره حساب|حساب:)[^0-9]{0,16}([0-9][0-9 -]{3,22})").matcher(n);
        if(cm.find()){String z=cm.group(1).replaceAll("\\D","");if(z.length()>=4)card=z.substring(z.length()-4);}
        String date="";
        java.util.regex.Matcher fullDate=java.util.regex.Pattern.compile("(?<![0-9])((?:13|14|19|20)[0-9]{2}[/-][0-9]{1,2}[/-][0-9]{1,2})(?![0-9])").matcher(n);
        if(fullDate.find())date=normalizeStatementDate(fullDate.group(1));
        if(date.isEmpty()){
            java.util.regex.Matcher labelledDate=java.util.regex.Pattern.compile("(?i)(?:تاریخ|مورخ|date)\\D{0,8}([0-9]{4})(?![0-9])").matcher(n);
            String shorthand="";
            if(labelledDate.find())shorthand=labelledDate.group(1);
            else {
                // Some bank SMS formats start with MMDD, e.g. 0806. Do not treat arbitrary
                // four-digit account/card/reference fragments elsewhere in the message as dates.
                java.util.regex.Matcher prefixDate=java.util.regex.Pattern.compile("^\\s*([0-9]{4})(?![0-9])").matcher(n);
                if(prefixDate.find())shorthand=prefixDate.group(1);
            }
            if(shorthand.length()==4){
                int mm=Integer.parseInt(shorthand.substring(0,2)),dd=Integer.parseInt(shorthand.substring(2));
                String current=jalaliDate(time>0?time:System.currentTimeMillis());
                java.util.regex.Matcher ym=java.util.regex.Pattern.compile("(13|14)[0-9]{2}").matcher(normalizeDigits(current));
                if(ym.find()&&mm>=1&&mm<=12&&dd>=1&&dd<=(mm<=6?31:mm==12?30:30))date=ym.group()+"/"+String.format(java.util.Locale.US,"%02d/%02d",mm,dd);
            }
        }
        String clock="";java.util.regex.Matcher tm=java.util.regex.Pattern.compile("(?<![0-9])([0-2]?[0-9]):([0-5][0-9])(?![0-9])").matcher(n);if(tm.find())clock=String.format(java.util.Locale.ROOT,"%02d:%02d",Integer.parseInt(tm.group(1)),Integer.parseInt(tm.group(2)));
        StringBuilder enriched=new StringBuilder(original);
        if(!date.isEmpty()&&!original.contains("تاریخ:"))enriched.append("\nتاریخ: ").append(date);
        if(!clock.isEmpty()&&!original.contains("ساعت استخراج‌شده:"))enriched.append("\nساعت استخراج‌شده: ").append(clock);
        if(!card.isEmpty()&&!original.contains("شناسه حساب استخراج‌شده:"))enriched.append("\nشناسه حساب استخراج‌شده: ").append(card);
        if(!"نامشخص".equals(bank)&&!original.contains("بانک شناسایی‌شده:"))enriched.append("\nبانک شناسایی‌شده: ").append(bank);
        String key=bankInboxSourceKey(source,original);
        ContentValues v=new ContentValues();v.put("source",source==null?"پیام بانکی":source);v.put("source_key",key);v.put("raw_text",enriched.toString());if(amount>0)v.put("amount",amount);v.put("kind",kind);v.put("bank",bank);if(!card.isEmpty())v.put("card_last4",card);v.put("received_at",time>0?time:System.currentTimeMillis());v.put("status","pending");
        String note="نیازمند تأیید کاربر؛ هنوز در دفتر مالی ثبت نشده است.";
        if(amount<=0)note+=" مبلغ تراکنش با اطمینان قابل تشخیص نیست.";
        if("نامشخص".equals(kind))note+=" نوع تراکنش مشخص نیست.";
        if("نامشخص".equals(bank))note+=" بانک مشخص نیست.";
        v.put("note",note);
        try{
            SQLiteDatabase inboxDb=db.getWritableDatabase();
            Cursor existing=inboxDb.rawQuery("SELECT id FROM bank_inbox WHERE source_key=? LIMIT 1",new String[]{key});
            boolean duplicate=existing.moveToFirst();existing.close();
            if(duplicate)return true; // Already staged; consume the local candidate without duplicating it.
            return inboxDb.insertOrThrow("bank_inbox",null,v)>0;
        }catch(Exception e){return false;}
    }
    private void drainBankCandidates(){
        android.content.SharedPreferences p=getSharedPreferences("bank_import_candidates",MODE_PRIVATE);
        java.util.Map<String,?> all=p.getAll();android.content.SharedPreferences.Editor ed=p.edit();boolean changed=false;
        for(java.util.Map.Entry<String,?> e:all.entrySet()){
            if(!e.getKey().startsWith("candidate_")||!(e.getValue() instanceof String))continue;
            String[] a=((String)e.getValue()).split("\n",4);if(a.length<4)continue;
            String source=a[0],sender=a[2],body=a[3];
            String raw=(sender==null||sender.trim().isEmpty()?"":"شناسه فرستنده/برنامه: "+sender+"\n")+body;
            if(stageBankText(source,raw,parseBankTime(a[1]))){ed.remove(e.getKey());changed=true;}
            // On database errors, retain the candidate so it can be retried instead of losing the SMS.
        }
        if(changed)ed.apply();
    }
    private java.util.ArrayList<String> bankNumericChoices(String raw){
        java.util.ArrayList<String> choices=new java.util.ArrayList<>();
        if(raw==null||raw.trim().isEmpty())return choices;
        String n=normalizeDigits(raw).replace('\u00a0',' ');
        // One stable regex for English, Persian and Arabic digits after normalization.
        java.util.regex.Pattern pattern=java.util.regex.Pattern.compile("(?<![0-9])([0-9]{1,3}(?:[,٬،. ]+[0-9]{3})+|[0-9]{1,18})(?![0-9])");
        java.util.regex.Matcher m=pattern.matcher(n);
        java.util.HashSet<String> seen=new java.util.HashSet<>();
        while(m.find()){
            String token=m.group(1).trim();
            String digits=token.replaceAll("[^0-9]","");
            if(digits.isEmpty()||digits.length()>18)continue;
            long value;try{value=Long.parseLong(digits);}catch(Exception ex){continue;}
            if(value<=0)continue;
            int a=Math.max(0,m.start()-42),b=Math.min(n.length(),m.end()+42);
            String context=n.substring(a,b).replace('\n',' ').replaceAll("\\s+"," ").trim();
            // Deprioritize identifiers and balances. We retain them only when explicitly selected
            // from the expanded list, but label them clearly so they cannot be mistaken silently.
            String normalizedContext=normalizeBankText(context);
            boolean balance=containsAny(normalizedContext,"مانده","موجودی","balance");
            boolean account=containsAny(normalizedContext,"حساب","شماره حساب","شماره کارت","کارت");
            boolean tracking=containsAny(normalizedContext,"پیگیری","رهگیری","شناسه","سریال","reference","trace");
            String role=balance?"مانده/موجودی":account?"شماره حساب/کارت":tracking?"شناسه/پیگیری":"عدد پیام";
            String label=String.format(java.util.Locale.US,"%,d",value)+"   •   "+role+" — "+context;
            String unique=String.valueOf(value)+"|"+role+"|"+context;
            if(seen.add(unique))choices.add(label);
        }
        return choices;
    }
    private void chooseBankCandidateAmount(String candidateKey,String candidateRaw,String candidateSource,String candidateSender,long candidateTimestamp,android.content.SharedPreferences p){
        final java.util.ArrayList<String> labels=bankNumericChoices(candidateRaw);
        
        if(labels.isEmpty()){
            showManualBankAmount(candidateKey,candidateRaw,candidateSource,candidateSender,candidateTimestamp,p,
                    "در متن پیام مبلغ قابل انتخابی پیدا نشد. مبلغ را دستی وارد کن.");
            return;
        }
        // Use an explicit ListView + adapter instead of AlertDialog.setItems, which can render
        // an empty-looking picker on some device/theme combinations.
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(8),dp(12),dp(4));
        TextView intro=text("یک مبلغ را لمس کن. گزینه‌ها همراه با متن اطراف عدد نمایش داده شده‌اند تا مانده و شماره‌ها قابل تشخیص باشند.",13,TEXT,false);content.addView(intro);
        ListView list=new ListView(this);list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,labels){
            @Override public View getView(int position,View convertView,android.view.ViewGroup parent){
                TextView row=(TextView)super.getView(position,convertView,parent);row.setTextSize(14);row.setPadding(dp(12),dp(10),dp(12),dp(10));row.setTextColor(TEXT);row.setMinHeight(dp(56));return row;
            }
        };
        list.setAdapter(adapter);content.addView(list,new LinearLayout.LayoutParams(-1,dp(Math.min(390,Math.max(150,labels.size()*66)))));
        AlertDialog picker=new AlertDialog.Builder(this).setTitle("انتخاب مبلغ تراکنش").setView(content)
                .setNegativeButton("بعداً",(d,w)->{})
                .setNeutralButton("ورود دستی مبلغ",(d,w)->showManualBankAmount(candidateKey,candidateRaw,candidateSource,candidateSender,candidateTimestamp,p,"مبلغ را به ریال وارد کن."))
                .setPositiveButton("انتخاب",null).create();
        list.setOnItemClickListener((parent,view,position,id)->{
            if(position<0||position>=labels.size())return;
            String label=labels.get(position);String left=label.split("\\s+•\\s+",2)[0].replaceAll("[^0-9]","");
            long selected=0;try{selected=Long.parseLong(left.replace(",", ""));}catch(Exception ignored){}
            if(selected<=0){toast("مبلغ انتخاب‌شده معتبر نیست.");return;}
            picker.dismiss();finishBankCandidateAmount(candidateKey,candidateRaw,candidateSource,candidateSender,candidateTimestamp,p,selected);
        });
        picker.setOnShowListener(dlg->picker.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int position=list.getCheckedItemPosition();
            if(position<0||position>=labels.size()){toast("ابتدا یکی از مبلغ‌های فهرست را لمس کن یا ورود دستی مبلغ را بزن.");return;}
            String label=labels.get(position);String left=label.split("\\s+•\\s+",2)[0].replaceAll("[^0-9]","");long selected=0;try{selected=Long.parseLong(left.replace(",", ""));}catch(Exception ignored){}
            if(selected<=0){toast("مبلغ انتخاب‌شده معتبر نیست.");return;}picker.dismiss();finishBankCandidateAmount(candidateKey,candidateRaw,candidateSource,candidateSender,candidateTimestamp,p,selected);
        }));
        picker.show();
    }
    private void showManualBankAmount(String candidateKey,String candidateRaw,String candidateSource,String candidateSender,long candidateTimestamp,android.content.SharedPreferences p,String message){
        EditText amountInput=edit("مبلغ تراکنش به ریال",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);amountInput.setSingleLine(true);
        LinearLayout form=formLayout();form.addView(text(message,14,TEXT,false));form.addView(amountInput);
        new AlertDialog.Builder(this).setTitle("ورود دستی مبلغ بانکی").setView(form).setNegativeButton("لغو",null).setPositiveButton("ادامه ثبت",(d,w)->{
            String digits=normalizeDigits(amountInput.getText().toString()).replaceAll("[^0-9]","");long selected=0;try{selected=Long.parseLong(digits);}catch(Exception ignored){}
            if(selected<=0){toast("مبلغ معتبر وارد کن.");showManualBankAmount(candidateKey,candidateRaw,candidateSource,candidateSender,candidateTimestamp,p,"مبلغ واردشده معتبر نیست؛ دوباره وارد کن.");return;}
            finishBankCandidateAmount(candidateKey,candidateRaw,candidateSource,candidateSender,candidateTimestamp,p,selected);
        }).show();
    }
    private void finishBankCandidateAmount(String candidateKey,String candidateRaw,String candidateSource,String candidateSender,long candidateTimestamp,android.content.SharedPreferences p,long selected){
        String stagedRaw=(candidateSender==null||candidateSender.trim().isEmpty()?"":"شناسه فرستنده/برنامه: "+candidateSender+"\n")+candidateRaw+"\nمبلغ انتخاب‌شده توسط کاربر: "+selected;
        if(!stageBankText(candidateSource,stagedRaw,candidateTimestamp,selected)){
            toast("پیام در صندوق بررسی ذخیره نشد؛ برای جلوگیری از ازدست‌رفتن در صف باقی ماند.");return;
        }
        p.edit().remove(candidateKey).apply();
        String sourceKey=bankInboxSourceKey(candidateSource,stagedRaw);
        Cursor found=db.getReadableDatabase().rawQuery("SELECT id,amount,kind,bank,raw_text,status FROM bank_inbox WHERE source_key=? LIMIT 1",new String[]{sourceKey});
        if(found.moveToFirst()){
            long id=found.getLong(0),amount=found.isNull(1)?selected:found.getLong(1);String kind=found.getString(2)==null?"نامشخص":found.getString(2);String bank=found.getString(3)==null?"نامشخص":found.getString(3);String raw=found.getString(4)==null?stagedRaw:found.getString(4);String status=found.getString(5);found.close();
            p.edit().remove(candidateKey).apply();
            if("imported".equals(status)){toast("این پیام قبلاً در حسابداری ثبت شده است؛ ثبت تکراری انجام نشد.");return;}
            if(!"pending".equals(status)){toast("این پیام قبلاً بررسی شده و وضعیت آن «"+status+"» است.");return;}
            toast("مبلغ انتخاب شد؛ اطلاعات ثبت را تکمیل کن.");postBankInboxItem(id,candidateSource,raw,amount,kind,bank);
        }else{found.close();toast("پیام در صندوق بررسی ثبت شد، اما مورد دقیق آن پیدا نشد؛ پیام از صف حذف نشد.");showBankInbox();}
    }
    private void reviewNextBankCandidate(){
        if(!getPreferences(0).getBoolean("confirm_bank_messages_on_start",false))return;
        android.content.SharedPreferences p=getSharedPreferences("bank_import_candidates",MODE_PRIVATE);
        java.util.ArrayList<String> keys=new java.util.ArrayList<>();java.util.ArrayList<String> vals=new java.util.ArrayList<>();
        for(java.util.Map.Entry<String,?> e:p.getAll().entrySet())if(e.getKey().startsWith("candidate_")&&e.getValue() instanceof String){String value=(String)e.getValue();String[] parts=value.split("\n",4);if(parts.length>=4&&isBankLikeForReview(parts[0],parts[2],parts[3])){keys.add(e.getKey());vals.add(value);}else p.edit().remove(e.getKey()).apply();}
        if(keys.isEmpty())return;
        String key=keys.get(0),value=vals.get(0);String[] a=value.split("\n",4);String raw=a.length>=4?a[3]:value;String source=a.length>0?a[0]:"پیام بانکی";String sender=a.length>2?a[2]:"";long candidateTime=a.length>1?parseBankTime(a[1]):System.currentTimeMillis();
        final String candidateKey=key;final String candidateRaw=raw;final String candidateSource=source;final String candidateSender=sender;final long candidateTimestamp=candidateTime;
        new AlertDialog.Builder(this).setTitle("تأیید پیام بانکی")
          .setMessage("پیام دریافت‌شده:\n\n"+raw+"\n\nبا تأیید، فهرست همه عددهای پیام باز می‌شود. مبلغ را خودت انتخاب می‌کنی و سپس فرم ثبت همین تراکنش باز خواهد شد. پیام بدون انتخاب و ثبت نهایی در حسابداری وارد نمی‌شود.")
          .setNegativeButton("بعداً",(d,w)->{})
          .setNeutralButton("نادیده گرفتن",(d,w)->{p.edit().remove(candidateKey).apply();uiHandler.postDelayed(()->reviewNextBankCandidate(),200);})
          .setPositiveButton("تأیید و انتخاب مبلغ",(d,w)->{if(isBankLikeForReview(candidateSource,candidateSender,candidateRaw))chooseBankCandidateAmount(candidateKey,candidateRaw,candidateSource,candidateSender,candidateTimestamp,p);else{p.edit().remove(candidateKey).apply();uiHandler.postDelayed(()->reviewNextBankCandidate(),250);}}).show();
    }
    private boolean isBankLikeForReview(String source,String sender,String raw){
        String x=normalizeBankText((source==null?"":source)+" "+(sender==null?"":sender)+" "+(raw==null?"":raw));
        boolean action=containsAny(x,"برداشت","واریز","خرید","پرداخت","انتقال","مانده","موجودی","تراکنش","کارت به کارت","پایا","ساتنا","کارمزد","withdrawal","deposit","transaction","balance");
        boolean money=x.matches("(?s).*([0-9]{1,3}([,٬][0-9]{3})+|[0-9]{4,}).*");
        boolean identity=containsAny(x,"بانک","صادرات","ملت","ملی","تجارت","بلو","blubank","بلوبانک","سامان","پاسارگاد","رفاه","کشاورزی","saderat","bank","ریال","تومان","شماره کارت","حساب");
        boolean capturedSource=containsAny(normalizeBankText(source==null?"":source),"پیامک","اعلان","notification","sms");
        return action&&money&&(identity||capturedSource);
    }

    private long parseBankTime(String s){try{return Long.parseLong(s);}catch(Exception e){return System.currentTimeMillis();}}
    private String bankField(String raw, String label, String fallback){
        if(raw==null)return fallback;
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?m)^\\s*"+java.util.regex.Pattern.quote(label)+"\\s*:\\s*(.*?)\\s*$").matcher(raw);
        return m.find()?m.group(1).trim():fallback;
    }
    private String findStatementDate(String raw){
        if(raw==null)return "";
        String labelled=bankField(raw,"تاریخ","");
        String normalized=normalizeStatementDate(labelled);
        if(!normalized.isEmpty())return normalized;
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?<!\\d)((?:13|14|19|20)\\d{2})[/-]([01]?\\d)[/-]([0-3]?\\d)(?!\\d)").matcher(normalizeDigits(raw));
        return m.find()?m.group(1)+"/"+m.group(2)+"/"+m.group(3):"";
    }
    private long statementDateMillis(String value){
        if(value==null)return System.currentTimeMillis();
        String normalizedDate=normalizeStatementDate(value);
        if(normalizedDate.isEmpty()){
            String x=normalizeDigits(value).trim();
            if(x.matches("\\d{5}(?:\\.0+)?"))try{double serial=Double.parseDouble(x);if(serial>=20000&&serial<=80000){Calendar excel=Calendar.getInstance();excel.clear();excel.set(1899,Calendar.DECEMBER,30,12,0,0);excel.add(Calendar.DAY_OF_YEAR,(int)serial);return excel.getTimeInMillis();}}catch(Exception ignored){}
            return System.currentTimeMillis();
        }
        value=normalizedDate;
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?<!\\d)((?:13|14|19|20)\\d{2})[/-]([01]?\\d)[/-]([0-3]?\\d)(?!\\d)").matcher(normalizeDigits(value));
        if(!m.find())return System.currentTimeMillis();
        int y=Integer.parseInt(m.group(1)),mo=Integer.parseInt(m.group(2)),day=Integer.parseInt(m.group(3));
        Calendar cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,12);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);
        if(y>=1900){cal.set(y,mo-1,day);return cal.getTimeInMillis();}
        // Jalali-to-Gregorian conversion; accepts the common 13xx/14xx bank statement dates.
        int jy=y-979;int jdn=365*jy+(jy/33)*8+((jy%33)+3)/4;
        for(int i=1;i<mo;i++)jdn+=(i<=6?31:30);jdn+=day-1;
        int gdn=jdn+79;int gy=1600+400*(gdn/146097);gdn%=146097;
        boolean leap=true;
        if(gdn>=36525){gdn--;gy+=100*(gdn/36524);gdn%=36524;if(gdn>=365)gdn++;else leap=false;}
        gy+=4*(gdn/1461);gdn%=1461;
        if(gdn>=366){leap=false;gdn--;gy+=gdn/365;gdn%=365;}
        int[] md={31,(leap?29:28),31,30,31,30,31,31,30,31,30,31};int gm=0;
        while(gm<12&&gdn>=md[gm]){gdn-=md[gm];gm++;}
        cal.set(gy,gm,(int)gdn+1);return cal.getTimeInMillis();
    }
    private boolean bankNamesMatch(String accountBank,String detectedBank){
        if(accountBank==null||detectedBank==null||accountBank.trim().isEmpty()||detectedBank.trim().isEmpty())return false;
        String a=normalizeBankText(accountBank),b=normalizeBankText(detectedBank);
        if(a.equals(b)||a.contains(b)||b.contains(a))return true;
        for(String[] group:bankAliases()){
            boolean accountAlias=false,detectedAlias=false;
            for(String alias:group){String key=normalizeBankText(alias);if(key.isEmpty())continue;if(a.contains(key))accountAlias=true;if(b.contains(key))detectedAlias=true;}
            if(accountAlias&&detectedAlias)return true;
        }
        return false;
    }

    private void postBankInboxItem(long id,String source,String raw,long amount,String kind,String bank){
        if(amount<=0){toast("مبلغ این ردیف مشخص نیست؛ امکان ثبت خودکار آن وجود ندارد.");return;}
        final java.util.ArrayList<String> accountNames=new java.util.ArrayList<>();final java.util.ArrayList<String> accountLabels=new java.util.ArrayList<>();
        String extractedCard="";
        java.util.regex.Matcher cardMatch=java.util.regex.Pattern.compile("(?m)^\\s*(?:شناسه حساب استخراج‌شده|چهار رقم آخر کارت)\\s*:\\s*([0-9]{4})\\s*$").matcher(normalizeDigits(raw==null?"":raw));
        if(cardMatch.find())extractedCard=cardMatch.group(1);
        boolean knownBank=bank!=null&&!bank.trim().isEmpty()&&!"نامشخص".equals(bank);
        Cursor ac=db.getReadableDatabase().rawQuery("SELECT name,COALESCE(bank_name,''),COALESCE(card_last4,'') FROM accounts WHERE book=? AND enabled=1 ORDER BY name",new String[]{activeBook});
        java.util.ArrayList<String> allNames=new java.util.ArrayList<>(),allLabels=new java.util.ArrayList<>(),bankNamesOnly=new java.util.ArrayList<>(),bankLabelsOnly=new java.util.ArrayList<>(),cardNamesOnly=new java.util.ArrayList<>(),cardLabelsOnly=new java.util.ArrayList<>();
        while(ac.moveToNext()){
            String n=ac.getString(0),bn=ac.getString(1),last=ac.getString(2);
            String label=n+(bn.isEmpty()?"":" • "+bn)+(last.isEmpty()?"":" • "+last);
            allNames.add(n);allLabels.add(label);
            if(knownBank&&bankNamesMatch(bn,bank)){bankNamesOnly.add(n);bankLabelsOnly.add(label);if(!extractedCard.isEmpty()&&extractedCard.equals(last)){cardNamesOnly.add(n);cardLabelsOnly.add(label);}}
        }
        ac.close();
        if(knownBank){
            if(!cardNamesOnly.isEmpty()){accountNames.addAll(cardNamesOnly);accountLabels.addAll(cardLabelsOnly);}
            else {accountNames.addAll(bankNamesOnly);accountLabels.addAll(bankLabelsOnly);}
        }else{accountNames.addAll(allNames);accountLabels.addAll(allLabels);}
        if(accountNames.isEmpty()){
            String reason=knownBank?"برای بانک «"+bank+"» حسابی با مشخصات سازگار در دفتر فعلی پیدا نشد. برای جلوگیری از ثبت در حساب اشتباه، ابتدا حساب درست را تعریف کن.":"هیچ حساب فعالی تعریف نشده است.";
            new AlertDialog.Builder(this).setTitle("حساب بانکی لازم است").setMessage(reason).setNegativeButton("بعداً",null).setPositiveButton("افزودن حساب",(d,w)->addAccountDialog()).show();return;
        }
        // Never preselect among several cards at the same bank. Auto-select only when the
        // detected card suffix identifies exactly one configured account.
        int preferred=(!extractedCard.isEmpty()&&cardNamesOnly.size()==1)?0:
            (extractedCard.isEmpty()&&knownBank&&bankNamesOnly.size()==1)?0:-1;
        String extractedDate=findStatementDate(raw);String dateText=bankField(raw,"تاریخ",extractedDate.isEmpty()?jalaliDate(System.currentTimeMillis()):extractedDate);
        LinearLayout f=formLayout();
        Spinner account=styledSpinner();java.util.ArrayList<String> visibleAccountLabels=new java.util.ArrayList<>();visibleAccountLabels.add("— انتخاب حساب بانکی —");visibleAccountLabels.addAll(accountLabels);account.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,visibleAccountLabels));account.setSelection(preferred>=0?preferred+1:0);
        Spinner type=styledSpinner();java.util.ArrayList<String> typeOptions=new java.util.ArrayList<>();typeOptions.add("— انتخاب نوع تراکنش —");typeOptions.add("هزینه");typeOptions.add("درآمد");type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,typeOptions));type.setSelection(0);
        Spinner cat=styledSpinner();java.util.ArrayList<String> initialCategories=new java.util.ArrayList<>();initialCategories.add("— ابتدا نوع تراکنش را انتخاب کن —");cat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,initialCategories));
        if("هزینه".equals(kind))type.setSelection(1);else if("درآمد".equals(kind))type.setSelection(2);
        type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,View view,int position,long itemId){
                java.util.ArrayList<String> options=new java.util.ArrayList<>();options.add("— انتخاب دسته‌بندی —");
                if(position>0)options.addAll(getCategoryOptions(String.valueOf(type.getSelectedItem())));
                cat.setAdapter(new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,options));cat.setSelection(0);
            }
            @Override public void onNothingSelected(AdapterView<?> parent){}
        });
        EditText note=edit("شرح تراکنش (قابل ویرایش)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);note.setMinLines(2);
        String suggestedDescription=bankField(raw,"شرح","").trim();if(suggestedDescription.isEmpty())suggestedDescription=bankField(raw,"توضیحات","").trim();if(suggestedDescription.isEmpty())suggestedDescription="تراکنش بانکی - "+bank+("نامشخص".equals(kind)?"":" - "+kind);note.setText(suggestedDescription);
        Calendar chosen=Calendar.getInstance();chosen.setTimeInMillis(statementDateMillis(dateText));Button date=button("تاریخ استخراج‌شده: "+jalaliDate(chosen.getTimeInMillis()));date.setOnClickListener(v->{Calendar cur=(Calendar)chosen.clone();new DatePickerDialog(this,(view,year,month,day)->{chosen.set(year,month,day,12,0,0);date.setText("تاریخ تراکنش: "+jalaliDate(chosen.getTimeInMillis()));},cur.get(Calendar.YEAR),cur.get(Calendar.MONTH),cur.get(Calendar.DAY_OF_MONTH)).show();});
        f.addView(text("بانک شناسایی‌شده: "+bank+"\nمبلغ استخراج‌شده: "+money(amount)+" ریال\nمنبع فایل: "+source+"\nتاریخ از گزارش بانک استخراج شده است؛ در صورت نیاز آن را اصلاح کن.",14,TEXT,true));
        if(!extractedCard.isEmpty()&&cardNamesOnly.isEmpty())f.addView(text("هشدار: چهار رقم آخر کارتِ پیام با حساب‌های تعریف‌شده تطبیق پیدا نکرد؛ حساب را با دقت انتخاب کن.",12,Color.rgb(180,95,35),true));
        if(knownBank&&bankNamesOnly.size()>1&&cardNamesOnly.size()!=1)f.addView(text("چند حساب از این بانک وجود دارد؛ هیچ‌کدام خودکار انتخاب نشده‌اند.",12,Color.rgb(180,95,35),true));
        f.addView(text("حساب بانکی مقصد/مبدأ",13,TEXT,true));f.addView(account);
        f.addView(text("نوع تراکنش",13,TEXT,true));f.addView(type);
        f.addView(text("دسته‌بندی هزینه یا درآمد (از گزینه‌های خود برنامه)",13,TEXT,true));f.addView(cat);
        f.addView(text("شرح پیشنهادی را بررسی و در صورت نیاز ویرایش کن؛ این توضیح همراه تراکنش ذخیره می‌شود.",12,DARK,false));f.addView(note);f.addView(date);
        ScrollView scroll=new ScrollView(this);scroll.addView(f);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("تکمیل اطلاعات و ثبت در حساب بانکی").setView(scroll).setNegativeButton("لغو",null).setPositiveButton("ثبت تراکنش",null).create();
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int selectedAccount=account.getSelectedItemPosition()-1;
            if(selectedAccount<0||selectedAccount>=accountNames.size()){toast("حساب بانکی مربوطه را انتخاب کن.");return;}
            if(type.getSelectedItemPosition()<1){toast("نوع تراکنش را انتخاب کن: هزینه یا درآمد.");return;}
            String ty=String.valueOf(type.getSelectedItem());
            if(cat.getSelectedItemPosition()<1){toast("دسته‌بندی را از گزینه‌های برنامه انتخاب کن.");return;}
            String categoryValue=String.valueOf(cat.getSelectedItem());String description=note.getText().toString().trim();
            if(description.isEmpty()){note.setError("شرح تراکنش را وارد کن.");note.requestFocus();return;}
            String acc=accountNames.get(selectedAccount);long when=chosen.getTimeInMillis();
            Cursor bankCursor=db.getReadableDatabase().rawQuery("SELECT bank_name FROM accounts WHERE book=? AND name=? AND enabled=1 LIMIT 1",new String[]{activeBook,acc});String selectedBank="";if(bankCursor.moveToFirst()&&!bankCursor.isNull(0))selectedBank=bankCursor.getString(0);bankCursor.close();
            if(selectedBank.trim().isEmpty()){toast("این حساب بانک مشخصی ندارد؛ برای اعمال محدودیت تاریخ، ابتدا نام بانک حساب را تکمیل کن.");return;}
            String accountCutoff=bankImportCutoff(selectedBank);if(accountCutoff.isEmpty()){toast("تاریخ معرفی این بانک در نرم‌افزار مشخص نیست؛ تراکنش ثبت نشد.");return;}
            String chosenKey=statementDateKey(jalaliDate(when));if(chosenKey.isEmpty()||chosenKey.compareTo(accountCutoff)<0){toast("تراکنش قبل از تاریخ معرفی بانک در نرم‌افزار است و اجازه ثبت ندارد.");return;}
            if(isMonthClosed(monthKey(when))){toast("این ماه بسته و بایگانی شده است؛ تاریخ را به ماه باز تغییر بده.");return;}
            Calendar dayStart=(Calendar)chosen.clone();dayStart.set(Calendar.HOUR_OF_DAY,0);dayStart.set(Calendar.MINUTE,0);dayStart.set(Calendar.SECOND,0);dayStart.set(Calendar.MILLISECOND,0);Calendar dayEnd=(Calendar)dayStart.clone();dayEnd.add(Calendar.DAY_OF_YEAR,1);
            Cursor dup=db.getReadableDatabase().rawQuery("SELECT id FROM transactions WHERE book=? AND account=? AND amount=? AND type=? AND date>=? AND date<? LIMIT 1",new String[]{activeBook,acc,String.valueOf(amount),ty,String.valueOf(dayStart.getTimeInMillis()),String.valueOf(dayEnd.getTimeInMillis())});boolean exists=dup.moveToFirst();dup.close();
            if(exists){new AlertDialog.Builder(this).setTitle("احتمال تراکنش تکراری").setMessage("تراکنشی با همین حساب، مبلغ، نوع و تاریخ وجود دارد. پیش از ثبت، گردش حساب را بررسی کن.").setNegativeButton("بازگشت",null).setPositiveButton("با این حال ثبت شود",(x,y)->{saveImportedBankTransaction(id,source,bank,acc,ty,amount,categoryValue,description,when);dialog.dismiss();}).show();return;}
            saveImportedBankTransaction(id,source,bank,acc,ty,amount,categoryValue,description,when);dialog.dismiss();
        }));dialog.show();
    }
    private void saveImportedBankTransaction(long id,String source,String bank,String account,String type,long amount,String category,String description,long when){
        ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",type);tx.put("amount",amount);tx.put("category",category);tx.put("account",account);tx.put("payment_method","انتقال بانکی");tx.put("note",description);tx.put("date",when);setMonthKey(tx,when);saveCategoryIfMissing(type,category);
        try{SQLiteDatabase sql=db.getWritableDatabase();sql.beginTransaction();try{sql.insertOrThrow("transactions",null,tx);ContentValues done=new ContentValues();done.put("status","imported");done.put("note","ثبت‌شده در حساب "+account);sql.update("bank_inbox",done,"id=?",new String[]{String.valueOf(id)});sql.setTransactionSuccessful();}finally{sql.endTransaction();}toast("تراکنش در حساب «"+account+"» ثبت شد.");showBankInbox();}catch(Exception ex){toast("ثبت انجام نشد: "+ex.getMessage());}
    }
    private void enforcePendingStatementCutoff(){
        SQLiteDatabase sql=db.getWritableDatabase();Cursor c=sql.rawQuery("SELECT id,source,raw_text,bank FROM bank_inbox WHERE status='pending' AND (source LIKE 'گزارش گردش حساب%' OR source LIKE 'گزارش PDF%')",null);
        java.util.ArrayList<long[]> blocked=new java.util.ArrayList<>();java.util.ArrayList<String> reasons=new java.util.ArrayList<>();
        while(c.moveToNext()){
            long id=c.getLong(0);String source=c.getString(1)==null?"":c.getString(1);String raw=c.getString(2)==null?"":c.getString(2);String bank=c.getString(3)==null?"":c.getString(3);
            String cutoff=bankImportCutoff(bank);String date=findStatementDate(raw);String key=statementDateKey(date);
            if(cutoff.isEmpty()||key.isEmpty()||key.compareTo(cutoff)<0){blocked.add(new long[]{id});reasons.add(cutoff.isEmpty()?"تاریخ شروع بانک مشخص نیست":key.isEmpty()?"تاریخ تراکنش قابل تشخیص نیست":"تراکنش قبل از تاریخ شروع بانک است");}
        }c.close();
        for(int i=0;i<blocked.size();i++){ContentValues v=new ContentValues();v.put("status","blocked_cutoff");v.put("note",reasons.get(i));sql.update("bank_inbox",v,"id=?",new String[]{String.valueOf(blocked.get(i)[0])});}
    }
    private void showBankInbox(){
        enforcePendingStatementCutoff();body.removeAllViews();setHeaderInfo("موارد نیازمند بررسی","فقط تراکنش‌هایی که تطبیق خودکارشان قطعی نبود");
        addHeading("موارد نیازمند بررسی");addEmpty("موارد قطعی و غیرتکراری خودکار ثبت شده‌اند. این فهرست فقط شامل موارد مبهم، حساب نامشخص یا اطلاعات ناقص است؛ موارد مشابه قبلی نیز برای جلوگیری از دوباره‌شماری خودکار رد می‌شوند.");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,source,raw_text,amount,kind,bank FROM bank_inbox WHERE status='pending' ORDER BY received_at DESC",null);
        if(!c.moveToFirst()){c.close();addEmpty("موردی برای بررسی وجود ندارد.");return;}
        do{
            final long id=c.getLong(0);final String source=c.getString(1),raw=c.getString(2),kind=c.getString(4)==null?"نامشخص":c.getString(4),bank=c.getString(5)==null?"نامشخص":c.getString(5);final long amount=c.isNull(3)?0:c.getLong(3);
            String extractedDate=findStatementDate(raw);String date=bankField(raw,"تاریخ",extractedDate.isEmpty()?"تاریخ نامشخص":extractedDate),desc=bankField(raw,"شرح",raw==null?"جزئیات در متن خام":raw.replace('\n',' ')),category=bankField(raw,"دسته‌بندی پیشنهادی","");
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(roundBg(Color.WHITE));card.setElevation(dp(1));
            card.addView(text(bank+" • "+(amount>0?money(amount)+" ریال":"مبلغ نامشخص"),16,TEXT,true));card.addView(text("تاریخ: "+date+"\nنوع پیشنهادی: "+kind+"\nشرح: "+desc+(category.isEmpty()?"":"\nدسته‌بندی: "+category)+"\nمنبع فایل: "+source,13,TEXT,false));
            TextView more=text("مشاهده ردیف کامل بانک ▾",12,GREEN,true);card.addView(more);more.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("جزئیات اصلی ردیف بانک").setMessage(raw).setPositiveButton("بستن",null).show());
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);Button post=button("ثبت در حساب");Button reject=button("رد ردیف");actions.addView(post,new LinearLayout.LayoutParams(0,-2,1));actions.addView(reject,new LinearLayout.LayoutParams(0,-2,1));card.addView(actions);post.setOnClickListener(v->postBankInboxItem(id,source,raw,amount,kind,bank));reject.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("رد این ردیف؟").setMessage("این مورد از صندوق بررسی حذف می‌شود و وارد حسابداری نمی‌شود.").setNegativeButton("بازگشت",null).setPositiveButton("رد ردیف",(d,w)->{db.getWritableDatabase().delete("bank_inbox","id=?",new String[]{String.valueOf(id)});showBankInbox();}).show());
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(7));body.addView(card,lp);
        }while(c.moveToNext());c.close();
    }
    private void showSettings() {
        setHeaderInfo("تنظیمات", "دفتر، پشتیبان‌گیری و تنظیمات برنامه");
        body.removeAllViews();addHeading("تنظیمات");
        addWideButton("مدیریت ورود هوشمند بانکی",()->showSmartBankImport());
        addWideButton("مدیریت آیکن‌های دسترسی سریع خانه",()->manageQuickActions());
        addWideButton("مدیریت دفترها",()->manageBooks());
        addWideButton("مدیریت حساب‌ها و موجودی",()->showAccounts());
        addWideButton("مدیریت دارایی‌ها و اموال",()->showAssets());
        addWideButton("بستن ماه و مشاهده بایگانی ماهانه",()->showMonthClosing());
        addWideButton("افزودن حساب بانکی یا کیف پول",()->addAccountDialog());
        addWideButton("مدیریت دسته‌بندی‌ها",()->manageCategories());
        addWideButton("بودجه‌بندی ماهانه و هشدار هزینه",()->showBudgets());
        addWideButton("پرداخت‌های تکرارشونده و سررسیدها",()->showRecurring());
        addWideButton("هدف‌های پس‌انداز",()->showGoals());
        addWideButton("خروجی گزارش تراکنش‌ها (CSV؛ سازگار با Excel)",()->exportTransactionsCsv());
        addWideButton("گزارش مالی و مقایسه ماه‌ها",()->showReports());
        boolean hidden=getPreferences(0).getBoolean("hide_amounts",false);
        addWideButton(hidden?"نمایش مبالغ مالی":"مخفی‌کردن مبالغ مالی",()->{boolean next=!getPreferences(0).getBoolean("hide_amounts",false);getPreferences(0).edit().putBoolean("hide_amounts",next).apply();toast(next?"مبالغ در صفحه‌ها مخفی شدند":"نمایش مبالغ فعال شد");showSettings();});
        long lastBackup=getPreferences(0).getLong("last_auto_backup_at",0L);
        addEmpty(lastBackup==0?"آخرین پشتیبان خودکار: هنوز ثبت نشده":"آخرین پشتیبان خودکار: "+jalaliDate(lastBackup)+" • "+new SimpleDateFormat("HH:mm",new Locale("fa","IR")).format(new Date(lastBackup)));
        addWideButton("بدهی‌ها، طلب‌ها و تسویه",()->showDebts());
        addWideButton("قفل برنامه با رمز عددی",()->setPinDialog());
        addWideButton("پشتیبان‌گیری از اطلاعات (انتخاب محل ذخیره)",()->exportBackup());
        addWideButton("ساخت پشتیبان خودکار همین حالا",()->{try{createAutomaticBackup();toast("پشتیبان خودکار روی گوشی ذخیره شد.");}catch(Exception e){toast("پشتیبان‌گیری ناموفق بود: "+e.getMessage());}});
        addWideButton("بازیابی پشتیبان",()->importBackup());
        addWideButton("🧹 حذف انتخابی اطلاعات برنامه",()->showSelectiveDeleteDialog());
        addWideButton("درباره برنامه",()->showAboutDialog());
        addEmpty("واحد مبالغ: ریال • تاریخ نمایشی: شمسی");
    }

    private void showBankImport() {
        String[] choices={"فعال‌سازی دریافت پیامک بانکی","فعال‌سازی دریافت اعلان‌های بانکی (مانند بلو)","بررسی موارد شناسایی‌شده","ورود متن پیامک یا ردیف‌های گزارش CSV"};
        new AlertDialog.Builder(this).setTitle("ورود هوشمند بانکی").setItems(choices,(d,w)->{
            if(w==0){if(Build.VERSION.SDK_INT>=23&&checkSelfPermission("android.permission.RECEIVE_SMS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.RECEIVE_SMS"},731);}else{android.preference.PreferenceManager.getDefaultSharedPreferences(this).edit().putBoolean("bank_sms_enabled",true).apply();toast("دریافت پیامک فعال شد؛ موارد ابتدا برای بررسی نگهداری می‌شوند.");}}
            else if(w==1){android.preference.PreferenceManager.getDefaultSharedPreferences(this).edit().putBoolean("bank_notifications_enabled",true).apply();try{startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));}catch(Exception e){toast("تنظیم دسترسی اعلان‌ها در دسترس نیست.");}}
            else if(w==2)showBankCandidateQueue(); else showBankTextPaste();
        }).setNegativeButton("بستن",null).show();
    }
    private void showBankCandidateQueue(){
        android.content.SharedPreferences p=getSharedPreferences("bank_import_candidates",MODE_PRIVATE);
        java.util.Map<String,?> all=p.getAll();
        java.util.ArrayList<String> keys=new java.util.ArrayList<>(), labels=new java.util.ArrayList<>(), values=new java.util.ArrayList<>();
        for(java.util.Map.Entry<String,?> e:all.entrySet()){
            if(!e.getKey().startsWith("candidate_")||!(e.getValue() instanceof String))continue;
            String value=(String)e.getValue();String[] a=value.split("\n",4);
            if(a.length<4)continue;
            if(!isBankLikeForReview(a[0],a[2],a[3]))continue;
            keys.add(e.getKey());values.add(value);
            String source=a[0],body=a[3].replace('\n',' ');
            labels.add(source+" • "+(a[2].isEmpty()?"پیام بانکی":a[2])+"\n"+body);
        }
        if(keys.isEmpty()){
            new AlertDialog.Builder(this).setTitle("صف پیامک‌ها و اعلان‌های بانکی")
              .setMessage("پیام بانکیِ دریافت‌نشده برای بررسی وجود ندارد. اگر موردی در صندوق بررسی مالی است، از گزینه «صندوق بررسی مالی» وارد شوید.")
              .setPositiveButton("باشه",null).show();return;
        }
        String[] items=labels.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("یک پیام بانکی را برای بررسی انتخاب کن")
          .setItems(items,(dialog,which)->{
              String key=keys.get(which),value=values.get(which);String[] a=value.split("\n",4);
              String source=a[0],timeText=a[1],sender=a[2],raw=a[3];long timestamp=parseBankTime(timeText);
              new AlertDialog.Builder(this).setTitle("بررسی پیام بانکی")
                .setMessage(raw+"\n\nبا ادامه، تمام عددهای موجود در همین پیام نمایش داده می‌شوند. خودت مبلغ تراکنش را انتخاب می‌کنی؛ سپس فرم ثبت باز خواهد شد.")
                .setNegativeButton("بازگشت",null)
                .setNeutralButton("نادیده گرفتن",(d,w)->{p.edit().remove(key).apply();toast("پیام از صف بررسی کنار گذاشته شد.");})
                .setPositiveButton("انتخاب مبلغ",(d,w)->chooseBankCandidateAmount(key,raw,source,sender,timestamp,p)).show();
          }).setNegativeButton("بستن",null).show();
    }
    private void showBankTextPaste(){EditText e=edit("متن پیامک یا ردیف CSV را وارد کنید",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);e.setMinLines(5);new AlertDialog.Builder(this).setTitle("ورود دستی متن بانکی").setView(e).setNegativeButton("لغو",null).setPositiveButton("افزودن به بررسی",(d,w)->{String raw=e.getText().toString().trim();if(raw.isEmpty())return;BankSmsReceiver.save(this,"MANUAL","",raw,System.currentTimeMillis());toast("به صف بررسی اضافه شد؛ هنوز ثبت مالی نشده است.");}).show();}

    private void showSelectiveDeleteDialog() {
        final String[] labels = {
            "تراکنش‌های درآمد و هزینه و انتقال‌ها",
            "حساب‌های بانکی و کیف پول‌ها",
            "دفترهای حسابداری",
            "دسته‌بندی‌های درآمد و هزینه",
            "بدهی‌ها و طلب‌ها",
            "چک‌ها",
            "دارایی‌ها و اموال",
            "بودجه‌بندی‌ها",
            "پرداخت‌های تکرارشونده و سررسیدها",
            "هدف‌های پس‌انداز",
            "بایگانی و ماه‌های بسته‌شده",
            "تنظیمات محلی برنامه (از جمله نمایش مبالغ و آخرین پشتیبان)"
        };
        final String[][] tables = {
            {"transactions"}, {"accounts"}, {"books"}, {"categories"}, {"debts"},
            {"cheques"}, {"assets"}, {"budgets"}, {"recurring"}, {"goals"}, {"closed_months"}, {}
        };
        boolean[] checked = new boolean[labels.length];
        new AlertDialog.Builder(this)
            .setTitle("انتخاب اطلاعات برای حذف")
            .setMultiChoiceItems(labels, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
            .setNeutralButton("انتخاب همه", (dialog, which) -> showSelectAllDeleteDialog(labels, tables))
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ادامه", (dialog, which) -> {
                java.util.ArrayList<String> selectedTables = new java.util.ArrayList<>();
                java.util.ArrayList<String> selectedLabels = new java.util.ArrayList<>();
                boolean clearPrefs = false;
                for (int i = 0; i < checked.length; i++) if (checked[i]) {
                    selectedLabels.add(labels[i]);
                    if (i == labels.length - 1) clearPrefs = true;
                    for (String table : tables[i]) selectedTables.add(table);
                }
                if (selectedTables.isEmpty() && !clearPrefs) { toast("هیچ موردی انتخاب نشده است"); return; }
                final boolean prefsToClear = clearPrefs;
                String summary = android.text.TextUtils.join("\n• ", selectedLabels);
                new AlertDialog.Builder(this)
                    .setTitle("تأیید حذف انتخابی")
                    .setMessage("موارد زیر حذف می‌شوند و قابل بازگشت نیستند:\n• " + summary + "\n\nپیشنهاد می‌شود ابتدا فایل پشتیبان خارج از برنامه ذخیره کنی.")
                    .setNegativeButton("بازگشت", null)
                    .setPositiveButton("حذف موارد انتخاب‌شده", (d, w) -> deleteSelectedData(selectedTables, prefsToClear))
                    .show();
            })
            .show();
    }

    private void showSelectAllDeleteDialog(String[] labels, String[][] tables) {
        final boolean[] checked = new boolean[labels.length];
        java.util.Arrays.fill(checked, true);
        new AlertDialog.Builder(this).setTitle("انتخاب همه موارد")
            .setMultiChoiceItems(labels, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ادامه", (dialog, which) -> {
                java.util.ArrayList<String> selectedTables = new java.util.ArrayList<>();
                java.util.ArrayList<String> selectedLabels = new java.util.ArrayList<>();
                boolean clearPrefs = false;
                for (int i=0;i<checked.length;i++) if (checked[i]) {
                    selectedLabels.add(labels[i]); if (i==labels.length-1) clearPrefs=true;
                    for (String table:tables[i]) selectedTables.add(table);
                }
                if (selectedTables.isEmpty() && !clearPrefs) { toast("هیچ موردی انتخاب نشده است"); return; }
                final boolean prefsToClear = clearPrefs;
                new AlertDialog.Builder(this).setTitle("تأیید نهایی حذف")
                    .setMessage("حذف این موارد دائمی است:\n• " + android.text.TextUtils.join("\n• ", selectedLabels) + "\n\nادامه می‌دهی؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("تأیید حذف", (d,w) -> deleteSelectedData(selectedTables, prefsToClear)).show();
            }).show();
    }

    private void deleteSelectedData(java.util.ArrayList<String> selectedTables, boolean clearPrefs) {
        SQLiteDatabase sql = null;
        try {
            sql = db.getWritableDatabase();
            sql.beginTransaction();
            try {
                for (String table : selectedTables) {
                    // Names are selected from a fixed allowlist above.
                    sql.delete("\"" + table + "\"", null, null);
                }
                sql.setTransactionSuccessful();
            } finally { sql.endTransaction(); }
            if (clearPrefs) getPreferences(0).edit().clear().apply();
            if (selectedTables.contains("books")) {
                activeBook = "شخصی";
                ensureDefaults();
            } else if (selectedTables.contains("accounts")) {
                // Account deletion does not remove transactions; the user selected these separately.
            }
            page = "تنظیمات";
            showShell(); showSettings();
            toast("موارد انتخاب‌شده حذف شدند.");
        } catch (Exception e) {
            Log.e("HisabYarReset", "Selective delete failed", e);
            toast("حذف انجام نشد: " + (e.getMessage() == null ? "خطای نامشخص" : e.getMessage()));
        }
    }

    private void showAboutDialog() {
        LinearLayout content=formLayout();
        content.addView(text("حساب‌یار پرو • نسخه ۱.۱۰.۷",19,selectedThemeColor(),true));
        content.addView(text("برنامهٔ حسابداری فارسی با ذخیره‌سازی محلی روی گوشی، دفترهای جداگانه، حساب‌ها، تراکنش‌ها، دستیار صوتی، گزارش مالی، بودجه، دارایی‌ها، بدهی و طلب و پشتیبان‌گیری.",14,TEXT,false));
        content.addView(text("طراح و برنامه‌نویس: مهدی ساریخانی فرد\nشماره تماس: ۰۹۱۲۱۳۹۸۸۹۳",13,TEXT,false));
        LinearLayout themeCard = new LinearLayout(this);
        themeCard.setOrientation(LinearLayout.VERTICAL);
        themeCard.setPadding(dp(12),dp(10),dp(12),dp(10));
        android.graphics.drawable.GradientDrawable themeCardBg = roundBg(lighten(selectedThemeColor(),0.92f));
        themeCardBg.setStroke(dp(1),lighten(selectedThemeColor(),0.45f));
        themeCard.setBackground(themeCardBg);
        LinearLayout.LayoutParams themeCardLp = new LinearLayout.LayoutParams(-1,-2);
        themeCardLp.setMargins(0,dp(12),0,0);
        themeCard.addView(text("انتخاب رنگ برنامه",16,selectedThemeColor(),true));
        themeCard.addView(text("رنگ دلخواه را انتخاب کنید. این رنگ در ظاهر برنامه و نوارهای سیستم اعمال می‌شود.",12,TEXT,false));
        showThemePalette(themeCard);
        content.addView(themeCard,themeCardLp);
        new AlertDialog.Builder(this).setTitle("درباره برنامه").setView(content).setPositiveButton("باشه",null).show();
    }

    private void showBudgets() {
        setHeaderInfo("بودجه‌بندی", "سقف هزینه ماهانه هر دسته را بررسی کنید");
        body.removeAllViews();addHeading("بودجه‌بندی ماهانه");
        addWideButton("＋ تعریف سقف هزینه برای دسته‌بندی",()->budgetDialog());
        String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT category,limit_amount FROM budgets WHERE book=? AND month=? ORDER BY category",new String[]{activeBook,month});
        if(!c.moveToFirst()){c.close();addEmpty("برای این ماه بودجه‌ای تعریف نشده است.");return;}
        do {String cat=c.getString(0);long limit=c.getLong(1),spent=categoryExpenseThisMonth(cat);int pct=limit<=0?0:(int)Math.min(100,spent*100.0/limit);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(cat,15,TEXT,true));card.addView(text("هزینه: "+money(spent)+" / بودجه: "+money(limit),13,TEXT,false));
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(pct);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(8)));
            card.addView(text(pct>=100?"هشدار: بودجه مصرف شده است":"مصرف بودجه: "+pct+"٪",12,pct>=100?Color.rgb(204,103,112):GREEN,false));body.addView(card,new LinearLayout.LayoutParams(-1,-2));
        }while(c.moveToNext());c.close();
    }
    private void budgetDialog() {
        LinearLayout f=formLayout();EditText cat=edit("دسته‌بندی هزینه (مثلاً خوراک)",InputType.TYPE_CLASS_TEXT),limit=edit("سقف بودجه ماهانه به ریال",InputType.TYPE_CLASS_NUMBER);f.addView(cat);f.addView(limit);
        new AlertDialog.Builder(this).setTitle("تعریف بودجه ماه جاری").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String name=cat.getText().toString().trim();long amount=parseAmount(limit.getText().toString());if(name.isEmpty()||amount<=0){toast("دسته‌بندی و سقف معتبر وارد کن");return;}String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());SQLiteDatabase sql=db.getWritableDatabase();sql.delete("budgets","book=? AND category=? AND month=?",new String[]{activeBook,name,month});ContentValues v=new ContentValues();v.put("book",activeBook);v.put("category",name);v.put("month",month);v.put("limit_amount",amount);sql.insert("budgets",null,v);showBudgets();}).show();
    }
    private long categoryExpenseThisMonth(String cat) {
        Calendar cal=Calendar.getInstance();cal.set(Calendar.DAY_OF_MONTH,1);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);long start=cal.getTimeInMillis();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type='هزینه' AND category=? AND date>=?",new String[]{activeBook,cat,String.valueOf(start)});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;
    }
    private void saveTransactionWithDuplicateWarning(ContentValues values,String type,long amount,String category,String account,long date,Runnable onSaved) {
        long from=date-24L*60*60*1000, to=date+24L*60*60*1000;
        Cursor duplicate=db.getReadableDatabase().rawQuery("SELECT date,note FROM transactions WHERE book=? AND type=? AND amount=? AND COALESCE(category,'')=? AND COALESCE(account,'')=? AND date>=? AND date<=? ORDER BY ABS(date-?) LIMIT 1",new String[]{activeBook,type,String.valueOf(amount),category==null?"":category,account==null?"":account,String.valueOf(from),String.valueOf(to),String.valueOf(date)});
        boolean found=duplicate.moveToFirst();String oldDate=found?jalaliDate(duplicate.getLong(0)):"";duplicate.close();
        Runnable save=()->{long id=db.getWritableDatabase().insert("transactions",null,values);if(id==-1){toast("ثبت تراکنش انجام نشد؛ دوباره بررسی کن.");return;}if(onSaved!=null)onSaved.run();};
        if(found)new AlertDialog.Builder(this).setTitle("احتمال ثبت تکراری").setMessage("تراکنشی با همین نوع، مبلغ، دسته‌بندی و حساب در تاریخ "+oldDate+" وجود دارد. اگر این یک پرداخت/دریافت جداگانه است، می‌توانی ثبت را ادامه بدهی.").setNegativeButton("بازگشت و بررسی",null).setPositiveButton("با این حال ثبت شود",(d,w)->save.run()).show();else save.run();
    }

    private void showReports() {
        setHeaderInfo("گزارش مالی", "خلاصه ساده وضعیت مالی و مقایسه ماه جاری با ماه قبل");
        body.removeAllViews();
        addWideButton("چاپ یا ذخیره گزارش به‌صورت PDF",()->printFinancialReport());
        addWideButton("خروجی تراکنش‌ها برای Excel (CSV)",()->exportTransactionsCsv());
        addHeading("خلاصه وضعیت مالی دفتر «"+activeBook+"»");
        long income=sum("درآمد"),expense=sum("هزینه"),assets=scalar("SELECT COALESCE(SUM(value),0) FROM assets WHERE book=?",activeBook),receivable=scalar("SELECT COALESCE(SUM(amount-paid),0) FROM debts WHERE book=? AND kind LIKE '%طلب%'",activeBook),payable=scalar("SELECT COALESCE(SUM(amount-paid),0) FROM debts WHERE book=? AND kind LIKE '%بدهی%'",activeBook);
        addMetric("موجودی حساب‌ها (محاسبه‌شده)",money(balance()),GREEN);
        addMetric("مجموع درآمدهای ثبت‌شده",money(income),GREEN);
        addMetric("مجموع هزینه‌های ثبت‌شده",money(expense),Color.rgb(204,103,112));
        addMetric("خالص درآمد منهای هزینه",money(income-expense),income>=expense?GREEN:Color.rgb(204,103,112));
        addMetric("ارزش دارایی‌های غیرنقدی",money(assets),GREEN);
        addMetric("طلب‌های باقی‌مانده",money(receivable),GREEN);
        addMetric("بدهی‌های باقی‌مانده",money(payable),Color.rgb(204,103,112));
        addMetric("ارزش خالص تقریبی",money(balance()+assets+receivable-payable),GREEN);

        String currentJalaliMonth=monthKey(System.currentTimeMillis());String previousJalaliMonth=previousJalaliMonthKey(currentJalaliMonth);
        long thisIncome=sumForMonth("درآمد",currentJalaliMonth),thisExpense=sumForMonth("هزینه",currentJalaliMonth),prevIncome=sumForMonth("درآمد",previousJalaliMonth),prevExpense=sumForMonth("هزینه",previousJalaliMonth);
        addHeading("مقایسه ماه جاری با ماه قبل");
        addEmpty("ماه جاری تا امروز: درآمد "+money(thisIncome)+" و هزینه "+money(thisExpense)+"\nماه قبل: درآمد "+money(prevIncome)+" و هزینه "+money(prevExpense)+"\nتغییر هزینه: "+changeText(thisExpense,prevExpense));
        addHeading("بیشترین گروه هزینه در ماه جاری");
        Cursor top=db.getReadableDatabase().rawQuery("SELECT category,COALESCE(SUM(amount),0) total FROM transactions WHERE book=? AND type='هزینه' AND month_key=? GROUP BY category ORDER BY total DESC LIMIT 1",new String[]{activeBook,currentJalaliMonth});
        if(top.moveToFirst())addEmpty(top.getString(0)+" • "+money(top.getLong(1)));else addEmpty("در ماه جاری هنوز هزینه‌ای ثبت نشده است.");top.close();
        addHeading("هزینه بر اساس دسته‌بندی (کل سوابق)");Cursor c=db.getReadableDatabase().rawQuery("SELECT category,SUM(amount) total FROM transactions WHERE book=? AND type='هزینه' GROUP BY category ORDER BY total DESC",new String[]{activeBook});if(!c.moveToFirst())addEmpty("هنوز هزینه‌ای ثبت نشده است.");else do{addEmpty((c.getString(0)==null?"بدون دسته‌بندی":c.getString(0))+" • "+money(c.getLong(1)));}while(c.moveToNext());c.close();
        addHeading("خلاصه ۳۰ روز اخیر");long since=System.currentTimeMillis()-30L*24*60*60*1000;addEmpty("درآمد: "+money(sumSince("درآمد",since))+"\nهزینه: "+money(sumSince("هزینه",since)));
        addEmpty("مقایسه‌ها بر اساس تراکنش‌های ثبت‌شده‌اند؛ پیش‌بینی قطعی آینده نیستند.");
    }
    private void printFinancialReport() {
        if(getPreferences(0).getBoolean("hide_amounts",false)) {
            new AlertDialog.Builder(this).setTitle("گزارش PDF شامل مبالغ واقعی است").setMessage("مخفی‌کردن مبالغ فقط نمایش داخل برنامه را تغییر می‌دهد. فایل گزارش برای استفادهٔ مالی، مبالغ واقعی را شامل می‌شود. ادامه می‌دهی؟").setNegativeButton("انصراف",null).setPositiveButton("ادامه و چاپ",(d,w)->printFinancialReportInternal()).show();
            return;
        }
        printFinancialReportInternal();
    }
    private void printFinancialReportInternal() {
        try {
            String currentJalaliMonth=monthKey(System.currentTimeMillis());
            StringBuilder rows=new StringBuilder();Cursor c=db.getReadableDatabase().rawQuery("SELECT date,type,amount,category,account,note FROM transactions WHERE book=? ORDER BY date DESC LIMIT 500",new String[]{activeBook});
            while(c.moveToNext())rows.append("<tr><td>").append(htmlEscape(jalaliDate(c.getLong(0)))).append("</td><td>").append(htmlEscape(c.getString(1))).append("</td><td class='num'>").append(NumberFormat.getInstance(new Locale("fa","IR")).format(c.getLong(2))).append(" ریال</td><td>").append(htmlEscape(c.getString(3))).append("</td><td>").append(htmlEscape(c.getString(4))).append("</td><td>").append(htmlEscape(c.getString(5))).append("</td></tr>");c.close();
            long mi=sumForMonth("درآمد",currentJalaliMonth),me=sumForMonth("هزینه",currentJalaliMonth);
            String html="<!doctype html><html lang='fa' dir='rtl'><head><meta charset='UTF-8'><style>body{font-family:sans-serif;direction:rtl;color:#222;padding:18px}h1,h2{color:#8e2343}table{width:100%;border-collapse:collapse;font-size:10pt}th,td{border:1px solid #bbb;padding:6px;text-align:right}th{background:#f7e5eb}.num{white-space:nowrap}.summary{padding:10px;background:#fff4f7;margin:10px 0}@page{size:A4;margin:12mm}</style></head><body><h1>گزارش مالی حساب‌یار پرو</h1><p>دفتر: "+htmlEscape(activeBook)+"</p><p>تاریخ تهیه: "+htmlEscape(jalaliDate(System.currentTimeMillis()))+"</p><div class='summary'>موجودی حساب‌ها: "+htmlEscape(moneyExport(balance()))+"<br>درآمد کل: "+htmlEscape(moneyExport(sum("درآمد")))+"<br>هزینه کل: "+htmlEscape(moneyExport(sum("هزینه")))+"<br>درآمد ماه جاری: "+htmlEscape(moneyExport(mi))+"<br>هزینه ماه جاری: "+htmlEscape(moneyExport(me))+"</div><h2>تراکنش‌ها (حداکثر ۵۰۰ مورد اخیر)</h2><table><thead><tr><th>تاریخ</th><th>نوع</th><th>مبلغ</th><th>دسته‌بندی</th><th>حساب</th><th>شرح</th></tr></thead><tbody>"+rows+"</tbody></table><p>این گزارش بر اساس اطلاعات ثبت‌شده در دفتر انتخاب‌شده تهیه شده است.</p></body></html>";
            WebView web=new WebView(this);web.getSettings().setJavaScriptEnabled(false);web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){try{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);if(pm==null){toast("سرویس چاپ در این گوشی در دسترس نیست.");return;}PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("hisabyar_pdf","HisabYar PDF",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();pm.print("HisabYar_"+activeBook,view.createPrintDocumentAdapter("HisabYar_Report"),attrs);}catch(Exception e){toast("آماده‌سازی PDF ناموفق بود: "+e.getMessage());}}});web.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);
        } catch(Exception e) { toast("تهیه گزارش PDF ناموفق بود: "+e.getMessage()); }
    }
    private String htmlEscape(String value){if(value==null)return "";return value.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
    private String moneyExport(long n){return NumberFormat.getInstance(new Locale("fa","IR")).format(n)+" ریال";}

    private long sumForMonth(String type,String month){Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=? AND month_key=?",new String[]{activeBook,type,month});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    private String previousJalaliMonthKey(String current){try{String normalized=normalizeDigits(current);String[] parts=normalized.split("-");int year=Integer.parseInt(parts[0]),month=Integer.parseInt(parts[1]);if(month<=1){year--;month=12;}else month--;return String.format(new Locale("fa","IR"),"%04d-%02d",year,month);}catch(Exception e){return current;}}
    private String changeText(long current,long previous){if(previous==0)return current==0?"بدون تغییر (هزینه‌ای ثبت نشده)":"در ماه قبل مبنایی برای مقایسه وجود ندارد";double pct=((double)current-(double)previous)*100.0/(double)previous;return String.format(new Locale("fa","IR"),"%+.1f درصد",pct);}
    private long scalar(String query,String book){Cursor c=db.getReadableDatabase().rawQuery(query,new String[]{book});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    private long sumSince(String type,long since){Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=? AND date>=?",new String[]{activeBook,type,String.valueOf(since)});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    private void exportBackup() {
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"HisabYar-backup.db");startActivityForResult(i,REQ_EXPORT_BACKUP);
    }
    private void importBackup() {
        final java.util.ArrayList<File> found = collectAutomaticBackupFiles();
        final File[] choices = found.toArray(new File[0]);
        String[] labels = new String[choices.length == 0 ? 1 : choices.length];
        if (choices.length == 0) {
            labels[0] = "هیچ پشتیبان خودکاری پیدا نشد؛ فایل دستی را انتخاب کنید";
        } else {
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss", Locale.getDefault());
            for (int i=0;i<choices.length;i++) {
                File f=choices[i];
                labels[i] = fmt.format(new Date(f.lastModified())) + "\n" + f.getName() + " • " + android.text.format.Formatter.formatShortFileSize(this, f.length());
            }
        }
        final int[] selected={-1};
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle("پشتیبان‌های خودکار روی گوشی ("+choices.length+")")
            .setSingleChoiceItems(labels,-1,(d,w)->{if(choices.length>0)selected[0]=w;})
            .setNegativeButton("بستن",null)
            .setNeutralButton("انتخاب فایل دستی",(d,w)->openManualBackupPicker())
            .setPositiveButton("بازیابی انتخاب‌شده",null).create();
        dialog.setOnShowListener(v->{
            Button restore=dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            restore.setEnabled(choices.length>0);
            restore.setOnClickListener(view->{int i=selected[0]; if(i<0||i>=choices.length){toast("ابتدا یک پشتیبان را از فهرست انتخاب کنید.");return;} dialog.dismiss();confirmRestoreBackup(choices[i]);});
        });
        dialog.show();
    }

    private java.util.ArrayList<File> collectAutomaticBackupFiles() {
        java.util.LinkedHashMap<String,File> unique=new java.util.LinkedHashMap<>();
        java.util.ArrayList<File> roots=new java.util.ArrayList<>();
        roots.add(new File(getFilesDir(),"auto_backups"));
        roots.add(getFilesDir());
        File ext=getExternalFilesDir(null); if(ext!=null){roots.add(new File(ext,"auto_backups"));roots.add(new File(ext,"Backups"));roots.add(new File(ext,"HisabYar/Backups"));}
        File docs=getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS); if(docs!=null){roots.add(new File(docs,"HisabYar/Backups"));roots.add(new File(docs,"auto_backups"));}
        for(File root:roots) scanBackupTree(root,0,unique);
        java.util.ArrayList<File> result=new java.util.ArrayList<>(unique.values());
        java.util.Collections.sort(result,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        return result;
    }

    private void scanBackupTree(File dir,int depth,java.util.Map<String,File> out) {
        if(dir==null||!dir.exists()||!dir.isDirectory()||depth>3)return;
        File[] files=dir.listFiles(); if(files==null)return;
        for(File f:files){
            if(f.isDirectory()){if(!f.getName().equals("cache")&&!f.getName().equals("code_cache"))scanBackupTree(f,depth+1,out);continue;}
            if(!f.isFile()||f.length()==0)continue;
            String n=f.getName().toLowerCase(Locale.ROOT);
            boolean backupName=(n.endsWith(".db")||n.endsWith(".sqlite")||n.endsWith(".sqlite3")) && (n.contains("backup")||n.contains("back_up")||n.contains("auto")||n.contains("hisabyar"));
            if(!backupName||n.equals("hisabyar.db")||n.contains("restore"))continue;
            try {out.put(f.getCanonicalPath(),f);}catch(IOException ignored){out.put(f.getAbsolutePath(),f);}
        }
    }

    private void openManualBackupPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/x-sqlite3", "application/vnd.sqlite3", "application/db", "application/x-db"});
        try { startActivityForResult(i, REQ_IMPORT_BACKUP); }
        catch (Exception e) { toast("باز کردن انتخاب‌گر فایل ممکن نشد."); }
    }

    private void confirmRestoreBackup(File source) {
        new AlertDialog.Builder(this)
            .setTitle("تأیید بازیابی")
            .setMessage("فایل انتخاب‌شده ابتدا بررسی می‌شود. اگر سالم و متعلق به حساب‌یار باشد، اطلاعات فعلی جایگزین خواهد شد. قبل از جایگزینی، یک نسخهٔ پشتیبان ایمنی از اطلاعات فعلی ساخته می‌شود. ادامه می‌دهی؟")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("بررسی و بازیابی", (d, w) -> {
                try { restoreBackupFile(source); }
                catch (Exception e) {
                    try { if (db == null) db = new DB(this); db.getWritableDatabase(); } catch (Exception reopenError) { Log.e("HisabYarBackup", "Database reopen after restore failure failed", reopenError); }
                    toast("بازیابی انجام نشد: " + e.getMessage());
                }
            }).show();
    }

    private void restoreBackupFile(File source) throws IOException {
        if (source == null || !source.isFile() || source.length() == 0) throw new IOException("فایل پشتیبان خالی یا در دسترس نیست.");
        File temp = new File(getCacheDir(), "hisabyar_restore.tmp");
        if (!source.getCanonicalFile().equals(temp.getCanonicalFile())) {
            try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(temp)) { copy(in, out); }
        }
        SQLiteDatabase check = null;
        try {
            check = SQLiteDatabase.openDatabase(temp.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            Cursor integrity = check.rawQuery("PRAGMA integrity_check", null);
            boolean healthy = integrity.moveToFirst() && "ok".equalsIgnoreCase(integrity.getString(0));
            integrity.close();
            Cursor tables = check.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('books','accounts','transactions','debts','assets','budgets')", null);
            boolean valid = tables.moveToFirst() && tables.getInt(0) >= 6;
            tables.close();
            if (!healthy || !valid) throw new IOException("فایل انتخاب‌شده پشتیبان معتبر حساب‌یار نیست.");
        } catch (android.database.SQLException e) {
            throw new IOException("فایل انتخاب‌شده پایگاه دادهٔ معتبر حساب‌یار نیست.", e);
        } finally { if (check != null) check.close(); }

        // Preserve the current data before replacing it when it contains user records.
        // An empty database must not block recovery from a valid older backup.
        try { createAutomaticBackup(); }
        catch (IOException backupError) {
            if (db != null && hasMeaningfulUserData(db.getReadableDatabase()))
                throw new IOException("پشتیبان ایمنی از اطلاعات فعلی ساخته نشد؛ برای جلوگیری از خطر، بازیابی متوقف شد: " + backupError.getMessage(), backupError);
            Log.w("HisabYarBackup", "Current database is empty/unusable; proceeding with verified restore", backupError);
        }
        File dest = getDatabasePath("hisabyar.db");
        File replacement = new File(dest.getParentFile(), "hisabyar.restore.new");
        File previous = new File(dest.getParentFile(), "hisabyar.pre_restore");
        try (InputStream in = new FileInputStream(temp); OutputStream out = new FileOutputStream(replacement)) { copy(in, out); }
        if (db != null) db.close();
        File wal = new File(dest.getPath() + "-wal"), shm = new File(dest.getPath() + "-shm");
        if (wal.exists() && !wal.delete()) throw new IOException("حذف فایل موقت WAL ممکن نشد.");
        if (shm.exists() && !shm.delete()) throw new IOException("حذف فایل موقت SHM ممکن نشد.");
        if (previous.exists() && !previous.delete()) throw new IOException("پاک‌سازی نسخهٔ موقت قبلی ممکن نشد.");
        boolean movedCurrent = false;
        if (dest.exists()) {
            if (!dest.renameTo(previous)) throw new IOException("نگهداری امن پایگاه دادهٔ فعلی ممکن نشد.");
            movedCurrent = true;
        }
        if (!replacement.renameTo(dest)) {
            if (movedCurrent) previous.renameTo(dest);
            db = new DB(this);
            db.getWritableDatabase();
            throw new IOException("جایگزینی پایگاه داده انجام نشد؛ اطلاعات قبلی حفظ شدند.");
        }
        db = new DB(this);
        db.getWritableDatabase();
        if (previous.exists()) previous.delete();
        toast("پشتیبان سالم با موفقیت بازیابی شد.");
        navigate("خانه");
    }
    // Bank-statement cutoff: use an explicitly configured bank introduction date when present;
    // otherwise use the earliest account registration timestamp for that bank in this book.
    private String statementDateKey(String value){
        if(value==null)return "";String x=normalizeDigits(value).trim().replace('\u200c',' ');
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?<!\\d)((?:13|14|19|20)\\d{2})[/-]?([01]?\\d)[/-]?([0-3]?\\d)(?!\\d)").matcher(x);
        if(m.find()){
            int y=Integer.parseInt(m.group(1)),mo=Integer.parseInt(m.group(2)),day=Integer.parseInt(m.group(3));
            if(mo<1||mo>12||day<1||day>(y<1600?(mo<=6?31:mo==12?29:30):31))return "";
            if(y>=1900){int[] j=gregorianToJalali(y,mo,day);return String.format(java.util.Locale.US,"%04d%02d%02d",j[0],j[1],j[2]);}
            return String.format(java.util.Locale.US,"%04d%02d%02d",y,mo,day);
        }
        // XLSX commonly stores dates as Excel day serials rather than visible date strings.
        if(x.matches("\\d{5}(?:\\.0+)?")){
            try{double serial=Double.parseDouble(x);if(serial>=20000&&serial<=80000){Calendar excel=Calendar.getInstance();excel.clear();excel.set(1899,Calendar.DECEMBER,30,12,0,0);excel.add(Calendar.DAY_OF_YEAR,(int)serial);String jalali=jalaliDate(excel.getTimeInMillis());return jalali.replace("/","");}}catch(Exception ignored){}
        }
        return "";
    }
    private String normalizeStatementDate(String value){
        String key=statementDateKey(value);if(key.length()!=8)return "";
        return key.substring(0,4)+"/"+key.substring(4,6)+"/"+key.substring(6,8);
    }
    private String bankImportCutoff(String bank){
        // Never infer the cutoff from an old transaction: that could silently allow older rows.
        if(bank==null||bank.trim().isEmpty())return "";
        String override=getPreferences(0).getString("bank_import_cutoff_"+activeBook+"_"+bank.trim(),"");
        if(override.matches("\\d{8}"))return override;
        SQLiteDatabase r=db.getReadableDatabase();long cutoff=0;
        Cursor c=r.rawQuery("SELECT MIN(created_at) FROM accounts WHERE book=? AND bank_name=? AND enabled=1 AND created_at>0",new String[]{activeBook,bank.trim()});
        if(c.moveToFirst()&&!c.isNull(0))cutoff=c.getLong(0);c.close();
        return cutoff>0?statementDateKey(jalaliDate(cutoff)):"";
    }
    // Date-first pass: purge only unposted bank-statement review rows older than the bank's configured start date.
    // Already-posted ledger transactions are deliberately never deleted by this cleanup.
    private int purgeOldPendingStatementRows(String bank,String cutoff){
        if(bank==null||bank.trim().isEmpty()||cutoff==null||!cutoff.matches("\\d{8}"))return 0;
        SQLiteDatabase sql=db.getWritableDatabase();Cursor c=sql.rawQuery("SELECT id,raw_text FROM bank_inbox WHERE status<>'imported' AND source LIKE 'گزارش گردش حساب%' AND bank=?",new String[]{bank});
        java.util.ArrayList<Long> remove=new java.util.ArrayList<>();
        while(c.moveToNext()){String date=findStatementDate(c.getString(1));String key=statementDateKey(date);if(!key.isEmpty()&&key.compareTo(cutoff)<0)remove.add(c.getLong(0));}c.close();
        for(Long id:remove)sql.delete("bank_inbox","id=? AND status<>'imported'",new String[]{String.valueOf(id)});
        return remove.size();
    }
    private String readTextFromPdf(byte[] bytes) throws Exception {
        com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(getApplicationContext());
        try (com.tom_roush.pdfbox.pdmodel.PDDocument doc = com.tom_roush.pdfbox.pdmodel.PDDocument.load(new java.io.ByteArrayInputStream(bytes))) {
            com.tom_roush.pdfbox.text.PDFTextStripper stripper = new com.tom_roush.pdfbox.text.PDFTextStripper();
            stripper.setSortByPosition(true);
            return stripper.getText(doc);
        }
    }
    private org.w3c.dom.Document parseXmlBytes(byte[] bytes) throws Exception {
        if (bytes == null) throw new IOException("محتوای XML خالی است.");
        // XLSX XML must not contain DTDs or entity declarations. Reject them before parsing,
        // because some Android XML parsers do not implement Apache-specific feature URLs.
        String probe = new String(bytes, java.nio.charset.StandardCharsets.UTF_8)
                .toUpperCase(java.util.Locale.ROOT);
        if (probe.contains("<!DOCTYPE") || probe.contains("<!ENTITY")) {
            throw new IOException("ساختار XML فایل امن نیست یا قابل پشتیبانی نیست.");
        }
        javax.xml.parsers.DocumentBuilderFactory f=javax.xml.parsers.DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        try { f.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true); } catch (Exception ignored) {}
        // These features are best-effort: implementations differ across Android versions.
        // DTD/entity declarations are independently rejected above, so unsupported feature
        // URLs no longer abort normal Excel imports.
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Exception ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Exception ignored) {}
        try { f.setXIncludeAware(false); } catch (Exception ignored) {}
        f.setExpandEntityReferences(false);
        return f.newDocumentBuilder().parse(new java.io.ByteArrayInputStream(bytes));
    }
    private java.util.Map<String,byte[]> unzipXlsx(byte[] bytes) throws Exception {
        java.util.Map<String,byte[]> files=new java.util.HashMap<>();
        try(java.util.zip.ZipInputStream zin=new java.util.zip.ZipInputStream(new java.io.ByteArrayInputStream(bytes))){
            java.util.zip.ZipEntry e; byte[] buf=new byte[8192];
            while((e=zin.getNextEntry())!=null){if(!e.isDirectory() && (e.getName().equals("xl/sharedStrings.xml")||e.getName().equals("xl/worksheets/sheet1.xml")||e.getName().equals("xl/workbook.xml")||e.getName().equals("xl/_rels/workbook.xml.rels"))){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();int n;while((n=zin.read(buf))>0)out.write(buf,0,n);files.put(e.getName(),out.toByteArray());}zin.closeEntry();}
        }
        if(!files.containsKey("xl/worksheets/sheet1.xml"))throw new IOException("فایل Excel فاقد برگه قابل‌خواندن است.");
        return files;
    }
    private java.util.List<java.util.List<String>> readXlsxRows(byte[] bytes) throws Exception {
        java.util.Map<String,byte[]> files=unzipXlsx(bytes);java.util.ArrayList<String> shared=new java.util.ArrayList<>();
        if(files.containsKey("xl/sharedStrings.xml")){org.w3c.dom.Document sd=parseXmlBytes(files.get("xl/sharedStrings.xml"));org.w3c.dom.NodeList sis=sd.getElementsByTagNameNS("*","si");for(int i=0;i<sis.getLength();i++){org.w3c.dom.NodeList ts=((org.w3c.dom.Element)sis.item(i)).getElementsByTagNameNS("*","t");StringBuilder b=new StringBuilder();for(int j=0;j<ts.getLength();j++)b.append(ts.item(j).getTextContent());shared.add(b.toString());}}
        org.w3c.dom.Document sheet=parseXmlBytes(files.get("xl/worksheets/sheet1.xml"));org.w3c.dom.NodeList rowNodes=sheet.getElementsByTagNameNS("*","row");java.util.ArrayList<java.util.List<String>> rows=new java.util.ArrayList<>();
        for(int r=0;r<rowNodes.getLength();r++){org.w3c.dom.NodeList cells=((org.w3c.dom.Element)rowNodes.item(r)).getElementsByTagNameNS("*","c");java.util.TreeMap<Integer,String> vals=new java.util.TreeMap<>();int max=-1;
            for(int c=0;c<cells.getLength();c++){org.w3c.dom.Element ce=(org.w3c.dom.Element)cells.item(c);String ref=ce.getAttribute("r");int col=excelColumnIndex(ref);if(col<0)continue;String type=ce.getAttribute("t");org.w3c.dom.NodeList vs=ce.getElementsByTagNameNS("*","v");String val=vs.getLength()>0?vs.item(0).getTextContent():"";
                if("s".equals(type)){try{val=shared.get(Integer.parseInt(val));}catch(Exception ignored){val="";}}
                else if("inlineStr".equals(type)){org.w3c.dom.NodeList ts=ce.getElementsByTagNameNS("*","t");StringBuilder b=new StringBuilder();for(int j=0;j<ts.getLength();j++)b.append(ts.item(j).getTextContent());val=b.toString();}
                vals.put(col,val);if(col>max)max=col;
            }
            if(max<0)continue;java.util.ArrayList<String> row=new java.util.ArrayList<>();for(int i=0;i<=max;i++)row.add(vals.containsKey(i)?vals.get(i):"");rows.add(row);
        }
        return rows;
    }
    private int excelColumnIndex(String ref){int n=0,i=0;while(i<ref.length()&&Character.isLetter(ref.charAt(i))){n=n*26+(Character.toUpperCase(ref.charAt(i))-'A'+1);i++;}return n-1;}
    private int headerScore(java.util.List<String> row){int score=0;for(String h:row)if(containsAny(normalizeBankText(h),"تاریخ","شرح","برداشت","واریز","مبلغ","مانده","date","description","debit","credit","amount","balance"))score++;return score;}
    // Automatically reconcile statement rows against the local ledger. Only high-confidence rows are posted.
    private int autoReconcileStatementRows(String bank){
        SQLiteDatabase sql=db.getWritableDatabase();int imported=0;
        String activeCutoff=bankImportCutoff(bank);purgeOldPendingStatementRows(bank,activeCutoff);
        Cursor inbox=sql.rawQuery("SELECT id,source,raw_text,amount,kind,bank FROM bank_inbox WHERE status='pending' AND source LIKE 'گزارش گردش حساب%' AND bank=? ORDER BY received_at,id",new String[]{bank});
        class Row { long id,amount; String source,raw,kind; Row(long i,String s,String r,long a,String k){id=i;source=s;raw=r;amount=a;kind=k;} }
        java.util.ArrayList<Row> rows=new java.util.ArrayList<>();
        while(inbox.moveToNext())rows.add(new Row(inbox.getLong(0),inbox.getString(1),inbox.getString(2),inbox.isNull(3)?0:inbox.getLong(3),inbox.getString(4)));
        inbox.close();
        for(Row r:rows){
            if(r.amount<=0||(!"هزینه".equals(r.kind)&&!"درآمد".equals(r.kind))){ContentValues pendingReason=new ContentValues();pendingReason.put("note","نیازمند بررسی: مبلغ یا نوع تراکنش از گزارش بانک به‌طور مطمئن استخراج نشد.");sql.update("bank_inbox",pendingReason,"id=? AND status='pending'",new String[]{String.valueOf(r.id)});continue;}
            String date=findStatementDate(r.raw);String dateKey=statementDateKey(date);String cutoff=bankImportCutoff(bank);
            if(dateKey.isEmpty()||cutoff.isEmpty()||dateKey.compareTo(cutoff)<0){ContentValues pendingReason=new ContentValues();pendingReason.put("note",dateKey.isEmpty()?"نیازمند بررسی: تاریخ تراکنش قابل تشخیص نیست.":cutoff.isEmpty()?"نیازمند بررسی: تاریخ شروع مجاز حساب بانکی مشخص نیست.":"رد شد: تاریخ تراکنش قبل از تاریخ شروع مجاز حساب بانکی است.");if(!dateKey.isEmpty()&&!cutoff.isEmpty()&&dateKey.compareTo(cutoff)<0)pendingReason.put("status","cutoff_rejected");sql.update("bank_inbox",pendingReason,"id=? AND status='pending'",new String[]{String.valueOf(r.id)});continue;}
            java.util.ArrayList<String> matches=new java.util.ArrayList<>();
            java.util.ArrayList<String> enabledBankAccounts=new java.util.ArrayList<>();
            Cursor ac=sql.rawQuery("SELECT name,bank_name FROM accounts WHERE book=? AND enabled=1 AND bank_name IS NOT NULL AND TRIM(bank_name)<>'' ORDER BY id",new String[]{activeBook});
            String normalizedBank=normalizeBankText(bank);
            while(ac.moveToNext()){
                String accountName=ac.getString(0),accountBank=ac.getString(1);
                enabledBankAccounts.add(accountName);
                String nb=normalizeBankText(accountBank);
                boolean bankMatch=!normalizedBank.isEmpty()&&!nb.isEmpty()&&(nb.equals(normalizedBank)||nb.contains(normalizedBank)||normalizedBank.contains(nb));
                if(!bankMatch&&!normalizedBank.isEmpty()){
                    for(String[] aliases:bankAliases()){
                        boolean selectedIsAlias=false,accountIsAlias=false;
                        for(String alias:aliases){String na=normalizeBankText(alias);if(!na.isEmpty()&&normalizedBank.contains(na))selectedIsAlias=true;if(!na.isEmpty()&&nb.contains(na))accountIsAlias=true;}
                        if(selectedIsAlias&&accountIsAlias){bankMatch=true;break;}
                    }
                }
                if(bankMatch)matches.add(accountName);
            }
            ac.close();
            // Some bank accounts were saved with a shortened/legacy bank label. If this book has
            // exactly one enabled bank account, it is a safe deterministic fallback; never guess
            // between multiple accounts.
            if(matches.isEmpty()&&enabledBankAccounts.size()==1)matches.add(enabledBankAccounts.get(0));
            if(matches.size()!=1){ContentValues pendingReason=new ContentValues();pendingReason.put("note",matches.isEmpty()?"نیازمند بررسی: حساب بانکی متناظر پیدا نشد؛ نام بانک حساب را در بخش حساب‌ها اصلاح کن.":"نیازمند بررسی: چند حساب بانکی با این بانک تطبیق دارند؛ برای جلوگیری از ثبت در حساب اشتباه، خودکار ثبت نشد.");sql.update("bank_inbox",pendingReason,"id=? AND status='pending'",new String[]{String.valueOf(r.id)});continue;}String account=matches.get(0);
            long when=statementDateMillis(date);if(isMonthClosed(monthKey(when))){ContentValues pendingReason=new ContentValues();pendingReason.put("note","نیازمند بررسی: ماه این تراکنش بسته شده است و ثبت خودکار مجاز نیست.");sql.update("bank_inbox",pendingReason,"id=? AND status='pending'",new String[]{String.valueOf(r.id)});continue;}
            Calendar start=Calendar.getInstance();start.setTimeInMillis(when);start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);Calendar end=(Calendar)start.clone();end.add(Calendar.DAY_OF_YEAR,1);
            Cursor dup=sql.rawQuery("SELECT id FROM transactions WHERE book=? AND account=? AND amount=? AND type=? AND date>=? AND date<? LIMIT 1",new String[]{activeBook,account,String.valueOf(r.amount),r.kind,String.valueOf(start.getTimeInMillis()),String.valueOf(end.getTimeInMillis())});boolean exists=dup.moveToFirst();dup.close();
            if(exists){ContentValues skipped=new ContentValues();skipped.put("status","duplicate_skipped");skipped.put("note","خودکار رد شد: تراکنش هم‌حساب، هم‌مبلغ، هم‌نوع و هم‌تاریخ از قبل وجود دارد.");sql.update("bank_inbox",skipped,"id=? AND status='pending'",new String[]{String.valueOf(r.id)});continue;}
            String description=bankField(r.raw,"شرح","").trim();if(description.isEmpty()||description.length()<2)continue;
            String category="متفرقه";
            if("هزینه".equals(r.kind)){String suggested=classifyBankExpense(description);if(!"نیازمند تعیین دسته‌بندی".equals(suggested)&&getCategoryOptions(r.kind).contains(suggested))category=suggested;}
            // Do not invent transaction descriptions or create unknown categories; preserve bank narration and use the existing fallback.
            ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",r.kind);tx.put("amount",r.amount);tx.put("category",category);tx.put("account",account);tx.put("payment_method","انتقال بانکی");tx.put("note",description);tx.put("date",when);setMonthKey(tx,when);
            sql.beginTransaction();try{sql.insertOrThrow("transactions",null,tx);ContentValues done=new ContentValues();done.put("status","imported");done.put("note","ثبت خودکار پس از تطبیق گردش حساب • "+account);sql.update("bank_inbox",done,"id=? AND status='pending'",new String[]{String.valueOf(r.id)});sql.setTransactionSuccessful();imported++;}catch(Exception ignored){}finally{sql.endTransaction();}
        }
        return imported;
    }
    private void importStatementBytes(byte[] bytes, String displayName, String bank) throws Exception {
        if(bank==null||bank.trim().isEmpty())throw new IOException("ابتدا بانک را انتخاب کنید.");
        String name=displayName==null?"":displayName.toLowerCase(Locale.ROOT);if(bytes.length>=4&&(bytes[0]&255)==0xD0&&(bytes[1]&255)==0xCF&&(bytes[2]&255)==0x11&&(bytes[3]&255)==0xE0)throw new IOException("فایل قدیمی Excel با پسوند XLS هنوز پشتیبانی نمی‌شود؛ آن را در Excel با فرمت XLSX یا CSV ذخیره کنید.");
        java.util.List<java.util.List<String>> rows=new java.util.ArrayList<>();String textContent="";boolean structured=false;
        if(name.endsWith(".xlsx") || (bytes.length>=2&&bytes[0]=='P'&&bytes[1]=='K')){rows=readXlsxRows(bytes);structured=true;}
        else if(name.endsWith(".pdf") || (bytes.length>=4&&bytes[0]=='%'&&bytes[1]=='P'&&bytes[2]=='D'&&bytes[3]=='F')){textContent=readTextFromPdf(bytes);if(textContent.trim().isEmpty())throw new IOException("این PDF احتمالاً اسکن‌شده یا تصویری است؛ در این نسخه فقط PDF دارای متن قابل‌استخراج خوانده می‌شود.");}
        else {textContent=new String(bytes,StandardCharsets.UTF_8).replace("\uFEFF","");String[] ls=textContent.split("\\r?\\n");for(String line:ls)if(!line.trim().isEmpty())rows.add(parseCsvLine(line));structured=true;}
        int added=0,skipped=0,olderSkipped=0,dateUnknownSkipped=0;long now=System.currentTimeMillis();String cutoff=bankImportCutoff(bank);
        if(cutoff.isEmpty())throw new IOException("تاریخ معرفی بانک در این دفتر مشخص نیست. برای جلوگیری از ورود تراکنش‌های قدیمی، ابتدا حساب بانکی را با تاریخ شروع صحیح در برنامه ثبت/اصلاح کن؛ تا آن زمان هیچ ردیفی وارد نمی‌شود.");
        int oldPendingPurged=purgeOldPendingStatementRows(bank,cutoff);
        if(structured){int headerIndex=-1,best=0;for(int i=0;i<Math.min(rows.size(),30);i++){int score=headerScore(rows.get(i));if(score>best){best=score;headerIndex=i;}}
            if(headerIndex>=0&&best>=2){java.util.List<String> headers=rows.get(headerIndex);int dateCol=findColumn(headers,"تاریخ","date","زمان");if(dateCol<0)throw new IOException("ستون تاریخ در فایل پیدا نشد؛ برای جلوگیری از ورود اشتباه، هیچ تراکنشی وارد نشد.");for(int i=headerIndex+1;i<rows.size();i++){java.util.List<String> row=rows.get(i);if(row.isEmpty())continue;if(dateCol>=row.size()){dateUnknownSkipped++;continue;}String key=statementDateKey(row.get(dateCol));if(key.isEmpty()){dateUnknownSkipped++;continue;}if(key.compareTo(cutoff)<0){olderSkipped++;continue;}if(stageStatementCsvRow(bank,headers,row,now+i))added++;else skipped++;}}
            else {throw new IOException("ساختار ستون‌های فایل قابل‌تشخیص نیست یا ستون تاریخ ندارد. هیچ ردیفی وارد نشد تا قانون تاریخ شروع بانک دور زده نشود.");}
        } else {
            String[] lines=textContent.split("\\r?\\n");for(int i=0;i<lines.length;i++){String line=lines[i].trim();if(line.isEmpty())continue;String normalized=normalizeBankText(line);java.util.regex.Matcher dm=java.util.regex.Pattern.compile("(?<!\\d)((?:13|14|19|20)\\d{2})[/-]([01]?\\d)[/-]([0-3]?\\d)(?!\\d)").matcher(normalizeDigits(line));if(!dm.find()){dateUnknownSkipped++;continue;}String rowDate=dm.group(1)+"/"+dm.group(2)+"/"+dm.group(3);String key=statementDateKey(rowDate);if(key.isEmpty()){dateUnknownSkipped++;continue;}if(key.compareTo(cutoff)<0){olderSkipped++;continue;}boolean moneyLike=java.util.regex.Pattern.compile("[0-9۰-۹٠-٩][0-9۰-۹٠-٩,٬،.]{3,}").matcher(line).find();if(!moneyLike){skipped++;continue;}String raw="بانک: "+bank+"\nتاریخ: "+rowDate+"\nشرح: "+line+"\nردیف اصلی PDF: "+line;if(stageBankText("گزارش PDF • "+bank,raw,now+i))added++;else skipped++;}
        }
        if(added==0)throw new IOException("هیچ تراکنش قابل‌ورودی پیدا نشد. قدیمی‌تر از تاریخ شروع: "+olderSkipped+"؛ تاریخ نامشخص: "+dateUnknownSkipped+"؛ ناقص/تکراری: "+skipped+". هیچ ردیفی بدون تاریخ معتبر وارد نشده است.");
        toast("تحلیل فایل انجام شد • حذف از صف بررسی به‌دلیل تاریخ قدیمی: "+oldPendingPurged+" • رد ردیف قدیمی فایل: "+olderSkipped+" • ردیف‌های اضافه‌شده به صف بررسی: "+added+" • موارد ناقص/تکراری: "+skipped+". هیچ تراکنشی بدون تأیید شما ثبت مالی نشد.");showBankInbox();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==732 && resultCode==RESULT_OK && data!=null && data.getData()!=null){try{Uri selectedUri=data.getData();String displayName="";try(android.database.Cursor meta=getContentResolver().query(selectedUri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){if(meta!=null&&meta.moveToFirst())displayName=meta.getString(0);}byte[] bytes;try(InputStream in=getContentResolver().openInputStream(selectedUri);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){if(in==null)throw new IOException("فایل باز نشد.");byte[] b=new byte[8192];int n;while((n=in.read(b))>0){if(out.size()+n>25000000)throw new IOException("حجم فایل بیشتر از ۲۵ مگابایت است.");out.write(b,0,n);}bytes=out.toByteArray();}String bank=getPreferences(0).getString("statement_import_bank","");importStatementBytes(bytes,displayName,bank);}catch(Exception e){toast("تحلیل فایل ناموفق بود: "+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}return;}
        if(requestCode==REQ_CHEQUE_EXPORT){if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out!=null){out.write(pendingChequeCsv.getBytes(java.nio.charset.StandardCharsets.UTF_8));toast("خروجی جدول چک‌ها ذخیره شد.");}else toast("ساخت فایل خروجی ناموفق بود.");}catch(Exception e){toast("ذخیره خروجی ناموفق بود: "+e.getMessage());}}else toast("ذخیره خروجی لغو شد.");pendingChequeCsv="";return;}
        if (requestCode == REQ_VOICE_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                java.util.ArrayList<String> results = data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) processVoiceCommand(results.get(0));
                else toast("متن گفتار دریافت نشد؛ زبان فارسی و سرویس گفتار را بررسی کن.");
            } else {
                toast("تشخیص گفتار انجام نشد؛ اینترنت، مجوز میکروفون و سرویس گفتار گوگل را بررسی کن.");
            }
            return;
        }
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try {
            if(requestCode==REQ_EXPORT_BACKUP) {
                SQLiteDatabase sql=db.getWritableDatabase();
                try(Cursor checkpoint=sql.rawQuery("PRAGMA wal_checkpoint(FULL)",null)){if(checkpoint.moveToFirst()&&checkpoint.getInt(0)!=0)throw new IOException("پایگاه داده در حال استفاده است؛ دوباره تلاش کن.");}
                File source=getDatabasePath("hisabyar.db");
                verifyDatabaseFile(source,false);
                File temp=new File(getCacheDir(),"hisabyar_manual_export.tmp");
                try {
                    try(InputStream in=new FileInputStream(source);OutputStream out=new FileOutputStream(temp)){copy(in,out);}
                    verifyDatabaseFile(temp,false);
                    try(InputStream in=new FileInputStream(temp);OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("محل ذخیره باز نشد.");copy(in,out);}
                    toast("پشتیبان دستی ذخیره و سلامت فایل بررسی شد.");
                } finally { if(temp.exists())temp.delete(); }
            } else if(requestCode==REQ_IMPORT_BACKUP) {
                File temp = new File(getCacheDir(), "hisabyar_restore.tmp");
                try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(temp)) { copy(in, out); }
                confirmRestoreBackup(temp);
            } else if(requestCode==703) {
                try(OutputStream out=getContentResolver().openOutputStream(uri);BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(out,StandardCharsets.UTF_8))) {
                    writer.write("\uFEFFتاریخ,نوع,مبلغ به ریال,دسته‌بندی,حساب,روش پرداخت,شرح\n");
                    Cursor c=db.getReadableDatabase().rawQuery("SELECT type,amount,category,account,note,date,payment_method FROM transactions WHERE book=? ORDER BY date DESC",new String[]{activeBook});
                    while(c.moveToNext())writer.write(csv(jalaliDate(c.getLong(5))+"")+","+csv(c.getString(0))+","+c.getLong(1)+","+csv(c.getString(2))+","+csv(c.getString(3))+","+csv(c.getString(6))+","+csv(c.getString(4))+"\n");
                    c.close();writer.flush();toast("گزارش CSV ذخیره شد");
                }
            }
        } catch(Exception e) {
            if(db==null)db=new DB(this);
            try{db.getWritableDatabase();}catch(Exception ignored){}
            toast("عملیات انجام نشد: "+e.getMessage());
        }
    }
    private void copy(InputStream in,OutputStream out)throws IOException {if(in==null||out==null)throw new IOException("فایل باز نشد");byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);out.flush();}
    private String csv(String s){if(s==null)return "\"\"";return "\""+s.replace("\"","\"\"").replace("\r"," ").replace("\n"," ")+"\"";}
    private String hashPin(String salt,String pin) {
        try {byte[] bytes=MessageDigest.getInstance("SHA-256").digest((salt+":"+pin).getBytes(StandardCharsets.UTF_8));StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format(Locale.US,"%02x",b&0xff));return out.toString();}
        catch(Exception e){return "";}
    }
    private void setPinDialog() {
        String old=getPreferences(0).getString("app_pin_hash",getPreferences(0).getString("app_pin",""));
        LinearLayout f=formLayout();EditText pin=edit("رمز عددی ۴ تا ۸ رقمی (خالی = حذف رمز)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);f.addView(pin);
        new AlertDialog.Builder(this).setTitle(old.isEmpty()?"تنظیم قفل برنامه":"تغییر یا حذف قفل").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            String p=pin.getText().toString().trim();if(!p.isEmpty()&&(p.length()<4||p.length()>8)){toast("رمز باید ۴ تا ۸ رقم باشد");return;}
            android.content.SharedPreferences.Editor editor=getPreferences(0).edit();
            if(p.isEmpty())editor.remove("app_pin").remove("app_pin_hash").remove("app_pin_salt");
            else {String salt=java.util.UUID.randomUUID().toString();String hash=hashPin(salt,p);if(hash.isEmpty()){toast("تنظیم قفل ناموفق بود");return;}editor.putString("app_pin_salt",salt).putString("app_pin_hash",hash).remove("app_pin");}
            editor.apply();toast(p.isEmpty()?"قفل حذف شد":"قفل برنامه فعال شد");
        }).show();
    }
    private void promptUnlockIfNeeded() {
        String storedHash=getPreferences(0).getString("app_pin_hash","");String legacy=getPreferences(0).getString("app_pin","");
        if(storedHash.isEmpty()&&legacy.isEmpty()){appUnlocked=true;return;}
        appUnlocked=false;
        EditText input=edit("رمز عددی برنامه",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("حساب‌یار قفل است").setView(input).setCancelable(false).setPositiveButton("باز کردن",null).create();
        dlg.setOnShowListener(x->dlg.getButton(-1).setOnClickListener(v->{String entered=input.getText().toString();boolean ok;
            if(!storedHash.isEmpty())ok=storedHash.equals(hashPin(getPreferences(0).getString("app_pin_salt",""),entered));else ok=legacy.equals(entered);
            if(ok){appUnlocked=true;if(storedHash.isEmpty()){String salt=java.util.UUID.randomUUID().toString();getPreferences(0).edit().putString("app_pin_salt",salt).putString("app_pin_hash",hashPin(salt,legacy)).remove("app_pin").apply();}dlg.dismiss();if(!pendingBankCandidateKey.isEmpty())uiHandler.postDelayed(()->openPendingBankCandidate(),300);if(widgetVoiceMode){widgetVoiceUnlockPending=false;if(widgetVoiceLaunchPending&&offlineVoiceReady)uiHandler.postDelayed(()->startWidgetVoiceCapture(),250);}}
            else{input.setText("");input.setError("رمز اشتباه است");}
        }));dlg.show();
    }
    private String jalaliDate(long millis){Calendar c=Calendar.getInstance();c.setTimeInMillis(millis);int gy=c.get(Calendar.YEAR),gm=c.get(Calendar.MONTH)+1,gd=c.get(Calendar.DAY_OF_MONTH);int[] j=gregorianToJalali(gy,gm,gd);return String.format(new Locale("fa","IR"),"%04d/%02d/%02d",j[0],j[1],j[2]);}
    private int[] gregorianToJalali(int gy,int gm,int gd){int[] gdm={0,31,59,90,120,151,181,212,243,273,304,334};int gy2=gm>2?gy+1:gy;int days=355666+365*gy+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400+gd+gdm[gm-1];int jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365;}int jm,jd;if(days<186){jm=1+days/31;jd=1+days%31;}else{jm=7+(days-186)/30;jd=1+(days-186)%30;}return new int[]{jy,jm,jd};}
    private void chooseBook() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM books ORDER BY id",null);java.util.ArrayList<String> names=new java.util.ArrayList<>();while(c.moveToNext())names.add(c.getString(0));c.close();
        String[] a=names.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("انتخاب دفتر").setItems(a,(d,w)->{activeBook=a[w];getPreferences(0).edit().putString("active_book",activeBook).apply();ensureBookAccount();navigate("خانه");}).setNegativeButton("انصراف",null).show();
    }
    private void manageBooks() {
        LinearLayout f=formLayout();EditText name=edit("نام دفتر جدید (مثلاً شخصی، گلخانه)",InputType.TYPE_CLASS_TEXT);f.addView(name);
        new AlertDialog.Builder(this).setTitle("افزودن دفتر مالی").setView(f).setNeutralButton("انتخاب دفتر",(d,w)->chooseBook()).setNegativeButton("بستن",null).setPositiveButton("افزودن",(d,w)->{String n=name.getText().toString().trim();if(!n.isEmpty()){Cursor ex=db.getReadableDatabase().rawQuery("SELECT id FROM books WHERE name=?",new String[]{n});boolean dup=ex.moveToFirst();ex.close();if(dup){toast("این دفتر از قبل وجود دارد");return;}addBookRaw(n);activeBook=n;getPreferences(0).edit().putString("active_book",activeBook).apply();ensureBookAccount();toast("دفتر اضافه شد");navigate("خانه");}}).show();
    }
    private void editAccountDialog(String oldName) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,kind,opening,bank_name,card_last4,account_uid FROM accounts WHERE book=? AND name=? LIMIT 1",new String[]{activeBook,oldName});
        if(!c.moveToFirst()){c.close();toast("حساب پیدا نشد");return;}
        long id=c.getLong(0),openingValue=c.getLong(3);String nameValue=c.getString(1),kindValue=c.getString(2),bankValue=c.getString(4),cardValue=c.getString(5),uid=c.getString(6);c.close();
        LinearLayout f=formLayout();EditText name=edit("نام نمایشی حساب",InputType.TYPE_CLASS_TEXT),kind=edit("نوع حساب",InputType.TYPE_CLASS_TEXT),opening=edit("موجودی اولیه به ریال",InputType.TYPE_CLASS_NUMBER),last4=edit("چهار رقم آخر کارت/شناسه حساب",InputType.TYPE_CLASS_NUMBER);Spinner bank=styledSpinner();java.util.ArrayList<String> banks=new java.util.ArrayList<>();banks.add("بدون بانک");for(String b:bankNames())banks.add(b);bank.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,banks));
        name.setText(nameValue);kind.setText(kindValue==null?"":kindValue);opening.setText(String.valueOf(openingValue));last4.setText(cardValue==null?"":cardValue);int pos=0;for(int i=0;i<banks.size();i++)if(banks.get(i).equals(bankValue)){pos=i;break;}bank.setSelection(pos);f.addView(name);f.addView(kind);f.addView(bank);f.addView(last4);f.addView(opening);
        new AlertDialog.Builder(this).setTitle("ویرایش حساب").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            String nn=name.getText().toString().trim(),kk=kind.getText().toString().trim(),bb=String.valueOf(bank.getSelectedItem());if(bb.equals("بدون بانک"))bb="";String cc=normalizeDigits(last4.getText().toString()).replaceAll("\\D","");long oo=parseAmount(opening.getText().toString());
            if(nn.isEmpty()||oo<0||(!cc.isEmpty()&&!cc.matches("\\d{4}"))){toast("نام، موجودی اولیه یا چهار رقم آخر معتبر نیست");return;}
            Cursor du=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=? AND id<>?",new String[]{activeBook,nn,String.valueOf(id)});boolean duplicate=du.moveToFirst();du.close();if(duplicate){toast("حساب دیگری با این نام وجود دارد");return;}
            SQLiteDatabase sql=db.getWritableDatabase();sql.beginTransaction();try{ContentValues v=new ContentValues();v.put("name",nn);v.put("kind",kk.isEmpty()?(bb.isEmpty()?"نقدی":"بانکی"):kk);v.put("opening",oo);v.put("bank_name",bb.isEmpty()?null:bb);v.put("card_last4",cc.isEmpty()?null:cc);sql.update("accounts",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});
                if(!oldName.equals(nn)){ContentValues ref=new ContentValues();ref.put("account",nn);sql.update("transactions",ref,"book=? AND account=?",new String[]{activeBook,oldName});sql.update("recurring",ref,"book=? AND account=?",new String[]{activeBook,oldName});sql.update("cheques",ref,"book=? AND account=?",new String[]{activeBook,oldName});}
                sql.setTransactionSuccessful();}catch(Exception ex){toast("ویرایش انجام نشد: "+ex.getMessage());}finally{sql.endTransaction();}toast("اطلاعات حساب و پیوندهای آن به‌روزرسانی شد");showAccounts();
        }).show();
    }

    private void addAccountDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام حساب (مثلاً کارت اصلی)",InputType.TYPE_CLASS_TEXT),kind=edit("نوع حساب (بانکی/نقدی/کیف پول)",InputType.TYPE_CLASS_TEXT),opening=edit("موجودی اولیه به ریال",InputType.TYPE_CLASS_NUMBER),last4=edit("چهار رقم آخر کارت (اختیاری)",InputType.TYPE_CLASS_NUMBER);Spinner bank=styledSpinner();java.util.ArrayList<String> banks=new java.util.ArrayList<>();banks.add("بدون بانک");for(String b:bankNames())banks.add(b);bank.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,banks));f.addView(name);f.addView(kind);f.addView(bank);f.addView(last4);f.addView(opening);
        new AlertDialog.Builder(this).setTitle("حساب جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();String bankName=String.valueOf(bank.getSelectedItem());if(bankName.equals("بدون بانک"))bankName="";String card=normalizeDigits(last4.getText().toString()).replaceAll("\\D","");if(!card.isEmpty()&&card.length()!=4){toast("چهار رقم آخر کارت باید دقیقاً ۴ رقم باشد");return;}if(n.isEmpty())n=bankName.isEmpty()?"پول نقد":"بانک "+bankName+(card.isEmpty()?"":" • "+card);long initial=parseAmount(opening.getText().toString());if(initial<0){toast("موجودی اولیه نمی‌تواند منفی باشد");return;}ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("kind",kind.getText().toString().trim().isEmpty()?(bankName.isEmpty()?"نقدی":"بانکی"):kind.getText().toString().trim());v.put("opening",initial);v.put("bank_name",bankName.isEmpty()?null:bankName);v.put("card_last4",card.isEmpty()?null:card);v.put("account_uid",java.util.UUID.randomUUID().toString());v.put("enabled",1);v.put("created_at",System.currentTimeMillis());Cursor exists=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{activeBook,n});boolean duplicate=exists.moveToFirst();exists.close();if(duplicate){toast("این نام حساب از قبل وجود دارد");return;}db.getWritableDatabase().insert("accounts",null,v);toast("حساب ذخیره شد. برای جلوگیری از ادغام اشتباه، اشتراک با دفتر دیگر فقط از بخش مدیریت حساب‌ها و به‌صورت دستی انجام می‌شود.");navigate("خانه");}).show();
    }
    private void ensureAccount(String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{activeBook,name});boolean exists=c.moveToFirst();c.close();
        if(!exists){ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name);v.put("kind","نقدی");v.put("opening",0);v.put("account_uid",java.util.UUID.randomUUID().toString());v.put("enabled",1);v.put("created_at",System.currentTimeMillis());db.getWritableDatabase().insert("accounts",null,v);}
    }
    private void ensureBookAccount() { if(countForBook("accounts",activeBook)==0)ensureAccount("پول نقد"); }
    private long sum(String type) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=?",new String[]{activeBook,type});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;
    }
    private long balance() {
        long total=0;
        java.util.HashSet<String> counted=new java.util.HashSet<>();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,COALESCE(account_uid,'') FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});
        while(c.moveToNext()){
            String name=c.getString(0),uid=c.getString(1);
            String identity=uid.isEmpty()?"local:"+name:"uid:"+uid;
            if(counted.add(identity))total+=accountBalance(name);
        }
        c.close();return total;
    }
    private long bankBalance() {
        long total=0;
        java.util.HashSet<String> counted=new java.util.HashSet<>();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,COALESCE(account_uid,''),COALESCE(bank_name,'') FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});
        while(c.moveToNext()){
            String name=c.getString(0),uid=c.getString(1),bank=c.getString(2);
            if(bank.trim().isEmpty())continue;
            String identity=uid.isEmpty()?"local:"+name:"uid:"+uid;
            if(counted.add(identity))total+=accountBalance(name);
        }
        c.close();return total;
    }
    private long parseAmount(String s) {
        if(s==null)return 0;
        String v=s.trim().replace(",","").replace("٬","").replace("،","").replace(" ","");
        StringBuilder out=new StringBuilder();
        for(int i=0;i<v.length();i++){
            char ch=v.charAt(i);
            if(ch>='۰'&&ch<='۹') ch=(char)('0'+(ch-'۰'));
            else if(ch>='٠'&&ch<='٩') ch=(char)('0'+(ch-'٠'));
            if(ch>='0'&&ch<='9')out.append(ch);
        }
        try{return Long.parseLong(out.toString());}catch(Exception e){return 0;}
    }
    private String money(long n) { if(getPreferences(0).getBoolean("hide_amounts",false))return "•••••• ریال"; NumberFormat f=NumberFormat.getInstance(new Locale("fa","IR"));return f.format(n)+" ریال"; }
    private void addHeading(String s) {
        TextView t = text(s, 17, TEXT, true);
        t.setPadding(dp(2), dp(16), dp(2), dp(9));
        body.addView(t);
    }

    private void addEmpty(String s) {TextView t=text(s,14,Color.rgb(86, 99, 91),false);t.setGravity(Gravity.CENTER);t.setPadding(dp(16),dp(20),dp(16),dp(20));body.addView(t);}
    private void addWideButton(String s,Runnable r) {
        TextView b = text(s + "   ›", 15, GREEN, true);
        b.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        b.setPadding(dp(16), dp(13), dp(16), dp(13));
        b.setBackground(roundBg(Color.WHITE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.setMargins(0, dp(4), 0, dp(4));
        body.addView(b, lp);
        b.setOnClickListener(v -> r.run());
    }

    private View actionBox(String s,Runnable r) {
        TextView t = text(s, 14, GREEN, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundBg(Color.WHITE));
        t.setElevation(dp(1));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private LinearLayout formLayout(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(20),dp(8),dp(20),dp(4));return l;}
    private ArrayAdapter<String> dropdownAdapter(java.util.List<String> values){return new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,values){@Override public View getView(int position,View convertView,android.view.ViewGroup parent){TextView v=(TextView)super.getView(position,convertView,parent);v.setTextColor(TEXT);v.setTextSize(15);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(dp(12),dp(8),dp(12),dp(8));return v;}@Override public View getDropDownView(int position,View convertView,android.view.ViewGroup parent){TextView v=(TextView)super.getDropDownView(position,convertView,parent);v.setTextColor(TEXT);v.setTextSize(15);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(dp(14),dp(12),dp(14),dp(12));v.setBackgroundColor(Color.WHITE);return v;}};}
    private android.graphics.drawable.GradientDrawable inputFieldBg(){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(Color.rgb(255,255,255));d.setCornerRadius(dp(12));d.setStroke(dp(1),Color.rgb(194,154,169));return d;}
    private Spinner styledSpinner(){Spinner sp=new Spinner(this,Spinner.MODE_DROPDOWN);sp.setPadding(dp(12),dp(7),dp(12),dp(7));sp.setMinimumHeight(dp(52));sp.setDropDownVerticalOffset(dp(4));sp.setDropDownWidth(getResources().getDisplayMetrics().widthPixels-dp(40));android.graphics.drawable.GradientDrawable bg=inputFieldBg();sp.setBackground(bg);return sp;}
    private EditText edit(String hint,int inputType){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(120,130,140));e.setTextColor(TEXT);e.setTextSize(15);e.setSingleLine(true);e.setInputType(inputType);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(dp(14),dp(10),dp(14),dp(10));e.setMinHeight(dp(52));e.setBackground(inputFieldBg());e.setSelectAllOnFocus(false);if((inputType&InputType.TYPE_CLASS_NUMBER)==InputType.TYPE_CLASS_NUMBER && (hint.contains("مبلغ")||hint.contains("موجودی")||hint.contains("ارزش")||hint.contains("سقف")||hint.contains("پس‌انداز")||hint.contains("هدف")))attachMoneyFormatting(e);return e;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT);t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));t.setIncludeFontPadding(true);t.setLineSpacing(dp(1),1.0f);t.setPadding(0,dp(3),0,dp(3));return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(GREEN);b.setAllCaps(false);return b;}
    private android.graphics.drawable.GradientDrawable gradientBg(int[] colors, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, colors);
        d.setCornerRadius(radius);
        return d;
    }
    private android.graphics.drawable.GradientDrawable ovalBg(int color) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(dp(1), Color.rgb(238, 172, 192));
        return d;
    }

    private android.graphics.drawable.GradientDrawable roundBg(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private class DB extends SQLiteOpenHelper {
        DB(Activity a){super(a,"hisabyar.db",null,16);}
        @Override public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE IF NOT EXISTS bank_inbox(id INTEGER PRIMARY KEY AUTOINCREMENT,source TEXT NOT NULL,source_key TEXT NOT NULL UNIQUE,raw_text TEXT NOT NULL,amount INTEGER,kind TEXT,bank TEXT,card_last4 TEXT,received_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',note TEXT)");
            d.execSQL("CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE)");
            d.execSQL("CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,opening INTEGER NOT NULL DEFAULT 0,bank_name TEXT,card_last4 TEXT,account_uid TEXT,enabled INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL DEFAULT 0)");
            d.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,name TEXT NOT NULL)");
            d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,note TEXT,date INTEGER NOT NULL,transfer_id TEXT,payment_method TEXT DEFAULT 'متفرقه',month_key TEXT)");
            d.execSQL("CREATE TABLE closed_months(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,month_key TEXT NOT NULL,closed_at INTEGER NOT NULL,UNIQUE(book,month_key))");
            d.execSQL("CREATE TABLE assets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,value INTEGER NOT NULL,note TEXT)");
            d.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,person TEXT NOT NULL,kind TEXT,amount INTEGER NOT NULL,paid INTEGER NOT NULL DEFAULT 0,note TEXT,date INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE budgets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,category TEXT NOT NULL,month TEXT NOT NULL,limit_amount INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE recurring(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,frequency TEXT NOT NULL,next_due INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,target INTEGER NOT NULL,current_amount INTEGER NOT NULL DEFAULT 0,deadline INTEGER NOT NULL DEFAULT 0,note TEXT)");
            d.execSQL("CREATE TABLE cheques(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,direction TEXT NOT NULL,cheque_no TEXT,bank TEXT,party TEXT,amount INTEGER NOT NULL,due_date TEXT,account TEXT,status TEXT NOT NULL,note TEXT,image_path TEXT,financial_posted INTEGER NOT NULL DEFAULT 0,exit_recipient TEXT,exit_description TEXT,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_cheques_book_due ON cheques(book,due_date,status)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_book_date ON transactions(book,date)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_debts_book ON debts(book)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_budgets_book_month ON budgets(book,month)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int oldVersion,int newVersion){
            if(oldVersion<2){d.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_book_date ON transactions(book,date)");d.execSQL("CREATE INDEX IF NOT EXISTS idx_debts_book ON debts(book)");d.execSQL("CREATE INDEX IF NOT EXISTS idx_budgets_book_month ON budgets(book,month)");}
            if(oldVersion<4){d.execSQL("CREATE TABLE IF NOT EXISTS recurring(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,frequency TEXT NOT NULL,next_due INTEGER NOT NULL)");}
            if(oldVersion<5){d.execSQL("CREATE TABLE IF NOT EXISTS goals(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,target INTEGER NOT NULL,current_amount INTEGER NOT NULL DEFAULT 0,deadline INTEGER NOT NULL DEFAULT 0,note TEXT)");}
            if(oldVersion<6){d.execSQL("ALTER TABLE transactions ADD COLUMN transfer_id TEXT");}
            if(oldVersion<7){
                // نسخه‌های قبلی مبالغ را به تومان نگه می‌داشتند؛ یک‌بار به ریال تبدیل می‌شوند.
                d.execSQL("UPDATE transactions SET amount=amount*10");
                d.execSQL("UPDATE accounts SET opening=opening*10");
                d.execSQL("UPDATE assets SET value=value*10");
                d.execSQL("UPDATE debts SET amount=amount*10, paid=paid*10");
                d.execSQL("UPDATE budgets SET limit_amount=limit_amount*10");
                d.execSQL("UPDATE recurring SET amount=amount*10");
                d.execSQL("UPDATE goals SET target=target*10, current_amount=current_amount*10");
            }
            if(oldVersion<8){d.execSQL("ALTER TABLE accounts ADD COLUMN bank_name TEXT");d.execSQL("ALTER TABLE accounts ADD COLUMN card_last4 TEXT");}
            if(oldVersion<9){d.execSQL("ALTER TABLE transactions ADD COLUMN payment_method TEXT DEFAULT 'متفرقه'");}
            if(oldVersion<10){
                d.execSQL("ALTER TABLE transactions ADD COLUMN month_key TEXT");
                d.execSQL("CREATE TABLE IF NOT EXISTS closed_months(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,month_key TEXT NOT NULL,closed_at INTEGER NOT NULL,UNIQUE(book,month_key))");
                Cursor cur=d.rawQuery("SELECT id,date FROM transactions WHERE month_key IS NULL",null);
                while(cur.moveToNext()){ContentValues mv=new ContentValues();mv.put("month_key",jalaliDate(cur.getLong(1)).substring(0,7));d.update("transactions",mv,"id=?",new String[]{String.valueOf(cur.getLong(0))});}cur.close();
            }
            if(oldVersion<11){
                d.execSQL("ALTER TABLE accounts ADD COLUMN account_uid TEXT");
                d.execSQL("ALTER TABLE accounts ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1");
                Cursor ac=d.rawQuery("SELECT id FROM accounts",null);
                java.util.ArrayList<Long> ids=new java.util.ArrayList<>();while(ac.moveToNext())ids.add(ac.getLong(0));ac.close();
                for(Long id:ids){ContentValues uv=new ContentValues();uv.put("account_uid",java.util.UUID.randomUUID().toString());d.update("accounts",uv,"id=?",new String[]{String.valueOf(id)});}
                d.execSQL("CREATE INDEX IF NOT EXISTS idx_accounts_uid ON accounts(account_uid)");
            }
            if(oldVersion<14){ d.execSQL("CREATE TABLE IF NOT EXISTS bank_inbox(id INTEGER PRIMARY KEY AUTOINCREMENT,source TEXT NOT NULL,source_key TEXT NOT NULL UNIQUE,raw_text TEXT NOT NULL,amount INTEGER,kind TEXT,bank TEXT,card_last4 TEXT,received_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',note TEXT)"); }
            if(oldVersion<15){ try{d.execSQL("ALTER TABLE accounts ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0");}catch(Exception ignored){} }
            if(oldVersion<16){ try{d.execSQL("ALTER TABLE cheques ADD COLUMN exit_recipient TEXT");}catch(Exception ignored){} try{d.execSQL("ALTER TABLE cheques ADD COLUMN exit_description TEXT");}catch(Exception ignored){} }
            if(oldVersion<13){
                d.execSQL("CREATE TABLE IF NOT EXISTS cheques(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,direction TEXT NOT NULL,cheque_no TEXT,bank TEXT,party TEXT,amount INTEGER NOT NULL,due_date TEXT,account TEXT,status TEXT NOT NULL,note TEXT,image_path TEXT,financial_posted INTEGER NOT NULL DEFAULT 0,exit_recipient TEXT,exit_description TEXT,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)");
                d.execSQL("CREATE INDEX IF NOT EXISTS idx_cheques_book_due ON cheques(book,due_date,status)");
            }
            if(oldVersion<13){
                // The table is created above for old databases; add a guard against posting a cheque twice.
                try { d.execSQL("ALTER TABLE cheques ADD COLUMN financial_posted INTEGER NOT NULL DEFAULT 0"); } catch(Exception ignored) {}
            }
        }
    }
}
