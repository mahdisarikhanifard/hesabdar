package com.example.hisabyar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.Locale;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(25, 104, 77);
    private static final int DARK = Color.rgb(20, 68, 54);
    private static final int BG = Color.rgb(245, 247, 245);
    private static final int TEXT = Color.rgb(35, 45, 40);
    private DB db;
    private LinearLayout root, body, topbar;
    private String activeBook = "شخصی";
    private String page = "خانه";
    private static final int REQ_EXPORT_BACKUP = 701;
    private static final int REQ_IMPORT_BACKUP = 702;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        ensureDefaults();
        showShell();
        showHome();
        promptUnlockIfNeeded();
    }

    private void ensureDefaults() {
        SQLiteDatabase w = db.getWritableDatabase();
        if (count("books") == 0) {
            addBookRaw("شخصی");
            addBookRaw("کسب‌وکار");
        }
        if (countForBook("accounts", activeBook) == 0) {
            ContentValues v = new ContentValues();
            v.put("book", activeBook); v.put("name", "پول نقد"); v.put("kind", "نقدی"); v.put("opening", 0L);
            w.insert("accounts", null, v);
        }
        if (count("categories") == 0) {
            String[][] cats = {{"هزینه","خوراک"},{"هزینه","مسکن"},{"هزینه","حمل‌ونقل"},{"هزینه","سلامت"},{"هزینه","خرید شخصی"},{"هزینه","قبوض"},{"هزینه","تفریح"},{"هزینه","سایر"},{"درآمد","حقوق"},{"درآمد","کسب‌وکار"},{"درآمد","سرمایه‌گذاری"},{"درآمد","سایر"}};
            for (String[] c : cats) { ContentValues v = new ContentValues(); v.put("type",c[0]); v.put("name",c[1]); w.insert("categories",null,v); }
        }
    }
    private long count(String table) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private long countForBook(String table, String book) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+" WHERE book=?",new String[]{book});
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private void addBookRaw(String name) {
        ContentValues v=new ContentValues(); v.put("name",name); db.getWritableDatabase().insert("books",null,v);
    }

    private void showShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        topbar = new LinearLayout(this); topbar.setOrientation(LinearLayout.VERTICAL); topbar.setPadding(dp(18),dp(16),dp(18),dp(12)); topbar.setBackgroundColor(DARK);
        TextView title = text("حساب‌یار",24,Color.WHITE,true); topbar.addView(title);
        TextView subtitle = text("حسابداری شخصی و مدیریت دارایی",13,Color.rgb(215,235,225),false); topbar.addView(subtitle);
        root.addView(topbar);
        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(14),dp(12),dp(14),dp(8));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this); nav.setBackgroundColor(Color.WHITE); nav.setElevation(dp(8));
        String[] tabs={"خانه","تراکنش‌ها","ثبت","دارایی‌ها","تنظیمات"};
        for(String t:tabs){ Button b=button(t); b.setTextSize(12); b.setPadding(dp(2),dp(10),dp(2),dp(10)); b.setBackgroundColor(Color.WHITE); b.setTextColor(GREEN); nav.addView(b,new LinearLayout.LayoutParams(0,dp(54),1)); b.setOnClickListener(v->navigate(t)); }
        root.addView(nav); setContentView(root);
    }
    private void navigate(String p) {
        page=p; body.removeAllViews();
        switch(p) {
            case "خانه": showHome(); break;
            case "تراکنش‌ها": showTransactions(); break;
            case "ثبت": showAddMenu(); break;
            case "دارایی‌ها": showAssets(); break;
            default: showSettings(); break;
        }
    }
    private void showHome() {
        body.removeAllViews();
        addHeading("خلاصه وضعیت مالی");
        LinearLayout bookrow=new LinearLayout(this); bookrow.setGravity(Gravity.CENTER_VERTICAL);
        TextView bl=text("دفتر فعال: "+activeBook,15,TEXT,true); bookrow.addView(bl,new LinearLayout.LayoutParams(0,-2,1));
        Button switchB=button("تغییر دفتر"); bookrow.addView(switchB); switchB.setOnClickListener(v->chooseBook()); body.addView(bookrow);
        long income=sum("درآمد"), expense=sum("هزینه"), balance=balance();
        addMetric("موجودی حساب‌های این دفتر", money(balance), GREEN);
        LinearLayout pair=new LinearLayout(this);
        pair.addView(metricBox("درآمد ثبت‌شده",money(income),GREEN),new LinearLayout.LayoutParams(0,-2,1));
        pair.addView(metricBox("هزینه ثبت‌شده",money(expense),Color.rgb(183,74,60)),new LinearLayout.LayoutParams(0,-2,1));
        body.addView(pair);
        addHeading("ثبت سریع");
        LinearLayout row1=new LinearLayout(this);
        row1.addView(actionBox("＋ ثبت هزینه",()->showEntry("هزینه")),new LinearLayout.LayoutParams(0,dp(76),1));
        row1.addView(actionBox("＋ ثبت درآمد",()->showEntry("درآمد")),new LinearLayout.LayoutParams(0,dp(76),1));
        body.addView(row1);
        LinearLayout row2=new LinearLayout(this);
        row2.addView(actionBox("⇄ انتقال پول",()->showTransfer()),new LinearLayout.LayoutParams(0,dp(76),1));
        row2.addView(actionBox("＋ دارایی",()->showAssetDialog()),new LinearLayout.LayoutParams(0,dp(76),1));
        body.addView(row2);
        addHeading("آخرین تراکنش‌ها");
        showRecentIntoBody();
    }
    private View metricBox(String label,String value,int color) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(12),dp(14),dp(12),dp(14)); box.setBackground(roundBg(Color.WHITE));
        TextView a=text(label,13,Color.GRAY,false), b=text(value,17,color,true); box.addView(a); box.addView(b); return box;
    }
    private void addMetric(String label,String value,int color) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(18),dp(16),dp(18)); box.setBackground(roundBg(Color.WHITE));
        TextView a=text(label,14,Color.GRAY,false), b=text(value,25,color,true); box.addView(a); box.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(10),0,dp(10)); body.addView(box,lp);
    }
    private void showAddMenu() {
        body.removeAllViews(); addHeading("ثبت عملیات مالی");
        addWideButton("ثبت هزینه",()->showEntry("هزینه"));
        addWideButton("ثبت درآمد",()->showEntry("درآمد"));
        addWideButton("انتقال بین حساب‌ها",()->showTransfer());
        addWideButton("ثبت دارایی",()->showAssetDialog());
        addWideButton("ثبت بدهی یا طلب",()->showDebtDialog());
        addWideButton("مشاهده و تسویه بدهی‌ها و طلب‌ها",()->showDebts());
        addWideButton("بودجه‌بندی ماهانه",()->showBudgets());
        addWideButton("گزارش‌ها و ارزش خالص",()->showReports());
    }
    private void showEntry(String type) {
        LinearLayout form=formLayout();
        EditText amount=edit("مبلغ به تومان",InputType.TYPE_CLASS_NUMBER);
        EditText category=edit("دسته‌بندی (مثلاً خوراک)",InputType.TYPE_CLASS_TEXT);
        EditText account=edit("حساب (مثلاً پول نقد)",InputType.TYPE_CLASS_TEXT);
        EditText note=edit("شرح / یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        form.addView(amount); form.addView(category); form.addView(account); form.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت "+type).setView(form)
          .setNegativeButton("انصراف",null).setPositiveButton("ثبت", (d,w)->{
              long a=parseAmount(amount.getText().toString());
              if(a<=0){toast("مبلغ باید بیشتر از صفر باشد");return;}
              String cat=category.getText().toString().trim(); if(cat.isEmpty()) cat=type.equals("هزینه")?"سایر":"سایر";
              String acc=account.getText().toString().trim(); if(acc.isEmpty()) acc="پول نقد";
              ensureAccount(acc);
              ContentValues v=new ContentValues(); v.put("book",activeBook); v.put("type",type); v.put("amount",a); v.put("category",cat); v.put("account",acc); v.put("note",note.getText().toString()); v.put("date",System.currentTimeMillis());
              db.getWritableDatabase().insert("transactions",null,v);
              toast("تراکنش ثبت شد"); navigate("خانه");
          }).show();
    }
    private void showTransfer() {
        LinearLayout f=formLayout();
        EditText from=edit("از حساب",InputType.TYPE_CLASS_TEXT), to=edit("به حساب",InputType.TYPE_CLASS_TEXT), amt=edit("مبلغ به تومان",InputType.TYPE_CLASS_NUMBER), note=edit("شرح (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(from);f.addView(to);f.addView(amt);f.addView(note);
        new AlertDialog.Builder(this).setTitle("انتقال پول").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ثبت انتقال",(d,w)->{
            long a=parseAmount(amt.getText().toString()); String fr=from.getText().toString().trim(),toN=to.getText().toString().trim();
            if(a<=0||fr.isEmpty()||toN.isEmpty()||fr.equals(toN)){toast("حساب‌ها و مبلغ را درست وارد کن");return;}
            ensureAccount(fr);ensureAccount(toN);
            SQLiteDatabase s=db.getWritableDatabase();
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("type","انتقال خروجی");v.put("amount",a);v.put("category","انتقال");v.put("account",fr);v.put("note","به "+toN+"؛ "+note.getText());v.put("date",System.currentTimeMillis());s.insert("transactions",null,v);
            ContentValues x=new ContentValues();x.put("book",activeBook);x.put("type","انتقال ورودی");x.put("amount",a);x.put("category","انتقال");x.put("account",toN);x.put("note","از "+fr+"؛ "+note.getText());x.put("date",System.currentTimeMillis());s.insert("transactions",null,x);
            toast("انتقال ثبت شد");navigate("خانه");
        }).show();
    }
    private void showTransactions() {
        body.removeAllViews(); addHeading("تراکنش‌های دفتر "+activeBook);
        Button add=button("＋ ثبت تراکنش"); body.addView(add); add.setOnClickListener(v->showAddMenu());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,type,amount,category,account,note,date FROM transactions WHERE book=? ORDER BY date DESC LIMIT 200",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز تراکنشی ثبت نشده است.");return;}
        do {
            long txId=c.getLong(0); String type=c.getString(1); long amount=c.getLong(2); String cat=c.getString(3), acc=c.getString(4), note=c.getString(5); long stamp=c.getLong(6);
            LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(dp(12),dp(10),dp(12),dp(10)); item.setBackground(roundBg(Color.WHITE));
            TextView line=text(cat+"  •  "+type,15,TEXT,true); item.addView(line);
            item.addView(text(acc+"  |  "+money(amount),14,type.equals("هزینه")||type.equals("انتقال خروجی")?Color.rgb(183,74,60):GREEN,false));
            item.addView(text(jalaliDate(stamp),12,Color.GRAY,false));
            if(note!=null&&!note.isEmpty()) item.addView(text(note,12,Color.GRAY,false));
            item.setOnClickListener(v->transactionActions(txId,type,amount,cat,acc,note));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        } while(c.moveToNext()); c.close();
    }
    private void transactionActions(long id,String type,long amount,String category,String account,String note){
        String[] options={"ویرایش تراکنش","حذف تراکنش"};new AlertDialog.Builder(this).setTitle("مدیریت تراکنش").setItems(options,(d,which)->{if(which==0)editTransaction(id,type,amount,category,account,note);else new AlertDialog.Builder(this).setTitle("حذف تراکنش").setMessage("این تراکنش حذف شود؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("transactions","id=? AND book=?",new String[]{String.valueOf(id),activeBook});toast("تراکنش حذف شد");showTransactions();}).show();}).show();
    }
    private void editTransaction(long id,String type,long amount,String category,String account,String note){
        LinearLayout f=formLayout();EditText a=edit("مبلغ به تومان",InputType.TYPE_CLASS_NUMBER),cat=edit("دسته‌بندی",InputType.TYPE_CLASS_TEXT),acc=edit("حساب",InputType.TYPE_CLASS_TEXT),nt=edit("شرح",InputType.TYPE_CLASS_TEXT);a.setText(String.valueOf(amount));cat.setText(category);acc.setText(account);nt.setText(note==null?"":note);f.addView(a);f.addView(cat);f.addView(acc);f.addView(nt);
        new AlertDialog.Builder(this).setTitle("ویرایش تراکنش").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{long value=parseAmount(a.getText().toString());String accountName=acc.getText().toString().trim();if(value<=0||accountName.isEmpty()){toast("مبلغ و حساب معتبر وارد کن");return;}ensureAccount(accountName);ContentValues v=new ContentValues();v.put("amount",value);v.put("category",cat.getText().toString().trim());v.put("account",accountName);v.put("note",nt.getText().toString());db.getWritableDatabase().update("transactions",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});toast("تراکنش ویرایش شد");showTransactions();}).show();
    }
    private void showRecentIntoBody() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT type,amount,category,account FROM transactions WHERE book=? ORDER BY date DESC LIMIT 5",new String[]{activeBook});
        if(!c.moveToFirst()){addEmpty("هنوز تراکنشی ثبت نشده است.");c.close();return;}
        do { String t=c.getString(0); long a=c.getLong(1); String cat=c.getString(2),acc=c.getString(3);
            TextView v=text(cat+"  •  "+money(a)+"\n"+t+" | "+acc,14,TEXT,false);v.setPadding(dp(10),dp(10),dp(10),dp(10));v.setBackground(roundBg(Color.WHITE));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);
        }while(c.moveToNext());c.close();
    }
    private void showAssets() {
        body.removeAllViews(); addHeading("دارایی‌ها و ارزش خالص");
        Button add=button("＋ افزودن دارایی");body.addView(add);add.setOnClickListener(v->showAssetDialog());
        long total=0; Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,value,note FROM assets WHERE book=? ORDER BY name",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز دارایی ثبت نشده است.");return;}
        do {String name=c.getString(0),kind=c.getString(1),note=c.getString(3);long val=c.getLong(2);total+=val;
            LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setPadding(dp(12),dp(10),dp(12),dp(10));item.setBackground(roundBg(Color.WHITE));
            item.addView(text(name+" • "+kind,15,TEXT,true));item.addView(text(money(val),16,GREEN,true));if(note!=null&&!note.isEmpty())item.addView(text(note,12,Color.GRAY,false));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        }while(c.moveToNext());c.close();
        addMetric("ارزش دارایی‌های ثبت‌شده",money(total),GREEN);
    }
    private void showAssetDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام دارایی",InputType.TYPE_CLASS_TEXT),kind=edit("نوع (طلا، خودرو، ملک و ...)",InputType.TYPE_CLASS_TEXT),value=edit("ارزش فعلی به تومان",InputType.TYPE_CLASS_NUMBER),note=edit("یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(name);f.addView(kind);f.addView(value);f.addView(note);
        new AlertDialog.Builder(this).setTitle("افزودن دارایی").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long val=parseAmount(value.getText().toString());if(name.getText().toString().trim().isEmpty()||val<0){toast("نام و ارزش دارایی را بررسی کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name.getText().toString().trim());v.put("kind",kind.getText().toString().trim());v.put("value",val);v.put("note",note.getText().toString());db.getWritableDatabase().insert("assets",null,v);navigate("دارایی‌ها");
        }).show();
    }
    private void showDebtDialog() {
        LinearLayout f=formLayout();
        EditText person=edit("نام شخص",InputType.TYPE_CLASS_TEXT);
        Spinner kind=new Spinner(this); String[] kinds={"طلب از شخص","بدهی به شخص"}; kind.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,kinds));
        EditText amount=edit("مبلغ کل به تومان",InputType.TYPE_CLASS_NUMBER),note=edit("شرح (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(person);f.addView(kind);f.addView(amount);f.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت بدهی یا طلب").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long a=parseAmount(amount.getText().toString());String who=person.getText().toString().trim();
            if(a<=0||who.isEmpty()){toast("نام و مبلغ را درست وارد کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("person",who);v.put("kind",kind.getSelectedItem().toString());v.put("amount",a);v.put("paid",0);v.put("note",note.getText().toString());v.put("date",System.currentTimeMillis());
            db.getWritableDatabase().insert("debts",null,v);toast("بدهی/طلب ثبت شد");showDebts();
        }).show();
    }
    private void showDebts() {
        body.removeAllViews();addHeading("بدهی‌ها و طلب‌ها");
        addWideButton("＋ ثبت بدهی یا طلب",()->showDebtDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,person,kind,amount,paid,note,date FROM debts WHERE book=? ORDER BY date DESC",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز بدهی یا طلبی ثبت نشده است.");return;}
        do {
            long id=c.getLong(0), amount=c.getLong(3), paid=c.getLong(4);String person=c.getString(1),kind=c.getString(2),note=c.getString(5);long remaining=Math.max(0,amount-paid);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));
            card.addView(text(person+" • "+kind,15,TEXT,true));card.addView(text("کل: "+money(amount)+" | تسویه: "+money(paid),13,Color.GRAY,false));
            card.addView(text("مانده: "+money(remaining),16,remaining==0?GREEN:Color.rgb(183,74,60),true));if(note!=null&&!note.isEmpty())card.addView(text(note,12,Color.GRAY,false));
            Button settle=button(remaining==0?"تسویه کامل شده":"ثبت تسویه / دریافت" );settle.setEnabled(remaining>0);card.addView(settle);settle.setOnClickListener(v->settleDebt(id,person,kind,remaining));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(card,lp);
        }while(c.moveToNext());c.close();
    }
    private void settleDebt(long id,String person,String kind,long remaining) {
        EditText amount=edit("مبلغ این تسویه (مانده: "+remaining+")",InputType.TYPE_CLASS_NUMBER);amount.setText(String.valueOf(remaining));
        new AlertDialog.Builder(this).setTitle("تسویه با "+person).setView(amount).setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{
            long a=parseAmount(amount.getText().toString());if(a<=0||a>remaining){toast("مبلغ باید بین ۱ تا مانده بدهی باشد");return;}
            SQLiteDatabase sql=db.getWritableDatabase();
            sql.execSQL("UPDATE debts SET paid=MIN(amount,paid+?) WHERE id=?",new Object[]{a,id});
            String txType=kind.contains("بدهی")?"هزینه":"درآمد";String cat=kind.contains("بدهی")?"تسویه بدهی":"دریافت طلب";ensureAccount("پول نقد");
            ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",txType);tx.put("amount",a);tx.put("category",cat);tx.put("account","پول نقد");tx.put("note","تسویه با "+person);tx.put("date",System.currentTimeMillis());sql.insert("transactions",null,tx);
            toast("تسویه ثبت شد");showDebts();
        }).show();
    }
    private void showSettings() {
        body.removeAllViews();addHeading("تنظیمات");
        addWideButton("مدیریت دفترها",()->manageBooks());
        addWideButton("افزودن حساب بانکی یا کیف پول",()->addAccountDialog());
        addWideButton("بودجه‌بندی ماهانه و هشدار هزینه",()->showBudgets());
        addWideButton("گزارش مالی و ارزش خالص دارایی",()->showReports());
        addWideButton("بدهی‌ها، طلب‌ها و تسویه",()->showDebts());
        addWideButton("قفل برنامه با رمز عددی",()->setPinDialog());
        addWideButton("پشتیبان‌گیری از اطلاعات",()->exportBackup());
        addWideButton("بازیابی پشتیبان",()->importBackup());
        addWideButton("درباره برنامه",()->new AlertDialog.Builder(this).setTitle("حساب‌یار ۰.۲").setMessage("حسابداری شخصی فارسی؛ ذخیره‌سازی محلی روی گوشی، دفترهای جداگانه، تراکنش‌ها، دارایی‌ها، بدهی و طلب، تسویه، بودجه، گزارش و پشتیبان‌گیری. قفل عددی برنامه جایگزین رمزنگاری فایل پایگاه داده نیست.").setPositiveButton("باشه",null).show());
        addEmpty("واحد: تومان • تاریخ نمایشی: شمسی • داده‌ها روی همین گوشی ذخیره می‌شوند.");
    }
    private void showBudgets() {
        body.removeAllViews();addHeading("بودجه‌بندی ماهانه");
        addWideButton("＋ تعریف سقف هزینه برای دسته‌بندی",()->budgetDialog());
        String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT category,limit_amount FROM budgets WHERE book=? AND month=? ORDER BY category",new String[]{activeBook,month});
        if(!c.moveToFirst()){c.close();addEmpty("برای این ماه بودجه‌ای تعریف نشده است.");return;}
        do {String cat=c.getString(0);long limit=c.getLong(1),spent=categoryExpenseThisMonth(cat);int pct=limit<=0?0:(int)Math.min(100,spent*100.0/limit);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(cat,15,TEXT,true));card.addView(text("هزینه: "+money(spent)+" / بودجه: "+money(limit),13,TEXT,false));
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(pct);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(8)));
            card.addView(text(pct>=100?"هشدار: بودجه مصرف شده است":"مصرف بودجه: "+pct+"٪",12,pct>=100?Color.rgb(183,74,60):GREEN,false));body.addView(card,new LinearLayout.LayoutParams(-1,-2));
        }while(c.moveToNext());c.close();
    }
    private void budgetDialog() {
        LinearLayout f=formLayout();EditText cat=edit("دسته‌بندی هزینه (مثلاً خوراک)",InputType.TYPE_CLASS_TEXT),limit=edit("سقف بودجه ماهانه به تومان",InputType.TYPE_CLASS_NUMBER);f.addView(cat);f.addView(limit);
        new AlertDialog.Builder(this).setTitle("تعریف بودجه ماه جاری").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String name=cat.getText().toString().trim();long amount=parseAmount(limit.getText().toString());if(name.isEmpty()||amount<=0){toast("دسته‌بندی و سقف معتبر وارد کن");return;}String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());SQLiteDatabase sql=db.getWritableDatabase();sql.delete("budgets","book=? AND category=? AND month=?",new String[]{activeBook,name,month});ContentValues v=new ContentValues();v.put("book",activeBook);v.put("category",name);v.put("month",month);v.put("limit_amount",amount);sql.insert("budgets",null,v);showBudgets();}).show();
    }
    private long categoryExpenseThisMonth(String cat) {
        Calendar cal=Calendar.getInstance();cal.set(Calendar.DAY_OF_MONTH,1);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);long start=cal.getTimeInMillis();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type='هزینه' AND category=? AND date>=?",new String[]{activeBook,cat,String.valueOf(start)});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;
    }
    private void showReports() {
        body.removeAllViews();addHeading("گزارش مالی و ارزش خالص");long income=sum("درآمد"),expense=sum("هزینه"),assets=scalar("SELECT COALESCE(SUM(value),0) FROM assets WHERE book=?",activeBook),receivable=scalar("SELECT COALESCE(SUM(amount-paid),0) FROM debts WHERE book=? AND kind LIKE '%طلب%'",activeBook),payable=scalar("SELECT COALESCE(SUM(amount-paid),0) FROM debts WHERE book=? AND kind LIKE '%بدهی%'",activeBook);
        addMetric("موجودی نقدی محاسبه‌شده",money(balance()),GREEN);addMetric("درآمد ثبت‌شده",money(income),GREEN);addMetric("هزینه ثبت‌شده",money(expense),Color.rgb(183,74,60));addMetric("خالص درآمد منهای هزینه",money(income-expense),income>=expense?GREEN:Color.rgb(183,74,60));addMetric("ارزش دارایی‌های غیرنقدی",money(assets),GREEN);addMetric("طلب‌های باز",money(receivable),GREEN);addMetric("بدهی‌های باز",money(payable),Color.rgb(183,74,60));addMetric("ارزش خالص تقریبی",money(balance()+assets+receivable-payable),GREEN);
        addHeading("هزینه بر اساس دسته‌بندی");Cursor c=db.getReadableDatabase().rawQuery("SELECT category,SUM(amount) total FROM transactions WHERE book=? AND type='هزینه' GROUP BY category ORDER BY total DESC",new String[]{activeBook});if(!c.moveToFirst())addEmpty("هنوز هزینه‌ای ثبت نشده است.");else do{addEmpty(c.getString(0)+"  •  "+money(c.getLong(1)));}while(c.moveToNext());c.close();
        addHeading("خلاصه ۳۰ روز اخیر");long since=System.currentTimeMillis()-30L*24*60*60*1000;addEmpty("درآمد: "+money(sumSince("درآمد",since))+"
هزینه: "+money(sumSince("هزینه",since)));
    }
    private long scalar(String query,String book){Cursor c=db.getReadableDatabase().rawQuery(query,new String[]{book});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    private long sumSince(String type,long since){Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=? AND date>=?",new String[]{activeBook,type,String.valueOf(since)});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    private void exportBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"HisabYar-backup.db");startActivityForResult(i,REQ_EXPORT_BACKUP);}
    private void importBackup(){new AlertDialog.Builder(this).setTitle("بازیابی پشتیبان").setMessage("بازیابی، اطلاعات فعلی برنامه را با نسخه پشتیبان جایگزین می‌کند. پیش از ادامه از اطلاعات فعلی نسخه پشتیبان بگیر.").setNegativeButton("انصراف",null).setPositiveButton("انتخاب فایل",(d,w)->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");startActivityForResult(i,REQ_IMPORT_BACKUP);}).show();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{if(requestCode==REQ_EXPORT_BACKUP){db.close();try(InputStream in=new FileInputStream(getDatabasePath("hisabyar.db"));OutputStream out=getContentResolver().openOutputStream(uri)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}db=new DB(this);toast("پشتیبان ذخیره شد");}else if(requestCode==REQ_IMPORT_BACKUP){db.close();try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(getDatabasePath("hisabyar.db"))){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}db=new DB(this);db.getWritableDatabase();toast("پشتیبان بازیابی شد");navigate("خانه");}}catch(Exception e){db=new DB(this);toast("عملیات پشتیبان انجام نشد: "+e.getMessage());}}
    private void setPinDialog(){String old=getPreferences(0).getString("app_pin","");LinearLayout f=formLayout();EditText pin=edit("رمز عددی ۴ تا ۸ رقمی (خالی = حذف رمز)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);f.addView(pin);new AlertDialog.Builder(this).setTitle(old.isEmpty()?"تنظیم قفل برنامه":"تغییر یا حذف قفل").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String p=pin.getText().toString().trim();if(!p.isEmpty()&&(p.length()<4||p.length()>8)){toast("رمز باید ۴ تا ۸ رقم باشد");return;}getPreferences(0).edit().putString("app_pin",p).apply();toast(p.isEmpty()?"قفل حذف شد":"قفل برنامه فعال شد");}).show();}
    private void promptUnlockIfNeeded(){String pin=getPreferences(0).getString("app_pin","");if(pin.isEmpty())return;EditText input=edit("رمز عددی برنامه",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);AlertDialog dlg=new AlertDialog.Builder(this).setTitle("حساب‌یار قفل است").setView(input).setCancelable(false).setPositiveButton("باز کردن",null).create();dlg.setOnShowListener(x->dlg.getButton(-1).setOnClickListener(v->{if(pin.equals(input.getText().toString()))dlg.dismiss();else{input.setText("");input.setError("رمز اشتباه است");}}));dlg.show();dlg.getButton(-1).setOnClickListener(v->{if(pin.equals(input.getText().toString()))dlg.dismiss();else{input.setText("");input.setError("رمز اشتباه است");}});}
    private String jalaliDate(long millis){Calendar c=Calendar.getInstance();c.setTimeInMillis(millis);int gy=c.get(Calendar.YEAR),gm=c.get(Calendar.MONTH)+1,gd=c.get(Calendar.DAY_OF_MONTH);int[] j=gregorianToJalali(gy,gm,gd);return String.format(new Locale("fa","IR"),"%04d/%02d/%02d",j[0],j[1],j[2]);}
    private int[] gregorianToJalali(int gy,int gm,int gd){int[] gdm={0,31,59,90,120,151,181,212,243,273,304,334};int gy2=gm>2?gy+1:gy;int days=355666+365*gy+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400+gd+gdm[gm-1];int jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365;}int jm,jd;if(days<186){jm=1+days/31;jd=1+days%31;}else{jm=7+(days-186)/30;jd=1+(days-186)%30;}return new int[]{jy,jm,jd};}
    private void chooseBook() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM books ORDER BY id",null);java.util.ArrayList<String> names=new java.util.ArrayList<>();while(c.moveToNext())names.add(c.getString(0));c.close();
        String[] a=names.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("انتخاب دفتر").setItems(a,(d,w)->{activeBook=a[w];ensureBookAccount();navigate("خانه");}).setNegativeButton("انصراف",null).show();
    }
    private void manageBooks() {
        LinearLayout f=formLayout();EditText name=edit("نام دفتر جدید (مثلاً شخصی، گلخانه)",InputType.TYPE_CLASS_TEXT);f.addView(name);
        new AlertDialog.Builder(this).setTitle("افزودن دفتر مالی").setView(f).setNeutralButton("انتخاب دفتر",(d,w)->chooseBook()).setNegativeButton("بستن",null).setPositiveButton("افزودن",(d,w)->{String n=name.getText().toString().trim();if(!n.isEmpty()){addBookRaw(n);activeBook=n;ensureBookAccount();toast("دفتر اضافه شد");navigate("خانه");}}).show();
    }
    private void addAccountDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام حساب",InputType.TYPE_CLASS_TEXT),kind=edit("نوع حساب (بانکی/نقدی/کیف پول)",InputType.TYPE_CLASS_TEXT),opening=edit("موجودی اولیه به تومان",InputType.TYPE_CLASS_NUMBER);f.addView(name);f.addView(kind);f.addView(opening);
        new AlertDialog.Builder(this).setTitle("حساب جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty())return;ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("kind",kind.getText().toString());v.put("opening",parseAmount(opening.getText().toString()));db.getWritableDatabase().insert("accounts",null,v);navigate("خانه");}).show();
    }
    private void ensureAccount(String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{activeBook,name});boolean exists=c.moveToFirst();c.close();
        if(!exists){ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name);v.put("kind","نقدی");v.put("opening",0);db.getWritableDatabase().insert("accounts",null,v);}
    }
    private void ensureBookAccount() { if(countForBook("accounts",activeBook)==0)ensureAccount("پول نقد"); }
    private long sum(String type) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=?",new String[]{activeBook,type});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;
    }
    private long balance() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(opening),0) FROM accounts WHERE book=?",new String[]{activeBook});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();
        Cursor t=db.getReadableDatabase().rawQuery("SELECT type,amount FROM transactions WHERE book=?",new String[]{activeBook});
        while(t.moveToNext()){String type=t.getString(0);long a=t.getLong(1);if(type.equals("درآمد")||type.equals("انتقال ورودی"))n+=a;else if(type.equals("هزینه")||type.equals("انتقال خروجی"))n-=a;}t.close();return n;
    }
    private long parseAmount(String s) { try{return Long.parseLong(s.replace(",","").replace("٬","").trim());}catch(Exception e){return 0;} }
    private String money(long n) { NumberFormat f=NumberFormat.getInstance(new Locale("fa","IR"));return f.format(n)+" تومان"; }
    private void addHeading(String s) {TextView t=text(s,18,TEXT,true);t.setPadding(0,dp(8),0,dp(10));body.addView(t);}
    private void addEmpty(String s) {TextView t=text(s,14,Color.GRAY,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(16),dp(20),dp(16),dp(20));body.addView(t);}
    private void addWideButton(String s,Runnable r) {Button b=button(s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.setMargins(0,dp(5),0,dp(5));body.addView(b,lp);b.setOnClickListener(v->r.run());}
    private View actionBox(String s,Runnable r) {TextView t=text(s,15,GREEN,true);t.setGravity(Gravity.CENTER);t.setBackground(roundBg(Color.WHITE));t.setOnClickListener(v->r.run());return t;}
    private LinearLayout formLayout(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(20),dp(8),dp(20),dp(4));return l;}
    private EditText edit(String hint,int inputType){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine(true);e.setInputType(inputType);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(dp(8),dp(6),dp(8),dp(6));return e;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(0,dp(3),0,dp(3));return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(GREEN);b.setAllCaps(false);return b;}
    private android.graphics.drawable.GradientDrawable roundBg(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private class DB extends SQLiteOpenHelper {
        DB(Activity a){super(a,"hisabyar.db",null,2);}
        @Override public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE)");
            d.execSQL("CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,opening INTEGER NOT NULL DEFAULT 0)");
            d.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,name TEXT NOT NULL)");
            d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,note TEXT,date INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE assets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,value INTEGER NOT NULL,note TEXT)");
            d.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,person TEXT NOT NULL,kind TEXT,amount INTEGER NOT NULL,paid INTEGER NOT NULL DEFAULT 0,note TEXT,date INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE budgets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,category TEXT NOT NULL,month TEXT NOT NULL,limit_amount INTEGER NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int oldVersion,int newVersion){
            if(oldVersion<2){d.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_book_date ON transactions(book,date)");d.execSQL("CREATE INDEX IF NOT EXISTS idx_debts_book ON debts(book)");d.execSQL("CREATE INDEX IF NOT EXISTS idx_budgets_book_month ON budgets(book,month)");}
        }
    }
}
