package com.example.hisabyar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.os.Build;
import android.widget.*;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.PrintWriter;
import android.content.ClipboardManager;
import android.content.ClipData;
import java.io.File;
import java.util.Locale;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private static final String VOICE_TAG = "HisabYarProVoice";
    // HisabYar Pro uses an embedded Persian Vosk model. Audio recognition is fully local.
    private org.vosk.Model offlineVoiceModel;
    private org.vosk.Recognizer offlineVoiceRecognizer;
    private org.vosk.android.SpeechService offlineSpeechService;
    private boolean offlineVoiceReady = false;
    private boolean offlineVoiceLoading = false;
    private boolean voiceButtonHeld = false;
    private boolean voiceStopRequested = false;
    private boolean voiceResultHandled = false;
    private static final int GREEN = Color.rgb(226, 78, 116);
    private static final int DARK = Color.rgb(142, 35, 67);
    private static final int BG = Color.rgb(255, 245, 247);
    private static final int TEXT = Color.rgb(35, 45, 40);
    private DB db;
    private static final int[] THEME_COLORS = new int[]{Color.rgb(226,78,116), Color.rgb(33,150,243), Color.rgb(76,175,80), Color.rgb(103,58,183), Color.rgb(255,152,0), Color.rgb(0,150,136), Color.rgb(55,71,79), Color.rgb(233,30,99)};
    private static final String[] THEME_NAMES = new String[]{"صورتی", "آبی", "سبز", "بنفش", "نارنجی", "فیروزه‌ای", "ذغالی", "سرخابی"};
    private int selectedThemeColor() { return getPreferences(0).getInt("theme_color", THEME_COLORS[0]); }
    private int darken(int color) { return Color.rgb((int)(Color.red(color)*0.65f),(int)(Color.green(color)*0.65f),(int)(Color.blue(color)*0.65f)); }
    private int lighten(int color, float amount) { return Color.rgb((int)(Color.red(color)+(255-Color.red(color))*amount),(int)(Color.green(color)+(255-Color.green(color))*amount),(int)(Color.blue(color)+(255-Color.blue(color))*amount)); }
    private void applyThemeToShell() {
        int c=selectedThemeColor();
        if(root!=null) root.setBackgroundColor(lighten(c,0.93f));
        if(topbar!=null) topbar.setBackground(gradientBg(new int[]{darken(c),c,darken(c)},dp(20)));
        if(navBar!=null) navBar.setBackground(gradientBg(new int[]{lighten(c,0.82f),lighten(c,0.48f),c,lighten(c,0.48f),lighten(c,0.82f)},dp(22)));
        if(Build.VERSION.SDK_INT>=21) {
            getWindow().setStatusBarColor(lighten(c,0.82f));
            getWindow().setNavigationBarColor(darken(c));
        }
    }
    private void showThemePalette(LinearLayout target) {
        target.addView(text("رنگ تم برنامه",16,TEXT,true));
        target.addView(text("رنگ دلخواه را انتخاب کنید؛ انتخاب شما ذخیره می‌شود.",12,TEXT,false));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,dp(8),0,dp(8));
        for(int i=0;i<THEME_COLORS.length;i++) { final int color=THEME_COLORS[i]; final String name=THEME_NAMES[i];
            TextView swatch=new TextView(this); swatch.setText("●"); swatch.setTextSize(29); swatch.setGravity(Gravity.CENTER); swatch.setTextColor(color); swatch.setContentDescription(name);
            android.graphics.drawable.GradientDrawable bg=ovalBg(lighten(color,0.8f)); bg.setStroke(dp(selectedThemeColor()==color?4:1),selectedThemeColor()==color?darken(color):Color.LTGRAY); swatch.setBackground(bg);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1); lp.setMargins(dp(2),0,dp(2),0); row.addView(swatch,lp);
            swatch.setOnClickListener(v->{getPreferences(0).edit().putInt("theme_color",color).apply(); applyThemeToShell(); showThemePaletteRefresh(); toast("تم برنامه: "+name);});
        }
        target.addView(row);
    }
    private void showThemePaletteRefresh() {
        applyThemeToShell();
        if ("تنظیمات".equals(page)) showSettings();
        else { showShell(); if ("خانه".equals(page)) showHome(); else showSettings(); }
    }

    private android.speech.SpeechRecognizer speechRecognizer;
    private LinearLayout root, body, topbar, navBar;
    private TextView headerTitle, headerHint, headerDateTime;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable clockTicker = new Runnable() { @Override public void run() { updateHeaderClock(); uiHandler.postDelayed(this, 60_000); } };
    private String activeBook = "شخصی";
    private String page = "خانه";
    private static final int REQ_EXPORT_BACKUP = 701;
    private static final int REQ_IMPORT_BACKUP = 702;
    private static final int REQ_EXPORT_CSV = 703;
    private static final int REQ_AUDIO_PERMISSION = 704;
    private static final int REQ_VOICE_INPUT = 705;
    private static final int REQ_CHEQUE_IMAGE = 706;
    private EditText chequeNumberField, chequeBankField, chequePartyField, chequeAmountField, chequeDueField, chequeAccountField, chequeNoteField;
    private Spinner chequeDirectionSpinner, chequeStatusSpinner;
    private String pendingChequeImagePath = "";
    private String pendingChequeOcrText = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        activeBook = getPreferences(0).getString("active_book", "شخصی");
        ensureDefaults();
        showShell();
        showHome();
        promptUnlockIfNeeded();
        prepareOfflineVoiceModel();
    }

    private void ensureDefaults() {
        SQLiteDatabase w = db.getWritableDatabase();
        if (count("books") == 0) {
            addBookRaw("شخصی");
            addBookRaw("کسب‌وکار");
        }
        if (countForBook("accounts", activeBook) == 0) {
            ContentValues v = new ContentValues();
            v.put("book", activeBook); v.put("name", "پول نقد"); v.put("kind", "نقدی"); v.put("opening", 0L); v.put("account_uid", java.util.UUID.randomUUID().toString()); v.put("enabled",1);
            w.insert("accounts", null, v);
        }
        if (count("categories") == 0) {
            String[][] cats = {{"هزینه","خوراک"},{"هزینه","مسکن"},{"هزینه","حمل‌ونقل"},{"هزینه","سلامت"},{"هزینه","خرید شخصی"},{"هزینه","قبوض"},{"هزینه","تفریح"},{"هزینه","سایر"},{"درآمد","حقوق"},{"درآمد","کسب‌وکار"},{"درآمد","سرمایه‌گذاری"},{"درآمد","سایر"}};
            for (String[] c : cats) { ContentValues v = new ContentValues(); v.put("type",c[0]); v.put("name",c[1]); w.insert("categories",null,v); }
        }
    }
    private long count(String table) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private long countForBook(String table, String book) {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+" WHERE book=?",new String[]{book});
        long n=0; if(c.moveToFirst()) n=c.getLong(0); c.close(); return n;
    }
    private void addBookRaw(String name) {
        ContentValues v=new ContentValues(); v.put("name",name); db.getWritableDatabase().insert("books",null,v);
    }

    private void showShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(lighten(selectedThemeColor(),0.93f));

        topbar = new LinearLayout(this);
        topbar.setOrientation(LinearLayout.VERTICAL);
        topbar.setPadding(dp(18), dp(10), dp(18), dp(10));
        topbar.setElevation(dp(5));
        topbar.setBackground(gradientBg(new int[]{darken(selectedThemeColor()), selectedThemeColor(), darken(selectedThemeColor())}, dp(20)));
        headerTitle = text(headerTitleForPage(), 23, Color.WHITE, true);
        headerTitle.setGravity(Gravity.RIGHT);
        topbar.addView(headerTitle);
        headerHint = text(headerHintForPage(), 12, Color.rgb(255, 235, 241), false);
        headerHint.setPadding(0, dp(3), 0, dp(5));
        topbar.addView(headerHint);
        LinearLayout infoRow = new LinearLayout(this);
        infoRow.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        headerDateTime = text("", 12, Color.rgb(255, 219, 230), true);
        infoRow.addView(headerDateTime);
        topbar.addView(infoRow);
        updateHeaderClock();
        uiHandler.removeCallbacks(clockTicker);
        uiHandler.postDelayed(clockTicker, 60_000);
        LinearLayout.LayoutParams topLp = new LinearLayout.LayoutParams(-1, -2);
        topLp.setMargins(dp(12), dp(8), dp(12), dp(4));
        root.addView(topbar, topLp);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        body.setPadding(dp(14), dp(10), dp(14), dp(14));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setGravity(Gravity.CENTER);
        navBar.setPadding(dp(5), dp(6), dp(5), dp(6));
        navBar.setClipChildren(false);
        navBar.setClipToPadding(false);
        // The palette becomes deeper toward the center to draw attention to voice entry.
        navBar.setBackground(gradientBg(new int[]{lighten(selectedThemeColor(),0.82f), lighten(selectedThemeColor(),0.48f), selectedThemeColor(), lighten(selectedThemeColor(),0.48f), lighten(selectedThemeColor(),0.82f)}, dp(22)));
        navBar.setElevation(dp(12));
        String[][] tabs = {{"خانه", "⌂"}, {"تراکنش‌ها", "↕"}, {"دستیار صوتی", ""}, {"دارایی‌ها", "◇"}, {"تنظیمات", "☰"}};
        for (int i = 0; i < tabs.length; i++) {
            final String target = tabs[i][0];
            final boolean voice = "دستیار صوتی".equals(target);
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setClipChildren(false);
            item.setClipToPadding(false);
            if (voice) {
                item.setGravity(Gravity.CENTER);
                item.setBackground(ovalBg(Color.rgb(255, 224, 234)));
                item.setElevation(dp(8));
                ImageView mic = new ImageView(this);
                mic.setImageResource(android.R.drawable.ic_btn_speak_now);
                mic.setColorFilter(Color.rgb(142, 35, 67));
                mic.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                item.addView(mic, new LinearLayout.LayoutParams(dp(31), dp(31)));
                item.setContentDescription("دستیار صوتی؛ شروع ثبت تراکنش با گفتار");
            } else {
                item.setPadding(dp(2), dp(3), dp(2), dp(3));
                boolean selected = target.equals(page);
                item.setBackground(roundBg(selected ? Color.rgb(255, 232, 239) : Color.TRANSPARENT));
                TextView icon = text(tabs[i][1], 21, target.equals(page) ? Color.rgb(125, 43, 73) : Color.rgb(91, 48, 63), true);
                icon.setGravity(Gravity.CENTER);
                TextView label = text(target, 11, target.equals(page) ? Color.rgb(125, 43, 73) : Color.rgb(91, 48, 63), true);
                label.setGravity(Gravity.CENTER);
                label.setMinHeight(dp(18));
                label.setMaxLines(1);
                label.setIncludeFontPadding(true);
                item.addView(icon);
                item.addView(label);
                item.setContentDescription(target);
            }
            if (voice) {
                item.setContentDescription("برای ضبط فرمان صوتی نگه دارید؛ با رها کردن، گفتار بررسی می‌شود");
                item.setOnTouchListener((v, event) -> {
                    switch (event.getAction()) {
                        case android.view.MotionEvent.ACTION_DOWN:
                            v.setPressed(true);
                            startVoiceAssistant();
                            return true;
                        case android.view.MotionEvent.ACTION_UP:
                        case android.view.MotionEvent.ACTION_CANCEL:
                            v.setPressed(false);
                            stopVoiceListening();
                            return true;
                        default:
                            return true;
                    }
                });
            } else {
                item.setOnClickListener(v -> navigate(target));
            }
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(0, voice ? dp(64) : dp(60), voice ? 1.08f : 1f);
            itemLp.setMargins(dp(2), 0, dp(2), 0);
            navBar.addView(item, itemLp);
        }
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(-1, -2);
        navLp.setMargins(dp(8), dp(4), dp(8), dp(3));
        root.addView(navBar, navLp);
        // Android 15 enforces edge-to-edge for targetSdk 35. Keep navigation items
        // above the system navigation buttons/gesture area on all supported versions.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int topInset;
            int bottomInset;
            if (Build.VERSION.SDK_INT >= 30) {
                topInset = insets.getInsets(WindowInsets.Type.statusBars()).top;
                bottomInset = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            // Keep the header pinned below the phone status bar on every page.
            root.setPadding(0, topInset, 0, 0);
            navBar.setPadding(dp(5), dp(6), dp(5), dp(6) + bottomInset);
            return insets;
        });
        if (Build.VERSION.SDK_INT >= 21) {
            // System bars follow the user's selected theme color.
            getWindow().setStatusBarColor(lighten(selectedThemeColor(),0.82f));
            getWindow().setNavigationBarColor(darken(selectedThemeColor()));
        }
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        setContentView(root);
        root.requestApplyInsets();
    }

    private String headerTitleForPage() {
        switch (page) {
            case "خانه": return "خانه";
            case "تراکنش‌ها": return "تراکنش‌ها";
            case "ثبت": return "ثبت عملیات مالی";
            case "دارایی‌ها": return "دارایی‌ها";
            case "تنظیمات": return "تنظیمات";
            default: return "حساب‌یار";
        }
    }

    private String headerHintForPage() {
        switch (page) {
            case "خانه": return "خلاصه موجودی، درآمد و هزینه‌های دفتر انتخاب‌شده";
            case "تراکنش‌ها": return "تراکنش‌ها را جست‌وجو و جزئیاتشان را بررسی کنید";
            case "ثبت": return "نوع عملیات را انتخاب کنید و پیش از ثبت، مبلغ را بررسی کنید";
            case "دارایی‌ها": return "ارزش دارایی‌ها و موارد ثبت‌شده را مدیریت کنید";
            case "تنظیمات": return "دفتر، پشتیبان‌گیری و تنظیمات برنامه";
            default: return "اطلاعات مالی شما روی همین گوشی ذخیره می‌شود";
        }
    }

    private void setHeaderInfo(String title, String hint) {
        if (headerTitle != null) headerTitle.setText(title);
        if (headerHint != null) headerHint.setText(hint);
    }

    private void updateHeaderClock() {
        if (headerDateTime != null) {
            String time = new SimpleDateFormat("HH:mm", new Locale("fa", "IR")).format(new Date());
            headerDateTime.setText(jalaliDate(System.currentTimeMillis()) + "  •  " + time);
        }
    }

    @Override protected void onDestroy() {
        uiHandler.removeCallbacks(clockTicker);
        releaseVoiceRecognizer();
        super.onDestroy();
    }

    private void navigate(String p) {
        page = p;
        showShell();
        body.removeAllViews();
        switch(p) {
            case "خانه": showHome(); break;
            case "تراکنش‌ها": showTransactions(); break;
            case "ثبت": showAddMenu(); break;
            case "دارایی‌ها": showAssets(); break;
            default: showSettings(); break;
        }
    }
    private void showHome() {
        setHeaderInfo("خانه", "موجودی، درآمد و هزینه‌های دفتر «" + activeBook + "»");
        body.removeAllViews();
        LinearLayout bookrow = new LinearLayout(this);
        bookrow.setGravity(Gravity.CENTER_VERTICAL);
        View bookSpacer = new View(this);
        bookrow.addView(bookSpacer, new LinearLayout.LayoutParams(0, 1, 1));
        Button switchB = button("دفتر: " + activeBook + " ▾");
        switchB.setTextSize(12);
        switchB.setBackground(roundBg(Color.WHITE));
        bookrow.addView(switchB);
        switchB.setOnClickListener(v -> chooseBook());
        body.addView(bookrow);

        long income = sum("درآمد"), expense = sum("هزینه"), bal = balance();
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(roundBg(selectedThemeColor()));
        TextView heroLabel = text("موجودی محاسبه‌شده", 14, Color.rgb(255, 226, 235), false);
        TextView heroValue = text(money(bal), 29, Color.WHITE, true);
        hero.addView(heroLabel); hero.addView(heroValue);
        TextView heroFoot = text("مجموع موجودی اولیه + درآمدها − هزینه‌ها", 11, Color.rgb(255, 226, 235), false);
        hero.addView(heroFoot);
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(-1, -2);
        heroLp.setMargins(0, dp(12), 0, dp(8));
        body.addView(hero, heroLp);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.addView(metricBox("درآمد کل", money(income), GREEN), new LinearLayout.LayoutParams(0, -2, 1));
        View spacer = new View(this); metrics.addView(spacer, new LinearLayout.LayoutParams(dp(8), 1));
        metrics.addView(metricBox("هزینه کل", money(expense), Color.rgb(204, 103, 112)), new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(metrics);

        java.util.ArrayList<String> quickActions = getQuickActions();
        if (!quickActions.isEmpty()) {
            addHeading("دسترسی سریع");
            for (String action : quickActions) addWideButton(quickActionLabel(action), () -> runQuickAction(action));
        }

        addHeading("موجودی حساب‌ها");
        addAccountBalancesIntoBody();

        addHeading("آخرین تراکنش‌ها");
        showRecentIntoBody();
        addWideButton("مشاهده همه تراکنش‌ها  ←", () -> navigate("تراکنش‌ها"));
    }

    private View spaceWidth(int width) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(width), 1)); return v; }

    private View metricBox(String label,String value,int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(14), dp(12), dp(14));
        box.setBackground(roundBg(Color.WHITE));
        TextView a = text(label, 12, Color.rgb(105, 116, 110), false);
        TextView b = text(value, 15, color, true);
        box.addView(a); box.addView(b);
        return box;
    }

    private void addMetric(String label,String value,int color) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(18),dp(16),dp(18)); box.setBackground(roundBg(Color.WHITE));
        TextView a=text(label,14,Color.rgb(86, 99, 91),false), b=text(value,25,color,true); box.addView(a); box.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(10),0,dp(10)); body.addView(box,lp);
    }
    private void showAddMenu() {
        setHeaderInfo("ثبت عملیات مالی", "نوع عملیات را انتخاب کنید و پیش از ثبت، مبلغ را بررسی کنید");
        body.removeAllViews(); addHeading("ثبت عملیات مالی");
        addWideButton("🎙 برای صحبت، دکمهٔ دستیار صوتی پایین صفحه را نگه دارید", () -> toast("برای ضبط فرمان، دکمهٔ میکروفون پایین صفحه را نگه دارید و پس از پایان صحبت رها کنید."));
        addWideButton("ثبت هزینه",()->showEntry("هزینه"));
        addWideButton("ثبت درآمد",()->showEntry("درآمد"));
        addWideButton("انتقال بین حساب‌ها",()->showTransfer());
        addWideButton("ثبت دارایی",()->showAssetDialog());
        addWideButton("ثبت بدهی یا طلب",()->showDebtDialog());
        addWideButton("دریافت و پرداخت چک",()->showCheques());
        addWideButton("مشاهده و تسویه بدهی‌ها و طلب‌ها",()->showDebts());
        addWideButton("بودجه‌بندی ماهانه",()->showBudgets());
        addWideButton("پرداخت‌های تکرارشونده و سررسیدها",()->showRecurring());
        addWideButton("هدف‌های پس‌انداز",()->showGoals());
        addWideButton("گزارش‌ها و ارزش خالص",()->showReports());
    }
    private void showEntry(String type) {
        LinearLayout form=formLayout();
        EditText amount=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER);
        AutoCompleteTextView category=categoryInput(type,"دسته‌بندی (مثلاً خوراک)");
        AutoCompleteTextView account=accountInput("حساب (مثلاً پول نقد)");
        Spinner paymentMethod=styledSpinner();paymentMethod.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"نقدی","کارت بانکی","انتقال بانکی","کارت‌خوان","اعتباری","متفرقه"}));paymentMethod.setSelection(5);
        EditText note=edit("شرح / یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        Calendar selectedDate=Calendar.getInstance();
        Button dateButton=button("تاریخ تراکنش: "+jalaliDate(selectedDate.getTimeInMillis()));
        dateButton.setOnClickListener(v->{Calendar cur=(Calendar)selectedDate.clone();new DatePickerDialog(this,(view,year,month,day)->{selectedDate.set(Calendar.YEAR,year);selectedDate.set(Calendar.MONTH,month);selectedDate.set(Calendar.DAY_OF_MONTH,day);selectedDate.set(Calendar.HOUR_OF_DAY,12);selectedDate.set(Calendar.MINUTE,0);selectedDate.set(Calendar.SECOND,0);dateButton.setText("تاریخ تراکنش: "+jalaliDate(selectedDate.getTimeInMillis()));},cur.get(Calendar.YEAR),cur.get(Calendar.MONTH),cur.get(Calendar.DAY_OF_MONTH)).show();});
        form.addView(amount); form.addView(category); form.addView(account); form.addView(text("نوع پرداخت",13,TEXT,true)); form.addView(paymentMethod); form.addView(dateButton); form.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت "+type).setView(form)
          .setNegativeButton("انصراف",null).setPositiveButton("ثبت", (d,w)->{
              long a=parseAmount(amount.getText().toString());
              if(a<=0){toast("مبلغ باید بیشتر از صفر باشد");return;}
              String cat=category.getText().toString().trim(); if(cat.isEmpty()) cat=type.equals("هزینه")?"سایر":"سایر";
              String acc=account.getText().toString().trim(); if(acc.isEmpty()) acc="پول نقد";
              ensureAccount(acc);
              saveCategoryIfMissing(type,cat);
              ContentValues v=new ContentValues(); v.put("book",activeBook); v.put("type",type); v.put("amount",a); v.put("category",cat); v.put("account",acc); v.put("payment_method",String.valueOf(paymentMethod.getSelectedItem())); v.put("note",note.getText().toString()); v.put("date",selectedDate.getTimeInMillis()); setMonthKey(v,selectedDate.getTimeInMillis());
              if(isMonthClosed(monthKey(selectedDate.getTimeInMillis()))){toast("این ماه بسته شده است؛ برای ثبت در ماه جدید تاریخ را تغییر بده.");return;} db.getWritableDatabase().insert("transactions",null,v);
              toast("تراکنش ثبت شد"); navigate("خانه");
          }).show();
    }
    private void saveVoiceErrorReport(String report) {
        try (OutputStreamWriter writer = new OutputStreamWriter(
                new FileOutputStream(new File(getFilesDir(), "voice_error_report.txt"), false),
                StandardCharsets.UTF_8)) {
            writer.write(report);
        } catch (Exception saveError) {
            Log.e(VOICE_TAG, "Could not save voice error report", saveError);
        }
    }

    private String makeVoiceErrorReport(String stage, Throwable error, File external, long freeExternal, long freeInternal) {
        StringBuilder report = new StringBuilder();
        report.append("HisabYar Pro offline voice diagnostic\n")
              .append("App version: 1.4.9-Pro\n")
              .append("Stage: ").append(stage).append('\n')
              .append("Android SDK: ").append(Build.VERSION.SDK_INT).append('\n')
              .append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
              .append("External files dir: ").append(external == null ? "null" : external.getAbsolutePath()).append('\n')
              .append("Internal files dir: ").append(getFilesDir().getAbsolutePath()).append('\n')
              .append("Free external bytes: ").append(freeExternal).append('\n')
              .append("Free internal bytes: ").append(freeInternal).append('\n')
              .append("Assets model-fa entries: ");
        try {
            String[] entries = getAssets().list("model-fa");
            report.append(entries == null ? "null" : java.util.Arrays.toString(entries));
        } catch (Exception e) { report.append("ASSET_LIST_ERROR: ").append(e); }
        report.append("\n\nERROR / STACK TRACE:\n");
        if (error == null) report.append("No exception object supplied.\n");
        else {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            error.printStackTrace(pw);
            pw.flush();
            report.append(sw);
            Throwable cause = error.getCause();
            int depth = 0;
            while (cause != null && cause != error && depth++ < 10) {
                report.append("\nCAUSE ").append(depth).append(": ");
                cause.printStackTrace(pw = new PrintWriter(sw = new StringWriter()));
                pw.flush(); report.append(sw);
                cause = cause.getCause();
            }
        }
        return report.toString();
    }

    private void showVoiceErrorReport(String title, String stage, Throwable error, File external, long freeExternal, long freeInternal) {
        String report = makeVoiceErrorReport(stage, error, external, freeExternal, freeInternal);
        saveVoiceErrorReport(report);
        Log.e(VOICE_TAG, report, error);
        TextView details = new TextView(this);
        details.setText(report);
        details.setTextIsSelectable(true);
        details.setTextSize(12);
        details.setTextColor(Color.rgb(35, 35, 35));
        details.setPadding(dp(12), dp(12), dp(12), dp(12));
        details.setTypeface(Typeface.MONOSPACE);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(details);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage("گزارش کامل خطا آماده است. متن زیر را می‌توانی انتخاب و کپی کنی یا با دکمهٔ «کپی گزارش» یکجا کپی کنی.")
                .setView(scroll)
                .setPositiveButton("کپی گزارش", (dialog, which) -> {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(ClipData.newPlainText("HisabYar Pro voice error", report));
                        toast("گزارش کامل کپی شد؛ آن را اینجا ارسال کن.");
                    }
                })
                .setNeutralButton("بستن", null)
                .show();
    }

    private void prepareOfflineVoiceModel() {
        if (offlineVoiceReady || offlineVoiceLoading) return;
        offlineVoiceLoading = true;
        toast("در حال آماده‌سازی دستیار صوتی فارسی؛ بار اول ممکن است کمی طول بکشد.");
        File external = getExternalFilesDir(null);
        File internal = getFilesDir();
        long freeInternal = internal != null ? internal.getUsableSpace() : -1L;
        long freeExternal = external != null ? external.getUsableSpace() : -1L;
        Log.i(VOICE_TAG, "Model prepare started; external=" + (external == null ? "null" : external.getAbsolutePath())
                + ", freeExternal=" + freeExternal + ", freeInternal=" + freeInternal);
        try {
            org.vosk.android.StorageService.unpack(this, "model-fa", "model-fa",
                model -> runOnUiThread(() -> {
                    offlineVoiceModel = model;
                    offlineVoiceLoading = false;
                    offlineVoiceReady = true;
                    Log.i(VOICE_TAG, "Persian Vosk model loaded successfully.");
                    toast("دستیار صوتی فارسی آفلاین آماده است.");
                }),
                exception -> runOnUiThread(() -> {
                    offlineVoiceLoading = false;
                    offlineVoiceReady = false;
                    showVoiceErrorReport("خطای آماده‌سازی دستیار صوتی", "StorageService.unpack callback", exception, external, freeExternal, freeInternal);
                }));
        } catch (Exception exception) {
            offlineVoiceLoading = false;
            offlineVoiceReady = false;
            showVoiceErrorReport("خطای آماده‌سازی دستیار صوتی", "prepareOfflineVoiceModel catch", exception, external, freeExternal, freeInternal);
        }
    }

    private void startVoiceAssistant() {
        voiceButtonHeld = true;
        voiceStopRequested = false;
        voiceResultHandled = false;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            voiceButtonHeld = false;
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, REQ_AUDIO_PERMISSION);
            return;
        }
        if (!offlineVoiceReady || offlineVoiceModel == null) {
            if (!offlineVoiceLoading) prepareOfflineVoiceModel();
            toast("دستیار آفلاین در حال آماده‌سازی است؛ چند ثانیه صبر کن و دوباره نگه دار.");
            return;
        }
        releaseVoiceRecognizer();
        try {
            offlineVoiceRecognizer = new org.vosk.Recognizer(offlineVoiceModel, 16000.0f);
            try { offlineVoiceRecognizer.setMaxAlternatives(5); } catch (Exception ignored) { }
            offlineSpeechService = new org.vosk.android.SpeechService(offlineVoiceRecognizer, 16000.0f);
            offlineSpeechService.startListening(new org.vosk.android.RecognitionListener() {
                @Override public void onPartialResult(String hypothesis) { }
                @Override public void onResult(String hypothesis) { }
                @Override public void onFinalResult(String hypothesis) {
                    handleOfflineVoiceResult(hypothesis);
                }
                @Override public void onError(Exception exception) {
                    runOnUiThread(() -> {
                        releaseVoiceRecognizer();
                        if (voiceButtonHeld) toast("خطا در تشخیص گفتار آفلاین؛ مجوز میکروفون و فضای آزاد گوشی را بررسی کن.");
                    });
                }
                @Override public void onTimeout() {
                    runOnUiThread(() -> {
                        releaseVoiceRecognizer();
                        if (!voiceResultHandled) toast("گفتاری تشخیص داده نشد؛ دوباره و واضح‌تر صحبت کن.");
                    });
                }
            });
            toast("دستیار آفلاین گوش می‌دهد؛ برای پایان، دکمه را رها کن.");
        } catch (Exception e) {
            releaseVoiceRecognizer();
            toast("شروع دستیار آفلاین ناموفق بود. یک‌بار برنامه را ببند و دوباره باز کن.");
        }
    }

    private void handleOfflineVoiceResult(String hypothesis) {
        final String text = extractVoskText(hypothesis);
        runOnUiThread(() -> {
            if (voiceResultHandled) return;
            voiceResultHandled = true;
            releaseVoiceRecognizer();
            if (!text.trim().isEmpty()) processVoiceCommand(text);
            else toast("متن گفتار دریافت نشد؛ دوباره امتحان کن.");
        });
    }

    private String extractVoskText(String hypothesis) {
        if (hypothesis == null || hypothesis.trim().isEmpty()) return "";
        try {
            org.json.JSONObject json = new org.json.JSONObject(hypothesis);
            java.util.ArrayList<String> candidates = new java.util.ArrayList<>();
            org.json.JSONArray alternatives = json.optJSONArray("alternatives");
            if (alternatives != null) {
                for (int i=0;i<alternatives.length();i++) {
                    String candidate=alternatives.optJSONObject(i)==null?"":alternatives.optJSONObject(i).optString("text","").trim();
                    if (!candidate.isEmpty() && !candidates.contains(candidate)) candidates.add(candidate);
                }
            }
            String primary=json.optString("text","").trim();
            if (!primary.isEmpty() && !candidates.contains(primary)) candidates.add(0,primary);
            if (!candidates.isEmpty()) return selectBestVoiceTranscript(candidates).trim();
            return primary;
        } catch (Exception ignored) { return hypothesis.trim(); }
    }

    private void stopVoiceListening() {
        voiceButtonHeld = false;
        if (offlineSpeechService != null) {
            try {
                toast("ضبط متوقف شد؛ در حال تحلیل گفتار آفلاین…");
                offlineSpeechService.stop();
            } catch (Exception ignored) { releaseVoiceRecognizer(); }
        }
    }

    private void releaseVoiceRecognizer() {
        if (offlineSpeechService != null) {
            try { offlineSpeechService.stop(); } catch (Exception ignored) { }
            try { offlineSpeechService.shutdown(); } catch (Exception ignored) { }
            offlineSpeechService = null;
        }
        if (offlineVoiceRecognizer != null) {
            try { offlineVoiceRecognizer.close(); } catch (Exception ignored) { }
            offlineVoiceRecognizer = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) toast("اجازهٔ میکروفون داده شد؛ دوباره دکمهٔ دستیار صوتی را نگه دار.");
            else toast("برای ثبت صوتی، اجازهٔ میکروفون لازم است.");
        }
    }

    private String selectBestVoiceTranscript(java.util.ArrayList<String> candidates) {
        // Pick the hypothesis that best fits a complete accounting command, not merely the longest text.
        String best = candidates.get(0);
        int bestScore = Integer.MIN_VALUE;
        for (String candidate : candidates) {
            if (candidate == null || candidate.trim().isEmpty()) continue;
            String n = normalizeVoiceText(candidate);
            int score = Math.min(n.length(), 120) / 12;
            if (containsKnownBank(n)) score += 5;
            if (parseVoiceAmount(n) > 0) score += 7;
            if (hasIncomeCue(n)) score += 4;
            if (hasExpenseCue(n)) score += 4;
            if (hasQueryCue(n) || hasNavigationCue(n)) score += 5;
            if (containsAny(n, "امروز", "دیروز", "پریروز", "ماه قبل", "هفته قبل")) score += 1;
            // Penalize isolated fragments which are unlikely to be a complete instruction.
            if (n.split("\\s+").length < 2) score -= 3;
            if (score > bestScore) { bestScore = score; best = candidate; }
        }
        return best;
    }

    private String monthKey(long millis) { String d=jalaliDate(millis); return d.length()>=7?d.substring(0,7):""; }
    private String currentMonthKey() { return monthKey(System.currentTimeMillis()); }
    private boolean isMonthClosed(String key) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT 1 FROM closed_months WHERE book=? AND month_key=?",new String[]{activeBook,key});
        boolean closed=c.moveToFirst(); c.close(); return closed;
    }
    private void setMonthKey(ContentValues values,long millis) { values.put("month_key",monthKey(millis)); }
    private void showMonthClosing() {
        setHeaderInfo("بستن ماه", "ماه‌های مالی بسته‌شده بایگانی می‌شوند و جداگانه قابل مشاهده‌اند"); body.removeAllViews();
        addHeading("مدیریت ماه مالی");
        String current=currentMonthKey();
        addEmpty("ماه جاری: "+current+"\nبا بستن ماه، تراکنش‌های همان ماه حذف نمی‌شوند؛ فقط بایگانی و از فهرست ماه جاری جدا می‌شوند.");
        addWideButton("بستن ماه جاری ("+current+")",()->new AlertDialog.Builder(this).setTitle("بستن ماه مالی")
            .setMessage("ماه "+current+" بسته و بایگانی شود؟ تراکنش‌ها محفوظ می‌مانند و از فهرست ماه جاری جدا می‌شوند. پس از بستن، ثبت تراکنش با تاریخ این ماه مسدود خواهد شد.")
            .setNegativeButton("انصراف",null).setPositiveButton("بستن و بایگانی",(d,w)->{
                ContentValues v=new ContentValues();v.put("book",activeBook);v.put("month_key",current);v.put("closed_at",System.currentTimeMillis());
                db.getWritableDatabase().insertWithOnConflict("closed_months",null,v,SQLiteDatabase.CONFLICT_REPLACE);
                toast("ماه "+current+" بایگانی شد");showMonthClosing();
            }).show());
        addHeading("ماه‌های بایگانی‌شده");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT month_key,closed_at FROM closed_months WHERE book=? ORDER BY month_key DESC",new String[]{activeBook});
        if(!c.moveToFirst()) addEmpty("هنوز ماهی بسته نشده است.");
        else do {String key=c.getString(0);long closedAt=c.getLong(1);addWideButton(key+" • بسته‌شده در "+jalaliDate(closedAt)+" • مشاهده تراکنش‌ها",()->showTransactionsForMonth(key));} while(c.moveToNext()); c.close();
    }
    private void showTransactionsForMonth(String key) {
        navigate("تراکنش‌ها");
        // The transaction page initializes its month selector to this archive month.
        getPreferences(0).edit().putString("transactions_month_override",key).apply();
        showTransactions();
    }

    private void processVoiceCommand(String spoken) {
        if (spoken == null || spoken.trim().isEmpty()) { toast("گفتار قابل تشخیص نبود؛ دوباره تلاش کن."); return; }
        String normalized = normalizeVoiceText(spoken);
        if (containsAny(normalized, "راهنمای دستیار صوتی", "راهنمای صوتی", "چه فرمان هایی", "چه فرمان‌هایی", "فرمان های صوتی", "فرمان‌های صوتی", "دستیار چه کارهایی می کند", "دستیار چه کارهایی می‌کند")) { showVoiceCommandHelp(); return; }

        // Office/book switching must run before generic navigation and transaction parsing.
        // A named book can be selected directly; ambiguous names always require a choice.
        if (handleVoiceBookSwitch(spoken, normalized)) return;
        // 1) Route natural-language commands centrally across every major app area.
        // This runs before transaction classification so navigation is not mistaken for money entry.
        if (routeVoiceCommandAcrossApp(spoken, normalized)) return;
        if (handleVoiceThemeCommand(normalized)) return;
        if (containsAny(normalized,"بستن ماه","پایان ماه","بایگانی ماه")) { showMonthClosing(); return; }
        if (containsAny(normalized,"صفحه قبل","صفحه قبلی","برگرد عقب","بازگشت")) { if (!"خانه".equals(page)) navigate("خانه"); else toast("در صفحهٔ اصلی هستی."); return; }
        if (containsAny(normalized,"صفحه اصلی","صفحهٔ اصلی","برو خانه","برو به خانه","خانه را باز کن","صفحه خانه","صفحه خانه را باز کن","برگرد صفحه اصلی")) { navigate("خانه"); return; }
        if (containsAny(normalized,"تنظیمات","تنظیمات برنامه","تنظیمات را باز کن","مدیریت تنظیمات","بخش تنظیمات")) { navigate("تنظیمات"); return; }
        if (containsAny(normalized,"ثبت عملیات","ثبت تراکنش","ثبت جدید","منوی ثبت","ثبت را باز کن")) { navigate("ثبت"); return; }
        if (containsAny(normalized,"فهرست تراکنش","تراکنش های اخیر","تراکنش‌های اخیر","همه تراکنش ها","همه تراکنش‌ها","جستجوی تراکنش","تراکنش ها را باز کن")) { navigate("تراکنش‌ها"); return; }
        if (containsAny(normalized,"هدف پس انداز","هدف‌های پس‌انداز","هدف های پس انداز","اهداف پس انداز")) { showGoals(); return; }
        if (containsAny(normalized,"پرداخت تکراری","پرداخت های تکراری","پرداخت‌های تکراری","سررسید","اقساط تکراری")) { showRecurring(); return; }
        if (containsAny(normalized,"مدیریت دفتر","دفترها","تعویض دفتر","تغییر دفتر")) { manageBooks(); return; }
        // Flexible navigation: tolerate colloquial phrasing, missing ezafe, and common ASR variants.
        if (isQuickIconManagementCommand(normalized)) { manageQuickActions(); return; }
        if (containsAny(normalized,"دسته بندی","دسته‌بندی","مدیریت دسته ها","مدیریت دسته‌بندی‌ها","دسته‌ها را باز کن","دسته بندی ها را باز کن")) { manageCategories(); return; }
        if (containsAny(normalized,"خروجی csv","خروجی سی اس وی","فایل اکسل تراکنش","خروجی تراکنش ها")) { exportTransactionsCsv(); return; }
        if (containsAny(normalized,"پشتیبان گیری","پشتیبان‌گیری","بکاپ بگیر","خروجی پشتیبان")) { exportBackup(); return; }
        if (containsAny(normalized,"بازیابی پشتیبان","بازیابی بکاپ","وارد کردن پشتیبان")) { importBackup(); return; }
        if (containsAny(normalized,"رمز برنامه","قفل برنامه","تنظیم رمز","تغییر رمز")) { setPinDialog(); return; }
        if (containsAny(normalized,"درباره برنامه","اطلاعات برنامه","نسخه برنامه")) { showAboutDialog(); return; }
        if (containsAny(normalized,"افزودن دارایی","ثبت دارایی جدید")) { showAssetDialog(); return; }
        if (containsAny(normalized,"ثبت چک با عکس","ثبت چک از عکس","خواندن عکس چک","اسکن چک")) { showChequeDialog(true); return; }
        if (containsAny(normalized,"ثبت چک دریافتی","دریافت چک جدید","چک دریافتی جدید")) { showChequeDialog(false, "دریافتی"); return; }
        if (containsAny(normalized,"ثبت چک پرداختی","پرداخت چک جدید","چک پرداختی جدید")) { showChequeDialog(false, "پرداختی"); return; }
        if (containsAny(normalized,"چک ها","چک‌ها","فهرست چک","مدیریت چک","دریافت و پرداخت چک","وضعیت چک","سررسید چک")) { showCheques(); return; }
        if (containsAny(normalized,"ثبت بدهی","ثبت طلب","افزودن بدهی","افزودن طلب")) { showDebtDialog(); return; }
        if (containsAny(normalized,"گردش حساب","گردش بانکی","تراکنش های بانک","تراکنش‌های بانک","تراکنش های حساب","تراکنش‌های حساب")) {
            String account=findVoiceAccount(spoken);
            if(account!=null){showAccountTransactions(account);return;}
            if (showVoiceAccountPicker(spoken, false)) return;
            toast("بانک یا حساب مشخصی پیدا نشد؛ نام حساب یا چهار رقم آخر کارت را بگو."); showAccounts(); return;
        }
        if (containsAny(normalized,"مانده حساب","موجودی حساب","موجودی بانک","مانده بانک","چقدر پول دارم","چقدر موجودی دارم","موجودی من")) {
            String account=findVoiceAccount(spoken);
            if(account!=null){new AlertDialog.Builder(this).setTitle("مانده حساب").setMessage(account+"\nمانده: "+money(accountBalance(account))).setPositiveButton("مشاهده گردش همین حساب",(d,w)->showAccountTransactions(account)).setNegativeButton("بستن",null).show();return;}
            if (showVoiceAccountPicker(spoken, true)) return;
            showAccounts(); toast("حساب مشخص نشد؛ نام حساب یا چهار رقم آخر کارت را بگو."); return;
        }
        if (containsAny(normalized,"گزارش","خلاصه مالی","درآمد و هزینه","وضعیت مالی","جمع هزینه","جمع درآمد","چقدر خرج کردم","چقدر درآمد داشتم")) { showReports(); return; }
        if (containsAny(normalized,"همه تراکنش ها","همه تراکنش‌ها","فهرست تراکنش","جستجوی تراکنش","تراکنش های اخیر","تراکنش‌های اخیر")) { navigate("تراکنش‌ها"); return; }
        if (containsAny(normalized,"حساب های بانکی","حساب‌های بانکی","فهرست حساب","حساب ها","حساب‌ها","حساب بانکی")) { showAccounts(); return; }
        if (containsAny(normalized,"دارایی","اموال")) { showAssets(); return; }
        if (containsAny(normalized,"بدهی","طلب","قرض")) { showDebts(); return; }
        if (containsAny(normalized,"بودجه")) { showBudgets(); return; }
        if (isTransferIntent(normalized)) { showTransfer(); return; }
        if (containsAny(normalized,"ثبت حساب بانکی","حساب جدید","افزودن حساب")) { addAccountDialog(); return; }

        // 2) Transaction intent uses positive and negative cues. Generic verbs such as "گرفتم"
        // or "دادم" alone are not enough to silently decide income vs expense.
        String type = detectVoiceTransactionType(normalized);
        long amountValue = parseVoiceAmount(normalized);
        if ("نامشخص".equals(type)) {
            showVoiceIntentChoice(spoken);
            return;
        }
        String category = matchExistingVoiceCategory(guessVoiceCategory(normalized, type), normalized, type);
        boolean yesterday = containsAny(normalized,"دیروز","روز گذشته");
        showVoiceDraft(spoken, type, amountValue, category, yesterday);
    }


    /** Central intent router for natural Persian phrases across all app pages and workflows. */
    private void showVoiceCommandHelp() {
        String help = "دفترها\n• «برو به دفتر شخصی»\n• «دفتر گلخانه را انتخاب کن»\n• «دفتر بعدی» / «دفتر قبلی»\n\n"+
            "ثبت مالی (همیشه پیش‌نویس را بررسی کن)\n• «هزینه ۵۰۰ هزار تومان برای خرید از کارت ملت»\n• «حقوق ۳۰ میلیون تومان به حساب ملی واریز شد»\n• «انتقال ۲ میلیون تومان از کارت ملت به پول نقد»\n\n"+
            "حساب و گزارش\n• «مانده بانک ملت کارت ۱۲۳۴»\n• «گردش حساب کارت اصلی»\n• «گزارش مالی این ماه»\n• «تراکنش‌های اخیر را باز کن»\n\n"+
            "بخش‌های برنامه\n• «حساب‌های بانکی را باز کن» / «حساب جدید»\n• «بودجه‌بندی را باز کن» / «هدف پس‌انداز»\n• «بدهی و طلب» / «دارایی‌ها» / «پرداخت‌های تکراری»\n• «مدیریت دسته‌بندی‌ها» / «بستن ماه»\n• «پشتیبان‌گیری» / «بازیابی پشتیبان» / «خروجی CSV»\n• «تنظیمات را باز کن» / «آبی کن» / «راهنمای دستیار صوتی»\n\n"+
            "اگر چند حساب از یک بانک وجود داشته باشد، نام حساب یا چهار رقم آخر کارت را هم بگو. اگر تطبیق مبهم باشد، برنامه از تو انتخاب می‌خواهد. هیچ تراکنشی بدون بررسی و تأیید نهایی ثبت نمی‌شود.";
        new AlertDialog.Builder(this).setTitle("راهنمای فرمان‌های صوتی آفلاین").setMessage(help).setPositiveButton("متوجه شدم",null).show();
    }

    private boolean handleVoiceBookSwitch(String spoken, String normalized) {
        String x = normalizeVoiceText(normalized);
        boolean bookIntent = containsAny(x, "دفتر", "دفترها", "دفتر ها", "دفتر مالی", "دفتر حسابداری");
        boolean switchIntent = containsAny(x, "تعویض", "تغییر", "انتخاب", "برو", "رفتن", "باز کن", "فعال کن", "سوئیچ", "سوییچ", "عوض کن", "جابه جا", "جابجا", "دفتر بعدی", "دفتر قبلی");
        if (!bookIntent && !containsAny(x, "دفتر بعدی", "دفتر قبلی")) return false;
        if (!switchIntent && !containsAny(x, "دفتر بعدی", "دفتر قبلی")) return false;
        Cursor c = db.getReadableDatabase().rawQuery("SELECT name FROM books ORDER BY id", null);
        java.util.ArrayList<String> books = new java.util.ArrayList<>();
        while (c.moveToNext()) books.add(c.getString(0));
        c.close();
        if (books.isEmpty()) { toast("هیچ دفتری برای انتخاب وجود ندارد."); return true; }
        if (containsAny(x, "دفتر بعدی", "دفتر قبلی")) {
            int current = books.indexOf(activeBook);
            if (current < 0) current = 0;
            int next = containsAny(x, "دفتر بعدی") ? (current + 1) % books.size() : (current - 1 + books.size()) % books.size();
            activateVoiceBook(books.get(next));
            return true;
        }
        String candidate = x;
        String[] phrases = {"دفتر حسابداری", "دفتر مالی", "انتخاب کن", "تغییر بده", "عوض کن", "فعال کن", "باز کن", "برو به", "می خواهم", "میخوام", "لطفاً", "لطفا", "سوئیچ", "سوییچ"};
        for (String phrase : phrases) candidate = candidate.replace(phrase, " ");
        candidate = candidate.replaceAll("(^|\\s)(دفتر|مالی|حسابداری|را|رو|به|برو|انتخاب|تغییر|تعویض|من|کن|کنید)(?=\\s|$)", " ");
        candidate = candidate.replaceAll("\\s+", " ").trim();
        java.util.ArrayList<String> matches = new java.util.ArrayList<>();
        String normCandidate = normalizeBankText(candidate);
        if (!normCandidate.isEmpty()) {
            for (String b : books) {
                String nb = normalizeBankText(b);
                if (normCandidate.equals(nb) || normCandidate.contains(nb) || nb.contains(normCandidate)) matches.add(b);
            }
        }
        if (matches.size() == 1) { activateVoiceBook(matches.get(0)); return true; }
        if (matches.size() > 1) {
            String[] opts = matches.toArray(new String[0]);
            new AlertDialog.Builder(this).setTitle("کدام دفتر را فعال کنم؟").setItems(opts, (d,w) -> activateVoiceBook(opts[w])).setNegativeButton("لغو", null).show();
            return true;
        }
        String[] opts = books.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("دفتر موردنظر را انتخاب کن").setMessage("نام دفتر در گفتار واضح تشخیص داده نشد؛ برای جلوگیری از ثبت در دفتر اشتباه، انتخاب را تأیید کن.").setItems(opts, (d,w) -> activateVoiceBook(opts[w])).setNegativeButton("لغو", null).show();
        return true;
    }

    private void activateVoiceBook(String book) {
        if (book == null || book.trim().isEmpty()) return;
        activeBook = book;
        getPreferences(0).edit().putString("active_book", activeBook).apply();
        ensureBookAccount();
        navigate("خانه");
        toast("دفتر فعال تغییر کرد: " + activeBook);
    }

    private boolean routeVoiceCommandAcrossApp(String spoken, String n) {
        String x = normalizeVoiceText(n)
            .replace("آیکون", "آیکن").replace("ایکون", "آیکن").replace("ایکن", "آیکن")
            .replace("های", " ها").replace("سی اس وی", "csv")
            .replace("پس انداز", "پس انداز");
        boolean actionVerb = containsAny(x,"باز کن","بیار","برو","برو به","برو تو","نشون بده","نمایش بده","ببر به","می خوام","میخوام","برو داخل","وارد شو","مدیریت","فهرست","صفحه");
        boolean moneyIntent = containsAny(x,"ثبت هزینه","ثبت درآمد","خرج کردم","هزینه کردم","خریدم","پرداخت کردم","حقوق گرفتم","درآمد داشتم","دریافت کردم","انتقال وجه","انتقال پول","کارت به کارت","واریز کردم","پول دادم","مبلغ","ریال","تومان","تومن");
        // Keep full financial utterances for the transaction parser instead of treating them as navigation.
        if (moneyIntent && (containsAny(x,"ریال","تومان","تومن","هزار","میلیون","میلیارد") || parseVoiceAmount(x)>0)
                && containsAny(x,"ثبت","خرج","هزینه","خرید","پرداخت","درآمد","حقوق","دریافت","انتقال","واریز","دادم","گرفتم")) return false;

        if (isQuickIconManagementCommand(x)) { manageQuickActions(); return true; }
        if (containsAny(x,"تغییر رنگ","رنگ برنامه","رنگ رابط","تم برنامه","ظاهر برنامه","رنگش رو عوض","رنگش را عوض") && !containsAny(x,"تیره","روشن")) {
            if (handleVoiceThemeCommand(x)) return true;
        }
        if (containsAny(x,"صفحه قبل","صفحه قبلی","برگرد عقب","بازگشت","برگرد عقب")) {
            if (!"خانه".equals(page)) navigate("خانه"); else toast("در صفحهٔ اصلی هستی."); return true;
        }
        if (containsAny(x,"خانه","صفحه اصلی","صفحهٔ اصلی","صفحه خانه","داشبورد","صفحه اول","برگرد خانه") && actionVerb) { navigate("خانه"); return true; }
        if (containsAny(x,"تنظیمات","تنظیمات برنامه","تنظیمات عمومی") && actionVerb) { navigate("تنظیمات"); return true; }
        if (containsAny(x,"ثبت عملیات","منوی ثبت","صفحه ثبت","ثبت جدید","بخش ثبت","ثبت تراکنش") && !containsAny(x,"هزینه","درآمد","مبلغ") ) { navigate("ثبت"); return true; }
        if (containsAny(x,"تراکنش","تراکنش ها","تراکنش‌های","تاریخچه مالی","سوابق مالی","ریز پرداخت ها","فهرست پرداخت ها") && actionVerb && !containsAny(x,"گردش حساب بانک","گردش بانکی")) { navigate("تراکنش‌ها"); return true; }
        if (containsAny(x,"گزارش","خلاصه مالی","تحلیل مالی","وضعیت مالی","ارزش خالص","جمع درآمد","جمع هزینه") && actionVerb) { showReports(); return true; }
        if (containsAny(x,"حساب بانکی","حساب های بانکی","حساب‌ها","حساب ها","کیف پول","مدیریت حساب","فهرست حساب") && actionVerb) { showAccounts(); return true; }
        if (containsAny(x,"افزودن حساب","حساب جدید","ثبت حساب بانکی","کیف پول جدید","حساب تازه")) { addAccountDialog(); return true; }
        if (containsAny(x,"مدیریت حساب","ویرایش حساب","اتصال حساب","حساب ها را مدیریت")) { manageAccountLinks(); return true; }
        if (containsAny(x,"دسته بندی","دسته‌بندی","دسته ها","مدیریت دسته","دسته های هزینه","دسته های درآمد") && actionVerb) { manageCategories(); return true; }
        if (containsAny(x,"بودجه","سقف هزینه","بودجه بندی","بودجه‌بندی") && actionVerb) { showBudgets(); return true; }
        if (containsAny(x,"هدف پس انداز","هدف‌های پس انداز","اهداف پس انداز","پس اندازها","پس انداز ماهانه") && actionVerb) { showGoals(); return true; }
        if (containsAny(x,"پرداخت تکراری","تراکنش تکراری","پرداخت های تکراری","سررسید","اقساط","قبض های دوره ای") && actionVerb) { showRecurring(); return true; }
        if (containsAny(x,"بدهی","طلب","قرض","تسویه","بدهکار","طلبکار") && actionVerb && !moneyIntent) { showDebts(); return true; }
        if (containsAny(x,"دارایی","اموال","سرمایه غیرنقدی") && actionVerb && !moneyIntent) { showAssets(); return true; }
        if (containsAny(x,"ثبت دارایی","افزودن دارایی","دارایی جدید","مال جدید")) { showAssetDialog(); return true; }
        if (containsAny(x,"ثبت بدهی","ثبت طلب","افزودن بدهی","افزودن طلب","قرض جدید")) { showDebtDialog(); return true; }
        if (containsAny(x,"انتقال وجه","انتقال پول","انتقال بین حساب","جابجایی پول","جابه جایی پول","کارت به کارت","کارت‌به‌کارت") && !containsAny(x,"تراکنش های انتقال","گزارش انتقال")) { showTransfer(); return true; }
        if (containsAny(x,"مدیریت دفتر","دفترها","دفتر ها","تعویض دفتر","تغییر دفتر","دفتر حسابداری") && actionVerb) { manageBooks(); return true; }
        if (containsAny(x,"بستن ماه","پایان ماه","بایگانی ماه","ماه های بسته شده","ماه‌های بایگانی") && actionVerb) { showMonthClosing(); return true; }
        if (containsAny(x,"خروجی csv","خروجی اکسل","فایل اکسل","خروجی تراکنش","گزارش اکسل","ذخیره تراکنش ها در فایل")) { exportTransactionsCsv(); return true; }
        if (containsAny(x,"پشتیبان گیری","پشتیبان‌گیری","بکاپ بگیر","خروجی پشتیبان","نسخه پشتیبان")) { exportBackup(); return true; }
        if (containsAny(x,"بازیابی پشتیبان","بازیابی بکاپ","وارد کردن پشتیبان","برگرداندن بکاپ")) { importBackup(); return true; }
        if (containsAny(x,"رمز برنامه","قفل برنامه","تنظیم رمز","تغییر رمز","رمز عبور")) { setPinDialog(); return true; }
        if (containsAny(x,"درباره برنامه","اطلاعات برنامه","نسخه برنامه","سازنده برنامه")) { showAboutDialog(); return true; }
        if (containsAny(x,"مانده حساب","موجودی حساب","موجودی بانک","مانده بانک","گردش حساب","گردش بانکی","تراکنش های بانک","تراکنش‌های بانک")) return false; // handled by account-aware logic below
        // If user asks to open a feature but the exact intent was not understood, don't create a transaction.
        if (actionVerb && containsAny(x,"صفحه","بخش","منوی","مدیریت","فهرست")) {
            new AlertDialog.Builder(this).setTitle("منظورت کدام بخش است؟")
                .setItems(new String[]{"خانه","ثبت عملیات","تراکنش‌ها","حساب‌های بانکی","گزارش مالی","دسته‌بندی‌ها","بودجه‌بندی","هدف‌های پس‌انداز","پرداخت‌های تکراری","بدهی و طلب","دارایی‌ها","تنظیمات"}, (d,w)->{
                    switch(w){case 0:navigate("خانه");break;case 1:navigate("ثبت");break;case 2:navigate("تراکنش‌ها");break;case 3:showAccounts();break;case 4:showReports();break;case 5:manageCategories();break;case 6:showBudgets();break;case 7:showGoals();break;case 8:showRecurring();break;case 9:showDebts();break;case 10:showAssets();break;case 11:navigate("تنظیمات");break;}
                }).setNegativeButton("لغو",null).show();
            return true;
        }
        return false;
    }

    private boolean isQuickIconManagementCommand(String input) {
        String n = normalizeVoiceText(input)
            .replace("های", " ها").replace("آیکون", "آیکن")
            .replace("ایکون", "آیکن").replace("ایکن", "آیکن")
            .replace("خانه گی", "خانه").replace("صفحه خانه", "خانه");
        boolean iconWord = containsAny(n, "آیکن", "آیکون", "میانبر", "دسترسی سریع", "دکمه های خانه", "دکمه های صفحه اصلی");
        boolean manageWord = containsAny(n, "مدیریت", "تنظیم", "ویرایش", "مرتب", "انتخاب", "تغییر", "باز کن", "برو به", "برو");
        if (iconWord && manageWord) return true;
        return containsAny(n, "مدیریت آیکن ها", "مدیریت آیکن های خانه", "مدیریت آیکن های صفحه اصلی",
            "مدیریت آیکن های دسترسی سریع", "صفحه مدیریت آیکن ها", "صفحه مدیریت آیکن های خانه",
            "مدیریت میانبرها", "تنظیم آیکن های خانه", "ویرایش آیکن های خانه", "آیکن های خانه را باز کن");
    }

    private boolean handleVoiceThemeCommand(String normalized) {
        boolean themeContext = containsAny(normalized,"تم","رنگ برنامه","رنگ برنامه رو","رنگ برنامه را","تغییر رنگ","رنگش","ظاهر برنامه","رنگ رابط") || (normalized.endsWith("کن") && containsAny(normalized,"صورتی","آبی","سبز","بنفش","نارنجی","فیروزه","ذغالی","زغالی","سرخابی"));
        if (containsAny(normalized,"تم تیره","حالت تیره","دارک مود","dark mode")) {
            toast("حالت تیره هنوز در این نسخه پیاده‌سازی نشده است؛ می‌توانی رنگ اصلی برنامه را تغییر بدهی.");
            navigate("تنظیمات");
            return true;
        }
        if (containsAny(normalized,"تم روشن","حالت روشن","لایت مود","light mode")) {
            toast("برنامه در حالت روشن است؛ برای تغییر ظاهر، رنگ موردنظر را بگو.");
            return true;
        }
        if (!themeContext) return false;
        int chosen = -1;
        String[] aliases = {"صورتی","صورتی کن","آبی","آبی کن","سبز","سبز کن","بنفش","بنفش کن","نارنجی","نارنجی کن","فیروزه ای","فیروزه‌ای","ذغالی","زغالی","سرخابی"};
        int[] map = {0,0,1,1,2,2,3,3,4,4,5,5,6,6,7};
        for (int i=0;i<aliases.length;i++) if (normalized.contains(aliases[i])) { chosen=map[i]; break; }
        if (containsAny(normalized,"رنگ قبلی","برگرد به رنگ قبلی","رنگ پیش فرض","رنگ پیش‌فرض","صورتی پیش فرض")) chosen=0;
        if (chosen >= 0) {
            int color=THEME_COLORS[chosen];
            getPreferences(0).edit().putInt("theme_color",color).apply();
            applyThemeToShell();
            showShell();
            switch(page) {
                case "خانه": showHome(); break;
                case "تراکنش‌ها": showTransactions(); break;
                case "ثبت": showAddMenu(); break;
                case "دارایی‌ها": showAssets(); break;
                default: showSettings(); break;
            }
            toast("رنگ برنامه به "+THEME_NAMES[chosen]+" تغییر کرد.");
            return true;
        }
        if (containsAny(normalized,"تم","رنگ برنامه","ظاهر برنامه")) {
            navigate("تنظیمات");
            new AlertDialog.Builder(this).setTitle("تغییر رنگ برنامه")
                .setMessage("رنگی را انتخاب کن یا بگو: آبی کن، سبز کن، بنفش کن، نارنجی کن، فیروزه‌ای کن، ذغالی کن یا صورتی کن.")
                .setPositiveButton("انتخاب رنگ",(d,w)->showAboutDialog()).setNegativeButton("بستن",null).show();
            return true;
        }
        return false;
    }

    private boolean hasQueryCue(String text) {
        return containsAny(text,"موجودی","مانده","گردش حساب","گزارش","چقدر خرج","چقدر درآمد","فهرست تراکنش","حساب های بانکی","حساب‌های بانکی");
    }

    private boolean hasNavigationCue(String text) {
        return containsAny(text,"بستن ماه","بایگانی ماه","حساب جدید","تنظیمات","صفحه اصلی","دارایی","بدهی","بودجه");
    }

    private boolean hasIncomeCue(String text) {
        return containsAny(text,"درآمد","حقوق گرفتم","حقوق واریز شد","دریافت کردم","دریافت شد","وصول کردم","وصول شد","به حسابم واریز شد","به حسابم آمد","فروختم","فروش داشتم","فروش کردم","مشتری پرداخت کرد","به من پرداخت کرد","سود گرفتم","اجاره گرفتم","پول گرفتم","وجه دریافت کردم");
    }

    private boolean hasExpenseCue(String text) {
        return containsAny(text,"هزینه","خرج","خریدم","خریدیم","خرید کردم","پرداخت کردم","پرداختیم","پرداختم","قبض پرداخت کردم","پول دادم","پول پرداخت کردم","هزینه کردم","خریداری کردم","برداشت کردم","کرایه دادم","کارت کشیدم","خرج کردم","پرداخت شد از حسابم");
    }

    private boolean isTransferIntent(String text) {
        boolean transferWord = containsAny(text,"انتقال پول","انتقال وجه","انتقال بین حساب","جابجایی پول","جابه جایی پول","از حساب","به حساب دیگر","کارت به کارت","کارت‌به‌کارت");
        boolean fromTo = (text.contains("از ") && text.contains(" به ")) && containsAny(text,"واریز","انتقال","جابجا","جابه جا","فرستادم","منتقل کردم");
        return transferWord || fromTo;
    }

    private String normalizeVoiceText(String input) {
        String value = normalizeDigits(input==null?"":input).toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک')
            .replace('ۀ','ه').replace('ة','ه').replaceAll("[\u064B-\u065F]","");
        value = value.replaceAll("(^|\\s)رو(?=\\s|$)", "$1را").replace("میخوام","می خواهم").replace("می خوام","می خواهم")
            .replace("واسه","برای").replace("تو صفحه","در صفحه").replace("برو تو","برو به")
            .replaceAll("\\s+"," ").trim();
        return value;
    }
    private void showVoiceIntentChoice(String spoken) {
        String[] choices={"ثبت هزینه","ثبت درآمد","انتقال بین حساب‌ها","مشاهده تراکنش‌ها","مشاهده حساب‌ها","گزارش مالی","بدهی و طلب","دارایی‌ها","بستن ماه"};
        new AlertDialog.Builder(this).setTitle("نوع درخواست را مشخص کن")
            .setMessage("از گفتار نتوانستم با اطمینان تشخیص بدهم چه کاری می‌خواهی. یکی از بخش‌ها را انتخاب کن.")
            .setItems(choices,(d,w)->{switch(w){case 0:showVoiceDraft(spoken,"هزینه",parseVoiceAmount(spoken),"سایر",spoken.contains("دیروز"));break;case 1:showVoiceDraft(spoken,"درآمد",parseVoiceAmount(spoken),"سایر",spoken.contains("دیروز"));break;case 2:showTransfer();break;case 3:navigate("تراکنش‌ها");break;case 4:showAccounts();break;case 5:showReports();break;case 6:showDebts();break;case 7:showAssets();break;case 8:showMonthClosing();break;}}).setNegativeButton("لغو",null).show();
    }

    /** Returns the start position of the last matching voice-intent cue, or -1. */
    private int lastCuePosition(String text, String[] cues) {
        if (text == null || cues == null || cues.length == 0) return -1;
        int lastPosition = -1;
        for (String cue : cues) {
            if (cue == null || cue.isEmpty()) continue;
            int position = text.lastIndexOf(cue);
            if (position > lastPosition) lastPosition = position;
        }
        return lastPosition;
    }

    private String detectVoiceTransactionType(String spoken) {
        String text = normalizeVoiceText(spoken);
        // Explicit phrases have priority over generic verbs.
        String[] incomeStrong = {"حقوق گرفتم", "حقوق واریز شد", "دریافت کردم", "دریافت شد", "وصول کردم", "وصول شد", "به حسابم واریز شد", "به حسابم آمد", "فروختم", "فروش داشتم", "فروش کردم", "مشتری پرداخت کرد", "به من پرداخت کرد", "سود گرفتم", "اجاره گرفتم", "پول گرفتم", "وجه دریافت کردم"};
        String[] expenseStrong = {"خرید کردم", "خریدم", "خریدیم", "پرداخت کردم", "پرداختم", "پرداختیم", "هزینه کردم", "خرج کردم", "پول دادم", "پول پرداخت کردم", "قبض پرداخت کردم", "برداشت کردم", "کرایه دادم", "کارت کشیدم", "خریداری کردم"};
        int incomeAt = lastCuePosition(text, incomeStrong);
        int expenseAt = lastCuePosition(text, expenseStrong);

        // Negated statements must not be interpreted as completed transactions.
        if (containsAny(text,"پرداخت نکردم","نخریدم","خرج نکردم","دریافت نکردم","واریز نشد","پرداخت نشده","هنوز پرداخت نکردم")) return "نامشخص";
        if (incomeAt >= 0 && expenseAt >= 0) {
            // A sentence can mention both sides (e.g. received money, then paid a bill).
            // Choose the last explicit completed action; user still reviews the draft.
            return incomeAt > expenseAt ? "درآمد" : "هزینه";
        }
        if (incomeAt >= 0) return "درآمد";
        if (expenseAt >= 0) return "هزینه";

        // Weak words are not sufficient on their own: "گرفتم" and "دادم" are ambiguous.
        boolean income = containsAny(text,"درآمد","حقوق","فروش","فروشم","وصول","اجاره گرفتم","واریز شد به حسابم");
        boolean expense = containsAny(text,"هزینه","خرج","خرید","قبض","کرایه","بنزین","پرداخت","برداشت","مصرف کردم");
        if (income && !expense) return "درآمد";
        if (expense && !income) return "هزینه";
        return "نامشخص";
    }

    private String normalizeDigits(String input) {
        if (input == null) return "";
        StringBuilder b = new StringBuilder(input.length());
        for (int i=0;i<input.length();i++) {
            char ch=input.charAt(i);
            if(ch>='۰'&&ch<='۹') ch=(char)('0'+ch-'۰');
            else if(ch>='٠'&&ch<='٩') ch=(char)('0'+ch-'٠');
            if(ch=='٬'||ch=='،') ch=',';
            b.append(ch);
        }
        return b.toString();
    }

    private boolean containsAny(String value, String... words) {
        for (String word : words) if (value.contains(word)) return true;
        return false;
    }

    private long parseVoiceAmount(String spoken) {
        String normalized = normalizeDigits(spoken).toLowerCase(Locale.ROOT).replace('‌', ' ').replace('ي','ی').replace('ك','ک');
        // اول عددی را پیدا می‌کنیم که مستقیماً به واحد پول وصل است؛ عدد تعداد کالا مثل «یه دفتر» نادیده گرفته می‌شود.
        java.util.regex.Matcher numericMoney = java.util.regex.Pattern.compile("([0-9][0-9,٬.]*)(?:\\s*(میلیارد|میلیون|هزار))?\\s*(ریال|تومان|تومن)").matcher(normalized);
        long explicitNumeric = 0;
        while (numericMoney.find()) {
            String raw = numericMoney.group(1).replace(",", "").replace("٬", "").replace(".", "");
            long n; try { n = Long.parseLong(raw); } catch (Exception e) { continue; }
            String scale = numericMoney.group(2) == null ? "" : numericMoney.group(2);
            if (scale.equals("هزار")) n = safeMultiply(n, 1000L);
            else if (scale.equals("میلیون")) n = safeMultiply(n, 1000000L);
            else if (scale.equals("میلیارد")) n = safeMultiply(n, 1000000000L);
            String currency = numericMoney.group(3);
            if (currency.equals("تومان") || currency.equals("تومن")) n = safeMultiply(n, 10L); // همهٔ مبالغ داخلی ریال‌اند.
            explicitNumeric = n;
        }
        if (explicitNumeric > 0) return explicitNumeric;

        long wordsWithCurrency = parseLastWordsAmountBeforeCurrency(normalized);
        if (wordsWithCurrency > 0) return wordsWithCurrency; // تابع بالا واحد همان عبارت را به ریال تبدیل می‌کند.

        // اگر واحد پول گفته نشد، عبارت عددیِ پس از واژه‌هایی مثل «قیمت» یا «مبلغ» اولویت دارد.
        long anchored = parseAmountAfterAnchor(normalized);
        if (anchored > 0) return anchored;
        long words = parsePersianWordsAmount(normalized);
        if (words > 0) return words;
        // ASR گاهی مبلغ را فقط به رقم می‌دهد و واحد پول را حذف می‌کند. فقط اعداد بزرگ را
        // در جمله‌های دارای نیت مالی می‌پذیریم تا شماره کارت/تاریخ به‌اشتباه مبلغ نشود.
        if (containsAny(normalized,"هزینه","خرج","پرداخت","واریز","دریافت","درآمد","فروختم","خریدم","مبلغ","قیمت","تراکنش","ریال","تومان","تومن")) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?<![0-9])([0-9][0-9,٬.]{4,})(?![0-9])").matcher(normalized);
            long candidate = 0; int count = 0;
            while (m.find()) { try { long v = Long.parseLong(m.group(1).replace(",","").replace("٬","").replace(".","")); if (v >= 10000) { candidate=v; count++; } } catch(Exception ignored) {} }
            if (count == 1) return candidate;
        }
        return 0;
    }

    private long parseLastWordsAmountBeforeCurrency(String text) {
        String[] tokens = text.replace('‌', ' ').split("\\s+");
        StringBuilder group = new StringBuilder();
        long lastAmount = 0;
        for (String raw : tokens) {
            String token = raw.replaceAll("^[^\\p{L}0-9]+|[^\\p{L}0-9]+$", "").replace('ي','ی').replace('ك','ک');
            if (token.equals("ریال") || token.equals("تومان") || token.equals("تومن")) {
                long amount = evaluatePersianNumberGroup(group.toString());
                if (amount > 0) lastAmount = (token.equals("تومان") || token.equals("تومن")) ? safeMultiply(amount, 10L) : amount;
                group.setLength(0);
                continue;
            }
            boolean numericWord = persianNumberTokenValue(token) >= 0 || token.matches("[0-9][0-9,٬.]*") || token.equals("هزار") || token.equals("میلیون") || token.equals("میلیارد") || token.equals("و");
            if (numericWord) {
                if (group.length() > 0) group.append(' ');
                group.append(token);
            } else {
                group.setLength(0);
            }
        }
        return lastAmount;
    }

    private long parseAmountAfterAnchor(String text) {
        int anchor = Math.max(Math.max(text.lastIndexOf("قیمت"), text.lastIndexOf("مبلغ")), Math.max(text.lastIndexOf("به مبلغ"), text.lastIndexOf("هزینه")));
        if (anchor < 0) return 0;
        String tail = text.substring(anchor);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("([0-9][0-9,٬.]*)(?:\\s*(میلیارد|میلیون|هزار))?").matcher(tail);
        long value = 0;
        while (m.find()) {
            try {
                long n = Long.parseLong(m.group(1).replace(",", "").replace("٬", "").replace(".", ""));
                String unit = m.group(2) == null ? "" : m.group(2);
                if (unit.equals("هزار")) n = safeMultiply(n, 1000L);
                else if (unit.equals("میلیون")) n = safeMultiply(n, 1000000L);
                else if (unit.equals("میلیارد")) n = safeMultiply(n, 1000000000L);
                value = n;
            } catch (Exception ignored) {}
        }
        long words = parsePersianWordsAmount(tail);
        return words > 0 ? words : value;
    }

    private long parsePersianWordsAmount(String spoken) {
        String[] tokens = normalizeDigits(spoken).toLowerCase(Locale.ROOT).split("\\s+");
        StringBuilder group = new StringBuilder();
        long lastValue = 0;
        for (String raw : tokens) {
            String token = raw.replaceAll("^[^\\p{L}0-9]+|[^\\p{L}0-9]+$", "");
            boolean numericWord = persianNumberTokenValue(token) >= 0 || token.equals("هزار") || token.equals("میلیون") || token.equals("میلیارد");
            if (numericWord) {
                if (group.length() > 0) group.append(' ');
                group.append(token);
            } else if (token.equals("و") && group.length() > 0) {
                group.append(" و");
            } else if (group.length() > 0) {
                long parsed = evaluatePersianNumberGroup(group.toString());
                if (parsed > 0) lastValue = parsed;
                group.setLength(0);
            }
        }
        if (group.length() > 0) {
            long parsed = evaluatePersianNumberGroup(group.toString());
            if (parsed > 0) lastValue = parsed;
        }
        return lastValue;
    }

    private long evaluatePersianNumberGroup(String phrase) {
        long total = 0, current = 0;
        for (String token : phrase.split("\\s+")) {
            if (token.equals("و")) continue;
            if (token.equals("هزار") || token.equals("میلیون") || token.equals("میلیارد")) {
                long factor = token.equals("هزار") ? 1000L : token.equals("میلیون") ? 1000000L : 1000000000L;
                total += safeMultiply(current == 0 ? 1 : current, factor);
                current = 0;
            } else {
                int n = persianNumberTokenValue(token);
                if (n >= 0) current += n;
                else if (token.matches("[0-9][0-9,٬.]*")) {
                    try { current += Long.parseLong(token.replace(",", "").replace("٬", "").replace(".", "")); }
                    catch (Exception ignored) {}
                }
            }
        }
        return total + current;
    }

    private int persianNumberTokenValue(String token) {
        switch (token) {
            case "یه": case "یک": case "یکی": return 1;
            case "دو": case "دوتا": return 2;
            case "سه": return 3; case "چهار": return 4; case "پنج": return 5;
            case "شش": case "شیش": return 6; case "هفت": return 7; case "هشت": return 8; case "نه": return 9;
            case "ده": return 10; case "یازده": return 11; case "دوازده": return 12; case "سیزده": return 13;
            case "چهارده": return 14; case "پانزده": return 15; case "شانزده": return 16; case "هفده": return 17;
            case "هجده": return 18; case "نوزده": return 19; case "بیست": return 20; case "سی": return 30;
            case "چهل": return 40; case "پنجاه": return 50; case "شصت": return 60; case "هفتاد": return 70;
            case "هشتاد": return 80; case "نود": return 90; case "صد": case "یکصد": return 100;
            case "دویست": return 200; case "سیصد": return 300; case "چهارصد": return 400;
            case "پانصد": case "پونصد": return 500; case "ششصد": case "شیشصد": return 600;
            case "هفتصد": return 700; case "هشتصد": return 800; case "نهصد": return 900;
            default: return -1;
        }
    }

    private long safeMultiply(long value, long factor) {
        if (value > Long.MAX_VALUE / factor) return Long.MAX_VALUE;
        return value * factor;
    }

    private String guessVoiceCategory(String text, String type) {
        if (type.equals("درآمد")) {
            if (containsAny(text, "حقوق", "دستمزد", "حقوق ماهانه")) return "حقوق";
            if (containsAny(text, "فروختم", "فروش", "مشتری", "وصول", "فاکتور صادر")) return "کسب‌وکار";
            if (containsAny(text, "سود", "سرمایه")) return "سرمایه‌گذاری";
            return "سایر";
        }
        if (containsAny(text, "دفتر", "خودکار", "کاغذ", "لوازم التحریر", "لوازم اداری", "پرینتر", "کارتریج")) return "لوازم اداری";
        if (containsAny(text, "غذا", "ناهار", "شام", "صبحانه", "رستوران", "نان", "میوه")) return "خوراک";
        if (containsAny(text, "بنزین", "تاکسی", "اسنپ", "اتوبوس", "کرایه", "سوخت")) return "حمل‌ونقل";
        if (containsAny(text, "دارو", "دکتر", "درمان", "بیمارستان")) return "سلامت";
        if (containsAny(text, "برق", "آب", "گاز", "اینترنت", "قبض")) return "قبوض";
        if (containsAny(text, "اجاره", "خانه", "مسکن")) return "مسکن";
        return "سایر";
    }

    private String matchExistingVoiceCategory(String guessed, String spoken, String type) {
        java.util.ArrayList<String> options = getCategoryOptions(type);
        String normalizedSpeech = normalizeDigits(spoken == null ? "" : spoken).toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک');
        String best = null;
        int bestScore = 0;
        for (String option : options) {
            String normOption = option.toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک');
            int score = 0;
            if (guessed != null && normOption.equals(guessed.toLowerCase(Locale.ROOT))) score += 8;
            String compact = normOption.replace("‌", " ").trim();
            if (!compact.isEmpty() && normalizedSpeech.contains(compact)) score += 12;
            String[] words = compact.split("\\s+");
            for (String word : words) if (word.length() >= 3 && normalizedSpeech.contains(word)) score += 2;
            // Common spoken variants map to likely user-defined category names.
            if (containsAny(normalizedSpeech, "بنزین", "تاکسی", "اسنپ", "اتوبوس", "کرایه", "سوخت") && containsAny(normOption,"حمل و نقل","حمل‌ونقل","رفت و آمد","رفت‌وآمد","سوخت")) score += 10;
            if (containsAny(normalizedSpeech, "اینترنت", "قبض برق", "قبض آب", "قبض گاز") && containsAny(normOption,"قبوض","آب و برق","خدمات","اینترنت")) score += 10;
            if (containsAny(normalizedSpeech, "حقوق", "دستمزد") && containsAny(normOption,"حقوق","دستمزد","درآمد شغلی")) score += 10;
            if (containsAny(normalizedSpeech, "نان", "غذا", "ناهار", "شام", "رستوران", "میوه") && containsAny(normOption,"خوراک","غذا","مواد غذایی")) score += 10;
            if (score > bestScore) { bestScore = score; best = option; }
        }
        if (best != null && bestScore >= 4) return best;
        if (guessed != null && options.contains(guessed)) return guessed;
        return options.contains("متفرقه") ? "متفرقه" : (options.isEmpty() ? "متفرقه" : options.get(0));
    }

    private void showVoiceDraft(String spoken, String guessedType, long guessedAmount, String guessedCategory, boolean yesterday) {
        LinearLayout form = formLayout();
        TextView recognized = text("متن تشخیص‌داده‌شده:\n" + spoken, 14, TEXT, true);
        recognized.setBackground(roundBg(Color.rgb(255, 235, 241)));
        recognized.setPadding(dp(12),dp(10),dp(12),dp(10));
        form.addView(recognized);
        TextView safetyNote = text("نوع عملیات، مبلغ، واحد پول، حساب، دسته‌بندی و شرح را بررسی کن. اگر دستیار منظور را اشتباه فهمیده، همین‌جا اصلاح کن؛ تا تأیید تو هیچ تراکنشی ذخیره نمی‌شود.", 13, DARK, true);
        safetyNote.setPadding(dp(4), dp(8), dp(4), dp(8));
        form.addView(safetyNote);
        Spinner typeSpinner = styledSpinner();
        typeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"هزینه", "درآمد"}));
        typeSpinner.setSelection("درآمد".equals(guessedType) ? 1 : 0);
        form.addView(typeSpinner);
        EditText amount = edit("مبلغ نهایی به ریال (اجباری)", InputType.TYPE_CLASS_NUMBER);
        if (guessedAmount > 0) amount.setText(String.valueOf(guessedAmount));
        form.addView(amount);
        form.addView(text("تبدیل واحد: هر ۱ تومان = ۱۰ ریال. اگر واحد در گفتار گفته نشود، مبلغ ریال فرض می‌شود. مبلغ تبدیل‌شده را قبل از ثبت بررسی کن.", 12, DARK, false));
        TextView categoryLabel = text("نوع هزینه / درآمد", 13, TEXT, true); form.addView(categoryLabel);
        Spinner category = styledSpinner();
        java.util.ArrayList<String> categoryOptions = getCategoryOptions(guessedType);
        if (guessedCategory != null && !guessedCategory.trim().isEmpty() && !categoryOptions.contains(guessedCategory)) categoryOptions.add(guessedCategory);
        category.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categoryOptions));
        int categoryIndex = categoryOptions.indexOf(guessedCategory);
        category.setSelection(categoryIndex >= 0 ? categoryIndex : categoryOptions.indexOf("متفرقه"));
        form.addView(category);
        final boolean[] categoryInit = {false};
        typeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!categoryInit[0]) { categoryInit[0] = true; return; }
                String selectedType = String.valueOf(typeSpinner.getSelectedItem());
                java.util.ArrayList<String> refreshed = getCategoryOptions(selectedType);
                String best = matchExistingVoiceCategory(guessVoiceCategory(normalizeDigits(spoken).toLowerCase(Locale.ROOT), selectedType), normalizeDigits(spoken).toLowerCase(Locale.ROOT), selectedType);
                category.setAdapter(new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, refreshed));
                int match = refreshed.indexOf(best);
                category.setSelection(match >= 0 ? match : Math.max(0, refreshed.indexOf("متفرقه")));
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        TextView paymentLabel = text("نوع پرداخت", 13, TEXT, true); form.addView(paymentLabel);
        Spinner paymentMethod = styledSpinner();
        String[] paymentOptions = {"نقدی", "کارت بانکی", "انتقال بانکی", "کارت‌خوان", "اعتباری", "متفرقه"};
        paymentMethod.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, paymentOptions));
        paymentMethod.setSelection(5);
        if (containsAny(normalizeDigits(spoken), "کارتخوان", "کارت‌خوان", "پوز")) paymentMethod.setSelection(3);
        else if (containsAny(normalizeDigits(spoken), "انتقال بانکی", "حواله", "واریز به")) paymentMethod.setSelection(2);
        else if (containsAny(normalizeDigits(spoken), "کارت", "کارت بانکی", "شماره کارت")) paymentMethod.setSelection(1);
        else if (containsAny(normalizeDigits(spoken), "نقدی", "پول نقد")) paymentMethod.setSelection(0);
        form.addView(paymentMethod);
        TextView accountLabel = text("حساب / بانک", 13, TEXT, true); form.addView(accountLabel);
        Spinner account = styledSpinner();
        java.util.ArrayList<String> accountOptions = getAccountOptions();
        account.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, accountOptions));
        String matchedAccount = findVoiceAccount(normalizeDigits(spoken));
        int accountIndex = -1;
        boolean bankMentioned = containsKnownBank(normalizeDigits(spoken));
        if (matchedAccount != null) {
            for (int i = 0; i < accountOptions.size(); i++) {
                if (accountNameFromOption(accountOptions.get(i)).equals(matchedAccount)) { accountIndex = i; break; }
            }
        }
        if (accountIndex < 0 && bankMentioned) { accountIndex = accountOptions.indexOf("متفرقه"); toast("نام بانک تشخیص داده شد اما حساب ثبت‌شدهٔ منطبق پیدا نشد؛ حساب را پیش از ثبت بررسی کن."); }
        if (accountIndex < 0) accountIndex = accountOptions.indexOf("پول نقد");
        if (accountIndex < 0) accountIndex = accountOptions.indexOf("متفرقه");
        account.setSelection(Math.max(0, accountIndex));
        form.addView(account);
        EditText note = edit("شرح تراکنش", InputType.TYPE_CLASS_TEXT);
        note.setText(spoken);
        form.addView(note);
        Calendar selectedDate = Calendar.getInstance();
        if (yesterday) selectedDate.add(Calendar.DAY_OF_MONTH, -1);
        Button dateButton = button("تاریخ تراکنش: " + jalaliDate(selectedDate.getTimeInMillis()));
        dateButton.setOnClickListener(v -> {
            Calendar cur=(Calendar)selectedDate.clone();
            new DatePickerDialog(this,(view,year,month,day)->{
                selectedDate.set(Calendar.YEAR,year); selectedDate.set(Calendar.MONTH,month); selectedDate.set(Calendar.DAY_OF_MONTH,day);
                selectedDate.set(Calendar.HOUR_OF_DAY,12); selectedDate.set(Calendar.MINUTE,0); selectedDate.set(Calendar.SECOND,0);
                dateButton.setText("تاریخ تراکنش: "+jalaliDate(selectedDate.getTimeInMillis()));
            },cur.get(Calendar.YEAR),cur.get(Calendar.MONTH),cur.get(Calendar.DAY_OF_MONTH)).show();
        });
        form.addView(dateButton);
        ScrollView scroll = new ScrollView(this); scroll.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("بررسی و تأیید تراکنش صوتی").setView(scroll)
            .setNegativeButton("لغو", null).setNeutralButton("اصلاح متن", (d,w)->showManualVoiceText(spoken)).setPositiveButton("تأیید و ثبت", null).create();
        dialog.setOnShowListener(dlg -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            long a = parseAmount(amount.getText().toString());
            String ty = String.valueOf(typeSpinner.getSelectedItem());
            String cat = String.valueOf(category.getSelectedItem());
            String acc = accountNameFromOption(String.valueOf(account.getSelectedItem()));
            String payment = String.valueOf(paymentMethod.getSelectedItem());
            if (a <= 0) { amount.setError("مبلغ معتبر به ریال و بیشتر از صفر وارد کن"); amount.requestFocus(); return; }
            if (cat.isEmpty()) cat = "متفرقه";
            if (acc.isEmpty()) acc = "متفرقه";
            if(isMonthClosed(monthKey(selectedDate.getTimeInMillis()))){toast("این ماه بایگانی و بسته شده است؛ تاریخ تراکنش را به ماه باز تغییر بده.");return;}
            ensureAccount(acc); saveCategoryIfMissing(ty,cat);
            ContentValues values = new ContentValues(); values.put("book",activeBook); values.put("type",ty); values.put("amount",a); values.put("category",cat); values.put("account",acc); values.put("payment_method",payment); values.put("note",note.getText().toString().trim()); values.put("date",selectedDate.getTimeInMillis()); setMonthKey(values,selectedDate.getTimeInMillis());
            long id = db.getWritableDatabase().insert("transactions",null,values);
            if (id == -1) { toast("ثبت تراکنش انجام نشد؛ دوباره بررسی کن."); return; }
            dialog.dismiss(); toast("تراکنش صوتی با تأیید شما ثبت شد."); navigate("خانه");
        }));
        dialog.show();
    }

    private java.util.ArrayList<String> getCategoryOptions(String type) {
        java.util.ArrayList<String> options = new java.util.ArrayList<>();
        Cursor c = db.getReadableDatabase().rawQuery("SELECT name FROM categories WHERE type=? ORDER BY name", new String[]{type});
        while (c.moveToNext()) { String n = c.getString(0); if (n != null && !n.trim().isEmpty() && !options.contains(n)) options.add(n); }
        c.close();
        Cursor tx = db.getReadableDatabase().rawQuery("SELECT DISTINCT category FROM transactions WHERE book=? AND type=? AND category IS NOT NULL ORDER BY category", new String[]{activeBook,type});
        while (tx.moveToNext()) { String n = tx.getString(0); if (n != null && !n.trim().isEmpty() && !options.contains(n)) options.add(n); }
        tx.close();
        if (!options.contains("متفرقه")) options.add("متفرقه");
        return options;
    }

    private java.util.ArrayList<String> getAccountOptions() {
        java.util.ArrayList<String> options = new java.util.ArrayList<>();
        Cursor c = db.getReadableDatabase().rawQuery("SELECT name,bank_name,card_last4 FROM accounts WHERE book=? ORDER BY id", new String[]{activeBook});
        while (c.moveToNext()) {
            String name = c.getString(0), bank = c.getString(1), last4 = c.getString(2);
            String label = name;
            if (bank != null && !bank.trim().isEmpty()) label += " • بانک " + bank;
            if (last4 != null && !last4.trim().isEmpty()) label += " • " + last4;
            if (!options.contains(label)) options.add(label);
        }
        c.close();
        if (!options.contains("پول نقد")) options.add("پول نقد");
        if (!options.contains("متفرقه")) options.add("متفرقه");
        return options;
    }

    private boolean showVoiceAccountPicker(String spoken, boolean showBalance) {
        String bank = detectBankFromSpeech(spoken);
        String last4 = null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?<![0-9])([0-9]{4})(?![0-9])").matcher(normalizeDigits(spoken));
        while (m.find()) last4 = m.group(1);
        java.util.ArrayList<String> names = new java.util.ArrayList<>();
        Cursor c = db.getReadableDatabase().rawQuery("SELECT name,COALESCE(bank_name,''),COALESCE(card_last4,'') FROM accounts WHERE book=? AND enabled=1 ORDER BY id", new String[]{activeBook});
        while (c.moveToNext()) {
            String name=c.getString(0), bankName=c.getString(1), card=c.getString(2);
            boolean bankMatch = bank != null && normalizeBankText(bankName).equals(normalizeBankText(bank));
            boolean cardMatch = last4 != null && last4.equals(normalizeDigits(card));
            // If both clues were spoken, require both to match. If only one was spoken, use it.
            if (bank != null && last4 != null) { if (bankMatch && cardMatch) names.add(name); }
            else if (last4 != null) { if (cardMatch) names.add(name); }
            else if (bank != null) { if (bankMatch) names.add(name); }
        }
        c.close();
        if (names.isEmpty()) return false;
        if (names.size() == 1) return false; // Caller will resolve the unique account via findVoiceAccount.
        java.util.ArrayList<String> labels = new java.util.ArrayList<>();
        for (String name : names) {
            Cursor meta = db.getReadableDatabase().rawQuery("SELECT COALESCE(bank_name,''),COALESCE(card_last4,'') FROM accounts WHERE book=? AND name=? LIMIT 1", new String[]{activeBook,name});
            String bankName="", card=""; if(meta.moveToFirst()){bankName=meta.getString(0);card=meta.getString(1);}meta.close();
            labels.add(name + (bankName.isEmpty()?"":" • بانک "+bankName) + (card.isEmpty()?"":" • کارت "+card));
        }
        String[] options = labels.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("کدام حساب را می‌خواهی؟")
            .setMessage("چند حساب با اطلاعات گفته‌شده تطبیق دارد. حساب درست را انتخاب کن؛ هیچ تراکنشی بدون تأیید ثبت نمی‌شود.")
            .setItems(options, (dialog, which) -> {
                String selected=names.get(which);
                if (showBalance) new AlertDialog.Builder(this).setTitle("مانده حساب")
                    .setMessage(selected+"\nمانده: "+money(accountBalance(selected)))
                    .setPositiveButton("مشاهده گردش حساب",(d,w)->showAccountTransactions(selected))
                    .setNegativeButton("بستن",null).show();
                else showAccountTransactions(selected);
            }).setNegativeButton("لغو",null).show();
        return true;
    }

    private String accountNameFromOption(String option) {
        if (option == null) return "متفرقه";
        int p = option.indexOf(" • بانک ");
        if (p >= 0) return option.substring(0, p).trim();
        return option.trim();
    }

    private int editDistance(String a, String b) {
        if (a == null || b == null) return 99;
        int[] prev = new int[b.length()+1], cur = new int[b.length()+1];
        for (int j=0;j<=b.length();j++) prev[j]=j;
        for (int i=1;i<=a.length();i++) {
            cur[0]=i;
            for (int j=1;j<=b.length();j++) cur[j]=Math.min(Math.min(cur[j-1]+1,prev[j]+1),prev[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));
            int[] tmp=prev;prev=cur;cur=tmp;
        }
        return prev[b.length()];
    }

    private String detectBankFromSpeech(String spoken) {
        String normalized=normalizeBankText(spoken);
        String[][] aliases=bankAliases();
        // First pass: exact/contained aliases are safest.
        for (String[] group:aliases) for (String alias:group) {
            String key=normalizeBankText(alias);
            if (key.length()>=3 && normalized.contains(key)) return group[0];
        }
        // Second pass: allow a one/two-character recognition error in a bank phrase.
        // Compare short token windows, not the whole sentence, to avoid accidental matches.
        String[] words=normalizeVoiceText(spoken).split("\\s+");
        String best=null; int bestDistance=99;
        for (int i=0;i<words.length;i++) for (int count=1;count<=3 && i+count<=words.length;count++) {
            StringBuilder phrase=new StringBuilder();
            for(int j=i;j<i+count;j++) { if(phrase.length()>0) phrase.append(' '); phrase.append(words[j]); }
            String candidate=normalizeBankText(phrase.toString());
            if(candidate.length()<4) continue;
            for(String[] group:aliases) for(String alias:group) {
                String key=normalizeBankText(alias);
                if(key.length()<4) continue;
                int limit=key.length()>=8?2:1;
                if(Math.abs(candidate.length()-key.length())>limit) continue;
                int distance=editDistance(candidate,key);
                if(distance<=limit && distance<bestDistance) { bestDistance=distance; best=group[0]; }
            }
        }
        return bestDistance<=2?best:null;
    }

    private String findVoiceAccount(String spoken) {
        String raw=normalizeVoiceText(spoken); String normalized=normalizeBankText(raw);
        String detectedBank=detectBankFromSpeech(spoken);
        java.util.regex.Matcher dm=java.util.regex.Pattern.compile("(?<![0-9])([0-9]{4})(?![0-9])").matcher(normalizeDigits(spoken));
        String last4=null;while(dm.find())last4=dm.group(1);
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,COALESCE(bank_name,''),COALESCE(card_last4,'') FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});
        java.util.ArrayList<String> bestNames = new java.util.ArrayList<>();
        int bestScore=0;
        while(c.moveToNext()) {
            String name=c.getString(0),bank=c.getString(1),card=c.getString(2);
            String nn=normalizeBankText(name), nb=normalizeBankText(bank);
            boolean bankMatch=detectedBank!=null && !nb.isEmpty() && (nb.equals(normalizeBankText(detectedBank)) || nn.contains(normalizeBankText(detectedBank)));
            boolean cardMatch=last4!=null && last4.equals(normalizeDigits(card));
            boolean nameMatch=!nn.isEmpty() && nn.length()>=3 && normalized.contains(nn);
            // When the user says both a bank and last four digits, both must match.
            if (detectedBank != null && last4 != null && !(bankMatch && cardMatch)) continue;
            int score=0;
            if(cardMatch) score+=1000;
            if(nameMatch) score+=300;
            if(bankMatch) score+=100;
            if(score>bestScore){bestScore=score;bestNames.clear();bestNames.add(name);}
            else if(score==bestScore && score>0 && !bestNames.contains(name)) bestNames.add(name);
        }
        c.close();
        // A bank name alone is not enough when multiple cards/accounts belong to that bank.
        // Return a result only when the match is unique; never silently choose the first row.
        return bestScore>0 && bestNames.size()==1 ? bestNames.get(0) : null;
    }
    private String[][] bankAliases() {
        return new String[][]{
          {"ملی","بانک ملی","ملی ایران","ملیی","مِلی","meli","bank melli","melli","melli iran"},
          {"ملت","بانک ملت","ملات","ملط","مملت","mellat","mellat bank","ملت ایران"},
          {"صادرات","بانک صادرات","صادرات ایران","صادارات","سادرات","saderat","bank saderat"},
          {"تجارت","بانک تجارت","تجارات","تجرت","tejarat","bank tejarat"},
          {"رفاه","بانک رفاه","رفاه کارگران","refah"},
          {"کشاورزی","بانک کشاورزی","کشاورزی ایران","keshavarzi"},
          {"مسکن","بانک مسکن","maskan"}, {"سپه","بانک سپه","sepah"},
          {"پارسیان","بانک پارسیان","parsian"}, {"پاسارگاد","بانک پاسارگاد","pasargad"},
          {"سامان","بانک سامان","saman"}, {"شهر","بانک شهر","shahr"},
          {"آینده","بانک آینده","ayandeh"}, {"اقتصاد نوین","بانک اقتصاد نوین","اقتصادنوین","eghtesad novin"},
          {"دی","بانک دی","day bank"}, {"کارآفرین","بانک کارآفرین","karafarin"},
          {"گردشگری","بانک گردشگری","tourism bank"}, {"ایران زمین","بانک ایران زمین","ایران‌زمین","iran zamin"},
          {"رسالت","بانک رسالت","قرض الحسنه رسالت","resalat"}, {"مهر ایران","بانک مهر ایران","قرض الحسنه مهر ایران","مهرایران","مهر","mehr iran","mehriran"},
          {"پست بانک","پست‌بانک","پست بانک ایران","post bank"}, {"توسعه تعاون","بانک توسعه تعاون","tosee taavon"},
          {"سینا","بانک سینا","sina"}, {"سرمایه","بانک سرمایه","sarmayeh"},
          {"خاورمیانه","بانک خاورمیانه","middle east bank"}, {"بلوبانک","بلو بانک","بلو","بلو بانک سامان","blu bank","blubank"},
          {"بانکینو","بانک اینو","bankino"}, {"ملل","موسسه اعتباری ملل","مؤسسه اعتباری ملل","melal"},
          {"نور","موسسه اعتباری نور","مؤسسه اعتباری نور"}, {"کوثر","موسسه اعتباری کوثر","مؤسسه اعتباری کوثر"},
          {"قوامین","بانک قوامین"}, {"انصار","بانک انصار"}, {"حکمت ایرانیان","بانک حکمت ایرانیان"},
          {"توسعه صادرات","بانک توسعه صادرات","توسعه صادرات ایران"}, {"صنعت و معدن","بانک صنعت و معدن"},
          {"ایران ونزوئلا","بانک مشترک ایران و ونزوئلا"}, {"کارآفرین","بانک کارآفرین"}
        };
    }
    private boolean containsKnownBank(String spoken) {
        String normalized = normalizeBankText(spoken);
        for(String[] group:bankAliases()) for(String bank:group){String key=normalizeBankText(bank);if(!key.isEmpty()&&normalized.contains(key))return true;}
        return false;
    }

    private String normalizeBankText(String input) {
        if (input == null) return "";
        String value = normalizeDigits(input).toLowerCase(Locale.ROOT)
            .replace('ي','ی').replace('ك','ک').replace('ۀ','ه').replace('ة','ه')
            .replace("بانک", "").replace("کارت", "").replace("حساب", "")
            .replace("شماره", "").replace("مالی", "");
        return value.replaceAll("[\\s\\p{Punct}‌ـ]+", "").trim();
    }

    private String[] bankNames() {
        return new String[]{"ملی","ملت","صادرات","تجارت","رفاه","کشاورزی","مسکن","سپه","پارسیان","پاسارگاد","سامان","شهر","آینده","اقتصاد نوین","دی","کارآفرین","گردشگری","قوامین","انصار","حکمت ایرانیان","ایران زمین","رسالت","خاورمیانه","سینا","سرمایه","توسعه تعاون","پست بانک","صنعت و معدن","توسعه صادرات","مهر ایران","قرض الحسنه مهر ایران","مهر اقتصاد","بانک مرکزی","بلوبانک","بانکینو","ایران ونزوئلا","توسعه صادرات ایران","موسسه اعتباری ملل","ملل","موسسه اعتباری نور","نور","موسسه اعتباری کوثر","کوثر","موسسه اعتباری ثامن","ثامن","بانک مشترک ایران و ونزوئلا","ایران ونزوئلا","بانک خاورمیانه","بانک قرض الحسنه رسالت","بانک قرض الحسنه مهر ایران"};
    }

    private void attachMoneyFormatting(EditText field) {
        final boolean[] changing = {false};
        field.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable editable) {
                if (changing[0]) return;
                String original = editable.toString();
                int cursor = Math.max(0, field.getSelectionStart());
                int digitsBefore = 0;
                for (int i=0; i<Math.min(cursor, original.length()); i++) if (Character.isDigit(original.charAt(i))) digitsBefore++;
                StringBuilder digits = new StringBuilder();
                for (int i=0; i<original.length(); i++) { char ch=original.charAt(i); if(ch>='۰'&&ch<='۹') digits.append((char)('0'+ch-'۰')); else if(ch>='٠'&&ch<='٩') digits.append((char)('0'+ch-'٠')); else if(ch>='0'&&ch<='9') digits.append(ch); }
                if (digits.length()==0) return;
                String formatted;
                try { formatted = NumberFormat.getIntegerInstance(new Locale("fa","IR")).format(Long.parseLong(digits.toString())); }
                catch (Exception e) { return; }
                if (formatted.equals(original)) return;
                changing[0]=true; field.setText(formatted);
                int target=0, seen=0;
                while(target<formatted.length() && seen<digitsBefore){ if(Character.isDigit(formatted.charAt(target))) seen++; target++; }
                field.setSelection(Math.min(target, formatted.length())); changing[0]=false;
            }
        });
    }

    private void showManualVoiceText(String initial) {
        EditText input = edit("متن دستور مالی را وارد کن", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setText(initial);
        new AlertDialog.Builder(this).setTitle("اصلاح متن تشخیص‌داده‌شده").setView(input)
            .setNegativeButton("لغو",null).setPositiveButton("تحلیل دوباره",(d,w)->processVoiceCommand(input.getText().toString().trim())).show();
    }

    private void showTransfer() {
        LinearLayout f=formLayout();
        AutoCompleteTextView from=accountInput("از حساب"), to=accountInput("به حساب"); EditText amt=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER), note=edit("شرح (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(from);f.addView(to);f.addView(amt);f.addView(note);
        new AlertDialog.Builder(this).setTitle("انتقال پول").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ثبت انتقال",(d,w)->{
            long a=parseAmount(amt.getText().toString()); String fr=from.getText().toString().trim(),toN=to.getText().toString().trim();
            if(a<=0||fr.isEmpty()||toN.isEmpty()||fr.equals(toN)){toast("حساب‌ها و مبلغ را درست وارد کن");return;}
            if(isMonthClosed(currentMonthKey())){toast("ماه جاری بسته شده است؛ انتقال جدید در این ماه مجاز نیست.");return;}
            ensureAccount(fr);ensureAccount(toN);
            SQLiteDatabase s=db.getWritableDatabase();
            String transferId=java.util.UUID.randomUUID().toString();
            s.beginTransaction();try{
                ContentValues v=new ContentValues();v.put("book",activeBook);v.put("type","انتقال خروجی");v.put("amount",a);v.put("category","انتقال");v.put("account",fr);v.put("note","به "+toN+"؛ "+note.getText());v.put("date",System.currentTimeMillis());setMonthKey(v,System.currentTimeMillis());v.put("transfer_id",transferId);s.insertOrThrow("transactions",null,v);
                ContentValues x=new ContentValues();x.put("book",activeBook);x.put("type","انتقال ورودی");x.put("amount",a);x.put("category","انتقال");x.put("account",toN);x.put("note","از "+fr+"؛ "+note.getText());x.put("date",System.currentTimeMillis());setMonthKey(x,System.currentTimeMillis());x.put("transfer_id",transferId);s.insertOrThrow("transactions",null,x);s.setTransactionSuccessful();
            }finally{s.endTransaction();}
            toast("انتقال ثبت شد");navigate("خانه");
        }).show();
    }
    private void showTransactions() {
        setHeaderInfo("تراکنش‌ها", "تراکنش‌ها را جست‌وجو و جزئیاتشان را بررسی کنید");
        body.removeAllViews(); addHeading("سوابق و جست‌وجوی تراکنش‌ها");
        EditText search=edit("جست‌وجو در شرح، دسته‌بندی یا حساب",InputType.TYPE_CLASS_TEXT);
        body.addView(search);
        Spinner filter=styledSpinner(); String[] filters={"همه تراکنش‌ها","فقط درآمد","فقط هزینه","انتقال‌ها"};
        filter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,filters)); body.addView(filter);
        Spinner accountFilter=styledSpinner(); java.util.ArrayList<String> accounts=new java.util.ArrayList<>();accounts.add("همه حساب‌ها");Cursor ac=db.getReadableDatabase().rawQuery("SELECT name FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});while(ac.moveToNext())accounts.add(ac.getString(0));ac.close();accountFilter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,accounts));body.addView(accountFilter);
        Spinner monthFilter=styledSpinner();java.util.ArrayList<String> months=new java.util.ArrayList<>();months.add("همه ماه‌ها");Cursor mc=db.getReadableDatabase().rawQuery("SELECT DISTINCT t.month_key FROM transactions t WHERE t.book=? AND t.month_key IS NOT NULL ORDER BY t.month_key DESC",new String[]{activeBook});while(mc.moveToNext())if(!months.contains(mc.getString(0)))months.add(mc.getString(0));mc.close();Cursor closed=db.getReadableDatabase().rawQuery("SELECT month_key FROM closed_months WHERE book=? ORDER BY month_key DESC",new String[]{activeBook});while(closed.moveToNext())if(!months.contains(closed.getString(0)))months.add(closed.getString(0));closed.close();String currentMonth=currentMonthKey();if(!months.contains(currentMonth))months.add(1,currentMonth);monthFilter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months));
        int defaultMonth=months.indexOf(currentMonth);if(defaultMonth>=0)monthFilter.setSelection(defaultMonth);
        String override=getPreferences(0).getString("transactions_month_override","");if(!override.isEmpty()){int ix=months.indexOf(override);if(ix>=0)monthFilter.setSelection(ix);getPreferences(0).edit().remove("transactions_month_override").apply();} body.addView(monthFilter);
        addWideButton("اعمال فیلتر",()->renderTransactions(search.getText().toString().trim(),filter.getSelectedItemPosition(),String.valueOf(accountFilter.getSelectedItem()),String.valueOf(monthFilter.getSelectedItem())));
        addWideButton("پاک کردن جست‌وجو",()->{search.setText("");filter.setSelection(0);accountFilter.setSelection(0);monthFilter.setSelection(Math.max(0,months.indexOf(currentMonth)));renderTransactions("",0,"همه حساب‌ها",currentMonth);});
        renderTransactions("",0,"همه حساب‌ها",currentMonth);
    }

    private void renderTransactions(String query,int filterIndex) { renderTransactions(query,filterIndex,"همه حساب‌ها","همه ماه‌ها"); }
    private void renderTransactions(String query,int filterIndex,String accountName,String monthKey) {
        while(body.getChildCount()>7) body.removeViewAt(7);
        String typeClause="";
        if(filterIndex==1) typeClause=" AND t.type='درآمد'";
        else if(filterIndex==2) typeClause=" AND t.type='هزینه'";
        else if(filterIndex==3) typeClause=" AND t.type LIKE 'انتقال%'";
        String visible="t.book=?";
        String sql="SELECT t.id,t.type,t.amount,t.category,t.account,t.note,t.date,t.transfer_id,t.payment_method,t.book FROM transactions t WHERE "+visible+typeClause+" AND (?='همه حساب‌ها' OR t.account=?) AND (?='همه ماه‌ها' OR t.month_key=?) AND (COALESCE(t.category,'') LIKE ? OR COALESCE(t.account,'') LIKE ? OR COALESCE(t.note,'') LIKE ?) ORDER BY t.date DESC LIMIT 1000";
        String q="%"+query+"%"; Cursor c=db.getReadableDatabase().rawQuery(sql,new String[]{activeBook,accountName,accountName,monthKey,monthKey,q,q,q});
        String totalSql="SELECT t.type,COALESCE(SUM(t.amount),0) FROM transactions t WHERE "+visible+" AND (?='همه حساب‌ها' OR t.account=?) AND (?='همه ماه‌ها' OR t.month_key=?) GROUP BY t.type";
        Cursor totals=db.getReadableDatabase().rawQuery(totalSql,new String[]{activeBook,accountName,accountName,monthKey,monthKey});long income=0,expense=0;while(totals.moveToNext()){if("درآمد".equals(totals.getString(0)))income=totals.getLong(1);if("هزینه".equals(totals.getString(0)))expense=totals.getLong(1);}totals.close();addMetric("جمع درآمد در فهرست",money(income),GREEN);addMetric("جمع هزینه در فهرست",money(expense),Color.rgb(204,103,112));addMetric("خالص",money(income-expense),TEXT);
        if(!c.moveToFirst()){c.close();addEmpty("تراکنشی مطابق این فیلتر پیدا نشد.");return;}
        do {
            long txId=c.getLong(0); String type=c.getString(1); long amount=c.getLong(2); String cat=c.getString(3), acc=c.getString(4), note=c.getString(5); long stamp=c.getLong(6);String transferId=c.isNull(7)?null:c.getString(7); String payment=c.isNull(8)?"متفرقه":c.getString(8);String sourceBook=c.getString(9);
            LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(dp(12),dp(10),dp(12),dp(10)); item.setBackground(roundBg(Color.WHITE));
            TextView line=text((cat==null?"بدون دسته":cat)+"  •  "+type,15,TEXT,true); item.addView(line);
            item.addView(text((acc==null?"":acc)+"  |  "+money(amount),14,type.equals("هزینه")||type.equals("انتقال خروجی")?Color.rgb(204,103,112):GREEN,false));
            item.addView(text("دفتر ثبت‌کننده: "+sourceBook+(sourceBook.equals(activeBook)?"":" • تراکنش مشترک حساب"),12,sourceBook.equals(activeBook)?Color.rgb(86,99,91):Color.rgb(90,100,170),true));
            item.addView(text("روش پرداخت: "+(payment==null?"متفرقه":payment),12,Color.rgb(86,99,91),false));
            item.addView(text(jalaliDate(stamp),12,Color.rgb(86, 99, 91),false));
            if(note!=null&&!note.isEmpty()) item.addView(text(note,12,Color.rgb(86, 99, 91),false));
            if(sourceBook.equals(activeBook)) item.setOnClickListener(v->transactionActions(txId,type,amount,cat,acc,note,transferId));
            else item.setOnClickListener(v->toast("این تراکنش در دفتر «"+sourceBook+"» ثبت شده است؛ برای جلوگیری از تغییر ناخواسته، از همان دفتر آن را ویرایش کن."));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        } while(c.moveToNext()); c.close();
    }
    private void transactionActions(long id,String type,long amount,String category,String account,String note,String transferId){
        boolean transfer=type!=null&&type.startsWith("انتقال");
        if(transfer){
            if(transferId==null){new AlertDialog.Builder(this).setTitle("انتقال قدیمی").setMessage("این انتقال در نسخهٔ قدیمی ثبت شده و دو سمت آن به هم متصل نیستند. برای جلوگیری از خراب‌شدن ماندهٔ حساب‌ها، حذف تکی آن از این صفحه غیرفعال است. اگر لازم است اصلاح شود، مبلغ را با یک انتقال معکوس جبران کن.").setPositiveButton("متوجه شدم",null).show();return;}
            new AlertDialog.Builder(this).setTitle("مدیریت انتقال").setMessage("هر دو سمت این انتقال با هم حذف می‌شوند.").setNegativeButton("بازگشت",null).setPositiveButton("حذف انتقال",(d,w)->new AlertDialog.Builder(this).setTitle("تأیید حذف").setMessage("حذف انتقال قابل بازگشت نیست. ادامه می‌دهی؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("transactions","book=? AND transfer_id=?",new String[]{activeBook,transferId});toast("هر دو سمت انتقال حذف شدند");showTransactions();}).show()).show();
            return;
        }
        String[] options={"ویرایش تراکنش","حذف تراکنش"};new AlertDialog.Builder(this).setTitle("مدیریت تراکنش").setItems(options,(d,which)->{if(which==0)editTransaction(id,type,amount,category,account,note);else new AlertDialog.Builder(this).setTitle("حذف تراکنش").setMessage("این تراکنش حذف شود؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("transactions","id=? AND book=?",new String[]{String.valueOf(id),activeBook});toast("تراکنش حذف شد");showTransactions();}).show();}).show();
    }
    private void editTransaction(long id,String type,long amount,String category,String account,String note){
        LinearLayout f=formLayout();EditText a=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER),nt=edit("شرح",InputType.TYPE_CLASS_TEXT);AutoCompleteTextView acc=accountInput("حساب"),cat=categoryInput(type.equals("هزینه")?"هزینه":"درآمد","دسته‌بندی");a.setText(String.valueOf(amount));cat.setText(category);acc.setText(account);nt.setText(note==null?"":note);f.addView(a);f.addView(cat);f.addView(acc);f.addView(nt);
        new AlertDialog.Builder(this).setTitle("ویرایش تراکنش").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{long value=parseAmount(a.getText().toString());String accountName=acc.getText().toString().trim();if(value<=0||accountName.isEmpty()){toast("مبلغ و حساب معتبر وارد کن");return;}ensureAccount(accountName);saveCategoryIfMissing(type,cat.getText().toString().trim());ContentValues v=new ContentValues();v.put("amount",value);v.put("category",cat.getText().toString().trim());v.put("account",accountName);v.put("note",nt.getText().toString());db.getWritableDatabase().update("transactions",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});toast("تراکنش ویرایش شد");showTransactions();}).show();
    }
    private void showRecentIntoBody() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT t.type,t.amount,t.category,t.account,t.payment_method,t.book FROM transactions t WHERE t.book=? ORDER BY t.date DESC LIMIT 5",new String[]{activeBook});
        if(!c.moveToFirst()){addEmpty("هنوز تراکنشی ثبت نشده است.");c.close();return;}
        do { String t=c.getString(0); long a=c.getLong(1); String cat=c.getString(2),acc=c.getString(3),payment=c.isNull(4)?"متفرقه":c.getString(4),sourceBook=c.getString(5);
            TextView v=text(cat+"  •  "+money(a)+"\n"+t+" | "+acc+"\nدفتر ثبت‌کننده: "+sourceBook+"\nروش پرداخت: "+payment,14,TEXT,false);v.setPadding(dp(10),dp(10),dp(10),dp(10));v.setBackground(roundBg(Color.WHITE));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);
        }while(c.moveToNext());c.close();
    }
    private void addAccountBalancesIntoBody() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,opening,bank_name,card_last4 FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز حسابی تعریف نشده است.");return;}
        do {
            String name=c.getString(0),kind=c.getString(1);long opening=c.getLong(2);
            long bal=accountBalance(name);
            TextView v=text(name+" • "+(kind==null?"حساب":kind)+"\n"+money(bal),14,bal<0?Color.rgb(204,103,112):GREEN,true);v.setPadding(dp(12),dp(10),dp(12),dp(10));v.setBackground(roundBg(Color.WHITE));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);
        }while(c.moveToNext());c.close();
    }

    private String accountUid(String book,String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT account_uid FROM accounts WHERE book=? AND name=?",new String[]{book,name});String uid=null;if(c.moveToFirst())uid=c.getString(0);c.close();return uid;
    }

    private long accountBalance(String name) {
        // حساب‌های متصل با account_uid مشترک‌اند. حساب بانکی با بانک و چهار رقم آخر یکسان
        // نیز بین دفترها مشترک محسوب می‌شود؛ خود تراکنش همچنان متعلق به دفتر ثبت‌کننده است.
        String uid=accountUid(activeBook,name), bankName="", last4="";
        Cursor meta=db.getReadableDatabase().rawQuery("SELECT COALESCE(bank_name,''),COALESCE(card_last4,'') FROM accounts WHERE book=? AND name=? LIMIT 1",new String[]{activeBook,name});
        if(meta.moveToFirst()){bankName=meta.getString(0);last4=meta.getString(1);}meta.close();
        boolean bankIdentity=!bankName.trim().isEmpty()&&last4.matches("\\d{4}");
        if(uid==null&&!bankIdentity)return accountBalanceForBook(activeBook,name);
        String identityClause=bankIdentity?"(a.account_uid=? OR (a.bank_name=? AND a.card_last4=?))":"a.account_uid=?";
        String[] identityArgs=bankIdentity?new String[]{uid==null?"":uid,bankName,last4}:new String[]{uid};
        Cursor opening=db.getReadableDatabase().rawQuery("SELECT COALESCE(MAX(opening),0) FROM accounts a WHERE "+identityClause,identityArgs);long n=0;if(opening.moveToFirst())n=opening.getLong(0);opening.close();
        Cursor t=db.getReadableDatabase().rawQuery("SELECT t.type,t.amount FROM transactions t JOIN accounts a ON a.book=t.book AND a.name=t.account WHERE "+identityClause,identityArgs);
        while(t.moveToNext()){String ty=t.getString(0);long a=t.getLong(1);if(ty.equals("درآمد")||ty.equals("انتقال ورودی"))n+=a;else if(ty.equals("هزینه")||ty.equals("انتقال خروجی"))n-=a;}t.close();return n;
    }
    private long accountBalanceForBook(String book,String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(opening,0) FROM accounts WHERE book=? AND name=?",new String[]{book,name});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();
        Cursor t=db.getReadableDatabase().rawQuery("SELECT type,amount FROM transactions WHERE book=? AND account=?",new String[]{book,name});while(t.moveToNext()){String ty=t.getString(0);long a=t.getLong(1);if(ty.equals("درآمد")||ty.equals("انتقال ورودی"))n+=a;else if(ty.equals("هزینه")||ty.equals("انتقال خروجی"))n-=a;}t.close();return n;
    }

    private void manageAccountLinks(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,enabled FROM accounts WHERE book=? ORDER BY id",new String[]{activeBook});java.util.ArrayList<String> labels=new java.util.ArrayList<>();java.util.ArrayList<String> names=new java.util.ArrayList<>();java.util.ArrayList<Integer> enabled=new java.util.ArrayList<>();while(c.moveToNext()){names.add(c.getString(0));enabled.add(c.getInt(1));labels.add(c.getString(0)+(c.getInt(1)==1?" • فعال":" • غیرفعال"));}c.close();
        labels.add("＋ افزودن حساب بانکی موجود از دفتر دیگر");String[] opts=labels.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("مدیریت حساب‌ها در دفتر «"+activeBook+"»").setItems(opts,(d,w)->{if(w==opts.length-1){shareExistingAccountToThisBook();return;}String n=names.get(w);if(enabled.get(w)==1){new AlertDialog.Builder(this).setTitle("غیرفعال‌سازی حساب").setMessage("حساب از فهرست عادی این دفتر پنهان شود؟ سوابق و گردش حساب حفظ می‌شود.").setNegativeButton("لغو",null).setPositiveButton("غیرفعال کن",(x,y)->{ContentValues v=new ContentValues();v.put("enabled",0);db.getWritableDatabase().update("accounts",v,"book=? AND name=?",new String[]{activeBook,n});showAccounts();}).show();}else{ContentValues v=new ContentValues();v.put("enabled",1);db.getWritableDatabase().update("accounts",v,"book=? AND name=?",new String[]{activeBook,n});showAccounts();}}).setNegativeButton("بستن",null).show();
    }
    private void manageSpecificAccount(String name){
        String[] opts={"غیرفعال کردن در این دفتر","فعال کردن در این دفتر","افزودن همین حساب به دفتر دیگر"};new AlertDialog.Builder(this).setTitle(name).setItems(opts,(d,w)->{if(w==0||w==1){ContentValues v=new ContentValues();v.put("enabled",w==1?1:0);db.getWritableDatabase().update("accounts",v,"book=? AND name=?",new String[]{activeBook,name});showAccounts();}else shareSpecificAccount(name);}).show();
    }
    private void shareSpecificAccount(String name){
        String uid=accountUid(activeBook,name);if(uid==null){toast("شناسه حساب پیدا نشد");return;}Cursor b=db.getReadableDatabase().rawQuery("SELECT name FROM books WHERE name<>? ORDER BY id",new String[]{activeBook});java.util.ArrayList<String> books=new java.util.ArrayList<>();while(b.moveToNext())books.add(b.getString(0));b.close();if(books.isEmpty()){toast("ابتدا یک دفتر دیگر ایجاد کن");return;}String[] arr=books.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("افزودن حساب به کدام دفتر؟").setItems(arr,(d,w)->linkAccountToBook(uid,name,arr[w])).setNegativeButton("لغو",null).show();
    }
    private void shareExistingAccountToThisBook(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT a.name,a.account_uid,b.name FROM accounts a JOIN books b ON b.name=a.book WHERE a.book<>? AND a.enabled=1 ORDER BY b.name,a.name",new String[]{activeBook});java.util.ArrayList<String> labels=new java.util.ArrayList<>(),uids=new java.util.ArrayList<>(),names=new java.util.ArrayList<>();while(c.moveToNext()){String n=c.getString(0),u=c.getString(1),b=c.getString(2);if(u!=null){labels.add(n+" • دفتر "+b);uids.add(u);names.add(n);}}c.close();if(labels.isEmpty()){toast("حساب فعالی در دفترهای دیگر پیدا نشد");return;}new AlertDialog.Builder(this).setTitle("انتخاب حساب موجود").setItems(labels.toArray(new String[0]),(d,w)->linkAccountToBook(uids.get(w),names.get(w),activeBook)).setNegativeButton("لغو",null).show();
    }
    private void linkAccountToBook(String uid,String name,String targetBook){
        Cursor src=db.getReadableDatabase().rawQuery("SELECT kind,bank_name,card_last4 FROM accounts WHERE account_uid=? ORDER BY id LIMIT 1",new String[]{uid});if(!src.moveToFirst()){src.close();toast("حساب پیدا نشد");return;}String kind=src.getString(0),bank=src.getString(1),last4=src.getString(2);src.close();Cursor ex=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND account_uid=?",new String[]{targetBook,uid});boolean exists=ex.moveToFirst();ex.close();if(exists){toast("این حساب از قبل در آن دفتر وجود دارد");return;}Cursor same=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{targetBook,name});boolean nameExists=same.moveToFirst();same.close();if(nameExists){toast("در دفتر مقصد حسابی با همین نام وجود دارد؛ ابتدا نام آن را تغییر بده");return;}ContentValues v=new ContentValues();v.put("book",targetBook);v.put("name",name);v.put("kind",kind);v.put("opening",0);v.put("bank_name",bank);v.put("card_last4",last4);v.put("account_uid",uid);v.put("enabled",1);db.getWritableDatabase().insertOrThrow("accounts",null,v);toast("حساب در دفتر «"+targetBook+"» فعال شد؛ موجودی اولیه دوباره ثبت نشد");if(targetBook.equals(activeBook))showAccounts();
    }

    private void showAccountTransactions(String accountName) {
        setHeaderInfo("گردش حساب", "فقط تراکنش‌های دفتر «"+activeBook+"»؛ ماندهٔ حساب مشترک است"); body.removeAllViews(); addHeading("گردش حساب: "+accountName+" • دفتر "+activeBook); addEmpty("فقط تراکنش‌های همین دفتر نمایش داده می‌شود. ماندهٔ حساب مشترک، تغییرات همهٔ دفترهای متصل را در نظر می‌گیرد.");
        String uid=accountUid(activeBook,accountName);
        Cursor c;
        if(uid==null)c=db.getReadableDatabase().rawQuery("SELECT type,amount,category,note,date,book FROM transactions WHERE book=? AND account=? ORDER BY date DESC",new String[]{activeBook,accountName});
        else c=db.getReadableDatabase().rawQuery("SELECT t.type,t.amount,t.category,t.note,t.date,t.book FROM transactions t JOIN accounts a ON a.book=t.book AND a.name=t.account WHERE a.account_uid=? AND t.book=? ORDER BY t.date DESC",new String[]{uid,activeBook});
        long income=0,expense=0,transferIn=0,transferOut=0; java.util.ArrayList<String> rows=new java.util.ArrayList<>();
        while(c.moveToNext()){String type=c.getString(0),cat=c.getString(2),note=c.getString(3),txBook=c.getString(5);long amount=c.getLong(1),date=c.getLong(4);
            if("درآمد".equals(type))income+=amount;else if("هزینه".equals(type))expense+=amount;else if("انتقال ورودی".equals(type))transferIn+=amount;else if("انتقال خروجی".equals(type))transferOut+=amount;
            rows.add(jalaliDate(date)+" • دفتر: "+txBook+" • "+type+" • "+(cat==null?"":cat)+" • "+money(amount)+(note==null||note.isEmpty()?"":"\n"+note));
        } c.close();
        addMetric("جمع درآمد",money(income),GREEN);addMetric("جمع هزینه",money(expense),Color.rgb(204,103,112));addMetric("انتقال ورودی",money(transferIn),GREEN);addMetric("انتقال خروجی",money(transferOut),Color.rgb(204,103,112));addMetric("جمع خالص گردش (بدون موجودی اولیه)",money(income-expense+transferIn-transferOut),TEXT);
        addHeading("ریز تراکنش‌ها");if(rows.isEmpty())addEmpty("برای این حساب تراکنشی ثبت نشده است.");else for(String row:rows){TextView v=text(row,14,TEXT,false);v.setPadding(dp(10),dp(9),dp(10),dp(9));v.setBackground(roundBg(Color.WHITE));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));body.addView(v,lp);}
        addWideButton("بازگشت به حساب‌ها",()->showAccounts());
    }

    private void showAccounts() {
        setHeaderInfo("حساب‌ها و موجودی", "موجودی اولیه و ماندهٔ فعلی هر حساب را بررسی کنید");
        body.removeAllViews();addHeading("حساب‌ها و ماندهٔ هر حساب");addWideButton("＋ حساب جدید",()->addAccountDialog());addWideButton("مدیریت حساب‌های غیرفعال و اشتراک حساب بین دفترها",()->manageAccountLinks());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,opening,bank_name,card_last4 FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("حسابی ثبت نشده است.");return;}
        do{String name=c.getString(0),kind=c.getString(1),bank=c.getString(3),last4=c.getString(4);long opening=c.getLong(2);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(roundBg(Color.WHITE));card.addView(text(name+" • "+kind+(bank!=null&&!bank.isEmpty()?" • بانک "+bank:"")+(last4!=null&&!last4.isEmpty()?" • "+last4:""),15,TEXT,true));card.addView(text("موجودی اولیه: "+money(opening),12,Color.rgb(86, 99, 91),false));card.addView(text("مانده فعلی: "+money(accountBalance(name)),18,GREEN,true));card.addView(text("برای مشاهده گردش حساب لمس کنید",12,DARK,false));card.setOnClickListener(v->showAccountTransactions(name));Button manage=button("مدیریت این حساب در دفترها");manage.setOnClickListener(v->manageSpecificAccount(name));card.addView(manage);body.addView(card,new LinearLayout.LayoutParams(-1,-2));}while(c.moveToNext());c.close();
    }

    private AutoCompleteTextView accountInput(String hint) {
        AutoCompleteTextView input=new AutoCompleteTextView(this);input.setHint(hint);input.setHintTextColor(Color.rgb(120,130,140));input.setTextColor(TEXT);input.setTextSize(15);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT);input.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);input.setPadding(dp(14),dp(10),dp(14),dp(10));input.setMinHeight(dp(52));input.setBackground(inputFieldBg());input.setDropDownBackgroundDrawable(roundBg(Color.WHITE));input.setDropDownVerticalOffset(dp(4));
        java.util.ArrayList<String> names=new java.util.ArrayList<>();Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});while(c.moveToNext())names.add(c.getString(0));c.close();
        input.setAdapter(dropdownAdapter(names));input.setThreshold(1);return input;
    }

    private AutoCompleteTextView categoryInput(String type,String hint) {
        AutoCompleteTextView input=new AutoCompleteTextView(this);input.setHint(hint);input.setHintTextColor(Color.rgb(120,130,140));input.setTextColor(TEXT);input.setTextSize(15);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT);input.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);input.setPadding(dp(14),dp(10),dp(14),dp(10));input.setMinHeight(dp(52));input.setBackground(inputFieldBg());input.setDropDownBackgroundDrawable(roundBg(Color.WHITE));input.setDropDownVerticalOffset(dp(4));
        java.util.ArrayList<String> names=new java.util.ArrayList<>();Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM categories WHERE type=? ORDER BY name",new String[]{type});while(c.moveToNext())names.add(c.getString(0));c.close();
        Cursor tx=db.getReadableDatabase().rawQuery("SELECT DISTINCT category FROM transactions WHERE book=? AND type=? AND category IS NOT NULL ORDER BY category",new String[]{activeBook,type});while(tx.moveToNext()){String n=tx.getString(0);if(n!=null&&!names.contains(n))names.add(n);}tx.close();
        input.setAdapter(dropdownAdapter(names));input.setThreshold(1);return input;
    }

    private void saveCategoryIfMissing(String type,String name) {
        if(name==null||name.trim().isEmpty())return;Cursor c=db.getReadableDatabase().rawQuery("SELECT id FROM categories WHERE type=? AND name=?",new String[]{type,name.trim()});boolean found=c.moveToFirst();c.close();if(!found){ContentValues v=new ContentValues();v.put("type",type);v.put("name",name.trim());db.getWritableDatabase().insert("categories",null,v);}
    }

    private void manageCategories() {
        setHeaderInfo("دسته‌بندی‌ها", "دسته‌بندی‌های درآمد و هزینه را مدیریت کنید");
        body.removeAllViews();addHeading("دسته‌بندی‌های درآمد و هزینه");addWideButton("＋ دسته‌بندی درآمد",()->categoryDialog("درآمد"));addWideButton("＋ دسته‌بندی هزینه",()->categoryDialog("هزینه"));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,type,name FROM categories ORDER BY type,name",null);if(!c.moveToFirst()){c.close();addEmpty("دسته‌بندی‌ای وجود ندارد.");return;}
        do{long id=c.getLong(0);String type=c.getString(1),name=c.getString(2);TextView row=text(type+" • "+name+"   (برای حذف لمس کن)",14,TEXT,false);row.setPadding(dp(12),dp(12),dp(12),dp(12));row.setBackground(roundBg(Color.WHITE));body.addView(row,new LinearLayout.LayoutParams(-1,-2));row.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف دسته‌بندی").setMessage("فقط دسته‌بندی حذف می‌شود؛ تراکنش‌های قبلی باقی می‌مانند.").setNegativeButton("انصراف",null).setPositiveButton("حذف",(d,w)->{db.getWritableDatabase().delete("categories","id=?",new String[]{String.valueOf(id)});manageCategories();}).show());}while(c.moveToNext());c.close();
    }

    private void categoryDialog(String type) {
        EditText name=edit("نام دسته‌بندی جدید",InputType.TYPE_CLASS_TEXT);new AlertDialog.Builder(this).setTitle("دسته‌بندی "+type).setView(name).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty()){toast("نام دسته‌بندی را وارد کن");return;}saveCategoryIfMissing(type,n);manageCategories();}).show();
    }

    private void showRecurring() {
        setHeaderInfo("پرداخت‌های تکرارشونده", "سررسیدها را بررسی و مورد لازم را ثبت کنید");
        body.removeAllViews();addHeading("پرداخت‌های تکرارشونده و سررسیدها");addEmpty("این بخش برای قبض‌ها، اجاره، اقساط، حقوق و درآمدهای تکراری است. ثبت هر سررسید با تأیید شما انجام می‌شود.");addWideButton("＋ تعریف مورد تکرارشونده",()->recurringDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,type,amount,category,account,frequency,next_due FROM recurring WHERE book=? ORDER BY next_due",new String[]{activeBook});if(!c.moveToFirst()){c.close();addEmpty("مورد تکرارشونده‌ای تعریف نشده است.");return;}
        do{long id=c.getLong(0),amount=c.getLong(3),due=c.getLong(7);String name=c.getString(1),type=c.getString(2),cat=c.getString(4),acc=c.getString(5),freq=c.getString(6);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(name+" • "+type,15,TEXT,true));card.addView(text(money(amount)+" | "+freq+" | سررسید: "+jalaliDate(due),13,Color.rgb(86, 99, 91),false));Button post=button("ثبت این سررسید در حساب‌ها");card.addView(post);post.setOnClickListener(v->postRecurring(id,name,type,amount,cat,acc,freq,due));Button del=button("حذف مورد تکرارشونده");card.addView(del);del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("این مورد از فهرست تکرارشونده حذف شود؟ تراکنش‌های قبلی حذف نمی‌شوند.").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,y)->{db.getWritableDatabase().delete("recurring","id=? AND book=?",new String[]{String.valueOf(id),activeBook});showRecurring();}).show());body.addView(card,new LinearLayout.LayoutParams(-1,-2));}while(c.moveToNext());c.close();
    }

    private void recurringDialog() {
        LinearLayout f=formLayout();EditText name=edit("عنوان (مثلاً اجاره خانه)",InputType.TYPE_CLASS_TEXT);Spinner type=styledSpinner();type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"هزینه","درآمد"}));EditText amount=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER);AutoCompleteTextView cat=categoryInput("هزینه","دسته‌بندی");AutoCompleteTextView account=accountInput("حساب (مثلاً پول نقد)");Spinner freq=styledSpinner();freq.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"ماهانه","هفتگی","سالانه"}));f.addView(name);f.addView(type);f.addView(amount);f.addView(cat);f.addView(account);f.addView(freq);
        new AlertDialog.Builder(this).setTitle("تعریف مورد تکرارشونده").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim(),a=account.getText().toString().trim();long val=parseAmount(amount.getText().toString());if(n.isEmpty()||val<=0){toast("عنوان و مبلغ معتبر وارد کن");return;}if(a.isEmpty())a="پول نقد";ensureAccount(a);String ty=type.getSelectedItem().toString(),category=cat.getText().toString().trim();if(category.isEmpty())category="سایر";saveCategoryIfMissing(ty,category);ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("type",ty);v.put("amount",val);v.put("category",category);v.put("account",a);v.put("frequency",freq.getSelectedItem().toString());v.put("next_due",System.currentTimeMillis());db.getWritableDatabase().insert("recurring",null,v);showRecurring();}).show();
    }

    private void postRecurring(long id,String name,String type,long amount,String category,String account,String frequency,long due) {
        new AlertDialog.Builder(this).setTitle("ثبت سررسید").setMessage("مورد «"+name+"» به‌عنوان تراکنش "+type+" به مبلغ "+money(amount)+" ثبت شود؟").setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{SQLiteDatabase sql=db.getWritableDatabase();sql.beginTransaction();try{ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",type);tx.put("amount",amount);tx.put("category",category);tx.put("account",account);tx.put("note","ثبت از سررسید تکرارشونده: "+name);tx.put("date",System.currentTimeMillis());setMonthKey(tx,System.currentTimeMillis());sql.insertOrThrow("transactions",null,tx);Calendar cal=Calendar.getInstance();cal.setTimeInMillis(Math.max(due,System.currentTimeMillis()));if(frequency.equals("هفتگی"))cal.add(Calendar.DAY_OF_YEAR,7);else if(frequency.equals("سالانه"))cal.add(Calendar.YEAR,1);else cal.add(Calendar.MONTH,1);ContentValues upd=new ContentValues();upd.put("next_due",cal.getTimeInMillis());sql.update("recurring",upd,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});sql.setTransactionSuccessful();toast("سررسید ثبت شد");}catch(Exception e){toast("ثبت سررسید انجام نشد");}finally{sql.endTransaction();}showRecurring();}).show();
    }

    private void showGoals() {
        setHeaderInfo("هدف‌های پس‌انداز", "میزان پیشرفت هر هدف را پیگیری کنید");
        body.removeAllViews();addHeading("هدف‌های پس‌انداز");addEmpty("هدف‌ها برای پیگیری پیشرفت پس‌انداز هستند؛ واریز به هدف به‌تنهایی موجودی حساب را تغییر نمی‌دهد. برای جابه‌جایی واقعی پول از «انتقال بین حساب‌ها» استفاده کن.");addWideButton("＋ هدف جدید",()->goalDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,target,current_amount,deadline,note FROM goals WHERE book=? ORDER BY id DESC",new String[]{activeBook});if(!c.moveToFirst()){c.close();addEmpty("هنوز هدفی تعریف نشده است.");return;}
        do{long id=c.getLong(0),target=c.getLong(2),current=c.getLong(3),deadline=c.getLong(4);String name=c.getString(1),note=c.getString(5);int pct=target<=0?0:(int)Math.min(100,current*100.0/target);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(name,16,TEXT,true));card.addView(text("پس‌انداز: "+money(current)+" از "+money(target),13,Color.rgb(86, 99, 91),false));ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(pct);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(8)));card.addView(text(pct+"٪ پیشرفت"+(deadline>0?" • موعد: "+jalaliDate(deadline):""),12,GREEN,false));if(note!=null&&!note.isEmpty())card.addView(text(note,12,Color.rgb(86, 99, 91),false));Button add=button("ثبت مبلغ پس‌اندازشده");card.addView(add);add.setOnClickListener(v->contributeGoal(id,name,target,current));body.addView(card,new LinearLayout.LayoutParams(-1,-2));}while(c.moveToNext());c.close();
    }

    private void goalDialog() {
        LinearLayout f=formLayout();EditText name=edit("عنوان هدف (مثلاً خرید خودرو)",InputType.TYPE_CLASS_TEXT),target=edit("مبلغ هدف به ریال",InputType.TYPE_CLASS_NUMBER),note=edit("یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);f.addView(name);f.addView(target);f.addView(note);new AlertDialog.Builder(this).setTitle("هدف پس‌انداز جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();long t=parseAmount(target.getText().toString());if(n.isEmpty()||t<=0){toast("عنوان و مبلغ هدف معتبر وارد کن");return;}ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",n);v.put("target",t);v.put("current_amount",0);v.put("deadline",0);v.put("note",note.getText().toString());db.getWritableDatabase().insert("goals",null,v);showGoals();}).show();
    }

    private void contributeGoal(long id,String name,long target,long current) {
        EditText amount=edit("مبلغ جدید پس‌اندازشده به ریال",InputType.TYPE_CLASS_NUMBER);new AlertDialog.Builder(this).setTitle("به‌روزرسانی هدف «"+name+"»").setView(amount).setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{long a=parseAmount(amount.getText().toString());if(a<=0){toast("مبلغ باید بیشتر از صفر باشد");return;}ContentValues v=new ContentValues();v.put("current_amount",Math.min(target,current+a));db.getWritableDatabase().update("goals",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});showGoals();}).show();
    }

    private void exportTransactionsCsv() {
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"HisabYar-transactions.csv");startActivityForResult(i,703);
    }

    private void showAssets() {
        setHeaderInfo("دارایی‌ها", "ارزش دارایی‌ها و موارد ثبت‌شده را مدیریت کنید");
        body.removeAllViews(); addHeading("دارایی‌ها و ارزش خالص");
        Button add=button("＋ افزودن دارایی");body.addView(add);add.setOnClickListener(v->showAssetDialog());
        long total=0; Cursor c=db.getReadableDatabase().rawQuery("SELECT name,kind,value,note FROM assets WHERE book=? ORDER BY name",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز دارایی ثبت نشده است.");return;}
        do {String name=c.getString(0),kind=c.getString(1),note=c.getString(3);long val=c.getLong(2);total+=val;
            LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setPadding(dp(12),dp(10),dp(12),dp(10));item.setBackground(roundBg(Color.WHITE));
            item.addView(text(name+" • "+kind,15,TEXT,true));item.addView(text(money(val),16,GREEN,true));if(note!=null&&!note.isEmpty())item.addView(text(note,12,Color.rgb(86, 99, 91),false));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(item,lp);
        }while(c.moveToNext());c.close();
        addMetric("ارزش دارایی‌های ثبت‌شده",money(total),GREEN);
    }
    private void showAssetDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام دارایی",InputType.TYPE_CLASS_TEXT),kind=edit("نوع (طلا، خودرو، ملک و ...)",InputType.TYPE_CLASS_TEXT),value=edit("ارزش فعلی به ریال",InputType.TYPE_CLASS_NUMBER),note=edit("یادداشت (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(name);f.addView(kind);f.addView(value);f.addView(note);
        new AlertDialog.Builder(this).setTitle("افزودن دارایی").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long val=parseAmount(value.getText().toString());if(name.getText().toString().trim().isEmpty()||val<0){toast("نام و ارزش دارایی را بررسی کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name.getText().toString().trim());v.put("kind",kind.getText().toString().trim());v.put("value",val);v.put("note",note.getText().toString());db.getWritableDatabase().insert("assets",null,v);navigate("دارایی‌ها");
        }).show();
    }
    private void showCheques() {
        setHeaderInfo("دریافت و پرداخت چک", "چک‌ها مستقل از تراکنش‌های نقدی ثبت می‌شوند؛ اثر مالی را هنگام وصول/پرداخت ثبت کنید");
        body.removeAllViews(); addHeading("مدیریت چک‌ها");
        addWideButton("＋ ثبت چک دریافتی", () -> showChequeDialog(false, "دریافتی"));
        addWideButton("＋ ثبت چک پرداختی", () -> showChequeDialog(false, "پرداختی"));
        addWideButton("📷 ثبت چک از روی عکس", () -> showChequeDialog(true));
        Spinner filter=styledSpinner(); filter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"همه چک‌ها","دریافتی","پرداختی","باز / در انتظار","وصول‌شده یا پرداخت‌شده","برگشتی","لغوشده"})); body.addView(filter);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); body.addView(list);
        Runnable refresh=()->{
            list.removeAllViews(); String f=String.valueOf(filter.getSelectedItem());
            String where="book=?"; java.util.ArrayList<String> args=new java.util.ArrayList<>(); args.add(activeBook);
            if("دریافتی".equals(f)||"پرداختی".equals(f)){where+=" AND direction=?";args.add(f);}
            else if("باز / در انتظار".equals(f)){where+=" AND status IN ('در انتظار وصول','در انتظار پرداخت','در جریان وصول','در جریان پرداخت')";}
            else if("وصول‌شده یا پرداخت‌شده".equals(f)){where+=" AND status IN ('وصول شد','پرداخت شد')";}
            else if("برگشتی".equals(f)){where+=" AND status='برگشتی'";}
            else if("لغوشده".equals(f)){where+=" AND status='لغو شد'";}
            Cursor c=db.getReadableDatabase().rawQuery("SELECT id,direction,cheque_no,bank,party,amount,due_date,account,status,note,image_path FROM cheques WHERE "+where+" ORDER BY due_date ASC,id DESC",args.toArray(new String[0]));
            if(!c.moveToFirst()){c.close(); TextView empty=text("برای این فیلتر چکی ثبت نشده است.",14,TEXT,false);list.addView(empty);return;}
            do { long id=c.getLong(0),amount=c.getLong(5);String direction=c.getString(1),no=c.getString(2),bank=c.getString(3),party=c.getString(4),due=c.getString(6),account=c.getString(7),status=c.getString(8),note=c.getString(9),imagePath=c.getString(10);
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));
                card.addView(text((direction.equals("دریافتی")?"⬇ چک دریافتی":"⬆ چک پرداختی")+" • "+(no==null||no.isEmpty()?"بدون شماره":"شماره "+no),16,TEXT,true));
                card.addView(text("بانک: "+safeCheque(bank)+" | طرف حساب: "+safeCheque(party),13,TEXT,false));
                card.addView(text("مبلغ: "+money(amount)+" ریال | سررسید: "+safeCheque(due),14,DARK,true));
                card.addView(text("وضعیت: "+status+" | حساب مرتبط: "+safeCheque(account),13,Color.rgb(86,99,91),false));
                if(note!=null&&!note.isEmpty())card.addView(text("شرح: "+note,12,TEXT,false));
                if(imagePath!=null&&!imagePath.isEmpty()) {Button photo=button("مشاهده عکس چک");card.addView(photo);photo.setOnClickListener(v->{File fimg=new File(imagePath);if(!fimg.exists()){toast("فایل عکس پیدا نشد؛ ممکن است از حافظه حذف شده باشد.");return;}Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(Uri.fromFile(fimg),"image/*");view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(view);}catch(Exception ex){toast("برنامه‌ای برای نمایش عکس پیدا نشد.");}});}
                Button change=button("تغییر وضعیت / ثبت وصول یا پرداخت");card.addView(change);change.setOnClickListener(v->changeChequeStatus(id,direction,status,amount,account,party));
                Button edit=button("ویرایش مشخصات چک");card.addView(edit);edit.setOnClickListener(v->editCheque(id));
                Button del=button("حذف چک");card.addView(del);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف چک").setMessage("این چک از دفتر فعلی حذف شود؟ تراکنش مالی احتمالی که جداگانه ثبت شده حذف نمی‌شود.").setNegativeButton("انصراف",null).setPositiveButton("حذف",(d,w)->{db.getWritableDatabase().delete("cheques","id=? AND book=?",new String[]{String.valueOf(id),activeBook});showCheques();}).show());
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));list.addView(card,lp);
            }while(c.moveToNext());c.close();
        };
        filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){refresh.run();}public void onNothingSelected(android.widget.AdapterView<?> a){}});
        refresh.run();
    }
    private String safeCheque(String s){return s==null||s.trim().isEmpty()?"—":s;}
    private void showChequeDialog(boolean fromImage){showChequeDialog(fromImage,"دریافتی");}
    private void showChequeDialog(boolean fromImage,String initialDirection){
        pendingChequeImagePath="";pendingChequeOcrText="";
        LinearLayout f=formLayout();
        chequeDirectionSpinner=styledSpinner();chequeDirectionSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"دریافتی","پرداختی"}));chequeDirectionSpinner.setSelection("پرداختی".equals(initialDirection)?1:0);
        chequeNumberField=edit("شماره چک",InputType.TYPE_CLASS_TEXT);chequeBankField=edit("نام بانک",InputType.TYPE_CLASS_TEXT);chequePartyField=edit("نام صادرکننده / دریافت‌کننده",InputType.TYPE_CLASS_TEXT);chequeAmountField=edit("مبلغ چک به ریال",InputType.TYPE_CLASS_NUMBER);chequeDueField=edit("تاریخ سررسید (مثلاً ۱۴۰۵/۰۸/۱۵)",InputType.TYPE_CLASS_TEXT);chequeAccountField=edit("حساب بانکی مرتبط (اختیاری)",InputType.TYPE_CLASS_TEXT);chequeNoteField=edit("شرح / متن استخراج‌شده از عکس",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        chequeStatusSpinner=styledSpinner();
        f.addView(text("نوع چک",13,TEXT,true));f.addView(chequeDirectionSpinner);f.addView(chequeNumberField);f.addView(chequeBankField);f.addView(chequePartyField);f.addView(chequeAmountField);f.addView(chequeDueField);f.addView(chequeAccountField);f.addView(text("وضعیت اولیه",13,TEXT,true));f.addView(chequeStatusSpinner);f.addView(chequeNoteField);
        Button photo=button("📷 انتخاب عکس چک و استخراج مشخصات");f.addView(photo);photo.setOnClickListener(v->chooseChequeImage());
        chequeDirectionSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){String[] opts=pos==0?new String[]{"در انتظار وصول","در جریان وصول","وصول شد","برگشتی","لغو شد"}:new String[]{"در انتظار پرداخت","در جریان پرداخت","پرداخت شد","برگشتی","لغو شد"};String old=chequeStatusSpinner.getSelectedItem()==null?"":chequeStatusSpinner.getSelectedItem().toString();chequeStatusSpinner.setAdapter(new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,opts));for(int i=0;i<opts.length;i++)if(opts[i].equals(old))chequeStatusSpinner.setSelection(i);}public void onNothingSelected(android.widget.AdapterView<?> a){}});
        new AlertDialog.Builder(this).setTitle("ثبت چک").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره چک",(d,w)->{
            String direction=chequeDirectionSpinner.getSelectedItem().toString(),no=chequeNumberField.getText().toString().trim(),bank=chequeBankField.getText().toString().trim(),party=chequePartyField.getText().toString().trim(),due=chequeDueField.getText().toString().trim(),account=chequeAccountField.getText().toString().trim(),note=chequeNoteField.getText().toString().trim();long amount=parseAmount(chequeAmountField.getText().toString());
            if(amount<=0){toast("مبلغ چک باید بیشتر از صفر باشد.");return;}if(no.isEmpty()&&bank.isEmpty()&&party.isEmpty()){toast("حداقل شماره چک، بانک یا نام طرف حساب را وارد کن.");return;}
            long now=System.currentTimeMillis();ContentValues cv=new ContentValues();cv.put("book",activeBook);cv.put("direction",direction);cv.put("cheque_no",no);cv.put("bank",bank);cv.put("party",party);cv.put("amount",amount);cv.put("due_date",due);cv.put("account",account);cv.put("status",chequeStatusSpinner.getSelectedItem().toString());cv.put("note",note);cv.put("image_path",pendingChequeImagePath);cv.put("created_at",now);cv.put("updated_at",now);db.getWritableDatabase().insert("cheques",null,cv);toast("چک در دفتر «"+activeBook+"» ثبت شد؛ هنوز به‌عنوان تراکنش نقدی ثبت نشده است.");showCheques();
        }).show();
        if(fromImage)chooseChequeImage();
    }
    private void chooseChequeImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_CHEQUE_IMAGE);}
    private void processChequeImage(Uri uri){
        try{
            File dir=new File(getFilesDir(),"cheque_images");if(!dir.exists()&&!dir.mkdirs())throw new IOException("ساخت پوشه عکس انجام نشد");File dest=new File(dir,"cheque_"+System.currentTimeMillis()+".jpg");
            try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(dest)){copy(in,out);}pendingChequeImagePath=dest.getAbsolutePath();
            com.google.mlkit.vision.common.InputImage image=com.google.mlkit.vision.common.InputImage.fromFilePath(this,uri);
            com.google.mlkit.vision.text.TextRecognizer recognizer=com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image).addOnSuccessListener(result->{String recognized=result.getText()==null?"":result.getText().trim();pendingChequeOcrText=recognized;if(chequeNoteField!=null)chequeNoteField.setText(recognized);if(chequeNumberField!=null&&chequeNumberField.getText().toString().trim().isEmpty()){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?<!\\d)(\\d{6,20})(?!\\d)").matcher(normalizeDigits(recognized));if(m.find())chequeNumberField.setText(m.group(1));}if(chequeAmountField!=null&&chequeAmountField.getText().toString().trim().isEmpty()){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)(?:مبلغ|amount|rial|ریال|تومان)[^\\d]{0,12}([\\d,٬،.]{4,})").matcher(normalizeDigits(recognized));if(m.find())chequeAmountField.setText(m.group(1).replaceAll("[^0-9]",""));}if(chequeBankField!=null&&chequeBankField.getText().toString().trim().isEmpty()){String[] banks={"ملی","ملت","صادرات","تجارت","رفاه","کشاورزی","مسکن","سپه","پاسارگاد","پارسیان","سامان","شهر","آینده","رسالت","دی","اقتصاد نوین","کارآفرین"};for(String b:banks)if(recognized.contains(b)){chequeBankField.setText("بانک "+b);break;}}new AlertDialog.Builder(this).setTitle("نتیجه خواندن عکس چک").setMessage(recognized.isEmpty()?"متنی از تصویر خوانده نشد. اطلاعات را دستی وارد کن.":"متن استخراج‌شده (حتماً با اصل چک تطبیق بده):\n\n"+recognized).setPositiveButton("بررسی و ادامه",null).show();if(recognized.isEmpty())toast("متن چک کامل خوانده نشد؛ فرم را دستی تکمیل کن.");}).addOnFailureListener(e->toast("استخراج متن از عکس انجام نشد؛ مشخصات را دستی وارد کن." )).addOnCompleteListener(t->recognizer.close());
        }catch(Exception e){toast("بازکردن عکس چک ناموفق بود: "+e.getMessage());}
    }
    private void changeChequeStatus(long id,String direction,String current,long amount,String account,String party){
        String[] opts=direction.equals("دریافتی")?new String[]{"در انتظار وصول","در جریان وصول","وصول شد","برگشتی","لغو شد"}:new String[]{"در انتظار پرداخت","در جریان پرداخت","پرداخت شد","برگشتی","لغو شد"};
        new AlertDialog.Builder(this).setTitle("وضعیت چک").setSingleChoiceItems(opts,Math.max(0,java.util.Arrays.asList(opts).indexOf(current)),(d,w)->{String selected=opts[w];d.dismiss();new AlertDialog.Builder(this).setTitle("تأیید وضعیت").setMessage("وضعیت چک به «"+selected+"» تغییر کند؟ تغییر وضعیت به‌تنهایی مانده حساب را تغییر نمی‌دهد.").setNegativeButton("انصراف",null).setPositiveButton("تأیید",(x,y)->{ContentValues v=new ContentValues();v.put("status",selected);v.put("updated_at",System.currentTimeMillis());db.getWritableDatabase().update("cheques",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});if((selected.equals("وصول شد")||selected.equals("پرداخت شد"))){new AlertDialog.Builder(this).setTitle("ثبت اثر مالی").setMessage("آیا می‌خواهی اثر وصول/پرداخت این چک هم به‌عنوان تراکنش مالی در دفتر ثبت شود؟ فقط در صورتی تأیید کن که قبلاً ثبت نشده باشد.").setNegativeButton("فقط تغییر وضعیت",(dd,ww)->showCheques()).setPositiveButton("ثبت تراکنش مالی",(dd,ww)->{String acc=account==null?"":account.trim();if(acc.isEmpty()){toast("حساب مرتبط مشخص نیست؛ چک را ویرایش کن و حساب را وارد کن، سپس اثر مالی را جداگانه ثبت کن.");showCheques();return;}ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",direction.equals("دریافتی")?"درآمد":"هزینه");tx.put("amount",amount);tx.put("category",direction.equals("دریافتی")?"وصول چک":"پرداخت چک");tx.put("account",acc);tx.put("note","اثر مالی چک "+(party==null?"":party)+" (شماره "+id+")");tx.put("date",System.currentTimeMillis());setMonthKey(tx,System.currentTimeMillis());Cursor posted=db.getReadableDatabase().rawQuery("SELECT financial_posted FROM cheques WHERE id=? AND book=?",new String[]{String.valueOf(id),activeBook});boolean alreadyPosted=posted.moveToFirst()&&posted.getInt(0)==1;posted.close();if(alreadyPosted){toast("اثر مالی این چک قبلاً ثبت شده است؛ از ثبت تکراری جلوگیری شد.");showCheques();return;}db.getWritableDatabase().beginTransaction();try{db.getWritableDatabase().insert("transactions",null,tx);ContentValues mark=new ContentValues();mark.put("financial_posted",1);mark.put("updated_at",System.currentTimeMillis());db.getWritableDatabase().update("cheques",mark,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});db.getWritableDatabase().setTransactionSuccessful();}finally{db.getWritableDatabase().endTransaction();}toast("تراکنش مالی ثبت شد");showCheques();}).show();}else showCheques();}).show();}).setNegativeButton("بستن",null).show();
    }
    private void editCheque(long id){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT direction,cheque_no,bank,party,amount,due_date,account,status,note,image_path FROM cheques WHERE id=? AND book=?",new String[]{String.valueOf(id),activeBook});if(!c.moveToFirst()){c.close();return;}String direction=c.getString(0),no=c.getString(1),bank=c.getString(2),party=c.getString(3),amount=String.valueOf(c.getLong(4)),due=c.getString(5),account=c.getString(6),status=c.getString(7),note=c.getString(8),img=c.getString(9);c.close();
        LinearLayout f=formLayout();EditText n=edit("شماره چک",InputType.TYPE_CLASS_TEXT),b=edit("بانک",InputType.TYPE_CLASS_TEXT),p=edit("طرف حساب",InputType.TYPE_CLASS_TEXT),a=edit("مبلغ به ریال",InputType.TYPE_CLASS_NUMBER),dt=edit("سررسید",InputType.TYPE_CLASS_TEXT),ac=edit("حساب مرتبط",InputType.TYPE_CLASS_TEXT),nt=edit("شرح",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);n.setText(no);b.setText(bank);p.setText(party);a.setText(amount);dt.setText(due);ac.setText(account);nt.setText(note);f.addView(n);f.addView(b);f.addView(p);f.addView(a);f.addView(dt);f.addView(ac);f.addView(nt);
        new AlertDialog.Builder(this).setTitle("ویرایش چک").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{long amt=parseAmount(a.getText().toString());if(amt<=0){toast("مبلغ نامعتبر است");return;}ContentValues v=new ContentValues();v.put("cheque_no",n.getText().toString().trim());v.put("bank",b.getText().toString().trim());v.put("party",p.getText().toString().trim());v.put("amount",amt);v.put("due_date",dt.getText().toString().trim());v.put("account",ac.getText().toString().trim());v.put("note",nt.getText().toString().trim());v.put("updated_at",System.currentTimeMillis());db.getWritableDatabase().update("cheques",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});showCheques();}).show();
    }

    private void showDebtDialog() {
        LinearLayout f=formLayout();
        EditText person=edit("نام شخص",InputType.TYPE_CLASS_TEXT);
        Spinner kind=styledSpinner(); String[] kinds={"طلب از شخص","بدهی به شخص"}; kind.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,kinds));
        EditText amount=edit("مبلغ کل به ریال",InputType.TYPE_CLASS_NUMBER),note=edit("شرح (اختیاری)",InputType.TYPE_CLASS_TEXT);
        f.addView(person);f.addView(kind);f.addView(amount);f.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت بدهی یا طلب").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            long a=parseAmount(amount.getText().toString());String who=person.getText().toString().trim();
            if(a<=0||who.isEmpty()){toast("نام و مبلغ را درست وارد کن");return;}
            ContentValues v=new ContentValues();v.put("book",activeBook);v.put("person",who);v.put("kind",kind.getSelectedItem().toString());v.put("amount",a);v.put("paid",0);v.put("note",note.getText().toString());v.put("date",System.currentTimeMillis());
            db.getWritableDatabase().insert("debts",null,v);toast("بدهی/طلب ثبت شد");showDebts();
        }).show();
    }
    private void showDebts() {
        setHeaderInfo("بدهی‌ها و طلب‌ها", "مانده و تسویه بدهی‌ها و طلب‌ها را بررسی کنید");
        body.removeAllViews();addHeading("بدهی‌ها و طلب‌ها");
        addWideButton("＋ ثبت بدهی یا طلب",()->showDebtDialog());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,person,kind,amount,paid,note,date FROM debts WHERE book=? ORDER BY date DESC",new String[]{activeBook});
        if(!c.moveToFirst()){c.close();addEmpty("هنوز بدهی یا طلبی ثبت نشده است.");return;}
        do {
            long id=c.getLong(0), amount=c.getLong(3), paid=c.getLong(4);String person=c.getString(1),kind=c.getString(2),note=c.getString(5);long remaining=Math.max(0,amount-paid);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));
            card.addView(text(person+" • "+kind,15,TEXT,true));card.addView(text("کل: "+money(amount)+" | تسویه: "+money(paid),13,Color.rgb(86, 99, 91),false));
            card.addView(text("مانده: "+money(remaining),16,remaining==0?GREEN:Color.rgb(204,103,112),true));if(note!=null&&!note.isEmpty())card.addView(text(note,12,Color.rgb(86, 99, 91),false));
            Button settle=button(remaining==0?"تسویه کامل شده":"ثبت تسویه / دریافت" );settle.setEnabled(remaining>0);card.addView(settle);settle.setOnClickListener(v->settleDebt(id,person,kind,remaining));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));body.addView(card,lp);
        }while(c.moveToNext());c.close();
    }
    private void settleDebt(long id,String person,String kind,long remaining) {
        EditText amount=edit("مبلغ این تسویه (مانده: "+remaining+")",InputType.TYPE_CLASS_NUMBER);amount.setText(String.valueOf(remaining));
        new AlertDialog.Builder(this).setTitle("تسویه با "+person).setView(amount).setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{
            long a=parseAmount(amount.getText().toString());if(a<=0||a>remaining){toast("مبلغ باید بین ۱ تا مانده بدهی باشد");return;}
            SQLiteDatabase sql=db.getWritableDatabase();
            sql.execSQL("UPDATE debts SET paid=MIN(amount,paid+?) WHERE id=?",new Object[]{a,id});
            String txType=kind.contains("بدهی")?"هزینه":"درآمد";String cat=kind.contains("بدهی")?"تسویه بدهی":"دریافت طلب";ensureAccount("پول نقد");
            ContentValues tx=new ContentValues();tx.put("book",activeBook);tx.put("type",txType);tx.put("amount",a);tx.put("category",cat);tx.put("account","پول نقد");tx.put("note","تسویه با "+person);tx.put("date",System.currentTimeMillis());setMonthKey(tx,System.currentTimeMillis());sql.insert("transactions",null,tx);
            toast("تسویه ثبت شد");showDebts();
        }).show();
    }
    private static final String QUICK_ACTIONS_PREF = "home_quick_actions_v1";
    private String[] quickActionOptions() {
        return new String[]{"ثبت هزینه", "ثبت درآمد", "انتقال بین حساب‌ها", "ثبت دارایی", "ثبت بدهی یا طلب", "گزارش مالی", "تراکنش‌ها", "هدف‌های پس‌انداز", "بودجه‌بندی"};
    }
    private java.util.ArrayList<String> getQuickActions() {
        String stored = getPreferences(0).getString(QUICK_ACTIONS_PREF, "");
        java.util.ArrayList<String> result = new java.util.ArrayList<>();
        if (!stored.trim().isEmpty()) for (String item : stored.split("\\|")) if (!item.trim().isEmpty()) result.add(item);
        return result;
    }
    private String quickActionLabel(String action) {
        switch (action) {
            case "ثبت هزینه": return "🧾 ثبت هزینه";
            case "ثبت درآمد": return "💰 ثبت درآمد";
            case "انتقال بین حساب‌ها": return "⇄ انتقال بین حساب‌ها";
            case "ثبت دارایی": return "◇ ثبت دارایی";
            case "ثبت بدهی یا طلب": return "↔ بدهی یا طلب";
            case "گزارش مالی": return "▤ گزارش مالی";
            case "تراکنش‌ها": return "↕ تراکنش‌ها";
            case "هدف‌های پس‌انداز": return "◎ هدف‌های پس‌انداز";
            case "بودجه‌بندی": return "▦ بودجه‌بندی";
            default: return action;
        }
    }
    private void runQuickAction(String action) {
        switch (action) {
            case "ثبت هزینه": showEntry("هزینه"); break;
            case "ثبت درآمد": showEntry("درآمد"); break;
            case "انتقال بین حساب‌ها": showTransfer(); break;
            case "ثبت دارایی": showAssetDialog(); break;
            case "ثبت بدهی یا طلب": showDebtDialog(); break;
            case "گزارش مالی": showReports(); break;
            case "تراکنش‌ها": navigate("تراکنش‌ها"); break;
            case "هدف‌های پس‌انداز": showGoals(); break;
            case "بودجه‌بندی": showBudgets(); break;
        }
    }
    private void manageQuickActions() {
        final String[] options = quickActionOptions();
        final java.util.ArrayList<String> current = getQuickActions();
        final boolean[] checked = new boolean[options.length];
        final CheckBox[] boxes = new CheckBox[options.length];
        for (int i = 0; i < options.length; i++) checked[i] = current.contains(options[i]);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        panel.setPadding(dp(14), dp(8), dp(14), dp(8));
        TextView instruction = text("برای نمایش هر گزینه در صفحه خانه، مربع کنار آن را فعال کن.", 14, TEXT, false);
        instruction.setPadding(dp(2), dp(4), dp(2), dp(12));
        panel.addView(instruction);

        ScrollView listScroll = new ScrollView(this);
        listScroll.setFillViewport(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for (int i = 0; i < options.length; i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            row.setPadding(dp(10), dp(5), dp(10), dp(5));
            row.setBackground(roundBg(Color.rgb(255, 247, 249)));
            CheckBox cb = new CheckBox(this);
            cb.setText(options[i]);
            cb.setTextColor(TEXT);
            cb.setTextSize(15);
            cb.setGravity(Gravity.CENTER_VERTICAL);
            cb.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            cb.setButtonTintList(android.content.res.ColorStateList.valueOf(GREEN));
            cb.setChecked(checked[i]);
            cb.setPadding(dp(4), dp(4), dp(4), dp(4));
            boxes[i] = cb;
            row.addView(cb, new LinearLayout.LayoutParams(-1, -2));
            row.setOnClickListener(v -> cb.setChecked(!cb.isChecked()));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
            rowLp.setMargins(0, dp(3), 0, dp(3));
            list.addView(row, rowLp);
        }
        listScroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        panel.addView(listScroll, new LinearLayout.LayoutParams(-1, dp(350)));

        new AlertDialog.Builder(this)
            .setTitle("مدیریت آیکن‌های دسترسی سریع")
            .setView(panel)
            .setNegativeButton("انصراف", null)
            .setNeutralButton("حذف همه", (dialog, which) -> {
                getPreferences(0).edit().putString(QUICK_ACTIONS_PREF, "").apply();
                toast("همه دسترسی‌های سریع حذف شدند");
                showSettings();
            })
            .setPositiveButton("ذخیره", (dialog, which) -> {
                StringBuilder saved = new StringBuilder();
                for (int i = 0; i < options.length; i++) {
                    if (boxes[i].isChecked()) {
                        if (saved.length() > 0) saved.append('|');
                        saved.append(options[i]);
                    }
                }
                getPreferences(0).edit().putString(QUICK_ACTIONS_PREF, saved.toString()).apply();
                toast(saved.length() == 0 ? "دسترسی سریع غیرفعال شد" : "دسترسی‌های سریع ذخیره شدند");
                showSettings();
            }).show();
    }

    private void showSettings() {
        setHeaderInfo("تنظیمات", "دفتر، پشتیبان‌گیری و تنظیمات برنامه");
        body.removeAllViews();addHeading("تنظیمات");
        addWideButton("مدیریت آیکن‌های دسترسی سریع خانه",()->manageQuickActions());
        addWideButton("مدیریت دفترها",()->manageBooks());
        addWideButton("مدیریت حساب‌ها و موجودی",()->showAccounts());
        addWideButton("بستن ماه و مشاهده بایگانی ماهانه",()->showMonthClosing());
        addWideButton("افزودن حساب بانکی یا کیف پول",()->addAccountDialog());
        addWideButton("مدیریت دسته‌بندی‌ها",()->manageCategories());
        addWideButton("بودجه‌بندی ماهانه و هشدار هزینه",()->showBudgets());
        addWideButton("پرداخت‌های تکرارشونده و سررسیدها",()->showRecurring());
        addWideButton("هدف‌های پس‌انداز",()->showGoals());
        addWideButton("خروجی گزارش تراکنش‌ها (CSV)",()->exportTransactionsCsv());
        addWideButton("گزارش مالی و ارزش خالص دارایی",()->showReports());
        addWideButton("بدهی‌ها، طلب‌ها و تسویه",()->showDebts());
        addWideButton("قفل برنامه با رمز عددی",()->setPinDialog());
        addWideButton("پشتیبان‌گیری از اطلاعات",()->exportBackup());
        addWideButton("بازیابی پشتیبان",()->importBackup());
        addWideButton("درباره برنامه",()->showAboutDialog());
        addEmpty("واحد مبالغ: ریال • تاریخ نمایشی: شمسی");
    }
    private void showAboutDialog() {
        LinearLayout content=formLayout();
        content.addView(text("حساب‌یار ۱.۳.۱",19,selectedThemeColor(),true));
        content.addView(text("برنامهٔ حسابداری فارسی با ذخیره‌سازی محلی روی گوشی، دفترهای جداگانه، حساب‌ها، تراکنش‌ها، دستیار صوتی، گزارش مالی، بودجه، دارایی‌ها، بدهی و طلب و پشتیبان‌گیری.",14,TEXT,false));
        content.addView(text("طراح و برنامه‌نویس: مهدی ساریخانی فرد\nشماره تماس: ۰۹۱۲۱۳۹۸۸۹۳",13,TEXT,false));
        LinearLayout themeCard = new LinearLayout(this);
        themeCard.setOrientation(LinearLayout.VERTICAL);
        themeCard.setPadding(dp(12),dp(10),dp(12),dp(10));
        android.graphics.drawable.GradientDrawable themeCardBg = roundBg(lighten(selectedThemeColor(),0.92f));
        themeCardBg.setStroke(dp(1),lighten(selectedThemeColor(),0.45f));
        themeCard.setBackground(themeCardBg);
        LinearLayout.LayoutParams themeCardLp = new LinearLayout.LayoutParams(-1,-2);
        themeCardLp.setMargins(0,dp(12),0,0);
        themeCard.addView(text("انتخاب رنگ برنامه",16,selectedThemeColor(),true));
        themeCard.addView(text("رنگ دلخواه را انتخاب کنید. این رنگ در ظاهر برنامه و نوارهای سیستم اعمال می‌شود.",12,TEXT,false));
        showThemePalette(themeCard);
        content.addView(themeCard,themeCardLp);
        new AlertDialog.Builder(this).setTitle("درباره برنامه").setView(content).setPositiveButton("باشه",null).show();
    }

    private void showBudgets() {
        setHeaderInfo("بودجه‌بندی", "سقف هزینه ماهانه هر دسته را بررسی کنید");
        body.removeAllViews();addHeading("بودجه‌بندی ماهانه");
        addWideButton("＋ تعریف سقف هزینه برای دسته‌بندی",()->budgetDialog());
        String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
        Cursor c=db.getReadableDatabase().rawQuery("SELECT category,limit_amount FROM budgets WHERE book=? AND month=? ORDER BY category",new String[]{activeBook,month});
        if(!c.moveToFirst()){c.close();addEmpty("برای این ماه بودجه‌ای تعریف نشده است.");return;}
        do {String cat=c.getString(0);long limit=c.getLong(1),spent=categoryExpenseThisMonth(cat);int pct=limit<=0?0:(int)Math.min(100,spent*100.0/limit);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(roundBg(Color.WHITE));card.addView(text(cat,15,TEXT,true));card.addView(text("هزینه: "+money(spent)+" / بودجه: "+money(limit),13,TEXT,false));
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(pct);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(8)));
            card.addView(text(pct>=100?"هشدار: بودجه مصرف شده است":"مصرف بودجه: "+pct+"٪",12,pct>=100?Color.rgb(204,103,112):GREEN,false));body.addView(card,new LinearLayout.LayoutParams(-1,-2));
        }while(c.moveToNext());c.close();
    }
    private void budgetDialog() {
        LinearLayout f=formLayout();EditText cat=edit("دسته‌بندی هزینه (مثلاً خوراک)",InputType.TYPE_CLASS_TEXT),limit=edit("سقف بودجه ماهانه به ریال",InputType.TYPE_CLASS_NUMBER);f.addView(cat);f.addView(limit);
        new AlertDialog.Builder(this).setTitle("تعریف بودجه ماه جاری").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String name=cat.getText().toString().trim();long amount=parseAmount(limit.getText().toString());if(name.isEmpty()||amount<=0){toast("دسته‌بندی و سقف معتبر وارد کن");return;}String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());SQLiteDatabase sql=db.getWritableDatabase();sql.delete("budgets","book=? AND category=? AND month=?",new String[]{activeBook,name,month});ContentValues v=new ContentValues();v.put("book",activeBook);v.put("category",name);v.put("month",month);v.put("limit_amount",amount);sql.insert("budgets",null,v);showBudgets();}).show();
    }
    private long categoryExpenseThisMonth(String cat) {
        Calendar cal=Calendar.getInstance();cal.set(Calendar.DAY_OF_MONTH,1);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);long start=cal.getTimeInMillis();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type='هزینه' AND category=? AND date>=?",new String[]{activeBook,cat,String.valueOf(start)});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;
    }
    private void showReports() {
        setHeaderInfo("گزارش مالی", "خلاصه درآمد، هزینه، بدهی و ارزش خالص دارایی‌ها");
        body.removeAllViews();addHeading("گزارش مالی و ارزش خالص");long income=sum("درآمد"),expense=sum("هزینه"),assets=scalar("SELECT COALESCE(SUM(value),0) FROM assets WHERE book=?",activeBook),receivable=scalar("SELECT COALESCE(SUM(amount-paid),0) FROM debts WHERE book=? AND kind LIKE '%طلب%'",activeBook),payable=scalar("SELECT COALESCE(SUM(amount-paid),0) FROM debts WHERE book=? AND kind LIKE '%بدهی%'",activeBook);
        addMetric("موجودی نقدی محاسبه‌شده",money(balance()),GREEN);addMetric("درآمد ثبت‌شده",money(income),GREEN);addMetric("هزینه ثبت‌شده",money(expense),Color.rgb(204,103,112));addMetric("خالص درآمد منهای هزینه",money(income-expense),income>=expense?GREEN:Color.rgb(204,103,112));addMetric("ارزش دارایی‌های غیرنقدی",money(assets),GREEN);addMetric("طلب‌های باز",money(receivable),GREEN);addMetric("بدهی‌های باز",money(payable),Color.rgb(204,103,112));addMetric("ارزش خالص تقریبی",money(balance()+assets+receivable-payable),GREEN);
        addHeading("هزینه بر اساس دسته‌بندی");Cursor c=db.getReadableDatabase().rawQuery("SELECT category,SUM(amount) total FROM transactions WHERE book=? AND type='هزینه' GROUP BY category ORDER BY total DESC",new String[]{activeBook});if(!c.moveToFirst())addEmpty("هنوز هزینه‌ای ثبت نشده است.");else do{addEmpty(c.getString(0)+"  •  "+money(c.getLong(1)));}while(c.moveToNext());c.close();
        addHeading("خلاصه ۳۰ روز اخیر");long since=System.currentTimeMillis()-30L*24*60*60*1000;addEmpty("درآمد: "+money(sumSince("درآمد",since))+"\nهزینه: "+money(sumSince("هزینه",since)));
    }
    private long scalar(String query,String book){Cursor c=db.getReadableDatabase().rawQuery(query,new String[]{book});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    private long sumSince(String type,long since){Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=? AND date>=?",new String[]{activeBook,type,String.valueOf(since)});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    private void exportBackup() {
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"HisabYar-backup.db");startActivityForResult(i,REQ_EXPORT_BACKUP);
    }
    private void importBackup() {
        new AlertDialog.Builder(this).setTitle("بازیابی پشتیبان").setMessage("ابتدا فایل بررسی می‌شود. فقط اگر پایگاه داده سالم باشد، اطلاعات فعلی جایگزین می‌شود. بهتر است پیش از ادامه یک پشتیبان از اطلاعات فعلی بگیری.").setNegativeButton("انصراف",null).setPositiveButton("انتخاب فایل",(d,w)->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");startActivityForResult(i,REQ_IMPORT_BACKUP);}).show();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_CHEQUE_IMAGE){if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)processChequeImage(data.getData());else toast("انتخاب عکس چک لغو شد.");return;}
        if (requestCode == REQ_VOICE_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                java.util.ArrayList<String> results = data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) processVoiceCommand(results.get(0));
                else toast("متن گفتار دریافت نشد؛ زبان فارسی و سرویس گفتار را بررسی کن.");
            } else {
                toast("تشخیص گفتار انجام نشد؛ اینترنت، مجوز میکروفون و سرویس گفتار گوگل را بررسی کن.");
            }
            return;
        }
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try {
            if(requestCode==REQ_EXPORT_BACKUP) {
                db.close();
                try(InputStream in=new FileInputStream(getDatabasePath("hisabyar.db"));OutputStream out=getContentResolver().openOutputStream(uri)){copy(in,out);}
                db=new DB(this);db.getWritableDatabase();toast("پشتیبان ذخیره شد");
            } else if(requestCode==REQ_IMPORT_BACKUP) {
                File temp=new File(getCacheDir(),"hisabyar_restore.tmp");
                try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(temp)){copy(in,out);}
                SQLiteDatabase check=null;
                try {
                    check=SQLiteDatabase.openDatabase(temp.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
                    Cursor integrity=check.rawQuery("PRAGMA integrity_check",null);boolean healthy=integrity.moveToFirst()&&"ok".equalsIgnoreCase(integrity.getString(0));integrity.close();
                    Cursor tables=check.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('books','accounts','transactions','debts','assets','budgets')",null);boolean valid=tables.moveToFirst()&&tables.getInt(0)>=6;tables.close();
                    if(!healthy||!valid)throw new IOException("فایل انتخاب‌شده پشتیبان معتبر حساب‌یار نیست.");
                } finally {if(check!=null)check.close();}
                db.close();File dest=getDatabasePath("hisabyar.db");File wal=new File(dest.getPath()+"-wal"),shm=new File(dest.getPath()+"-shm");if(wal.exists())wal.delete();if(shm.exists())shm.delete();
                if(dest.exists()&&!dest.delete())throw new IOException("جایگزینی پایگاه داده انجام نشد.");
                if(!temp.renameTo(dest)){try(InputStream in=new FileInputStream(temp);OutputStream out=new FileOutputStream(dest)){copy(in,out);}temp.delete();}
                db=new DB(this);db.getWritableDatabase();toast("پشتیبان سالم بازیابی شد");navigate("خانه");
            } else if(requestCode==703) {
                try(OutputStream out=getContentResolver().openOutputStream(uri);BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(out,StandardCharsets.UTF_8))) {
                    writer.write("\uFEFFتاریخ,نوع,مبلغ به ریال,دسته‌بندی,حساب,روش پرداخت,شرح\n");
                    Cursor c=db.getReadableDatabase().rawQuery("SELECT type,amount,category,account,note,date,payment_method FROM transactions WHERE book=? ORDER BY date DESC",new String[]{activeBook});
                    while(c.moveToNext())writer.write(csv(jalaliDate(c.getLong(5))+"")+","+csv(c.getString(0))+","+c.getLong(1)+","+csv(c.getString(2))+","+csv(c.getString(3))+","+csv(c.getString(6))+","+csv(c.getString(4))+"\n");
                    c.close();writer.flush();toast("گزارش CSV ذخیره شد");
                }
            }
        } catch(Exception e) {
            if(db==null)db=new DB(this);
            try{db.getWritableDatabase();}catch(Exception ignored){}
            toast("عملیات انجام نشد: "+e.getMessage());
        }
    }
    private void copy(InputStream in,OutputStream out)throws IOException {if(in==null||out==null)throw new IOException("فایل باز نشد");byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);out.flush();}
    private String csv(String s){if(s==null)return "\"\"";return "\""+s.replace("\"","\"\"").replace("\r"," ").replace("\n"," ")+"\"";}
    private String hashPin(String salt,String pin) {
        try {byte[] bytes=MessageDigest.getInstance("SHA-256").digest((salt+":"+pin).getBytes(StandardCharsets.UTF_8));StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format(Locale.US,"%02x",b&0xff));return out.toString();}
        catch(Exception e){return "";}
    }
    private void setPinDialog() {
        String old=getPreferences(0).getString("app_pin_hash",getPreferences(0).getString("app_pin",""));
        LinearLayout f=formLayout();EditText pin=edit("رمز عددی ۴ تا ۸ رقمی (خالی = حذف رمز)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);f.addView(pin);
        new AlertDialog.Builder(this).setTitle(old.isEmpty()?"تنظیم قفل برنامه":"تغییر یا حذف قفل").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            String p=pin.getText().toString().trim();if(!p.isEmpty()&&(p.length()<4||p.length()>8)){toast("رمز باید ۴ تا ۸ رقم باشد");return;}
            android.content.SharedPreferences.Editor editor=getPreferences(0).edit();
            if(p.isEmpty())editor.remove("app_pin").remove("app_pin_hash").remove("app_pin_salt");
            else {String salt=java.util.UUID.randomUUID().toString();String hash=hashPin(salt,p);if(hash.isEmpty()){toast("تنظیم قفل ناموفق بود");return;}editor.putString("app_pin_salt",salt).putString("app_pin_hash",hash).remove("app_pin");}
            editor.apply();toast(p.isEmpty()?"قفل حذف شد":"قفل برنامه فعال شد");
        }).show();
    }
    private void promptUnlockIfNeeded() {
        String storedHash=getPreferences(0).getString("app_pin_hash","");String legacy=getPreferences(0).getString("app_pin","");
        if(storedHash.isEmpty()&&legacy.isEmpty())return;
        EditText input=edit("رمز عددی برنامه",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("حساب‌یار قفل است").setView(input).setCancelable(false).setPositiveButton("باز کردن",null).create();
        dlg.setOnShowListener(x->dlg.getButton(-1).setOnClickListener(v->{String entered=input.getText().toString();boolean ok;
            if(!storedHash.isEmpty())ok=storedHash.equals(hashPin(getPreferences(0).getString("app_pin_salt",""),entered));else ok=legacy.equals(entered);
            if(ok){if(storedHash.isEmpty()){String salt=java.util.UUID.randomUUID().toString();getPreferences(0).edit().putString("app_pin_salt",salt).putString("app_pin_hash",hashPin(salt,legacy)).remove("app_pin").apply();}dlg.dismiss();}
            else{input.setText("");input.setError("رمز اشتباه است");}
        }));dlg.show();
    }
    private String jalaliDate(long millis){Calendar c=Calendar.getInstance();c.setTimeInMillis(millis);int gy=c.get(Calendar.YEAR),gm=c.get(Calendar.MONTH)+1,gd=c.get(Calendar.DAY_OF_MONTH);int[] j=gregorianToJalali(gy,gm,gd);return String.format(new Locale("fa","IR"),"%04d/%02d/%02d",j[0],j[1],j[2]);}
    private int[] gregorianToJalali(int gy,int gm,int gd){int[] gdm={0,31,59,90,120,151,181,212,243,273,304,334};int gy2=gm>2?gy+1:gy;int days=355666+365*gy+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400+gd+gdm[gm-1];int jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365;}int jm,jd;if(days<186){jm=1+days/31;jd=1+days%31;}else{jm=7+(days-186)/30;jd=1+(days-186)%30;}return new int[]{jy,jm,jd};}
    private void chooseBook() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM books ORDER BY id",null);java.util.ArrayList<String> names=new java.util.ArrayList<>();while(c.moveToNext())names.add(c.getString(0));c.close();
        String[] a=names.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("انتخاب دفتر").setItems(a,(d,w)->{activeBook=a[w];getPreferences(0).edit().putString("active_book",activeBook).apply();ensureBookAccount();navigate("خانه");}).setNegativeButton("انصراف",null).show();
    }
    private void manageBooks() {
        LinearLayout f=formLayout();EditText name=edit("نام دفتر جدید (مثلاً شخصی، گلخانه)",InputType.TYPE_CLASS_TEXT);f.addView(name);
        new AlertDialog.Builder(this).setTitle("افزودن دفتر مالی").setView(f).setNeutralButton("انتخاب دفتر",(d,w)->chooseBook()).setNegativeButton("بستن",null).setPositiveButton("افزودن",(d,w)->{String n=name.getText().toString().trim();if(!n.isEmpty()){Cursor ex=db.getReadableDatabase().rawQuery("SELECT id FROM books WHERE name=?",new String[]{n});boolean dup=ex.moveToFirst();ex.close();if(dup){toast("این دفتر از قبل وجود دارد");return;}addBookRaw(n);activeBook=n;getPreferences(0).edit().putString("active_book",activeBook).apply();ensureBookAccount();toast("دفتر اضافه شد");navigate("خانه");}}).show();
    }
    private void addAccountDialog() {
        LinearLayout f=formLayout();EditText name=edit("نام حساب (مثلاً کارت اصلی)",InputType.TYPE_CLASS_TEXT),kind=edit("نوع حساب (بانکی/نقدی/کیف پول)",InputType.TYPE_CLASS_TEXT),opening=edit("موجودی اولیه به ریال",InputType.TYPE_CLASS_NUMBER),last4=edit("چهار رقم آخر کارت (اختیاری)",InputType.TYPE_CLASS_NUMBER);Spinner bank=styledSpinner();java.util.ArrayList<String> banks=new java.util.ArrayList<>();banks.add("بدون بانک");for(String b:bankNames())banks.add(b);bank.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,banks));f.addView(name);f.addView(kind);f.addView(bank);f.addView(last4);f.addView(opening);
        new AlertDialog.Builder(this).setTitle("حساب جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();String bankName=String.valueOf(bank.getSelectedItem());if(bankName.equals("بدون بانک"))bankName="";String card=normalizeDigits(last4.getText().toString()).replaceAll("\\D","");if(!card.isEmpty()&&card.length()!=4){toast("چهار رقم آخر کارت باید دقیقاً ۴ رقم باشد");return;}if(n.isEmpty())n=bankName.isEmpty()?"پول نقد":"بانک "+bankName+(card.isEmpty()?"":" • "+card);long initial=parseAmount(opening.getText().toString());if(initial<0){toast("موجودی اولیه نمی‌تواند منفی باشد");return;}ContentValues v=new ContentValues();String sharedUid=null;boolean linkedBank=false;if(!bankName.isEmpty()&&card.matches("\\d{4}")){Cursor shared=db.getReadableDatabase().rawQuery("SELECT account_uid FROM accounts WHERE bank_name=? AND card_last4=? AND account_uid IS NOT NULL ORDER BY id LIMIT 1",new String[]{bankName,card});if(shared.moveToFirst()){sharedUid=shared.getString(0);linkedBank=true;}shared.close();}v.put("book",activeBook);v.put("name",n);v.put("kind",kind.getText().toString().trim().isEmpty()?(bankName.isEmpty()?"نقدی":"بانکی"):kind.getText().toString().trim());v.put("opening",linkedBank?0:initial);v.put("bank_name",bankName.isEmpty()?null:bankName);v.put("card_last4",card.isEmpty()?null:card);v.put("account_uid",sharedUid==null?java.util.UUID.randomUUID().toString():sharedUid);v.put("enabled",1);Cursor exists=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{activeBook,n});boolean duplicate=exists.moveToFirst();exists.close();if(duplicate){toast("این نام حساب از قبل وجود دارد");return;}db.getWritableDatabase().insert("accounts",null,v);toast(linkedBank?"حساب بانکی به‌صورت مشترک به دفتر اضافه شد؛ موجودی اولیه دوباره منظور نشد":"حساب ذخیره شد؛ برای اشتراک خودکار بانک، چهار رقم آخر کارت را وارد کن");navigate("خانه");}).show();
    }
    private void ensureAccount(String name) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=?",new String[]{activeBook,name});boolean exists=c.moveToFirst();c.close();
        if(!exists){ContentValues v=new ContentValues();v.put("book",activeBook);v.put("name",name);v.put("kind","نقدی");v.put("opening",0);v.put("account_uid",java.util.UUID.randomUUID().toString());v.put("enabled",1);db.getWritableDatabase().insert("accounts",null,v);}
    }
    private void ensureBookAccount() { if(countForBook("accounts",activeBook)==0)ensureAccount("پول نقد"); }
    private long sum(String type) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE book=? AND type=?",new String[]{activeBook,type});long n=0;if(c.moveToFirst())n=c.getLong(0);c.close();return n;
    }
    private long balance() {
        long total=0;
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM accounts WHERE book=? AND enabled=1 ORDER BY id",new String[]{activeBook});
        while(c.moveToNext()) total+=accountBalance(c.getString(0));
        c.close();
        return total;
    }
    private long parseAmount(String s) {
        if(s==null)return 0;
        String v=s.trim().replace(",","").replace("٬","").replace("،","").replace(" ","");
        StringBuilder out=new StringBuilder();
        for(int i=0;i<v.length();i++){
            char ch=v.charAt(i);
            if(ch>='۰'&&ch<='۹') ch=(char)('0'+(ch-'۰'));
            else if(ch>='٠'&&ch<='٩') ch=(char)('0'+(ch-'٠'));
            if(ch>='0'&&ch<='9')out.append(ch);
        }
        try{return Long.parseLong(out.toString());}catch(Exception e){return 0;}
    }
    private String money(long n) { NumberFormat f=NumberFormat.getInstance(new Locale("fa","IR"));return f.format(n)+" ریال"; }
    private void addHeading(String s) {
        TextView t = text(s, 17, TEXT, true);
        t.setPadding(dp(2), dp(16), dp(2), dp(9));
        body.addView(t);
    }

    private void addEmpty(String s) {TextView t=text(s,14,Color.rgb(86, 99, 91),false);t.setGravity(Gravity.CENTER);t.setPadding(dp(16),dp(20),dp(16),dp(20));body.addView(t);}
    private void addWideButton(String s,Runnable r) {
        TextView b = text(s + "   ›", 15, GREEN, true);
        b.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        b.setPadding(dp(16), dp(13), dp(16), dp(13));
        b.setBackground(roundBg(Color.WHITE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.setMargins(0, dp(4), 0, dp(4));
        body.addView(b, lp);
        b.setOnClickListener(v -> r.run());
    }

    private View actionBox(String s,Runnable r) {
        TextView t = text(s, 14, GREEN, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundBg(Color.WHITE));
        t.setElevation(dp(1));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private LinearLayout formLayout(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(20),dp(8),dp(20),dp(4));return l;}
    private ArrayAdapter<String> dropdownAdapter(java.util.List<String> values){return new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,values){@Override public View getView(int position,View convertView,android.view.ViewGroup parent){TextView v=(TextView)super.getView(position,convertView,parent);v.setTextColor(TEXT);v.setTextSize(15);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(dp(12),dp(8),dp(12),dp(8));return v;}@Override public View getDropDownView(int position,View convertView,android.view.ViewGroup parent){TextView v=(TextView)super.getDropDownView(position,convertView,parent);v.setTextColor(TEXT);v.setTextSize(15);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(dp(14),dp(12),dp(14),dp(12));v.setBackgroundColor(Color.WHITE);return v;}};}
    private android.graphics.drawable.GradientDrawable inputFieldBg(){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(Color.rgb(255,255,255));d.setCornerRadius(dp(12));d.setStroke(dp(1),Color.rgb(194,154,169));return d;}
    private Spinner styledSpinner(){Spinner sp=new Spinner(this);sp.setPadding(dp(12),dp(7),dp(12),dp(7));sp.setMinimumHeight(dp(52));android.graphics.drawable.GradientDrawable bg=inputFieldBg();sp.setBackground(bg);return sp;}
    private EditText edit(String hint,int inputType){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(120,130,140));e.setTextColor(TEXT);e.setTextSize(15);e.setSingleLine(true);e.setInputType(inputType);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(dp(14),dp(10),dp(14),dp(10));e.setMinHeight(dp(52));e.setBackground(inputFieldBg());e.setSelectAllOnFocus(false);if((inputType&InputType.TYPE_CLASS_NUMBER)==InputType.TYPE_CLASS_NUMBER && (hint.contains("مبلغ")||hint.contains("موجودی")||hint.contains("ارزش")||hint.contains("سقف")||hint.contains("پس‌انداز")||hint.contains("هدف")))attachMoneyFormatting(e);return e;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT);t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));t.setIncludeFontPadding(true);t.setLineSpacing(dp(1),1.0f);t.setPadding(0,dp(3),0,dp(3));return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(GREEN);b.setAllCaps(false);return b;}
    private android.graphics.drawable.GradientDrawable gradientBg(int[] colors, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, colors);
        d.setCornerRadius(radius);
        return d;
    }
    private android.graphics.drawable.GradientDrawable ovalBg(int color) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(dp(1), Color.rgb(238, 172, 192));
        return d;
    }

    private android.graphics.drawable.GradientDrawable roundBg(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private class DB extends SQLiteOpenHelper {
        DB(Activity a){super(a,"hisabyar.db",null,13);}
        @Override public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE)");
            d.execSQL("CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,opening INTEGER NOT NULL DEFAULT 0,bank_name TEXT,card_last4 TEXT,account_uid TEXT,enabled INTEGER NOT NULL DEFAULT 1)");
            d.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,name TEXT NOT NULL)");
            d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,note TEXT,date INTEGER NOT NULL,transfer_id TEXT,payment_method TEXT DEFAULT 'متفرقه',month_key TEXT)");
            d.execSQL("CREATE TABLE closed_months(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,month_key TEXT NOT NULL,closed_at INTEGER NOT NULL,UNIQUE(book,month_key))");
            d.execSQL("CREATE TABLE assets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,kind TEXT,value INTEGER NOT NULL,note TEXT)");
            d.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,person TEXT NOT NULL,kind TEXT,amount INTEGER NOT NULL,paid INTEGER NOT NULL DEFAULT 0,note TEXT,date INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE budgets(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,category TEXT NOT NULL,month TEXT NOT NULL,limit_amount INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE recurring(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,frequency TEXT NOT NULL,next_due INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,target INTEGER NOT NULL,current_amount INTEGER NOT NULL DEFAULT 0,deadline INTEGER NOT NULL DEFAULT 0,note TEXT)");
            d.execSQL("CREATE TABLE cheques(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,direction TEXT NOT NULL,cheque_no TEXT,bank TEXT,party TEXT,amount INTEGER NOT NULL,due_date TEXT,account TEXT,status TEXT NOT NULL,note TEXT,image_path TEXT,financial_posted INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_cheques_book_due ON cheques(book,due_date,status)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_book_date ON transactions(book,date)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_debts_book ON debts(book)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_budgets_book_month ON budgets(book,month)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int oldVersion,int newVersion){
            if(oldVersion<2){d.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_book_date ON transactions(book,date)");d.execSQL("CREATE INDEX IF NOT EXISTS idx_debts_book ON debts(book)");d.execSQL("CREATE INDEX IF NOT EXISTS idx_budgets_book_month ON budgets(book,month)");}
            if(oldVersion<4){d.execSQL("CREATE TABLE IF NOT EXISTS recurring(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,category TEXT,account TEXT,frequency TEXT NOT NULL,next_due INTEGER NOT NULL)");}
            if(oldVersion<5){d.execSQL("CREATE TABLE IF NOT EXISTS goals(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,name TEXT NOT NULL,target INTEGER NOT NULL,current_amount INTEGER NOT NULL DEFAULT 0,deadline INTEGER NOT NULL DEFAULT 0,note TEXT)");}
            if(oldVersion<6){d.execSQL("ALTER TABLE transactions ADD COLUMN transfer_id TEXT");}
            if(oldVersion<7){
                // نسخه‌های قبلی مبالغ را به تومان نگه می‌داشتند؛ یک‌بار به ریال تبدیل می‌شوند.
                d.execSQL("UPDATE transactions SET amount=amount*10");
                d.execSQL("UPDATE accounts SET opening=opening*10");
                d.execSQL("UPDATE assets SET value=value*10");
                d.execSQL("UPDATE debts SET amount=amount*10, paid=paid*10");
                d.execSQL("UPDATE budgets SET limit_amount=limit_amount*10");
                d.execSQL("UPDATE recurring SET amount=amount*10");
                d.execSQL("UPDATE goals SET target=target*10, current_amount=current_amount*10");
            }
            if(oldVersion<8){d.execSQL("ALTER TABLE accounts ADD COLUMN bank_name TEXT");d.execSQL("ALTER TABLE accounts ADD COLUMN card_last4 TEXT");}
            if(oldVersion<9){d.execSQL("ALTER TABLE transactions ADD COLUMN payment_method TEXT DEFAULT 'متفرقه'");}
            if(oldVersion<10){
                d.execSQL("ALTER TABLE transactions ADD COLUMN month_key TEXT");
                d.execSQL("CREATE TABLE IF NOT EXISTS closed_months(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,month_key TEXT NOT NULL,closed_at INTEGER NOT NULL,UNIQUE(book,month_key))");
                Cursor cur=d.rawQuery("SELECT id,date FROM transactions WHERE month_key IS NULL",null);
                while(cur.moveToNext()){ContentValues mv=new ContentValues();mv.put("month_key",jalaliDate(cur.getLong(1)).substring(0,7));d.update("transactions",mv,"id=?",new String[]{String.valueOf(cur.getLong(0))});}cur.close();
            }
            if(oldVersion<11){
                d.execSQL("ALTER TABLE accounts ADD COLUMN account_uid TEXT");
                d.execSQL("ALTER TABLE accounts ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1");
                Cursor ac=d.rawQuery("SELECT id FROM accounts",null);
                java.util.ArrayList<Long> ids=new java.util.ArrayList<>();while(ac.moveToNext())ids.add(ac.getLong(0));ac.close();
                for(Long id:ids){ContentValues uv=new ContentValues();uv.put("account_uid",java.util.UUID.randomUUID().toString());d.update("accounts",uv,"id=?",new String[]{String.valueOf(id)});}
                d.execSQL("CREATE INDEX IF NOT EXISTS idx_accounts_uid ON accounts(account_uid)");
            }
            if(oldVersion<13){
                d.execSQL("CREATE TABLE IF NOT EXISTS cheques(id INTEGER PRIMARY KEY AUTOINCREMENT,book TEXT NOT NULL,direction TEXT NOT NULL,cheque_no TEXT,bank TEXT,party TEXT,amount INTEGER NOT NULL,due_date TEXT,account TEXT,status TEXT NOT NULL,note TEXT,image_path TEXT,financial_posted INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)");
                d.execSQL("CREATE INDEX IF NOT EXISTS idx_cheques_book_due ON cheques(book,due_date,status)");
            }
            if(oldVersion<13){
                // The table is created above for old databases; add a guard against posting a cheque twice.
                try { d.execSQL("ALTER TABLE cheques ADD COLUMN financial_posted INTEGER NOT NULL DEFAULT 0"); } catch(Exception ignored) {}
            }
        }
    }
}
