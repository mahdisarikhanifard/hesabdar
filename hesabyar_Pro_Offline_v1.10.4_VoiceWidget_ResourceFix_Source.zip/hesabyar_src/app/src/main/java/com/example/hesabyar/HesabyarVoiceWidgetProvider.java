package com.example.hesabyar;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** Compact home-screen entry point for Hesabyar's existing Persian offline voice assistant. */
public class HesabyarVoiceWidgetProvider extends AppWidgetProvider {
    private static final String PREFS = "hesabyar_voice_widget";
    private static final String KEY_STATUS = "status";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction())) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, HesabyarVoiceWidgetProvider.class));
            for (int id : ids) updateOne(context, manager, id);
        }
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_voice_assistant);
        String status = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_STATUS, "آماده دریافت دستور");
        views.setTextViewText(R.id.widget_voice_status, status);
        Intent launch = new Intent(context, MainActivity.class);
        launch.setAction(MainActivity.ACTION_WIDGET_VOICE);
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, 8103, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_voice_mic, pending);
        views.setOnClickPendingIntent(R.id.widget_voice_root, pending);
        manager.updateAppWidget(id, views);
    }

    public static void updateStatus(Context context, String status) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_STATUS, status).apply();
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, HesabyarVoiceWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }
}
