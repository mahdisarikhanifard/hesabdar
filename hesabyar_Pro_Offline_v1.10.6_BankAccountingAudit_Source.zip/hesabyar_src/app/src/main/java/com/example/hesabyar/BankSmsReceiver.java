package com.example.hesabyar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import java.util.Locale;
import java.util.UUID;

public class BankSmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        try {
            if (!android.preference.PreferenceManager.getDefaultSharedPreferences(context).getBoolean("bank_sms_enabled", false)) return;
            SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
            if (messages == null || messages.length == 0) return;
            StringBuilder body = new StringBuilder();
            String sender = "";
            long timestamp = 0;
            for (SmsMessage m : messages) {
                if (m == null) continue;
                if (sender.isEmpty() && m.getOriginatingAddress() != null) sender = m.getOriginatingAddress();
                if (body.length() > 0) body.append("\n");
                if (m.getMessageBody() != null) body.append(m.getMessageBody());
                timestamp = Math.max(timestamp, m.getTimestampMillis());
            }
            String text = body.toString().trim();
            if (!text.isEmpty() && isCandidate(sender, text))
                save(context, "پیامک", sender, text, timestamp > 0 ? timestamp : System.currentTimeMillis());
        } catch (Exception ignored) { }
    }
    private static boolean isCandidate(String sender, String body) {
        String x = norm((sender == null ? "" : sender) + " " + body);
        boolean action = has(x, "برداشت","واریز","خرید","پرداخت","انتقال","تراکنش","کسر","واریزشد","برداشتشد",
                "مانده","موجودی","کارتبهکارت","پایا","ساتنا","withdraw","deposit","purchase","transaction","transfer","debit","credit");
        boolean money = x.matches("(?s).*[0-9]{1,3}([,٬،.][0-9]{3})+.*")
                || x.matches("(?s).*[0-9]{4,}.*") || has(x,"ریال","تومان","تومن");
        boolean bank = has(x,"بانک","بلو","blubank","ملت","ملی","صادرات","تجارت","سامان","پاسارگاد","رفاه",
                "کشاورزی","بانکینو","bank","shaparak","شتاب","شمارهکارت");
        // Sender IDs are often numeric/short codes; action + money is enough to queue for review.
        return action && money && (bank || (sender != null && sender.trim().matches("[0-9+*# -]{3,}")));
    }
    private static String norm(String s) {
        if (s == null) return "";
        StringBuilder digits = new StringBuilder(s.length());
        for (int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if (c>='۰' && c<='۹') c=(char)('0'+(c-'۰'));
            else if (c>='٠' && c<='٩') c=(char)('0'+(c-'٠'));
            digits.append(c);
        }
        return digits.toString().toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک').replace('‌',' ')
                .replaceAll("[\\s\\p{Punct}]+","");
    }
    private static boolean has(String s, String... terms) { for (String t:terms) if(s.contains(norm(t))) return true; return false; }
    public static String save(Context c,String source,String sender,String raw,long time) {
        if(c==null||raw==null||raw.trim().isEmpty())return "";
        String safeSource=source==null?"بانک":source;
        long received=time>0?time:System.currentTimeMillis();
        android.content.SharedPreferences prefs=c.getSharedPreferences("bank_import_candidates",Context.MODE_PRIVATE);
        String normalized=dedupeText(raw);
        // SMS and the matching bank-app notification can describe the same event.
        // Keep one candidate when their content and arrival times are nearly identical.
        for(java.util.Map.Entry<String,?> entry:prefs.getAll().entrySet()){
            if(!entry.getKey().startsWith("candidate_")||!(entry.getValue() instanceof String))continue;
            String[] old=((String)entry.getValue()).split("\n",4);
            if(old.length<4)continue;
            long oldTime=0;try{oldTime=Long.parseLong(old[1]);}catch(Exception ignored){}
            if(oldTime>0&&Math.abs(received-oldTime)<=180000L){
                String previous=dedupeText(old[3]);
                boolean same=normalized.equals(previous)||(normalized.length()>=24&&previous.length()>=24&&(normalized.contains(previous)||previous.contains(normalized)));
                if(same)return entry.getKey();
            }
        }
        String value=safeSource+"\n"+received+"\n"+(sender==null?"":sender)+"\n"+raw.trim();
        String key="candidate_"+UUID.randomUUID();
        prefs.edit().putString(key,value).apply();
        if(!"MANUAL".equalsIgnoreCase(safeSource))postReviewNotification(c,key,safeSource,sender,raw.trim());
        return key;
    }
    private static String dedupeText(String s){
        if(s==null)return "";
        StringBuilder out=new StringBuilder(s.length());
        for(int i=0;i<s.length();i++){char ch=s.charAt(i);if(ch>='۰'&&ch<='۹')ch=(char)('0'+ch-'۰');else if(ch>='٠'&&ch<='٩')ch=(char)('0'+ch-'٠');out.append(ch);}
        return out.toString().toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک').replaceAll("[^a-z0-9\u0600-\u06ff]+","");
    }
    private static void postReviewNotification(Context context,String key,String source,String sender,String raw){
        try{
            if(android.os.Build.VERSION.SDK_INT>=33&&context.checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
            android.app.NotificationManager manager=(android.app.NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(manager==null)return;
            String channel="bank_transaction_review";
            if(android.os.Build.VERSION.SDK_INT>=26){
                android.app.NotificationChannel c=new android.app.NotificationChannel(channel,"درخواست ثبت تراکنش بانکی",android.app.NotificationManager.IMPORTANCE_HIGH);
                c.setDescription("اعلان فوری برای بررسی و تأیید تراکنش‌های بانکی");manager.createNotificationChannel(c);
            }
            android.content.Intent open=new android.content.Intent(context,MainActivity.class);
            open.setAction(MainActivity.ACTION_REVIEW_BANK_CANDIDATE);
            open.putExtra(MainActivity.EXTRA_BANK_CANDIDATE_KEY,key);
            open.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP|android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int request=key.hashCode();
            int flags=android.app.PendingIntent.FLAG_UPDATE_CURRENT;
            if(android.os.Build.VERSION.SDK_INT>=23)flags|=android.app.PendingIntent.FLAG_IMMUTABLE;
            android.app.PendingIntent pending=android.app.PendingIntent.getActivity(context,request,open,flags);
            String preview=raw.replace('\n',' ').replaceAll("\\s+"," ").trim();if(preview.length()>115)preview=preview.substring(0,112)+"…";
            android.app.Notification.Builder builder=android.os.Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,channel):new android.app.Notification.Builder(context);
            builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("تراکنش بانکی جدید • نیازمند بررسی")
                    .setContentText(preview).setStyle(new android.app.Notification.BigTextStyle().bigText("منبع: "+source+(sender==null||sender.isEmpty()?"":" • "+sender)+"\n\n"+raw))
                    .setContentIntent(pending).setAutoCancel(true).setCategory(android.app.Notification.CATEGORY_EVENT)
                    .setVisibility(android.app.Notification.VISIBILITY_PRIVATE);
            if(android.os.Build.VERSION.SDK_INT<26)builder.setPriority(android.app.Notification.PRIORITY_HIGH);
            manager.notify(request,builder.build());
        }catch(Exception ignored){}
    }

}
