package com.example.hisabyar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import java.util.Locale;
import java.util.UUID;

/** Captures likely bank SMS locally for user review; it never posts directly to accounting. */
public class BankSmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        try {
            if (!android.preference.PreferenceManager.getDefaultSharedPreferences(context)
                    .getBoolean("bank_sms_enabled", false)) return;
            for (SmsMessage message : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                if (message == null) continue;
                String body = message.getMessageBody();
                if (body == null || body.trim().isEmpty()) continue;
                String sender = message.getOriginatingAddress() == null ? "" : message.getOriginatingAddress();
                String searchable = (sender + " " + body).toLowerCase(Locale.ROOT);
                if (isLikelyBankMessage(searchable)) {
                    save(context, "پیامک", sender, body, message.getTimestampMillis());
                }
            }
        } catch (Exception ignored) {
            // Do not crash the SMS delivery pipeline; candidate remains local-only.
        }
    }

    private static boolean isLikelyBankMessage(String text) {
        String x = text == null ? "" : text.toLowerCase(Locale.ROOT);
        boolean action = x.contains("برداشت") || x.contains("واریز") || x.contains("خرید")
                || x.contains("پرداخت") || x.contains("انتقال") || x.contains("تراکنش")
                || x.contains("مانده") || x.contains("موجودی") || x.contains("withdrawal")
                || x.contains("deposit") || x.contains("transaction") || x.contains("balance");
        boolean amount = x.matches("(?s).*([0-9۰-۹٠-٩]{1,3}([,٬][0-9۰-۹٠-٩]{3})+|[0-9۰-۹٠-٩]{4,}).*");
        boolean bank = x.contains("بانک") || x.contains("صادرات") || x.contains("ملت")
                || x.contains("ملی") || x.contains("تجارت") || x.contains("بلو")
                || x.contains("blubank") || x.contains("بلوبانک") || x.contains("سامان") || x.contains("پاسارگاد")
                || x.contains("رفاه") || x.contains("کشاورزی") || x.contains("saderat")
                || x.contains("ریال") || x.contains("تومان") || x.contains("شماره کارت")
                || x.contains("شماره حساب") || x.contains("پایا") || x.contains("ساتنا");
        // Sender IDs are frequently short codes and the SMS body may not name the bank.
        // These are only queued for user confirmation; no SMS is ever posted directly to the ledger.
        return action && amount && (bank || x.matches("(?s).*\\b[0-9]{4,}\\b.*"));
    }

    /** Stores raw candidate locally. De-duplication and financial registration happen later. */
    public static void save(Context context, String source, String sender, String raw, long timestamp) {
        if (context == null || raw == null || raw.trim().isEmpty()) return;
        String value = (source == null ? "بانک" : source) + "\n"
                + timestamp + "\n" + (sender == null ? "" : sender) + "\n" + raw.trim();
        context.getSharedPreferences("bank_import_candidates", Context.MODE_PRIVATE)
                .edit().putString("candidate_" + UUID.randomUUID(), value).apply();
    }
}
