from pathlib import Path
p=Path('/mnt/data/hisabwork/app/src/main/java/com/example/hisabyar/MainActivity.java')
s=p.read_text()
# replace stageBankText method
start=s.index('    private boolean stageBankText(String source,String raw,long time){')
end=s.index('    private void drainBankCandidates()',start)
new=r'''    private boolean stageBankText(String source,String raw,long time){
        String n=normalizeDigits(raw==null?"":raw).replace('٬',',').replace('،',',');
        String lower=normalizeBankText(n);
        // Choose the transaction amount near the action/amount label; never simply take the largest number,
        // because bank messages commonly contain a larger post-transaction balance.
        long amount=0;
        java.util.regex.Pattern labelled=java.util.regex.Pattern.compile("(?i)(?:مبلغ(?:\s+تراکنش)?|برداشت|خرید(?:\s+اینترنتی)?|واریز|پرداخت|انتقال(?:\s+وجه)?)\\s*[:：]?\\s*(-?\\s*[0-9][0-9,٬،.]{2,})");
        java.util.regex.Matcher lm=labelled.matcher(n);
        while(lm.find()) { String digits=lm.group(1).replaceAll("[^0-9]",""); try { long v=Long.parseLong(digits); if(v>0){amount=v;break;} }catch(Exception ignored){} }
        if(amount<=0){
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?<!\\d)([0-9][0-9,]{2,})(?!\\d)").matcher(n);
            while(m.find()){
                int at=m.start();String before=n.substring(Math.max(0,at-35),at);
                if(before.matches("(?s).*(?:مانده|موجودی|balance|available)\\s*[:：]?\\s*$"))continue;
                try{long v=Long.parseLong(m.group(1).replace(",",""));if(v>0){amount=v;break;}}catch(Exception ignored){}
            }
        }
        String kind="نامشخص";
        if(containsAny(lower,"برداشت","خرید","پرداخت","کسر","انتقال به"))kind="هزینه";
        else if(containsAny(lower,"واریز","دریافت","حقوق","انتقال از"))kind="درآمد";
        String bank="نامشخص";for(String b:new String[]{"صادرات","بلو","ملت","ملی","تجارت","سامان","پاسارگاد","رسالت","رفاه","سپه","شهر"})if(lower.contains(normalizeBankText(b))){bank=b;break;}
        String card="";java.util.regex.Matcher cm=java.util.regex.Pattern.compile("(?i)(?:حساب|کارت|شماره حساب|حساب:)[^0-9]{0,12}([0-9]{4,})").matcher(n);if(cm.find()){String z=cm.group(1);card=z.length()>4?z.substring(z.length()-4):z;}
        String date="";java.util.regex.Matcher dm=java.util.regex.Pattern.compile("(?<![0-9])((?:13|14|19|20)[0-9]{2}[/-][0-9]{1,2}[/-][0-9]{1,2}|[0-9]{4})(?![0-9])").matcher(n);
        if(dm.find()){String d=dm.group(1);if(d.matches("[0-9]{4}")&&d.length()==4){String mm=d.substring(0,2),dd=d.substring(2);date="۱۴۰۵/"+mm+"/"+dd;}else date=normalizeStatementDate(d);}
        String clock="";java.util.regex.Matcher tm=java.util.regex.Pattern.compile("(?<![0-9])([0-2]?[0-9]):([0-5][0-9])(?![0-9])").matcher(n);if(tm.find())clock=String.format(java.util.Locale.ROOT,"%02d:%02d",Integer.parseInt(tm.group(1)),Integer.parseInt(tm.group(2)));
        String enriched=raw;
        if(!date.isEmpty()&&!raw.contains("تاریخ استخراج‌شده:"))enriched+="\nتاریخ استخراج‌شده: "+date;
        if(!clock.isEmpty()&&!raw.contains("ساعت استخراج‌شده:"))enriched+="\nساعت استخراج‌شده: "+clock;
        if(!card.isEmpty()&&!raw.contains("شناسه حساب استخراج‌شده:"))enriched+="\nشناسه حساب استخراج‌شده: "+card;
        String key;try{key=java.util.Base64.getEncoder().encodeToString(java.security.MessageDigest.getInstance("SHA-256").digest((n.replaceAll("\\s+"," ").trim()).getBytes(java.nio.charset.StandardCharsets.UTF_8)));}catch(Exception e){key=String.valueOf(n.hashCode());}
        ContentValues v=new ContentValues();v.put("source",source);v.put("source_key",key);v.put("raw_text",enriched);if(amount>0)v.put("amount",amount);v.put("kind",kind);v.put("bank",bank);if(!card.isEmpty())v.put("card_last4",card);v.put("received_at",time);v.put("status","pending");
        try{return db.getWritableDatabase().insertOrThrow("bank_inbox",null,v)>0;}catch(Exception e){return false;}
    }
'''
s=s[:start]+new+s[end:]
# Add edit button to each account card
old='Button manage=button("مدیریت این حساب در دفترها");manage.setOnClickListener(v->manageSpecificAccount(name));card.addView(manage);body.addView(card,new LinearLayout.LayoutParams(-1,-2));'
new2='Button edit=button("ویرایش حساب");edit.setOnClickListener(v->editAccountDialog(name));card.addView(edit);Button manage=button("مدیریت این حساب در دفترها");manage.setOnClickListener(v->manageSpecificAccount(name));card.addView(manage);body.addView(card,new LinearLayout.LayoutParams(-1,-2));'
assert old in s
s=s.replace(old,new2,1)
# insert edit account dialog before addAccountDialog
idx=s.index('    private void addAccountDialog() {')
method=r'''    private void editAccountDialog(String oldName) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,kind,opening,bank_name,card_last4,account_uid FROM accounts WHERE book=? AND name=? LIMIT 1",new String[]{activeBook,oldName});
        if(!c.moveToFirst()){c.close();toast("حساب پیدا نشد");return;}
        long id=c.getLong(0),openingValue=c.getLong(3);String nameValue=c.getString(1),kindValue=c.getString(2),bankValue=c.getString(4),cardValue=c.getString(5),uid=c.getString(6);c.close();
        LinearLayout f=formLayout();EditText name=edit("نام نمایشی حساب",InputType.TYPE_CLASS_TEXT),kind=edit("نوع حساب",InputType.TYPE_CLASS_TEXT),opening=edit("موجودی اولیه به ریال",InputType.TYPE_CLASS_NUMBER),last4=edit("چهار رقم آخر کارت/شناسه حساب",InputType.TYPE_CLASS_NUMBER);Spinner bank=styledSpinner();java.util.ArrayList<String> banks=new java.util.ArrayList<>();banks.add("بدون بانک");for(String b:bankNames())banks.add(b);bank.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,banks));
        name.setText(nameValue);kind.setText(kindValue==null?"":kindValue);opening.setText(String.valueOf(openingValue));last4.setText(cardValue==null?"":cardValue);int pos=0;for(int i=0;i<banks.size();i++)if(banks.get(i).equals(bankValue)){pos=i;break;}bank.setSelection(pos);f.addView(name);f.addView(kind);f.addView(bank);f.addView(last4);f.addView(opening);
        new AlertDialog.Builder(this).setTitle("ویرایش حساب").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
            String nn=name.getText().toString().trim(),kk=kind.getText().toString().trim(),bb=String.valueOf(bank.getSelectedItem());if(bb.equals("بدون بانک"))bb="";String cc=normalizeDigits(last4.getText().toString()).replaceAll("\\D","");long oo=parseAmount(opening.getText().toString());
            if(nn.isEmpty()||oo<0||(!cc.isEmpty()&&!cc.matches("\\d{4}"))){toast("نام، موجودی اولیه یا چهار رقم آخر معتبر نیست");return;}
            Cursor du=db.getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE book=? AND name=? AND id<>?",new String[]{activeBook,nn,String.valueOf(id)});boolean duplicate=du.moveToFirst();du.close();if(duplicate){toast("حساب دیگری با این نام وجود دارد");return;}
            SQLiteDatabase sql=db.getWritableDatabase();sql.beginTransaction();try{ContentValues v=new ContentValues();v.put("name",nn);v.put("kind",kk.isEmpty()?(bb.isEmpty()?"نقدی":"بانکی"):kk);v.put("opening",oo);v.put("bank_name",bb.isEmpty()?null:bb);v.put("card_last4",cc.isEmpty()?null:cc);sql.update("accounts",v,"id=? AND book=?",new String[]{String.valueOf(id),activeBook});
                if(!oldName.equals(nn)){ContentValues ref=new ContentValues();ref.put("account",nn);sql.update("transactions",ref,"book=? AND account=?",new String[]{activeBook,oldName});sql.update("recurring",ref,"book=? AND account=?",new String[]{activeBook,oldName});sql.update("cheques",ref,"book=? AND account=?",new String[]{activeBook,oldName});}
                sql.setTransactionSuccessful();}catch(Exception ex){toast("ویرایش انجام نشد: "+ex.getMessage());}finally{sql.endTransaction();}toast("اطلاعات حساب و پیوندهای آن به‌روزرسانی شد");showAccounts();
        }).show();
    }

'''
s=s[:idx]+method+s[idx:]
# bump version
p.write_text(s)
g=Path('/mnt/data/hisabwork/app/build.gradle'); gs=g.read_text().replace("versionCode 186","versionCode 187").replace("versionName '1.8.6-Pro'","versionName '1.8.7-Pro'");g.write_text(gs)
# workflow adjust version and expected zip name and tests add edit + date checks; old snapshot phrase test likely corrected yml used, source test needs adapt
wf=Path('/mnt/data/hisabwork/.github/workflows/build-apk.yml'); w=wf.read_text()
w=w.replace('v1.8.6','v1.8.7').replace('versionCode&#91;&#91;:space:&#93;&#93;+186','versionCode&#91;&#91;:space:&#93;&#93;+187').replace("versionName '1.8.6-Pro'","versionName '1.8.7-Pro'")
w=w.replace("grep -qF 'Could not create snapshot before listing backups' app/src/main/java/com/example/hisabyar/MainActivity.java", "grep -qF 'Snapshot before listing failed' app/src/main/java/com/example/hisabyar/MainActivity.java")
w=w.replace("echo \"Version 1.8.6-Pro (186) verified.\"", "grep -qF 'private void editAccountDialog(String oldName)' app/src/main/java/com/example/hisabyar/MainActivity.java\n  grep -qF 'تاریخ استخراج‌شده:' app/src/main/java/com/example/hisabyar/MainActivity.java\n  echo \"Version 1.8.7-Pro (187) verified.\"")
wf.write_text(w)
